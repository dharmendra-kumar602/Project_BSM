import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:intl/intl.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';

class FirebaseChatService{

  static final FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;
  static final FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  /// Get chat users list
  static Stream<QuerySnapshot> getUsers () {
    Stream<QuerySnapshot> data;
    data = firebaseFirestore.
    collection(FirestoreConstants.pathUserCollection)
        .where(FirestoreConstants.id, isEqualTo: TMTLocalStorage.getUserId().toString())
        .orderBy(FirestoreConstants.sentAt, descending: true)
        .snapshots();
    return data;
  }

  /// remove chat user by reference
  static Future<void> removeUser(QueryDocumentSnapshot<Object?>? doc, Function(String message) onClick) async {
    await firebaseFirestore.runTransaction((Transaction myTransaction) async {
      myTransaction.delete(doc!.reference);
    }).onError((error, stackTrace){
      onClick(error.toString());
    });
  }

  /// get formatted date time
  static String parseDate(String sentAt) {

    var now = DateTime.now();
    bool b = DateTime.fromMillisecondsSinceEpoch(int.parse(sentAt)).isBefore(DateTime(now.year, now.month, now.day, (now.hour - 12)));

    try {
      if (b) {
        return DateFormat('hh:mm a / dd-MM-yyyy')
            .format(DateTime.fromMillisecondsSinceEpoch(int.parse(sentAt)));
      } else {
        return DateFormat('hh:mm a')
            .format(DateTime.fromMillisecondsSinceEpoch(int.parse(sentAt)));
      }
    } catch (e) {
      return DateFormat('hh:mm a').format(DateTime.fromMillisecondsSinceEpoch(DateTime.now().millisecondsSinceEpoch));
    }
  }

  /// Get last message type
  static String getLastMessage(String lastMessage) {
    if (lastMessage.contains("mimi")) {
      return lastMessage = "Gif";
    } else if (lastMessage.contains("https://firebasestorage")) {
      return lastMessage = "Image";
    }else{
      return lastMessage;
    }
  }

  /// Delete all chat
  static void deleteChatById(String groupChatId, Function pop) async {
    firebaseFirestore
        .collection(FirestoreConstants.pathMessageCollection)
        .doc(groupChatId)
        .collection(groupChatId)
        .where(FirestoreConstants.timestamp,
        isLessThan: DateTime.now().millisecondsSinceEpoch.toString())
        .snapshots()
        .forEach((snapshot) {
      for (DocumentSnapshot ds in snapshot.docs) {
        ds.reference.delete();
      }
    });

    await FirebaseStorage.instance.ref(groupChatId).listAll().then((value) {
      for (var element in value.items) {
        FirebaseStorage.instance
            .ref(element.fullPath)
            .delete()
            .whenComplete(() {})
            .catchError((v) {
          print("Storage haven't deleted yet");
        });
      }
    });

    pop.call();
  }

  ///Upload file to flutter storage
  static UploadTask uploadChatFile(File image, String fileName, String groupChatId) {
    Reference reference =
    FirebaseStorage.instance.ref(groupChatId).child(fileName);
    UploadTask uploadTask = reference.putFile(image);
    return uploadTask;
  }

  ///For updating current collection
  static Future<void> updateDataFirestore(Map<String, dynamic> dataNeedUpdate, String id) {
    return firebaseFirestore
        .collection(FirestoreConstants.pathUserCollection)
        .doc(id)
        .update(dataNeedUpdate)
        .onError((error, stackTrace) {});
  }

  ///Get messages from Flutter Firestore
  static Stream<QuerySnapshot> getChatStream(String groupChatId, int limit) {
    return firebaseFirestore
        .collection(FirestoreConstants.pathMessageCollection)
        .doc(groupChatId)
        .collection(groupChatId)
        .orderBy(FirestoreConstants.timestamp, descending: true)
        .limit(limit)
        .snapshots();
  }
}