import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:take_my_tack/core/error/exceptions.dart';
import 'package:take_my_tack/data/datasource/remote/services/BaseClient.dart';
import 'package:take_my_tack/data/datasource/remote/services/BaseService.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';

class RestClient implements BaseService {

  var dioInstance = BaseNetworkClient();

  // Get:-----------------------------------------------------------------------
  @override
  Future get({required String url, Map<String, dynamic>? params}) async {
    try {
      final response = await dioInstance
          .getNetworkClient
          .get(url, queryParameters: params);
      return response.data;
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
      throw ServerException(TMTConstant.someThingWentWrong);
    }
  }

  // Post:----------------------------------------------------------------------
  @override
  Future post(
      {required String url, required Map<String, dynamic> request}) async {
    try {
      final response = await dioInstance.getNetworkClient.post(
            url,
            data: request,
          );
      return response.data;
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
      throw ServerException(TMTConstant.someThingWentWrong);
    }
  }

// Put:-----------------------------------------------------------------------
  @override
  Future put(
      {required String url, required Map<String, dynamic> request}) async {
    //request.addAll(DioUtils.getRequestHeader());
    try {
      final response = await dioInstance
          .getNetworkClient
          .put(url, data: request);
      return response.data;
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
      throw ServerException(TMTConstant.someThingWentWrong);
    }
  }

  // Delete:-----------------------------------------------------------------------
  @override
  Future delete(
      {required String url, Map<String, dynamic>? request}) async {
    try {
      final response = await dioInstance
          .getNetworkClient
          .delete(url, data: request);
      return response.data;
    } catch(e){
      if (kDebugMode) {
        print(e);
      }
    }
    throw ServerException(TMTConstant.someThingWentWrong);
  }

  // Post form data:-----------------------------------------------------------------------
  @override
  Future postFormData(
      {required String url, required Map<String, dynamic> request}) async {
    try {
      FormData formData = FormData.fromMap(request);
      final response = await dioInstance.getNetworkClient.post(
        url,
        data: formData,
      );
      return response.data;
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
      throw ServerException(TMTConstant.someThingWentWrong);
    }
  }

  // Put form data:-----------------------------------------------------------------------
  @override
  Future putFormData(
      {required String url, required Map<String, dynamic> request}) async {
    try {
      FormData formData = FormData.fromMap(request);
      final response = await dioInstance.getNetworkClient.put(
        url,
        data: formData,
      );
      return response.data;
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
      throw ServerException(TMTConstant.someThingWentWrong);
    }
  }
}