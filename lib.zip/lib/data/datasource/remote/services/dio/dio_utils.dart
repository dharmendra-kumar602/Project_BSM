import 'dart:io';
import 'dart:math';

import 'package:dio/dio.dart';
import 'package:take_my_tack/core/model/request_header.dart';
import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/model/request/post_add_new_product_request.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';

class DioUtils {

  /*
- Method use to make request header.
- Parameter- No Parameter.
- Return -> @Map<String, dynamic> - return request header for api request.
*/
  static Map<String, dynamic> getRequestHeader() {
    var requestId = {"requestId": randomString(36)};
    var requestHeader = {"requestHeader": requestId};
    return requestHeader;
  }

  /*
- Method use to make error response header.
- Parameter- No Parameter.
- Return -> @Map<String, dynamic> - return error response header for api request.
*/
  static Map<String, dynamic> getErrorResponseHeader() {
    return ResponseHeader(requestId: "requestId", responseId: "responseId", message: TMTConstant.someThingWentWrong, error: Error(messages: [], statusCode: 0), status: 'ERROR').toJson();
  }

  /*
- Method use to make request header.
- Parameter- No Parameter.
- Return -> @Map<String, dynamic> - return request header for api request.
*/
  static RequestHeader getRequestHeaderModel() {
    var requestId = {"requestId": randomString(36)};
    return RequestHeader.fromJson(requestId);
  }

  /*
- Method use to make random string for api_manager request id.
- Parameter- @length- Length of string
- Return -> @string - return string.
*/
  static String randomString(int length) {
    var rand = Random();
    const _chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
    return List.generate(length, (index) => _chars[rand.nextInt(_chars.length)]).join();
  }

  /// Method use to return file request through multipart
  static Future<Map<String, dynamic>> createFileRequestByMultipart(int index, File? file) async {
    if (file != null) {
      String filePath = file.path;
      String fileName = filePath.split('/').last;
      return {
        "document[$index][file]": await MultipartFile.fromFile(filePath, filename: fileName)
      };
    } else {
      return {};
    }
  }

  /// Method use to return file request through multipart
  static Future<Map<String, dynamic>> createProfileRequestByMultipart(File? file) async {
    if (file != null) {
      String filePath = file.path;
      String fileName = filePath.split('/').last;
      return {
        "profilePicture": await MultipartFile.fromFile(filePath, filename: fileName)
      };
    } else {
      return {};
    }
  }

  /// Method use to return attribute request through multipart
  static Future<Map<String, dynamic>> createAttributesRequestByMultipart(ProductAttributes attributes, int index) async {
    return {
      "varients[0][attributes][$index][id]": attributes.id,
      "varients[0][attributes][$index][name]": attributes.name,
      "varients[0][attributes][$index][value]": attributes.value,
    };
  }

  /// Method use to return file request through multipart
  static Future<Map<String, dynamic>> createProductImagesRequestByMultipart(File? file, int i) async {
    if (file != null) {
      String filePath = file.path;
      String fileName = filePath.split('/').last;
      return {
        "varients[0][productImages][$i][imageUrls]": await MultipartFile.fromFile(filePath, filename: fileName)
      };
    } else {
      return {};
    }
  }

  /// Method use to return file request through multipart
  static Future<Map<String, dynamic>> updateProductImagesRequestByMultipart(File? file, int i) async {
    if (file != null) {
      String filePath = file.path;
      String fileName = filePath.split('/').last;
      return {
        "[productImages][$i][imageUrls]": await MultipartFile.fromFile(filePath, filename: fileName)
      };
    } else {
      return {};
    }
  }
}
