import 'package:dio/dio.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/logging.dart';

//get the dio singleton object for whole app
class WebUtil {
  static Dio createDio() {
    var dio = Dio();
    dio.options.connectTimeout = const Duration(milliseconds: 180000); /// in milliseconds
    dio.options.receiveTimeout = const Duration(milliseconds: 180000); /// in milliseconds
    dio.interceptors.add(Logging());
    dio.options.followRedirects = false;
    dio.options.responseType = ResponseType.plain;
    return dio;
  }
}