import 'package:take_my_tack/data/datasource/remote/services/dio/dio.dart';

class BaseNetworkClient {
  get getNetworkClient => WebUtil.createDio();
}
