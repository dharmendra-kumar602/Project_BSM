import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:take_my_tack/core/model/cart_models.dart';
import 'package:take_my_tack/core/model/notification_model.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/model/response/get_cart_response.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';

class TMTLocalStorage {

  static final box = GetStorage();

  /// for writing dynamic value
  static void save(String key, dynamic v) {
    box.write(key, v);
  }

  /// for reading string value
  static String getString(String key) {
    return box.read(key) ?? "";
  }

  /// for reading string value
  static bool? getBool(String key) {
    return box.read(key);
  }

  /// to clear value from storage
  static void clearValueByKey(String key) {
    box.remove(key);
  }

  /// to save login status
  static void isUserLoggedIn(bool v) {
    save(GetXStorageConstants.login, v);
  }

  /// to fcm token
  static void saveFcm(String token) {
    save(GetXStorageConstants.fcm, token);
  }

  /// get fcm token
  static String getFcm() {
    return box.read(GetXStorageConstants.fcm) ?? "";
  }

  /// to save login status
  static bool getUserLoggedIn() {
    return getBool(GetXStorageConstants.login) ?? false;
  }

  /// to save rememberMe status
  static void setRememberMe(bool v) {
    save(GetXStorageConstants.rememberMe, v);
  }

  /// to save rememberMe status
  static bool getRememberMe() {
    return box.read(GetXStorageConstants.rememberMe) ?? false;
  }

  /// for saving file
  static void saveFile(String key, dynamic v) {
    box.write(key, v);
  }

  /// for getting file
  static dynamic getFile(String key) {
    return box.read(key);
  }

  /// for clearing all data
  static void clear() {
    var fcm = getFcm();
    box.erase();
    save(GetXStorageConstants.showIntroPage, false);
    saveFcm(fcm);
  }

  /// add wishlist product in DB
  static void addToWishlist (WishlistModel product) {
    if (product.productId == product.variationId) {
      return;
    }
    if (product.productId == 0 && product.variationId == 0) {
      return;
    }
    List<WishlistModel> itemList = [];
    try {
      itemList = _getWishlist();
    } catch (e) {
    }
    if (itemList.isEmpty) {
      itemList = [product];
    } else {
      var hasDuplicate = itemList.where((element) => element.productId == product.productId).toList();
      if (hasDuplicate.isEmpty) {
        itemList.add(product);
      }
    }
    box.write(GetXStorageConstants.wishlist, itemList);
  }

  /// remove wishlist product from DB
  static void removeFromWishlist (WishlistModel product) {
    List<WishlistModel> itemList = [];
    try {
      itemList = _getWishlist();
    } catch (e) {
    }
    if (itemList.isNotEmpty) {
      itemList.removeWhere((element) => element.productId == product.productId);
    }
    box.write(GetXStorageConstants.wishlist, itemList);
  }

  /// get wishlist items
  static List<WishlistModel> getWishlistItems() {
    return _getWishlist();
  }

  /// get wishlist items
  static List<WishlistModel> _getWishlist() {
    List<WishlistModel> list = [];
    try {
      var v = box.read(GetXStorageConstants.wishlist);
      if (v == null)
        {
          return [];
        }

      v.forEach((e) {
        if (e == null) {
          return;
        }
        if (e is WishlistModel) {
          list.add(e);
        } else if (e is Map<String, dynamic>) {
          list.add(WishlistModel(productId: e["productId"], variationId: e["variationId"], variation: Variation.fromJson(e["variation"])));
        }
        });
    } catch (e) {
      e.printInfo();
    }

    if (list.isEmpty) {
      return [];
    }
    return list;
  }

  /// add cart product in DB
  static void addToCart (CartModel product) {
    List<CartModel> itemList = [];
    try {
      itemList = _getCart();
    } catch (e) {
    }
    if (itemList.isEmpty) {
      itemList = [product];
    } else {
      var hasDuplicate = itemList.where((element) => element.productId == product.productId).toList();
      if (hasDuplicate.isEmpty) {
        itemList.add(product);
      } else {
        for (int i=0; i<itemList.length; i++) {
          if (itemList[i].productId == product.productId) {
            int qt = itemList[i].quantity;
            qt++;
            itemList[i] = product;
            itemList[i].quantity = qt;
          }
        }
      }
    }
    box.write(GetXStorageConstants.cart, itemList);
  }

  static void clearCart () {
    box.remove(GetXStorageConstants.cart);
  }

  static void clearWishlist () {
    box.remove(GetXStorageConstants.wishlist);
  }

  /// add cart product in DB
  static void updateCart (CartModel product) {
    List<CartModel> itemList = [];
    try {
      itemList = _getCart();
    } catch (e) {
    }
    if (itemList.isEmpty) {
      itemList = [product];
    } else {
      for (int i=0; i<itemList.length; i++) {
        if (itemList[i].productId == product.productId) {
          itemList[i] = product;
        }
      }
    }
    box.write(GetXStorageConstants.cart, itemList);
  }

  /// remove wishlist product from DB
  static void removeFromCart (CartModel product) {
    List<CartModel> itemList = [];
    try {
      itemList = _getCart();
    } catch (e) {
    }
    if (itemList.isNotEmpty) {
      itemList.removeWhere((element) => element.productId == product.productId);
    }
    box.write(GetXStorageConstants.cart, itemList);
  }

  /// get cart items
  static List<CartModel> getCartItems() {
    var v = _getCart();
    return v;
  }

  /// get cart items
  static List<CartModel> _getCart() {
    List<CartModel> list = [];
    try {
      var v = box.read(GetXStorageConstants.cart);
      if (v == null)
      {
        return [];
      }

      v.forEach((e) {
        if (e == null) {
          return;
        }
        if (e is CartModel) {
          list.add(e);
        } else if (e is Map<String, dynamic>) {
          list.add(CartModel(productId: e["productId"], productVariationId: e["productVariationId"], quantity: e["quantity"]));
        }
      });
    } catch (e) {
      e.printInfo();
    }

    if (list.isEmpty) {
      return [];
    }
    return list;
  }

  /// add recent viewed product in DB
  static void addToRecentlyViewed (WishlistModel product) {
    List<WishlistModel> itemList = [];
    try {
      itemList = _getRecentlyViewed();
    } catch (e) {
    }
    if (itemList.isEmpty) {
      itemList = [product];
    } else {
      var hasDuplicate = itemList.where((element) => element.productId == product.productId).toList();
      if (hasDuplicate.isEmpty) {
        itemList.add(product);
      }
    }
    box.write(GetXStorageConstants.recentlyViewed, itemList);
  }

  /// remove recent viewed product from DB
  static void removeFromRecentlyViewed (WishlistModel product) {
    List<WishlistModel> itemList = [];
    try {
      itemList = _getRecentlyViewed();
    } catch (e) {
    }
    if (itemList.isNotEmpty) {
      itemList.removeWhere((element) => element.productId == product.productId);
    }
    box.write(GetXStorageConstants.recentlyViewed, itemList);
  }

  /// get recent viewed items
  static List<WishlistModel> getRecentlyViewedItems() {
    return _getRecentlyViewed();
  }

  /// get recent viewed items
  static List<WishlistModel> _getRecentlyViewed() {
    List<WishlistModel> list = [];
    try {
      list = box.read(GetXStorageConstants.recentlyViewed);
    } catch (e) {}

    if (list.isEmpty) {
      return [];
    }
    return list;
  }

  static String getUserId() {
    return box.read(GetXStorageConstants.userId) ?? "";
  }

  static saveUserId(String userId) {
    return box.write(GetXStorageConstants.userId, userId);
  }

  static String getSellerStatus() {
    return box.read(GetXStorageConstants.getSellerStatus) ?? "";
  }

  static saveSellerStatus(String status) {
    return box.write(GetXStorageConstants.getSellerStatus, status);
  }

  static int getSellerId() {
    return box.read(GetXStorageConstants.getSellerId) ?? 0;
  }

  static saveSellerId(int userId) {
    return box.write(GetXStorageConstants.getSellerId, userId);
  }

  /// add to notification list
  static void addToNotification (Notifications notifications) {
    List<Notifications> itemList = [];
    try {
      itemList = getNotifications();
    } catch (e) {
    }
    if (itemList.isEmpty) {
      itemList = [notifications];
    } else {
      var hasDuplicate = itemList.where((element) => element.id == notifications.id).toList();
      if (hasDuplicate.isEmpty) {
        itemList.add(notifications);
      }
    }
    box.write(GetXStorageConstants.notifications, itemList);
  }

  /// get notifications items
  static List<Notifications> getNotifications() {
    List<Notifications> list = [];
    try {
      var v = box.read(GetXStorageConstants.notifications);
      if (v == null)
      {
        return [];
      }

      v.forEach((e) {
        if (e == null) {
          return;
        }
        if (e is Notifications) {
          list.add(e);
        }
      });
    } catch (e) {
      e.printInfo();
    }

    if (list.isEmpty) {
      return [];
    }
    return list;
  }
}
