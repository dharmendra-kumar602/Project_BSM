import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:take_my_tack/data/service/stripe/payment.intent_service_entity.dart';

class StripePaymentUtil {
  presentApplePay() {
    Stripe.instance.presentPaymentSheet();
  }

  Future<void> initializeStripe({required PaymentIntentData intentData}) async {
    Stripe.publishableKey = intentData.publishableKey ?? '';
    Stripe.merchantIdentifier = 'merchant.com.tmt';
    Stripe.urlScheme = 'tmtStripe';
    await Stripe.instance.applySettings();
  }

  Future<void> initPaymentSheet(BuildContext context,
      {required PaymentIntentData? intentData,
      required MGPaymentIntentRequest request,
      required void Function(bool isSuccess) callBack}) async {
    try {
      await initializeStripe(intentData: intentData!);
      // create some billing details.
      final billingDetails = BillingDetails(
        name: request.firstname,
        email: request.email,
      ); // mocked data for tests
      // 2. initialize the payment sheet
      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          // Main params
          paymentIntentClientSecret: intentData.paymentIntent,
          merchantDisplayName: 'Take My Tack',
          // Customer params
          customerId: intentData.customer,
          // Extra params
          primaryButtonLabel: 'Pay now',
          googlePay: PaymentSheetGooglePay(
            merchantCountryCode: 'UK',
            currencyCode: 'EURO',
            testEnv: true,
          ),
          style: ThemeMode.dark,
          billingDetails: billingDetails,
        ),
      );
      callBack.call(true);
    } catch (e) {
      print("Stripe.instance.initPaymentSheet(" + e.toString());
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Payment failed!')),
      );
      callBack.call(false);
    }
  }

  Future<void> confirmPayment(BuildContext context,
      {required void Function(bool isSuccess) callBack}) async {
    try {
      await Stripe.instance.presentPaymentSheet();
      Navigator.pop(context);
      callBack.call(true);
    } on Exception catch (e) {
      debugPrint('Error from Stripe: ${e}');
      if (e is StripeException) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Exit from payment.'),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Exit from payment.'),
          ),
        );
      }
      callBack.call(false);
    }
  }
}
