PaymentIntentServiceEntity paymentIntentServiceEntityFromJson(
        Map<String, dynamic> json) =>
    PaymentIntentServiceEntity.fromJson(json);

class PaymentIntentServiceEntity {
  final bool? success;
  final ResponseObject? response;
  final PaymentIndentError? error;

  PaymentIntentServiceEntity({
    this.success,
    this.response,
    this.error,
  });

  factory PaymentIntentServiceEntity.fromJson(Map<String, dynamic> json) =>
      PaymentIntentServiceEntity(
        success: json["success"],
        response: json["response"] == null
            ? null
            : ResponseObject.fromJson(json["response"]),
        error: json["error"] == null
            ? null
            : PaymentIndentError.fromJson(json["error"]),
      );
}

class ResponseObject {
  final PaymentIntentData? data;

  ResponseObject({
    this.data,
  });

  factory ResponseObject.fromJson(Map<String, dynamic> json) => ResponseObject(
        data: json["data"] == null
            ? null
            : PaymentIntentData.fromJson(json["data"]),
      );
}

class PaymentIntentData {
  final String? paymentIntent;
  final String? publishableKey;
  final String? customer;
  final String? amount;

  PaymentIntentData({
    this.paymentIntent,
    this.publishableKey,
    this.customer,
    this.amount,
  });

  factory PaymentIntentData.fromJson(Map<String, dynamic> json) =>
      PaymentIntentData(
        paymentIntent: json["paymentIntent"],
        publishableKey: json["publishableKey"],
        customer: json["customer"],
        amount: json["amount"],
      );
}

class PaymentIndentError {
  final dynamic code;
  final String? message;

  PaymentIndentError({
    this.code,
    this.message,
  });

  factory PaymentIndentError.fromJson(Map<String, dynamic> json) =>
      PaymentIndentError(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}

class MGPaymentIntentRequest {
  String? firstname;
  String? email;
  int? userId;
  String? amount;

  MGPaymentIntentRequest(
      {this.firstname, this.userId, this.email, this.amount});

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'email': email,
      'amount': amount,
    };
  }
}