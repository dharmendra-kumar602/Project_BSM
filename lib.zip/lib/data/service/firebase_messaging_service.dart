import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/model/notification_model.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

Future<void> onBackgroundMessage(RemoteMessage message) async {

  await Firebase.initializeApp();
  // Handle data message
  if (message.data.isNotEmpty) {
    // Handle data message
    _insertNotification(message);
  }
}

class FirebaseMessagingService {

  registerNotifications(BuildContext context) async {
    await Firebase.initializeApp();
    FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(alert: true, badge: true, sound: true);
    var firebaseMessaging = FirebaseMessaging.instance;
    // With this token you can test it easily on your phone
    await firebaseMessaging.getToken().then((token) => {
      print('Token line: $token'),
      TMTLocalStorage.saveFcm(token ?? "")
    });
    FirebaseMessaging.onBackgroundMessage(onBackgroundMessage);
    //  On iOS, this helps to take the user permissions
    NotificationSettings settings = await firebaseMessaging.requestPermission(
      alert: true,
      badge: true,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      FirebaseMessaging.onMessage.listen(
            (message) async {
          if (message.data.isNotEmpty) {
            _insertNotification(message, context: context);
          }
        },
      );
    } else {
      if (!context.mounted) return;
      showPermissionAlertDialog(context);
    }
    // For handling notification when the app is in background
    // but not terminated
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage? message) {
      if (message != null) {
        //handle message
        if (message.data.isNotEmpty) {
          _insertNotification(message, context: context);
        }
      }
    });
  }

  /// For handling notification when the app is in terminated state
  checkForInitialMessage(BuildContext context) async {
    await Firebase.initializeApp();
    RemoteMessage? initialMessage =
    await FirebaseMessaging.instance.getInitialMessage();

    if (initialMessage != null) {
      // handle initial message
      if (initialMessage.data.isNotEmpty) {
        if (!context.mounted) return;
        _insertNotification(initialMessage, context: context);
      }
    }
  }

  /// permission not granted dialog
  showPermissionAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: const TMTTextWidget(title: "OK"),
      onPressed: () {},
    );
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("Notification Permission"),
      content: const Text("User permission are not granted"),
      actions: [
        okButton,
      ],
    );

    /// show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}

/// insert notification in database
_insertNotification(dynamic message, {BuildContext? context}) {
  try {
    Notifications notifications = Notifications(
      id: int.parse(message?.data["id"] ?? "-1"),
      fromUserId: int.parse(message?.data["fromUserId"] ?? "-1"),
      toUserId: int.parse(message?.data["toUserId"] ?? "-1"),
      text: message?.data["text"] ?? "",
      notificationType: message?.data["notificationType"] ?? "",
      title: message?.data["title"] ?? "",
      createdAt: message?.data["createdAt"] ?? "",
      updatedAt: message?.data["updatedAt"] ?? "",
      price: message?.data["price"] ?? "",
      subText: message?.data["subText"] ?? "",
    );
    TMTLocalStorage.addToNotification(notifications);
  } catch (e) {
    print("Error while saving notification in DB : ${e.toString()}");
  }
  showNotification(message, context: context);
}

void showNotification(dynamic message, {BuildContext? context}) {
  AndroidNotificationChannel channel = const AndroidNotificationChannel(
    'uk.co.takemytack', // id
    'Take My Tack', // title
    importance: Importance.high,
  );
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();

  var initializationSettingsAndroid =
  const AndroidInitializationSettings("@mipmap/ic_launcher");

  var initializationSettings =
  InitializationSettings(android: initializationSettingsAndroid);
  flutterLocalNotificationsPlugin.initialize(
    initializationSettings,
    onDidReceiveNotificationResponse: (value) async {
      if (context != null) {
        _clickOnNotifications(message, context);
      }
    },
  );

  try {
    flutterLocalNotificationsPlugin.show(
      message.hashCode,
      message?.data["title"],
      message?.data["text"],
      NotificationDetails(
        android: AndroidNotificationDetails(
          channel.id,
          channel.name,
          icon: "@mipmap/ic_launcher",
          playSound: true,
          enableVibration: true,
          priority: Priority.high,
          channelShowBadge: true,
          importance: Importance.high,
        ),
        iOS: const DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      payload: message?.data.toString(),
    );
  } catch (e) {
    print("error while showing notification : ${e.toString()}");
  }
}

///perform click on notification
_clickOnNotifications(RemoteMessage message, BuildContext context) {
Get.toNamed(AppRoutes.notificationScreen);
}