import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetDocumentStusResponse getDocumentStusResponseFromJson(String str) => GetDocumentStusResponse.fromJson(json.decode(str));

String getDocumentStusResponseToJson(GetDocumentStusResponse data) => json.encode(data.toJson());

class GetDocumentStusResponse {
  final ResponseHeader responseHeader;
  final List<DRDatum> data;

  GetDocumentStusResponse({
    required this.responseHeader,
    required this.data,
  });

  factory GetDocumentStusResponse.fromJson(Map<String, dynamic> json) => GetDocumentStusResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    data: List<DRDatum>.from(json["data"].map((x) => DRDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class DRDatum {
  final int id;
  final int sellerStoreId;
  final String title;
  final String description;
  final String documentUrl;
  final dynamic status;
  final dynamic statusComment;
  final DateTime createdAt;
  final DateTime updatedAt;

  DRDatum({
    required this.id,
    required this.sellerStoreId,
    required this.title,
    required this.description,
    required this.documentUrl,
    this.status,
    this.statusComment,
    required this.createdAt,
    required this.updatedAt,
  });

  factory DRDatum.fromJson(Map<String, dynamic> json) => DRDatum(
    id: json["id"],
    sellerStoreId: json["sellerStoreId"],
    title: json["title"],
    description: json["description"],
    documentUrl: json["documentUrl"],
    status: json["status"],
    statusComment: json["statusComment"] ?? "",
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "sellerStoreId": sellerStoreId,
    "title": title,
    "description": description,
    "documentUrl": documentUrl,
    "status": status,
    "statusComment": statusComment,
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
  };
}