import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerDashboardResponse getSellerDashboardResponseFromJson(String str) => GetSellerDashboardResponse.fromJson(json.decode(str));

String getSellerDashboardResponseToJson(GetSellerDashboardResponse data) => json.encode(data.toJson());

class GetSellerDashboardResponse {
  ResponseHeader? responseHeader;
  SellerDashboardData? data;

  GetSellerDashboardResponse({
    this.responseHeader,
    this.data,
  });

  factory GetSellerDashboardResponse.fromJson(Map<String, dynamic> json) => GetSellerDashboardResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : SellerDashboardData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class SellerDashboardData {
  int? totalOrders;
  int? pendingOrderCount;
  int? productsCount;
  List<OrderList>? orderList;

  SellerDashboardData({
    this.totalOrders,
    this.pendingOrderCount,
    this.productsCount,
    this.orderList,
  });

  factory SellerDashboardData.fromJson(Map<String, dynamic> json) => SellerDashboardData(
    totalOrders: json["totalOrders"],
    pendingOrderCount: json["pendingOrderCount"],
    productsCount: json["productsCount"],
    orderList: json["orderList"] == null ? [] : List<OrderList>.from(json["orderList"]!.map((x) => OrderList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "totalOrders": totalOrders,
    "pendingOrderCount": pendingOrderCount,
    "productsCount": productsCount,
    "orderList": orderList == null ? [] : List<dynamic>.from(orderList!.map((x) => x.toJson())),
  };
}

class OrderList {
  int? id;
  int? userId;
  dynamic paymentStatus;
  dynamic taxInPercentage;
  dynamic deliveryAddressId;
  dynamic paymentMethod;
  dynamic totalShippingCharges;
  dynamic paymentIntentId;
  DateTime? createdAt;
  DateTime? updatedAt;
  List<OrderedItem>? orderedItems;
  dynamic totalCartCost;

  OrderList({
    this.id,
    this.userId,
    this.paymentStatus,
    this.taxInPercentage,
    this.deliveryAddressId,
    this.paymentMethod,
    this.totalShippingCharges,
    this.paymentIntentId,
    this.createdAt,
    this.updatedAt,
    this.orderedItems,
    this.totalCartCost,
  });

  factory OrderList.fromJson(Map<String, dynamic> json) => OrderList(
    id: json["id"],
    userId: json["userId"],
    paymentStatus: json["paymentStatus"],
    taxInPercentage: json["taxInPercentage"],
    deliveryAddressId: json["deliveryAddressId"],
    paymentMethod: json["paymentMethod"],
    totalShippingCharges: json["totalShippingCharges"],
    paymentIntentId: json["paymentIntentId"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    orderedItems: json["ordered_items"] == null ? [] : List<OrderedItem>.from(json["ordered_items"]!.map((x) => OrderedItem.fromJson(x))),
    totalCartCost: json["totalCartCost"]?.toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "paymentStatus": paymentStatus,
    "taxInPercentage": taxInPercentage,
    "deliveryAddressId": deliveryAddressId,
    "paymentMethod": paymentMethod,
    "totalShippingCharges": totalShippingCharges,
    "paymentIntentId": paymentIntentId,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "ordered_items": orderedItems == null ? [] : List<dynamic>.from(orderedItems!.map((x) => x.toJson())),
    "totalCartCost": totalCartCost,
  };
}

class OrderedItem {
  int? id;
  int? orderId;
  int? sellerStoreId;
  int? productId;
  int? productVariationId;
  dynamic productName;
  int? salePrice;
  dynamic maxRetailPrice;
  dynamic shippingMethod;
  dynamic status;
  dynamic quantity;

  OrderedItem({
    this.id,
    this.orderId,
    this.sellerStoreId,
    this.productId,
    this.productVariationId,
    this.productName,
    this.salePrice,
    this.maxRetailPrice,
    this.shippingMethod,
    this.status,
    this.quantity,
  });

  factory OrderedItem.fromJson(Map<String, dynamic> json) => OrderedItem(
    id: json["id"],
    orderId: json["orderId"],
    sellerStoreId: json["sellerStoreId"],
    productId: json["productId"],
    productVariationId: json["productVariationId"],
    productName: json["productName"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    shippingMethod: json["shippingMethod"],
    status: json["status"],
    quantity: json["quantity"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "sellerStoreId": sellerStoreId,
    "productId": productId,
    "productVariationId": productVariationId,
    "productName": productName,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "shippingMethod": shippingMethod,
    "status": status,
    "quantity": quantity,
  };
}