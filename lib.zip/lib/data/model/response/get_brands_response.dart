import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetBrandListResponse getBrandListResponseFromJson(String str) => GetBrandListResponse.fromJson(json.decode(str));

String getBrandListResponseToJson(GetBrandListResponse data) => json.encode(data.toJson());

class GetBrandListResponse {
  ResponseHeader? responseHeader;
  List<BrandData>? data;

  GetBrandListResponse({
    this.responseHeader,
    this.data,
  });

  factory GetBrandListResponse.fromJson(Map<String, dynamic> json) => GetBrandListResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? [] : List<BrandData>.from(json["data"]!.map((x) => BrandData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class BrandData {
  int? id;
  String? name;
  dynamic imageUrl;
  dynamic description;
  int? isTopBrand;
  DateTime? createdAt;
  DateTime? updatedAt;

  BrandData({
    this.id,
    this.name,
    this.imageUrl,
    this.description,
    this.isTopBrand,
    this.createdAt,
    this.updatedAt,
  });

  factory BrandData.fromJson(Map<String, dynamic> json) => BrandData(
    id: json["id"],
    name: json["name"],
    imageUrl: json["imageUrl"],
    description: json["description"],
    isTopBrand: json["isTopBrand"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "imageUrl": imageUrl,
    "description": description,
    "isTopBrand": isTopBrand,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}