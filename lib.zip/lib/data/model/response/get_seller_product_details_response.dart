import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerProductDetailsResponse getSellerProductDetailsResponseFromJson(String str) => GetSellerProductDetailsResponse.fromJson(json.decode(str));

String getSellerProductDetailsResponseToJson(GetSellerProductDetailsResponse data) => json.encode(data.toJson());

class GetSellerProductDetailsResponse {
  ResponseHeader? responseHeader;
  SellerProductData? data;

  GetSellerProductDetailsResponse({
    this.responseHeader,
    this.data,
  });

  factory GetSellerProductDetailsResponse.fromJson(Map<String, dynamic> json) => GetSellerProductDetailsResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : SellerProductData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class SellerProductData {
  int? id;
  int? sellerStoreId;
  String? title;
  String? description;
  int? categoryId;
  int? badgeId;
  String? extras;
  String? status;
  String? reason;
  String? processingTime;
  List<ProductVariation>? productVariations;
  SellerStore? sellerStore;
  Brand? brand;
  Category? category;

  SellerProductData({
    this.id,
    this.sellerStoreId,
    this.title,
    this.description,
    this.categoryId,
    this.badgeId,
    this.extras,
    this.status,
    this.reason,
    this.processingTime,
    this.productVariations,
    this.sellerStore,
    this.brand,
    this.category,
  });

  factory SellerProductData.fromJson(Map<String, dynamic> json) => SellerProductData(
    id: json["id"],
    sellerStoreId: json["sellerStoreId"],
    title: json["title"],
    description: json["description"],
    categoryId: json["categoryId"],
    badgeId: json["badgeId"],
    extras: json["extras"],
    processingTime: json["processingTime"],
    productVariations: json["product_variations"] == null ? [] : List<ProductVariation>.from(json["product_variations"]!.map((x) => ProductVariation.fromJson(x))),
    sellerStore: json["sellerStore"] == null ? null : SellerStore.fromJson(json["sellerStore"]),
    brand: json["brand"] == null ? null : Brand.fromJson(json["brand"]),
    category: json["category"] == null ? null : Category.fromJson(json["category"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "sellerStoreId": sellerStoreId,
    "title": title,
    "description": description,
    "categoryId": categoryId,
    "badgeId": badgeId,
    "extras": extras,
    "processingTime": processingTime,
    "product_variations": productVariations == null ? [] : List<dynamic>.from(productVariations!.map((x) => x.toJson())),
    "sellerStore": sellerStore?.toJson(),
    "brand": brand?.toJson(),
    "category": category?.toJson(),
  };
}

class Brand {
  int? id;
  String? name;

  Brand({
    this.id,
    this.name,
  });

  factory Brand.fromJson(Map<String, dynamic> json) => Brand(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}

class Category {
  String? name;

  Category({
    this.name,
  });

  factory Category.fromJson(Map<String, dynamic> json) => Category(
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
  };
}

class ProductVariation {
  int? id;
  int? productId;
  dynamic? salePrice;
  dynamic? maxRetailPrice;
  String? condition;
  String? approvalStatus;
  String? rejectionReason;
  dynamic? weightInPound;
  dynamic heightInCentimeter;
  dynamic widthInCentimeter;
  dynamic lengthInCentimeter;
  List<SellerProductAttributeMapping>? productAttributeMappings;
  List<ProductImage>? productImages;

  ProductVariation({
    this.id,
    this.productId,
    this.salePrice,
    this.maxRetailPrice,
    this.condition,
    this.approvalStatus,
    this.rejectionReason,
    this.weightInPound,
    this.heightInCentimeter,
    this.widthInCentimeter,
    this.lengthInCentimeter,
    this.productAttributeMappings,
    this.productImages,
  });

  factory ProductVariation.fromJson(Map<String, dynamic> json) => ProductVariation(
    id: json["id"],
    productId: json["productId"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    condition: json["condition"],
    approvalStatus: json["approvalStatus"],
    rejectionReason: json["rejectionReason"],
    productAttributeMappings: json["product_attribute_mappings"] == null ? [] : List<SellerProductAttributeMapping>.from(json["product_attribute_mappings"]!.map((x) => SellerProductAttributeMapping.fromJson(x))),
    productImages: json["product_images"] == null ? [] : List<ProductImage>.from(json["product_images"]!.map((x) => ProductImage.fromJson(x))),
    weightInPound: json["weightInPound"],
    heightInCentimeter: json["heightInCentimeter"],
    widthInCentimeter: json["widthInCentimeter"],
    lengthInCentimeter: json["lengthInCentimeter"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "productId": productId,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "condition": condition,
    "approvalStatus": approvalStatus,
    "rejectionReason": rejectionReason,
    "weightInPound": weightInPound,
    "heightInCentimeter": heightInCentimeter,
    "widthInCentimeter": widthInCentimeter,
    "lengthInCentimeter": lengthInCentimeter,
    "product_attribute_mappings": productAttributeMappings == null ? [] : List<dynamic>.from(productAttributeMappings!.map((x) => x.toJson())),
    "product_images": productImages == null ? [] : List<dynamic>.from(productImages!.map((x) => x.toJson())),
  };
}

class SellerProductAttributeMapping {
  int? id;
  int? variationId;
  int? attributeId;
  String? value;
  DateTime? createdAt;
  DateTime? updatedAt;
  Attribute? attribute;

  SellerProductAttributeMapping({
    this.id,
    this.variationId,
    this.attributeId,
    this.value,
    this.createdAt,
    this.updatedAt,
    this.attribute,
  });

  factory SellerProductAttributeMapping.fromJson(Map<String, dynamic> json) => SellerProductAttributeMapping(
    id: json["id"],
    variationId: json["variationId"],
    attributeId: json["attributeId"],
    value: json["value"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    attribute: json["attribute"] == null ? null : Attribute.fromJson(json["attribute"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "variationId": variationId,
    "attributeId": attributeId,
    "value": value,
    "createdAt": "${createdAt!.year.toString().padLeft(4, '0')}-${createdAt!.month.toString().padLeft(2, '0')}-${createdAt!.day.toString().padLeft(2, '0')}",
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
    "attribute": attribute?.toJson(),
  };
}

class Attribute {
  int? id;
  String? attributeName;

  Attribute({
    this.id,
    this.attributeName,
  });

  factory Attribute.fromJson(Map<String, dynamic> json) => Attribute(
    id: json["id"],
    attributeName: json["attributeName"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "attributeName": attributeName,
  };
}

class ProductImage {
  String? imageName;
  String? imageThumbnail;

  ProductImage({
    this.imageName,
    this.imageThumbnail,
  });

  factory ProductImage.fromJson(Map<String, dynamic> json) => ProductImage(
    imageName: json["imageName"],
    imageThumbnail: json["imageThumbnail"],
  );

  Map<String, dynamic> toJson() => {
    "imageName": imageName,
    "imageThumbnail": imageThumbnail,
  };
}

class SellerStore {
  int? isPickupFromStoreEnabled;

  SellerStore({
    this.isPickupFromStoreEnabled,
  });

  factory SellerStore.fromJson(Map<String, dynamic> json) => SellerStore(
    isPickupFromStoreEnabled: json["isPickupFromStoreEnabled"],
  );

  Map<String, dynamic> toJson() => {
    "isPickupFromStoreEnabled": isPickupFromStoreEnabled,
  };
}