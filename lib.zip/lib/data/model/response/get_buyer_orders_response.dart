import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetBuyerOrdersResponse getBuyerOrdersResponseFromJson(String str) => GetBuyerOrdersResponse.fromJson(json.decode(str));

String getBuyerOrdersResponseToJson(GetBuyerOrdersResponse data) => json.encode(data.toJson());

class GetBuyerOrdersResponse {
  final ResponseHeader responseHeader;
  List<BuyerOrderData>? data;

  GetBuyerOrdersResponse({
    required this.responseHeader,
    this.data,
  });

  factory GetBuyerOrdersResponse.fromJson(Map<String, dynamic> json) {
    if (json["data"] == null) {
      return GetBuyerOrdersResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return GetBuyerOrdersResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: List<BuyerOrderData>.from(json["data"].map((x) => BuyerOrderData.fromJson(x))),
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class BuyerOrderData {
  final String productName;
  final String productImage;
  final String productDescription;
  final int id;
  final int orderId;
  final int sellerStoreId;
  final int productId;
  final int productVariationId;
  final int salePrice;
  final String status;
  final DateTime updatedAt;
  final DateTime createdAt;
  ProductData? productData;

  BuyerOrderData({
    required this.productImage,
    required this.productDescription,
    required this.id,
    required this.orderId,
    required this.sellerStoreId,
    required this.productId,
    required this.productVariationId,
    required this.productName,
    required this.salePrice,
    required this.status,
    required this.updatedAt,
    required this.createdAt,
    this.productData,
  });

  factory BuyerOrderData.fromJson(Map<String, dynamic> json) => BuyerOrderData(
    id: json["id"],
    orderId: json["orderId"],
    sellerStoreId: json["sellerStoreId"],
    productId: json["productId"],
    productVariationId: json["productVariationId"],
    productName: json["productName"],
    salePrice: json["salePrice"],
    status: json["status"],
    updatedAt: DateTime.parse(json["updatedAt"]),
    createdAt: DateTime.parse(json["createdAt"]),
    productData: json["productData"] == null ? null : ProductData.fromJson(json["productData"]), productImage: json["productImage"], productDescription: json["productDescription"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "sellerStoreId": sellerStoreId,
    "productId": productId,
    "productVariationId": productVariationId,
    "productName": productName,
    "salePrice": salePrice,
    "status": status,
    "updatedAt": updatedAt.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "productData": productData?.toJson(),
  };
}

class ProductData {
  PickupAddress? pickupAddress;
  DeliveryAddress? deliveryAddress;

  ProductData({
    this.pickupAddress,
    this.deliveryAddress,
  });

  factory ProductData.fromJson(Map<String, dynamic> json) {
    try {
      if (json["pickupAddress"] == null) {
        return ProductData(
          deliveryAddress: json["deliveryAddress"] == null ? null : DeliveryAddress.fromJson(json["deliveryAddress"]),
        );
      }
      else {
        return ProductData(
          pickupAddress: json["pickupAddress"] == null ? null : PickupAddress.fromJson(json["pickupAddress"]),
          deliveryAddress: DeliveryAddress.fromJson(json["deliveryAddress"]),
        );
      }
    } catch (e) {
      return ProductData(
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "pickup_address": pickupAddress?.toJson(),
    "delivery_address": deliveryAddress?.toJson(),
  };
}

class DeliveryAddress {
  final dynamic id;
  final dynamic city;
  final dynamic state;
  final dynamic street;
  final dynamic userId;
  final dynamic country;
  final dynamic lastName;
  final dynamic postCode;
  final dynamic firstName;
  final dynamic phoneNumber;
  final dynamic addressLine1;
  final dynamic addressLine2;

  DeliveryAddress({
    required this.id,
    required this.city,
    required this.state,
    required this.street,
    required this.userId,
    required this.country,
    required this.lastName,
    required this.postCode,
    required this.firstName,
    required this.phoneNumber,
    required this.addressLine1,
    required this.addressLine2,
  });

  factory DeliveryAddress.fromJson(Map<String, dynamic> json) => DeliveryAddress(
    id: json["id"] ?? "",
    city: json["city"] ?? "",
    state: json["state"] ?? "",
    street: json["street"] ?? "",
    userId: json["userId"] ?? "",
    country: json["country"] ?? "",
    lastName: json["lastName"] ?? "",
    postCode: json["postCode"] ?? "",
    firstName: json["firstName"] ?? "",
    phoneNumber: json["phoneNumber"] ?? "",
    addressLine1: json["addressLine1"] ?? "",
    addressLine2: json["addressLine2"] ?? "",
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "city": city,
    "state": state,
    "street": street,
    "userId": userId,
    "country": country,
    "lastName": lastName,
    "postCode": postCode,
    "firstName": firstName,
    "phoneNumber": phoneNumber,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
  };
}

class PickupAddress {
  final dynamic city;
  final dynamic name;
  final dynamic about;
  final dynamic email;
  final dynamic contact;
  final dynamic country;
  final dynamic postCode;
  final dynamic addressLine1;
  final dynamic addressLine2;

  PickupAddress({
    required this.city,
    required this.name,
    required this.about,
    required this.email,
    required this.contact,
    required this.country,
    required this.postCode,
    required this.addressLine1,
    required this.addressLine2,
  });

  factory PickupAddress.fromJson(Map<String, dynamic> json) => PickupAddress(
    city: json["city"] ?? "",
    name: json["name"] ?? "",
    about: json["about"] ?? "",
    email: json["email"] ?? "",
    contact: json["contact"] ?? "",
    country: json["country"] ?? "",
    postCode: json["postCode"] ?? "",
    addressLine1: json["addressLine1"] ?? "",
    addressLine2: json["addressLine2"] ?? "",
  );

  Map<String, dynamic> toJson() => {
    "city": city,
    "name": name,
    "about": about,
    "email": email,
    "contact": contact,
    "country": country,
    "postCode": postCode,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
  };
}