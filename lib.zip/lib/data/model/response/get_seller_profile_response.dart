import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerProfileResponse getSellerProfileResponseFromJson(String str) => GetSellerProfileResponse.fromJson(json.decode(str));

String getSellerProfileResponseToJson(GetSellerProfileResponse data) => json.encode(data.toJson());

class GetSellerProfileResponse {
  ResponseHeader? responseHeader;
  SellerProfileData? data;

  GetSellerProfileResponse({
    this.responseHeader,
    this.data,
  });

  factory GetSellerProfileResponse.fromJson(Map<String, dynamic> json) => GetSellerProfileResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : SellerProfileData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class SellerProfileData {
  int? userId;
  String? firstName;
  String? lastName;
  String? contact;
  String? email;
  dynamic latitude;
  dynamic longitude;
  String? gender;
  String? profilePicture;
  List<SellerStore>? sellerStores;

  SellerProfileData({
    this.userId,
    this.firstName,
    this.lastName,
    this.contact,
    this.email,
    this.latitude,
    this.longitude,
    this.gender,
    this.profilePicture,
    this.sellerStores,
  });

  factory SellerProfileData.fromJson(Map<String, dynamic> json) => SellerProfileData(
    userId: json["userId"],
    firstName: json["firstName"],
    lastName: json["lastName"],
    contact: json["contact"],
    email: json["email"],
    latitude: json["latitude"],
    longitude: json["longitude"],
    gender: json["gender"],
    profilePicture: json["profilePicture"],
    sellerStores: json["seller_stores"] == null ? [] : List<SellerStore>.from(json["seller_stores"]!.map((x) => SellerStore.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "userId": userId,
    "firstName": firstName,
    "lastName": lastName,
    "contact": contact,
    "email": email,
    "latitude": latitude,
    "longitude": longitude,
    "gender": gender,
    "profilePicture": profilePicture,
    "seller_stores": sellerStores == null ? [] : List<dynamic>.from(sellerStores!.map((x) => x.toJson())),
  };
}

class SellerStore {
  int? id;
  String? addressLine1;
  String? addressLine2;
  String? city;
  String? country;
  String? postCode;
  String? contact;
  String? county;

  SellerStore({
    this.id,
    this.addressLine1,
    this.addressLine2,
    this.city,
    this.country,
    this.postCode,
    this.contact,
    this.county,
  });

  factory SellerStore.fromJson(Map<String, dynamic> json) => SellerStore(
    id: json["id"],
    addressLine1: json["addressLine1"],
    addressLine2: json["addressLine2"],
    city: json["city"],
    country: json["country"],
    postCode: json["postCode"],
    contact: json["contact"],
    county: json["county"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "country": country,
    "postCode": postCode,
    "contact": contact,
    "county": county,
  };
}