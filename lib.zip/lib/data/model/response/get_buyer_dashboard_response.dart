import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetBuyerDashboardResponse getBuyerDashboardResponseFromJson(String str) => GetBuyerDashboardResponse.fromJson(json.decode(str));

String getBuyerDashboardResponseToJson(GetBuyerDashboardResponse data) => json.encode(data.toJson());

class GetBuyerDashboardResponse {
  final ResponseHeader responseHeader;
  final Data data;

  GetBuyerDashboardResponse({
    required this.responseHeader,
    required this.data,
  });

  factory GetBuyerDashboardResponse.fromJson(Map<String, dynamic> json) => GetBuyerDashboardResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": data.toJson(),
  };
}

class Data {
  final List<JustAdded> justAdded;
  final List<AllChildCat> allChildCats;
  final List<AllChildCat> featuredCategories;
  final List<Banner> banners;
  bool? isLiked = false;

  Data({
    this.isLiked,
    required this.justAdded,
    required this.allChildCats,
    required this.featuredCategories,
    required this.banners,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    justAdded: List<JustAdded>.from(json["justAdded"].map((x) => JustAdded.fromJson(x))),
    allChildCats: List<AllChildCat>.from(json["allChildCats"].map((x) => AllChildCat.fromJson(x))),
    featuredCategories: List<AllChildCat>.from(json["featuredCategories"].map((x) => AllChildCat.fromJson(x))),
    banners: List<Banner>.from(json["banners"].map((x) => Banner.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "justAdded": List<dynamic>.from(justAdded.map((x) => x.toJson())),
    "allChildCats": List<dynamic>.from(allChildCats.map((x) => x.toJson())),
    "featuredCategories": List<dynamic>.from(featuredCategories.map((x) => x.toJson())),
    "banners": List<dynamic>.from(banners.map((x) => x.toJson())),
  };
}

class AllChildCat {
  int? id;
  String? name;
  int? parentCategory;
  String? imageName;
  String? iconName;
  String? description;
  String? thumbnailName;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? isActive;
  String? title;

  AllChildCat({
    this.id,
    this.name,
    this.parentCategory,
    this.imageName,
    this.iconName,
    this.description,
    this.thumbnailName,
    this.createdAt,
    this.updatedAt,
    this.isActive,
    this.title,
  });

  factory AllChildCat.fromJson(Map<String, dynamic> json) => AllChildCat(
    id: json["id"],
    name: json["name"],
    parentCategory: json["parentCategory"],
    imageName: json["imageName"],
    iconName: json["iconName"],
    description: json["description"] ?? "",
    thumbnailName: json["thumbnailName"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    isActive: json["isActive"],
    title: json["title"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "parentCategory": parentCategory,
    "imageName": imageName,
    "iconName": iconName,
    "description": description,
    "thumbnailName": thumbnailName,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "isActive": isActive,
    "title": title,
  };
}

class Banner {
  final int typeId;
  final List<String> images;

  Banner({
    required this.typeId,
    required this.images,
  });

  factory Banner.fromJson(Map<String, dynamic> json) => Banner(
    typeId: json["typeId"],
    images: List<String>.from(json["images"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "typeId": typeId,
    "images": List<dynamic>.from(images.map((x) => x)),
  };
}

class JustAdded {
  final int id;
  final String title;
  final int sellerStoreId;
  final String description;
  final int badgeId;
  final DateTime createdAt;
  final List<ProductVariation> productVariations;
  final Badge badge;
  final bool isInCart;
  bool isLiked;

  JustAdded({
    this.isLiked = false,
    required this.id,
    required this.title,
    required this.sellerStoreId,
    required this.description,
    required this.badgeId,
    required this.createdAt,
    required this.productVariations,
    required this.badge,
    required this.isInCart,
  });

  factory JustAdded.fromJson(Map<String, dynamic> json) => JustAdded(
    id: json["id"],
    title: json["title"],
    sellerStoreId: json["sellerStoreId"],
    description: json["description"],
    badgeId: json["badgeId"],
    createdAt: DateTime.parse(json["createdAt"]),
    productVariations: List<ProductVariation>.from(json["product_variations"].map((x) => ProductVariation.fromJson(x))),
    badge: Badge.fromJson(json["badge"]),
    isInCart: json["isInCart"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "sellerStoreId": sellerStoreId,
    "description": description,
    "badgeId": badgeId,
    "createdAt": createdAt.toIso8601String(),
    "product_variations": List<dynamic>.from(productVariations.map((x) => x.toJson())),
    "badge": badge.toJson(),
    "isInCart": isInCart,
  };
}

class Badge {
  final String name;
  final String title;
  final String image;
  final String description;

  Badge({
    required this.name,
    required this.title,
    required this.image,
    required this.description,
  });

  factory Badge.fromJson(Map<String, dynamic> json) => Badge(
    name: json["name"],
    title: json["title"],
    image: json["image"],
    description: json["description"] ?? "",
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "title": title,
    "image": image,
    "description": description,
  };
}

class ProductVariation {
  final int id;
  final int isInWishlist;
  final dynamic salePrice;
  final dynamic maxRetailPrice;
  final dynamic discountInPercent;
  final List<ProductImage> productImages;

  ProductVariation({
    required this.id,
    required this.isInWishlist,
    required this.salePrice,
    required this.maxRetailPrice,
    this.discountInPercent,
    required this.productImages,
  });

  factory ProductVariation.fromJson(Map<String, dynamic> json) => ProductVariation(
    id: json["id"],
    isInWishlist: json["isInWishlist"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    discountInPercent: json["discountInPercent"] ?? "",
    productImages: List<ProductImage>.from(json["product_images"].map((x) => ProductImage.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "isInWishlist": isInWishlist,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "discountInPercent": discountInPercent,
    "product_images": List<dynamic>.from(productImages.map((x) => x.toJson())),
  };
}

class ProductImage {
  final String imageName;

  ProductImage({
    required this.imageName,
  });

  factory ProductImage.fromJson(Map<String, dynamic> json) => ProductImage(
    imageName: json["imageName"],
  );

  Map<String, dynamic> toJson() => {
    "imageName": imageName,
  };
}