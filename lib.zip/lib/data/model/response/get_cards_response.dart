import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetCardsResponse getCardsResponseFromJson(String str) => GetCardsResponse.fromJson(json.decode(str));

String getCardsResponseToJson(GetCardsResponse data) => json.encode(data.toJson());

class GetCardsResponse {
  final ResponseHeader responseHeader;
  OrderDetails? orderDetails;

  GetCardsResponse({
    required this.responseHeader,
    this.orderDetails,
  });

  factory GetCardsResponse.fromJson(Map<String, dynamic> json) {
    if (json["orderDetails"] == null) {
      return GetCardsResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return GetCardsResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        orderDetails: OrderDetails.fromJson(json["orderDetails"]),
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "orderDetails": orderDetails?.toJson(),
  };
}

class OrderDetails {
  final String object;
  final List<CardResponseData> data;
  final bool hasMore;
  final String url;

  OrderDetails({
    required this.object,
    required this.data,
    required this.hasMore,
    required this.url,
  });

  factory OrderDetails.fromJson(Map<String, dynamic> json) => OrderDetails(
    object: json["object"],
    data: List<CardResponseData>.from(json["data"].map((x) => CardResponseData.fromJson(x))),
    hasMore: json["has_more"],
    url: json["url"],
  );

  Map<String, dynamic> toJson() => {
    "object": object,
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "has_more": hasMore,
    "url": url,
  };
}

class CardResponseData {
  final String id;
  final String object;
  final BillingDetails billingDetails;
  final Card card;
  final int created;
  final String customer;
  final bool livemode;
  final Metadata metadata;
  final String type;

  CardResponseData({
    required this.id,
    required this.object,
    required this.billingDetails,
    required this.card,
    required this.created,
    required this.customer,
    required this.livemode,
    required this.metadata,
    required this.type,
  });

  factory CardResponseData.fromJson(Map<String, dynamic> json) => CardResponseData(
    id: json["id"],
    object: json["object"],
    billingDetails: BillingDetails.fromJson(json["billing_details"]),
    card: Card.fromJson(json["card"]),
    created: json["created"],
    customer: json["customer"],
    livemode: json["livemode"],
    metadata: Metadata.fromJson(json["metadata"]),
    type: json["type"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "object": object,
    "billing_details": billingDetails.toJson(),
    "card": card.toJson(),
    "created": created,
    "customer": customer,
    "livemode": livemode,
    "metadata": metadata.toJson(),
    "type": type,
  };
}

class BillingDetails {
  final Address address;
  final dynamic email;
  final dynamic name;
  final dynamic phone;

  BillingDetails({
    required this.address,
    this.email,
    this.name,
    this.phone,
  });

  factory BillingDetails.fromJson(Map<String, dynamic> json) => BillingDetails(
    address: Address.fromJson(json["address"]),
    email: json["email"],
    name: json["name"],
    phone: json["phone"],
  );

  Map<String, dynamic> toJson() => {
    "address": address.toJson(),
    "email": email,
    "name": name,
    "phone": phone,
  };
}

class Address {
  final dynamic city;
  final dynamic country;
  final dynamic line1;
  final dynamic line2;
  final String postalCode;
  final dynamic state;

  Address({
    this.city,
    this.country,
    this.line1,
    this.line2,
    required this.postalCode,
    this.state,
  });

  factory Address.fromJson(Map<String, dynamic> json) => Address(
    city: json["city"],
    country: json["country"],
    line1: json["line1"],
    line2: json["line2"],
    postalCode: json["postal_code"],
    state: json["state"],
  );

  Map<String, dynamic> toJson() => {
    "city": city,
    "country": country,
    "line1": line1,
    "line2": line2,
    "postal_code": postalCode,
    "state": state,
  };
}

class Card {
  final String brand;
  final Checks checks;
  final String country;
  final int expMonth;
  final int expYear;
  final String fingerprint;
  final String funding;
  final dynamic generatedFrom;
  final String last4;
  final Networks networks;
  final ThreeDSecureUsage threeDSecureUsage;
  final dynamic wallet;

  Card({
    required this.brand,
    required this.checks,
    required this.country,
    required this.expMonth,
    required this.expYear,
    required this.fingerprint,
    required this.funding,
    this.generatedFrom,
    required this.last4,
    required this.networks,
    required this.threeDSecureUsage,
    this.wallet,
  });

  factory Card.fromJson(Map<String, dynamic> json) => Card(
    brand: json["brand"],
    checks: Checks.fromJson(json["checks"]),
    country: json["country"],
    expMonth: json["exp_month"],
    expYear: json["exp_year"],
    fingerprint: json["fingerprint"],
    funding: json["funding"],
    generatedFrom: json["generated_from"],
    last4: json["last4"],
    networks: Networks.fromJson(json["networks"]),
    threeDSecureUsage: ThreeDSecureUsage.fromJson(json["three_d_secure_usage"]),
    wallet: json["wallet"],
  );

  Map<String, dynamic> toJson() => {
    "brand": brand,
    "checks": checks.toJson(),
    "country": country,
    "exp_month": expMonth,
    "exp_year": expYear,
    "fingerprint": fingerprint,
    "funding": funding,
    "generated_from": generatedFrom,
    "last4": last4,
    "networks": networks.toJson(),
    "three_d_secure_usage": threeDSecureUsage.toJson(),
    "wallet": wallet,
  };
}

class Checks {
  final dynamic addressLine1Check;
  final String addressPostalCodeCheck;
  final String cvcCheck;

  Checks({
    this.addressLine1Check,
    required this.addressPostalCodeCheck,
    required this.cvcCheck,
  });

  factory Checks.fromJson(Map<String, dynamic> json) => Checks(
    addressLine1Check: json["address_line1_check"],
    addressPostalCodeCheck: json["address_postal_code_check"],
    cvcCheck: json["cvc_check"],
  );

  Map<String, dynamic> toJson() => {
    "address_line1_check": addressLine1Check,
    "address_postal_code_check": addressPostalCodeCheck,
    "cvc_check": cvcCheck,
  };
}

class Networks {
  final List<String> available;
  final dynamic preferred;

  Networks({
    required this.available,
    this.preferred,
  });

  factory Networks.fromJson(Map<String, dynamic> json) => Networks(
    available: List<String>.from(json["available"].map((x) => x)),
    preferred: json["preferred"],
  );

  Map<String, dynamic> toJson() => {
    "available": List<dynamic>.from(available.map((x) => x)),
    "preferred": preferred,
  };
}

class ThreeDSecureUsage {
  final bool supported;

  ThreeDSecureUsage({
    required this.supported,
  });

  factory ThreeDSecureUsage.fromJson(Map<String, dynamic> json) => ThreeDSecureUsage(
    supported: json["supported"],
  );

  Map<String, dynamic> toJson() => {
    "supported": supported,
  };
}

class Metadata {
  Metadata();

  factory Metadata.fromJson(Map<String, dynamic> json) => Metadata(
  );

  Map<String, dynamic> toJson() => {
  };
}