import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetRefundReasonsResponse getRefundReasonsResponseFromJson(String str) => GetRefundReasonsResponse.fromJson(json.decode(str));

String getRefundReasonsResponseToJson(GetRefundReasonsResponse data) => json.encode(data.toJson());

class GetRefundReasonsResponse {
  ResponseHeader? responseHeader;
  List<RefundReason>? refundReasons;

  GetRefundReasonsResponse({
    this.responseHeader,
    this.refundReasons,
  });

  factory GetRefundReasonsResponse.fromJson(Map<String, dynamic> json) => GetRefundReasonsResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    refundReasons: json["refundReasons"] == null ? [] : List<RefundReason>.from(json["refundReasons"]!.map((x) => RefundReason.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "refundReasons": refundReasons == null ? [] : List<dynamic>.from(refundReasons!.map((x) => x.toJson())),
  };
}

class RefundReason {
  int? id;
  String? text;

  RefundReason({
    this.id,
    this.text,
  });

  factory RefundReason.fromJson(Map<String, dynamic> json) => RefundReason(
    id: json["id"],
    text: json["text"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "text": text,
  };
}