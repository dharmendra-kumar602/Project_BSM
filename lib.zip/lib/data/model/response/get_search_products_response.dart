import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSearchProductsResponse getSearchProductsResponseFromJson(String str) => GetSearchProductsResponse.fromJson(json.decode(str));

String getSearchProductsResponseToJson(GetSearchProductsResponse data) => json.encode(data.toJson());

class GetSearchProductsResponse {
  final ResponseHeader responseHeader;
  final List<SearchResult> data;

  GetSearchProductsResponse({
    required this.responseHeader,
    required this.data,
  });

  factory GetSearchProductsResponse.fromJson(Map<String, dynamic> json) => GetSearchProductsResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    data: List<SearchResult>.from(json["data"].map((x) => SearchResult.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class SearchResult {
  final int id;
  final String title;

  SearchResult({
    required this.id,
    required this.title,
  });

  factory SearchResult.fromJson(Map<String, dynamic> json) => SearchResult(
    id: json["id"],
    title: json["title"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
  };
}