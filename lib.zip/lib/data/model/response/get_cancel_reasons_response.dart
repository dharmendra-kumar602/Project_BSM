import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetCancelReasonsResponse getCancelReasonsResponseFromJson(String str) => GetCancelReasonsResponse.fromJson(json.decode(str));

String getCancelReasonsResponseToJson(GetCancelReasonsResponse data) => json.encode(data.toJson());

class GetCancelReasonsResponse {
  ResponseHeader? responseHeader;
  List<CancelOrderReason>? cancelOrderReasons;

  GetCancelReasonsResponse({
    this.responseHeader,
    this.cancelOrderReasons,
  });

  factory GetCancelReasonsResponse.fromJson(Map<String, dynamic> json) => GetCancelReasonsResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    cancelOrderReasons: json["cancelOrderReasons"] == null ? [] : List<CancelOrderReason>.from(json["cancelOrderReasons"]!.map((x) => CancelOrderReason.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "cancelOrderReasons": cancelOrderReasons == null ? [] : List<dynamic>.from(cancelOrderReasons!.map((x) => x.toJson())),
  };
}

class CancelOrderReason {
  int? id;
  String? text;

  CancelOrderReason({
    this.id,
    this.text,
  });

  factory CancelOrderReason.fromJson(Map<String, dynamic> json) => CancelOrderReason(
    id: json["id"],
    text: json["text"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "text": text,
  };
}