import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetShippingDetailsResponse getShippingDetailsResponseFromJson(String str) => GetShippingDetailsResponse.fromJson(json.decode(str));

String getShippingDetailsResponseToJson(GetShippingDetailsResponse data) => json.encode(data.toJson());

class GetShippingDetailsResponse {
  ResponseHeader? responseHeader;
  ShippingData? data;

  GetShippingDetailsResponse({
    this.responseHeader,
    this.data,
  });

  factory GetShippingDetailsResponse.fromJson(Map<String, dynamic> json) => GetShippingDetailsResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : ShippingData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class ShippingData {
  int? isFreeShippingEnabled;
  int? freeShippingMinimumCost;
  int? isPickupFromStoreEnabled;
  int? pickupFromStoreHandlingCharges;
  List<ShippingMethod>? shippingMethods;

  ShippingData({
    this.isFreeShippingEnabled,
    this.freeShippingMinimumCost,
    this.isPickupFromStoreEnabled,
    this.pickupFromStoreHandlingCharges,
    this.shippingMethods,
  });

  factory ShippingData.fromJson(Map<String, dynamic> json) => ShippingData(
    isFreeShippingEnabled: json["isFreeShippingEnabled"],
    freeShippingMinimumCost: json["freeShippingMinimumCost"],
    isPickupFromStoreEnabled: json["isPickupFromStoreEnabled"],
    pickupFromStoreHandlingCharges: json["pickupFromStoreHandlingCharges"],
    shippingMethods: json["shippingMethods"] == null ? [] : List<ShippingMethod>.from(json["shippingMethods"]!.map((x) => ShippingMethod.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "isFreeShippingEnabled": isFreeShippingEnabled,
    "freeShippingMinimumCost": freeShippingMinimumCost,
    "isPickupFromStoreEnabled": isPickupFromStoreEnabled,
    "pickupFromStoreHandlingCharges": pickupFromStoreHandlingCharges,
    "shippingMethods": shippingMethods == null ? [] : List<dynamic>.from(shippingMethods!.map((x) => x.toJson())),
  };
}

class ShippingMethod {
  List<Rule>? rules;
  int? defaultPrice;
  String? country;

  ShippingMethod({
    this.rules,
    this.defaultPrice,
    this.country,
  });

  factory ShippingMethod.fromJson(Map<String, dynamic> json) => ShippingMethod(
    rules: json["rules"] == null ? [] : List<Rule>.from(json["rules"]!.map((x) => Rule.fromJson(x))),
    defaultPrice: json["defaultPrice"],
    country: json["country"],
  );

  Map<String, dynamic> toJson() => {
    "rules": rules == null ? [] : List<dynamic>.from(rules!.map((x) => x.toJson())),
    "defaultPrice": defaultPrice,
    "country": country,
  };
}

class Rule {
  int? id;
  int? sellerStoreId;
  String? ruleType;
  int? weightOnRule;
  int? costOnRule;
  String? country;

  Rule({
    this.id,
    this.sellerStoreId,
    this.ruleType,
    this.weightOnRule,
    this.costOnRule,
    this.country,
  });

  factory Rule.fromJson(Map<String, dynamic> json) => Rule(
    id: json["id"],
    sellerStoreId: json["sellerStoreId"],
    ruleType: json["ruleType"],
    weightOnRule: json["weightOnRule"],
    costOnRule: json["costOnRule"],
    country: json["country"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "sellerStoreId": sellerStoreId,
    "ruleType": ruleType,
    "weightOnRule": weightOnRule,
    "costOnRule": costOnRule,
    "country": country,
  };
}