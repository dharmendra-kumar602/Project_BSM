import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostCreateOrderResponse postCreateOrderResponseFromJson(String str) => PostCreateOrderResponse.fromJson(json.decode(str));

String postCreateOrderResponseToJson(PostCreateOrderResponse data) => json.encode(data.toJson());

class PostCreateOrderResponse {
  ResponseHeader? responseHeader;
  CreatedOrder? createdOrder;

  PostCreateOrderResponse({
    this.responseHeader,
    this.createdOrder,
  });

  factory PostCreateOrderResponse.fromJson(Map<String, dynamic> json) => PostCreateOrderResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    createdOrder: json["createdOrder"] == null ? null : CreatedOrder.fromJson(json["createdOrder"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "createdOrder": createdOrder?.toJson(),
  };
}

class CreatedOrder {
  int? id;
  int? taxInPercentage;
  int? deliveryAddressId;
  int? totalShippingCharges;
  String? paymentStatus;
  int? totalHandlingCharges;
  int? userId;
  List<ShippingCostDetail>? shippingCostDetails;
  String? paymentMethod;
  int? cartSubCost;
  DateTime? updatedAt;
  DateTime? createdAt;

  CreatedOrder({
    this.id,
    this.taxInPercentage,
    this.deliveryAddressId,
    this.totalShippingCharges,
    this.paymentStatus,
    this.totalHandlingCharges,
    this.userId,
    this.shippingCostDetails,
    this.paymentMethod,
    this.cartSubCost,
    this.updatedAt,
    this.createdAt,
  });

  factory CreatedOrder.fromJson(Map<String, dynamic> json) => CreatedOrder(
    id: json["id"],
    taxInPercentage: json["taxInPercentage"],
    deliveryAddressId: json["deliveryAddressId"],
    totalShippingCharges: json["totalShippingCharges"],
    paymentStatus: json["paymentStatus"],
    totalHandlingCharges: json["totalHandlingCharges"],
    userId: json["userId"],
    shippingCostDetails: json["shippingCostDetails"] == null ? [] : List<ShippingCostDetail>.from(json["shippingCostDetails"]!.map((x) => ShippingCostDetail.fromJson(x))),
    paymentMethod: json["paymentMethod"],
    cartSubCost: json["cartSubCost"],
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "taxInPercentage": taxInPercentage,
    "deliveryAddressId": deliveryAddressId,
    "totalShippingCharges": totalShippingCharges,
    "paymentStatus": paymentStatus,
    "totalHandlingCharges": totalHandlingCharges,
    "userId": userId,
    "shippingCostDetails": shippingCostDetails == null ? [] : List<dynamic>.from(shippingCostDetails!.map((x) => x.toJson())),
    "paymentMethod": paymentMethod,
    "cartSubCost": cartSubCost,
    "updatedAt": updatedAt?.toIso8601String(),
    "createdAt": createdAt?.toIso8601String(),
  };
}

class ShippingCostDetail {
  int? sellerId;
  int? totalWeightShippingCost;
  int? totalhandlingCharges;

  ShippingCostDetail({
    this.sellerId,
    this.totalWeightShippingCost,
    this.totalhandlingCharges,
  });

  factory ShippingCostDetail.fromJson(Map<String, dynamic> json) => ShippingCostDetail(
    sellerId: json["sellerId"],
    totalWeightShippingCost: json["totalWeightShippingCost"],
    totalhandlingCharges: json["totalhandlingCharges"],
  );

  Map<String, dynamic> toJson() => {
    "sellerId": sellerId,
    "totalWeightShippingCost": totalWeightShippingCost,
    "totalhandlingCharges": totalhandlingCharges,
  };
}