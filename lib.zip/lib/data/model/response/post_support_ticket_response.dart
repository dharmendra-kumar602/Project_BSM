import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostSupportTicketResponse postSupportTicketResponseFromJson(String str) => PostSupportTicketResponse.fromJson(json.decode(str));

String postSupportTicketResponseToJson(PostSupportTicketResponse data) => json.encode(data.toJson());

class PostSupportTicketResponse {
  final ResponseHeader responseHeader;
  final Ticket ticket;

  PostSupportTicketResponse({
    required this.responseHeader,
    required this.ticket,
  });

  factory PostSupportTicketResponse.fromJson(Map<String, dynamic> json) => PostSupportTicketResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    ticket: Ticket.fromJson(json["ticket"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "ticket": ticket.toJson(),
  };
}

class Ticket {
  final int id;
  final int userId;
  final String title;
  final String status;
  final String description;
  final DateTime updatedAt;
  final DateTime createdAt;

  Ticket({
    required this.id,
    required this.userId,
    required this.title,
    required this.status,
    required this.description,
    required this.updatedAt,
    required this.createdAt,
  });

  factory Ticket.fromJson(Map<String, dynamic> json) => Ticket(
    id: json["id"],
    userId: json["userId"],
    title: json["title"],
    status: json["status"],
    description: json["description"],
    updatedAt: DateTime.parse(json["updatedAt"]),
    createdAt: DateTime.parse(json["createdAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "title": title,
    "status": status,
    "description": description,
    "updatedAt": updatedAt.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
  };
}
