import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerPlanStatusResponse getSellerPlanStatusResponseFromJson(String str) => GetSellerPlanStatusResponse.fromJson(json.decode(str));

String getSellerPlanStatusResponseToJson(GetSellerPlanStatusResponse data) => json.encode(data.toJson());

class GetSellerPlanStatusResponse {
  ResponseHeader? responseHeader;
  PlanList? planList;

  GetSellerPlanStatusResponse({
    this.responseHeader,
    this.planList,
  });

  factory GetSellerPlanStatusResponse.fromJson(Map<String, dynamic> json) => GetSellerPlanStatusResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    planList: json["planList"] == null ? null : PlanList.fromJson(json["planList"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "planList": planList?.toJson(),
  };
}

class PlanList {
  Seller? seller;
  ProductsAllowed? productsAllowed;
  int? productsCount;
  List<Document>? documents;

  PlanList({
    this.seller,
    this.productsAllowed,
    this.productsCount,
    this.documents,
  });

  factory PlanList.fromJson(Map<String, dynamic> json) => PlanList(
    seller: json["seller"] == null ? null : Seller.fromJson(json["seller"]),
    productsAllowed: json["productsAllowed"] == null ? null : ProductsAllowed.fromJson(json["productsAllowed"]),
    productsCount: json["productsCount"],
    documents: json["documents"] == null ? [] : List<Document>.from(json["documents"]!.map((x) => Document.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "seller": seller?.toJson(),
    "productsAllowed": productsAllowed?.toJson(),
    "productsCount": productsCount,
    "documents": documents == null ? [] : List<dynamic>.from(documents!.map((x) => x.toJson())),
  };
}

class Document {
  int? id;
  int? sellerStoreId;
  String? title;
  String? description;
  String? url;
  String? status;
  dynamic statusComment;
  DateTime? createdAt;
  DateTime? updatedAt;

  Document({
    this.id,
    this.sellerStoreId,
    this.title,
    this.description,
    this.url,
    this.status,
    this.statusComment,
    this.createdAt,
    this.updatedAt,
  });

  factory Document.fromJson(Map<String, dynamic> json) => Document(
    id: json["id"],
    sellerStoreId: json["sellerStoreId"],
    title: json["title"],
    description: json["description"],
    url: json["url"],
    status: json["status"],
    statusComment: json["statusComment"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "sellerStoreId": sellerStoreId,
    "title": title,
    "description": description,
    "url": url,
    "status": status,
    "statusComment": statusComment,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}

class ProductsAllowed {
  int? value;

  ProductsAllowed({
    this.value,
  });

  factory ProductsAllowed.fromJson(Map<String, dynamic> json) => ProductsAllowed(
    value: json["value"],
  );

  Map<String, dynamic> toJson() => {
    "value": value,
  };
}

class Seller {
  int? isDocumentVerified;
  int? id;
  String? docsRejectionReason;

  Seller({
    this.isDocumentVerified,
    this.id,
    this.docsRejectionReason,
  });

  factory Seller.fromJson(Map<String, dynamic> json) => Seller(
    isDocumentVerified: json["isDocumentVerified"],
    id: json["id"],
    docsRejectionReason: json["docsRejectionReason"],
  );

  Map<String, dynamic> toJson() => {
    "isDocumentVerified": isDocumentVerified,
    "id": id,
    "docsRejectionReason": docsRejectionReason,
  };
}