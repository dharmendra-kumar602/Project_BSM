import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetAllCategoriesResponse getAllCategoriesResponseFromJson(String str) => GetAllCategoriesResponse.fromJson(json.decode(str));

String getAllCategoriesResponseToJson(GetAllCategoriesResponse data) => json.encode(data.toJson());

class GetAllCategoriesResponse {
  final ResponseHeader responseHeader;
  CategoryData? data;

  GetAllCategoriesResponse({
    required this.responseHeader,
    this.data,
  });

  factory GetAllCategoriesResponse.fromJson(Map<String, dynamic> json) {
    if (json["data"] == null) {
      return GetAllCategoriesResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return GetAllCategoriesResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: CategoryData.fromJson(json["data"]),
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": data?.toJson(),
  };
}

class CategoryData {
  final List<CategoryObj> categories;
  final int categoriesLength;

  CategoryData({
    required this.categories,
    required this.categoriesLength,
  });

  factory CategoryData.fromJson(Map<String, dynamic> json) => CategoryData(
    categories: List<CategoryObj>.from(json["categories"].map((x) => CategoryObj.fromJson(x))),
    categoriesLength: json["categoriesLength"],
  );

  Map<String, dynamic> toJson() => {
    "categories": List<dynamic>.from(categories.map((x) => x.toJson())),
    "categoriesLength": categoriesLength,
  };
}

class CategoryObj {
  final int id;
  final String name;
  final String? description;
  final String iconName;
  final String imageName;
  final List<CategoryObj> sub;
  final int products;

  CategoryObj({
    required this.id,
    required this.name,
    this.description,
    required this.iconName,
    required this.imageName,
    required this.sub,
    required this.products,
  });

  factory CategoryObj.fromJson(Map<String, dynamic> json) => CategoryObj(
    id: json["id"],
    name: json["name"],
    description: json["description"],
    iconName: json["iconName"],
    imageName: json["imageName"],
    sub: List<CategoryObj>.from(json["sub"].map((x) => CategoryObj.fromJson(x))),
    products: json["products"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "description": description,
    "iconName": iconName,
    "imageName": imageName,
    "sub": List<dynamic>.from(sub.map((x) => x.toJson())),
    "products": products,
  };
}