import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetCountriesListResponse getCountriesListResponseFromJson(String str) => GetCountriesListResponse.fromJson(json.decode(str));

String getCountriesListResponseToJson(GetCountriesListResponse data) => json.encode(data.toJson());

class GetCountriesListResponse {
  ResponseHeader? responseHeader;
  List<Country>? countries;

  GetCountriesListResponse({
    this.responseHeader,
    this.countries,
  });

  factory GetCountriesListResponse.fromJson(Map<String, dynamic> json) => GetCountriesListResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    countries: json["countries"] == null ? [] : List<Country>.from(json["countries"]!.map((x) => Country.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "countries": countries == null ? [] : List<dynamic>.from(countries!.map((x) => x.toJson())),
  };
}

class Country {
  int? id;
  String? name;
  String? countryCode;
  String? currencyName;
  String? currencyCode;

  Country({
    this.id,
    this.name,
    this.countryCode,
    this.currencyName,
    this.currencyCode,
  });

  factory Country.fromJson(Map<String, dynamic> json) => Country(
    id: json["id"],
    name: json["name"],
    countryCode: json["countryCode"],
    currencyName: json["currencyName"],
    currencyCode: json["currencyCode"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "countryCode": countryCode,
    "currencyName": currencyName,
    "currencyCode": currencyCode,
  };
}