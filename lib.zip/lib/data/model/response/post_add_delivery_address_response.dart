import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostAddDeliveryAddressResponse postAddDeliveryAddressResponseFromJson(String str) => PostAddDeliveryAddressResponse.fromJson(json.decode(str));

String postAddDeliveryAddressResponseToJson(PostAddDeliveryAddressResponse data) => json.encode(data.toJson());

class PostAddDeliveryAddressResponse {
  final ResponseHeader responseHeader;
  final Data data;

  PostAddDeliveryAddressResponse({
    required this.responseHeader,
    required this.data,
  });

  factory PostAddDeliveryAddressResponse.fromJson(Map<String, dynamic> json) => PostAddDeliveryAddressResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": data.toJson(),
  };
}

class Data {
  final int id;
  final String address1;
  final String postCode;
  final String street;
  final String city;
  final String state;
  final String country;
  final String firstName;
  final String phoneNumber;
  final int userId;
  final int isDefault;
  final DateTime updatedAt;
  final DateTime createdAt;

  Data({
    required this.id,
    required this.address1,
    required this.postCode,
    required this.street,
    required this.city,
    required this.state,
    required this.country,
    required this.firstName,
    required this.phoneNumber,
    required this.userId,
    required this.isDefault,
    required this.updatedAt,
    required this.createdAt,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    address1: json["address1"],
    postCode: json["postCode"],
    street: json["street"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
    firstName: json["firstName"],
    phoneNumber: json["phoneNumber"],
    userId: json["userId"],
    isDefault: json["isDefault"],
    updatedAt: DateTime.parse(json["updatedAt"]),
    createdAt: DateTime.parse(json["createdAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "address1": address1,
    "postCode": postCode,
    "street": street,
    "city": city,
    "state": state,
    "country": country,
    "firstName": firstName,
    "phoneNumber": phoneNumber,
    "userId": userId,
    "isDefault": isDefault,
    "updatedAt": updatedAt.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
  };
}