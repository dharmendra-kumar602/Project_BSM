import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/model/response/get_seller_product_details_response.dart';

GetProductByProductIdResponse getProductByProductIdResponseFromJson(String str) => GetProductByProductIdResponse.fromJson(json.decode(str));

String getProductByProductIdResponseToJson(GetProductByProductIdResponse data) => json.encode(data.toJson());

class GetProductByProductIdResponse {
  ResponseHeader? responseHeader;
  Data? data;

  GetProductByProductIdResponse({
    this.responseHeader,
    this.data,
  });

  factory GetProductByProductIdResponse.fromJson(Map<String, dynamic> json) => GetProductByProductIdResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class Data {
  Product? product;
  bool? isInCart;
  bool? isOwnProduct;

  Data({
    this.product,
    this.isInCart,
    this.isOwnProduct,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    product: json["product"] == null ? null : Product.fromJson(json["product"]),
    isInCart: json["isInCart"],
    isOwnProduct: json["isOwnProduct"],
  );

  Map<String, dynamic> toJson() => {
    "product": product?.toJson(),
    "isInCart": isInCart,
    "isOwnProduct": isOwnProduct,
  };
}

class Product {
  String? title;
  int? sellerStoreId;
  String? description;
  int? categoryId;
  int? badgeId;
  String? processingTime;
  DateTime? createdAt;
  DateTime? updatedAt;
  SellerStore? sellerStore;
  List<ProductVariation>? productVariations;
  Badge? badge;
  Category? category;
  Brand? brand;

  Product({
    this.title,
    this.sellerStoreId,
    this.description,
    this.categoryId,
    this.badgeId,
    this.processingTime,
    this.createdAt,
    this.updatedAt,
    this.sellerStore,
    this.productVariations,
    this.badge,
    this.brand,
    this.category,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    title: json["title"],
    sellerStoreId: json["sellerStoreId"],
    description: json["description"],
    categoryId: json["categoryId"],
    badgeId: json["badgeId"],
    processingTime: json["processingTime"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    sellerStore: json["sellerStore"] == null ? null : SellerStore.fromJson(json["sellerStore"]),
    productVariations: json["product_variations"] == null ? [] : List<ProductVariation>.from(json["product_variations"]!.map((x) => ProductVariation.fromJson(x))),
    badge: json["badge"] == null ? null : Badge.fromJson(json["badge"]),
    brand: json["brand"] == null ? null : Brand.fromJson(json["brand"]),
    category: json["category"] == null ? null : Category.fromJson(json["category"]),
  );

  Map<String, dynamic> toJson() => {
    "title": title,
    "sellerStoreId": sellerStoreId,
    "description": description,
    "categoryId": categoryId,
    "badgeId": badgeId,
    "processingTime": processingTime,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
    "sellerStore": sellerStore?.toJson(),
    "product_variations": productVariations == null ? [] : List<dynamic>.from(productVariations!.map((x) => x.toJson())),
    "badge": badge?.toJson(),
    "brand": brand?.toJson(),
    "category": category?.toJson(),
  };
}

class Badge {
  String? name;
  String? title;
  String? image;
  String? description;

  Badge({
    this.name,
    this.title,
    this.image,
    this.description,
  });

  factory Badge.fromJson(Map<String, dynamic> json) => Badge(
    name: json["name"],
    title: json["title"],
    image: json["image"],
    description: json["description"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "title": title,
    "image": image,
    "description": description,
  };
}

class Brand {
  int? id;
  String? name;

  Brand({
    this.id,
    this.name,
  });

  factory Brand.fromJson(Map<String, dynamic> json) => Brand(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}

class ProductVariation {
  int? id;
  dynamic? salePrice;
  dynamic? maxRetailPrice;
  dynamic? height;
  dynamic? width;
  dynamic? length;
  String? condition;
  int? inStock;
  dynamic? weight;
  List<ProductAttributeMapping>? productAttributeMappings;
  List<ProductImage>? productImages;

  ProductVariation({
    this.id,
    this.salePrice,
    this.maxRetailPrice,
    this.height,
    this.width,
    this.length,
    this.condition,
    this.inStock,
    this.weight,
    this.productAttributeMappings,
    this.productImages,
  });

  factory ProductVariation.fromJson(Map<String, dynamic> json) => ProductVariation(
    id: json["id"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    height: json["height"],
    width: json["width"],
    length: json["length"],
    condition: json["condition"],
    inStock: json["inStock"],
    weight: json["weight"],
    productAttributeMappings: json["product_attribute_mappings"] == null ? [] : List<ProductAttributeMapping>.from(json["product_attribute_mappings"]!.map((x) => ProductAttributeMapping.fromJson(x))),
    productImages: json["product_images"] == null ? [] : List<ProductImage>.from(json["product_images"]!.map((x) => ProductImage.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "height": height,
    "width": width,
    "length": length,
    "condition": condition,
    "inStock": inStock,
    "weight": weight,
    "product_attribute_mappings": productAttributeMappings == null ? [] : List<dynamic>.from(productAttributeMappings!.map((x) => x.toJson())),
    "product_images": productImages == null ? [] : List<dynamic>.from(productImages!.map((x) => x.toJson())),
  };
}

class ProductAttributeMapping {
  int? attributeId;
  int variation;
  String? value;
  String? attributeName;

  ProductAttributeMapping({
    this.attributeId,
    this.variation = 0,
    this.value,
    this.attributeName,
  });

  factory ProductAttributeMapping.fromJson(Map<String, dynamic> json) => ProductAttributeMapping(
    attributeId: json["attributeId"],
    value: json["value"],
    attributeName: json["attributeName"],
  );

  Map<String, dynamic> toJson() => {
    "attributeId": attributeId,
    "value": value,
    "attributeName": attributeName,
  };
}

class ProductImage {
  int? variationId;
  String? imageName;
  String? imageThumbnail;

  ProductImage({
    this.variationId,
    this.imageName,
    this.imageThumbnail,
  });

  factory ProductImage.fromJson(Map<String, dynamic> json) => ProductImage(
    variationId: json["variationId"],
    imageName: json["imageName"],
    imageThumbnail: json["imageThumbnail"],
  );

  Map<String, dynamic> toJson() => {
    "variationId": variationId,
    "imageName": imageName,
    "imageThumbnail": imageThumbnail,
  };
}

class SellerStore {
  int? id;
  String? name;
  StorePickupAddress? storePickupAddress;

  SellerStore({
    this.id,
    this.name,
    this.storePickupAddress,
  });

  factory SellerStore.fromJson(Map<String, dynamic> json) => SellerStore(
    id: json["id"],
    name: json["name"],
    storePickupAddress: json["store_pickup_address"] == null ? null : StorePickupAddress.fromJson(json["store_pickup_address"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "store_pickup_address": storePickupAddress?.toJson(),
  };
}

class StorePickupAddress {
  int? id;
  int? sellerStoreId;
  String? address1;
  String? address2;
  String? postCode;
  String? city;
  String? state;
  String? country;
  String? street;
  String? firstName;
  String? phoneNumber;
  String? lastName;
  DateTime? createdAt;
  DateTime? updatedAt;

  StorePickupAddress({
    this.id,
    this.sellerStoreId,
    this.address1,
    this.address2,
    this.postCode,
    this.city,
    this.state,
    this.country,
    this.street,
    this.firstName,
    this.phoneNumber,
    this.lastName,
    this.createdAt,
    this.updatedAt,
  });

  factory StorePickupAddress.fromJson(Map<String, dynamic> json) => StorePickupAddress(
    id: json["id"],
    sellerStoreId: json["sellerStoreId"],
    address1: json["address1"],
    address2: json["address2"],
    postCode: json["postCode"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
    street: json["street"],
    firstName: json["firstName"],
    phoneNumber: json["phoneNumber"],
    lastName: json["lastName"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "sellerStoreId": sellerStoreId,
    "address1": address1,
    "address2": address2,
    "postCode": postCode,
    "city": city,
    "state": state,
    "country": country,
    "street": street,
    "firstName": firstName,
    "phoneNumber": phoneNumber,
    "lastName": lastName,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}