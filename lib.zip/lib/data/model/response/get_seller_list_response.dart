import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerListResponse getSellerListResponseFromJson(String str) => GetSellerListResponse.fromJson(json.decode(str));

String getSellerListResponseToJson(GetSellerListResponse data) => json.encode(data.toJson());

class GetSellerListResponse {
  ResponseHeader? responseHeader;
  List<SellerData>? data;

  GetSellerListResponse({
    this.responseHeader,
    this.data,
  });

  factory GetSellerListResponse.fromJson(Map<String, dynamic> json) => GetSellerListResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? [] : List<SellerData>.from(json["data"]!.map((x) => SellerData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class SellerData {
  int? id;
  int? userId;
  String? name;
  String? email;
  String? addressLine1;
  String? addressLine2;
  String? city;
  String? county;
  String? storeImage;
  String? country;
  String? postCode;
  String? about;
  String? bankName;
  String? ifsc;
  String? accountNumber;
  String? accountHolderName;
  int? isFreeShippingEnabled;
  int? isPickupFromStoreEnabled;
  int? freeShippingMinimumCost;
  int? pickupFromStoreHandlingCharges;
  String? description;
  int? isVerified;
  int? isDocumentVerified;
  int? isActive;
  String? contact;
  String? sellerStatus;
  String? rejectionReason;
  DateTime? createdAt;
  DateTime? updatedAt;

  SellerData({
    this.id,
    this.userId,
    this.name,
    this.email,
    this.addressLine1,
    this.addressLine2,
    this.city,
    this.county,
    this.storeImage,
    this.country,
    this.postCode,
    this.about,
    this.bankName,
    this.ifsc,
    this.accountNumber,
    this.accountHolderName,
    this.isFreeShippingEnabled,
    this.isPickupFromStoreEnabled,
    this.freeShippingMinimumCost,
    this.pickupFromStoreHandlingCharges,
    this.description,
    this.isVerified,
    this.isDocumentVerified,
    this.isActive,
    this.contact,
    this.sellerStatus,
    this.rejectionReason,
    this.createdAt,
    this.updatedAt,
  });

  factory SellerData.fromJson(Map<String, dynamic> json) => SellerData(
    id: json["id"],
    userId: json["userId"],
    name: json["name"],
    email: json["email"],
    addressLine1: json["addressLine1"],
    addressLine2: json["addressLine2"],
    city: json["city"],
    county: json["county"],
    storeImage: json["storeImage"],
    country: json["country"],
    postCode: json["postCode"],
    about: json["about"],
    bankName: json["bankName"],
    ifsc: json["IFSC"],
    accountNumber: json["accountNumber"],
    accountHolderName: json["accountHolderName"],
    isFreeShippingEnabled: json["isFreeShippingEnabled"],
    isPickupFromStoreEnabled: json["isPickupFromStoreEnabled"],
    freeShippingMinimumCost: json["freeShippingMinimumCost"],
    pickupFromStoreHandlingCharges: json["pickupFromStoreHandlingCharges"],
    description: json["description"],
    isVerified: json["isVerified"],
    isDocumentVerified: json["isDocumentVerified"],
    isActive: json["isActive"],
    contact: json["contact"],
    sellerStatus: json["sellerStatus"],
    rejectionReason: json["rejectionReason"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "name": name,
    "email": email,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "county": county,
    "storeImage": storeImage,
    "country": country,
    "postCode": postCode,
    "about": about,
    "bankName": bankName,
    "IFSC": ifsc,
    "accountNumber": accountNumber,
    "accountHolderName": accountHolderName,
    "isFreeShippingEnabled": isFreeShippingEnabled,
    "isPickupFromStoreEnabled": isPickupFromStoreEnabled,
    "freeShippingMinimumCost": freeShippingMinimumCost,
    "pickupFromStoreHandlingCharges": pickupFromStoreHandlingCharges,
    "description": description,
    "isVerified": isVerified,
    "isDocumentVerified": isDocumentVerified,
    "isActive": isActive,
    "contact": contact,
    "sellerStatus": sellerStatus,
    "rejectionReason": rejectionReason,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}