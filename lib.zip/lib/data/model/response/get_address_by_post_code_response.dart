import 'dart:convert';
import '../../../core/model/response_header.dart';

GetAddressByPostIdResponse getAddressByPostIdResponseFromJson(String str) => GetAddressByPostIdResponse.fromJson(json.decode(str));

class GetAddressByPostIdResponse {
  ResponseHeader? responseHeader;
  List<PostCodeAddress>? data;

  GetAddressByPostIdResponse({
    this.responseHeader,
    this.data,
  });

  factory GetAddressByPostIdResponse.fromJson(Map<String, dynamic> json) => GetAddressByPostIdResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? [] : List<PostCodeAddress>.from(json["data"]!.map((x) => PostCodeAddress.fromJson(x))),
  );
}

class PostCodeAddress {
  String? postcode;
  String? line1;
  String? line2;
  String? line3;
  String? line4;
  String? city;
  String? locality;
  String? county;
  String? country;
  String? url;
  String? id;

  PostCodeAddress({
    this.url,
    this.id,
    this.postcode,
    this.line1,
    this.line2,
    this.line3,
    this.line4,
    this.city,
    this.locality,
    this.county,
    this.country
  });

  factory PostCodeAddress.fromJson(Map<String, dynamic> json) {
    var address = json["address"];
    var addressInArray = address.toString().split(",");
    if (addressInArray.isNotEmpty) {
      try {
        PostCodeAddress postCodeAddress = PostCodeAddress(
          url: json["url"],
          id: json["id"],
          postcode: addressInArray.first,
          line1: addressInArray[1],
          line2: addressInArray[2],
          line3: addressInArray[3],
          line4: addressInArray[4],
          city: addressInArray[5],
          locality: addressInArray[6],
          county: addressInArray[7],
          country: addressInArray[8],
        );
        return postCodeAddress;
      } catch (error) {
        return PostCodeAddress(
          url: json["url"],
          id: json["id"],
        );
      }

    } else {
      return PostCodeAddress(
        url: json["url"],
        id: json["id"],
      );
    }
  }
}