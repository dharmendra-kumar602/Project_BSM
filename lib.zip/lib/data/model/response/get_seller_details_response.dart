import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerDetailsResponse getSellerDetailsResponseFromJson(String str) => GetSellerDetailsResponse.fromJson(json.decode(str));

String getSellerDetailsResponseToJson(GetSellerDetailsResponse data) => json.encode(data.toJson());

class GetSellerDetailsResponse {
  final ResponseHeader responseHeader;
  final SellerData data;

  GetSellerDetailsResponse({
    required this.responseHeader,
    required this.data,
  });

  factory GetSellerDetailsResponse.fromJson(Map<String, dynamic> json) => GetSellerDetailsResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    data: SellerData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": data.toJson(),
  };
}

class SellerData {
  final int storeId;
  final String name;
  final int userId;
  final String description;
  final String profilePicture;
  bool? isBuyer;
  String? productId;
  String? productName;
  String? productImage;
  String? productPrice;

  SellerData({
    required this.storeId,
    required this.name,
    required this.userId,
    required this.description,
    required this.profilePicture,
    this.isBuyer = true,
    this.productId,
    this.productName,
    this.productPrice,
    this.productImage
  });

  factory SellerData.fromJson(Map<String, dynamic> json) => SellerData(
    storeId: json["storeId"],
    name: json["name"] ?? "",
    userId: json["userId"] ?? "",
    description: json["description"] ?? "",
    profilePicture: json["profilePicture"] ?? "",
  );

  Map<String, dynamic> toJson() => {
    "storeId": storeId,
    "name": name,
    "userId": userId,
    "description": description,
    "profilePicture": profilePicture,
  };
}