import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetTicketChatByUserIdResponse getTicketChatByUserIdResponseFromJson(String str) => GetTicketChatByUserIdResponse.fromJson(json.decode(str));

String getTicketChatByUserIdResponseToJson(GetTicketChatByUserIdResponse data) => json.encode(data.toJson());

class GetTicketChatByUserIdResponse {
  ResponseHeader? responseHeader;
  Chat? chat;

  GetTicketChatByUserIdResponse({
    this.responseHeader,
    this.chat,
  });

  factory GetTicketChatByUserIdResponse.fromJson(Map<String, dynamic> json) => GetTicketChatByUserIdResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    chat: json["chat"] == null ? null : Chat.fromJson(json["chat"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "chat": chat?.toJson(),
  };
}

class Chat {
  List<TicketChat>? ticketChat;
  String? status;

  Chat({
    this.ticketChat,
    this.status,
  });

  factory Chat.fromJson(Map<String, dynamic> json) => Chat(
    ticketChat: json["ticketChat"] == null ? [] : List<TicketChat>.from(json["ticketChat"]!.map((x) => TicketChat.fromJson(x))),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "ticketChat": ticketChat == null ? [] : List<dynamic>.from(ticketChat!.map((x) => x.toJson())),
    "status": status,
  };
}

class TicketChat {
  int? id;
  String? msg;
  int? ticketId;
  DateTime? createdAt;
  DateTime? updatedAt;
  dynamic userType;
  int? userId;
  dynamic fileName;

  TicketChat({
    this.id,
    this.msg,
    this.ticketId,
    this.createdAt,
    this.updatedAt,
    this.userType,
    this.userId,
    this.fileName,
  });

  factory TicketChat.fromJson(Map<String, dynamic> json) => TicketChat(
    id: json["id"],
    msg: json["msg"],
    ticketId: json["ticketId"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    userType: json["userType"],
    userId: json["userId"],
    fileName: json["fileName"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "msg": msg,
    "ticketId": ticketId,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "userType": userType,
    "userId": userId,
    "fileName": fileName,
  };
}