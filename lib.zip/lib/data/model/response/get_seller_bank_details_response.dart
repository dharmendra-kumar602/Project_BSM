import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerBankDetailsResponse getSellerBankDetailsResponseFromJson(String str) => GetSellerBankDetailsResponse.fromJson(json.decode(str));

String getSellerBankDetailsResponseToJson(GetSellerBankDetailsResponse data) => json.encode(data.toJson());

class GetSellerBankDetailsResponse {
  ResponseHeader? responseHeader;
  BankData? data;

  GetSellerBankDetailsResponse({
    this.responseHeader,
    this.data,
  });

  factory GetSellerBankDetailsResponse.fromJson(Map<String, dynamic> json) => GetSellerBankDetailsResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : BankData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class BankData {
  int? id;
  int? userId;
  String? bankName;
  String? ifsc;
  String? accountNumber;
  String? accountHolderName;

  BankData({
    this.id,
    this.userId,
    this.bankName,
    this.ifsc,
    this.accountNumber,
    this.accountHolderName,
  });

  factory BankData.fromJson(Map<String, dynamic> json) => BankData(
    id: json["id"],
    userId: json["userId"],
    bankName: json["bankName"],
    ifsc: json["IFSC"],
    accountNumber: json["accountNumber"],
    accountHolderName: json["accountHolderName"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "bankName": bankName,
    "IFSC": ifsc,
    "accountNumber": accountNumber,
    "accountHolderName": accountHolderName,
  };
}