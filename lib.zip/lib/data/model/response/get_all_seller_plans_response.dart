import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetAllSellerPlansResponse getAllSellerPlansResponseFromJson(String str) => GetAllSellerPlansResponse.fromJson(json.decode(str));

String getAllSellerPlansResponseToJson(GetAllSellerPlansResponse data) => json.encode(data.toJson());

class GetAllSellerPlansResponse {
  final ResponseHeader responseHeader;
  final List<SellerPlan> sellerPlans;

  GetAllSellerPlansResponse({
    required this.responseHeader,
    required this.sellerPlans,
  });

  factory GetAllSellerPlansResponse.fromJson(Map<String, dynamic> json) => GetAllSellerPlansResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    sellerPlans: List<SellerPlan>.from(json["sellerPlans"].map((x) => SellerPlan.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "sellerPlans": List<dynamic>.from(sellerPlans.map((x) => x.toJson())),
  };
}

class SellerPlan {
  final String title;
  final dynamic cost;
  final String description;

  SellerPlan({
    required this.title,
    this.cost,
    required this.description,
  });

  factory SellerPlan.fromJson(Map<String, dynamic> json) => SellerPlan(
    title: json["title"],
    cost: json["cost"],
    description: json["description"],
  );

  Map<String, dynamic> toJson() => {
    "title": title,
    "cost": cost,
    "description": description,
  };
}
