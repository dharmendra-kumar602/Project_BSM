import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

DeleteCartItemResponse deleteCartItemResponseFromJson(String str) => DeleteCartItemResponse.fromJson(json.decode(str));

String deleteCartItemResponseToJson(DeleteCartItemResponse data) => json.encode(data.toJson());

class DeleteCartItemResponse {
  final ResponseHeader responseHeader;
  int? data;

  DeleteCartItemResponse({
    required this.responseHeader,
    this.data,
  });

  factory DeleteCartItemResponse.fromJson(Map<String, dynamic> json) {
    if (json["data"] == null) {
      return DeleteCartItemResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return DeleteCartItemResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: json["data"],
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": data,
  };
}
