import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/model/response/get_order_item_response.dart';

GetOrderDetailResponse getOrderDetailResponseFromJson(String str) => GetOrderDetailResponse.fromJson(json.decode(str));

String getOrderDetailResponseToJson(GetOrderDetailResponse data) => json.encode(data.toJson());

class GetOrderDetailResponse {
  ResponseHeader? responseHeader;
  OrderDetails? orderDetails;

  GetOrderDetailResponse({
    this.responseHeader,
    this.orderDetails,
  });

  factory GetOrderDetailResponse.fromJson(Map<String, dynamic> json) => GetOrderDetailResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    orderDetails: json["orderDetails"] == null ? null : OrderDetails.fromJson(json["orderDetails"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "orderDetails": orderDetails?.toJson(),
  };
}

class OrderDetails {
  int? id;
  int? userId;
  String? paymentStatus;
  int? cartSubCost;
  int? taxInPercentage;
  int? deliveryAddressId;
  String? paymentMethod;
  List<ShippingCostDetail>? shippingCostDetails;
  int? totalHandlingCharges;
  int? totalShippingCharges;
  dynamic paymentIntentId;
  DateTime? createdAt;
  DateTime? updatedAt;
  DeliveryAddress? deliveryAddress;
  List<OrderPaymentMapping>? orderPaymentMappings;
  double? grandTotal;
  List<SellerElement>? sellers;
  List<ShippingSummary>? shippingSummary;
  int? tax;

  OrderDetails({
    this.id,
    this.userId,
    this.paymentStatus,
    this.cartSubCost,
    this.taxInPercentage,
    this.deliveryAddressId,
    this.paymentMethod,
    this.shippingCostDetails,
    this.totalHandlingCharges,
    this.totalShippingCharges,
    this.paymentIntentId,
    this.createdAt,
    this.updatedAt,
    this.deliveryAddress,
    this.orderPaymentMappings,
    this.grandTotal,
    this.sellers,
    this.shippingSummary,
    this.tax,
  });

  factory OrderDetails.fromJson(Map<String, dynamic> json) => OrderDetails(
    id: json["id"],
    userId: json["userId"],
    paymentStatus: json["paymentStatus"],
    cartSubCost: json["cartSubCost"],
    taxInPercentage: json["taxInPercentage"],
    deliveryAddressId: json["deliveryAddressId"],
    paymentMethod: json["paymentMethod"],
    shippingCostDetails: json["shippingCostDetails"] == null ? [] : List<ShippingCostDetail>.from(json["shippingCostDetails"]!.map((x) => ShippingCostDetail.fromJson(x))),
    totalHandlingCharges: json["totalHandlingCharges"],
    totalShippingCharges: json["totalShippingCharges"],
    paymentIntentId: json["paymentIntentId"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    deliveryAddress: json["deliveryAddress"] == null ? null : DeliveryAddress.fromJson(json["deliveryAddress"]),
    orderPaymentMappings: json["order_payment_mappings"] == null ? [] : List<OrderPaymentMapping>.from(json["order_payment_mappings"]!.map((x) => OrderPaymentMapping.fromJson(x))),
    grandTotal: json["grandTotal"]?.toDouble(),
    sellers: json["sellers"] == null ? [] : List<SellerElement>.from(json["sellers"]!.map((x) => SellerElement.fromJson(x))),
    shippingSummary: json["shippingSummary"] == null ? [] : List<ShippingSummary>.from(json["shippingSummary"]!.map((x) => ShippingSummary.fromJson(x))),
    tax: json["tax"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "paymentStatus": paymentStatus,
    "cartSubCost": cartSubCost,
    "taxInPercentage": taxInPercentage,
    "deliveryAddressId": deliveryAddressId,
    "paymentMethod": paymentMethod,
    "shippingCostDetails": shippingCostDetails == null ? [] : List<dynamic>.from(shippingCostDetails!.map((x) => x.toJson())),
    "totalHandlingCharges": totalHandlingCharges,
    "totalShippingCharges": totalShippingCharges,
    "paymentIntentId": paymentIntentId,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "deliveryAddress": deliveryAddress?.toJson(),
    "order_payment_mappings": orderPaymentMappings == null ? [] : List<dynamic>.from(orderPaymentMappings!.map((x) => x.toJson())),
    "grandTotal": grandTotal,
    "sellers": sellers == null ? [] : List<dynamic>.from(sellers!.map((x) => x.toJson())),
    "shippingSummary": shippingSummary == null ? [] : List<dynamic>.from(shippingSummary!.map((x) => x.toJson())),
    "tax": tax,
  };
}

class DeliveryAddress {
  int? id;
  int? userId;
  String? address1;
  dynamic address2;
  String? postCode;
  String? city;
  String? state;
  String? country;
  String? street;
  String? firstName;
  dynamic lastName;
  String? phoneNumber;
  int? isDefault;
  DateTime? createdAt;
  DateTime? updatedAt;

  DeliveryAddress({
    this.id,
    this.userId,
    this.address1,
    this.address2,
    this.postCode,
    this.city,
    this.state,
    this.country,
    this.street,
    this.firstName,
    this.lastName,
    this.phoneNumber,
    this.isDefault,
    this.createdAt,
    this.updatedAt,
  });

  factory DeliveryAddress.fromJson(Map<String, dynamic> json) => DeliveryAddress(
    id: json["id"],
    userId: json["userId"],
    address1: json["address1"],
    address2: json["address2"],
    postCode: json["postCode"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
    street: json["street"],
    firstName: json["firstName"],
    lastName: json["lastName"],
    phoneNumber: json["phoneNumber"],
    isDefault: json["isDefault"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "address1": address1,
    "address2": address2,
    "postCode": postCode,
    "city": city,
    "state": state,
    "country": country,
    "street": street,
    "firstName": firstName,
    "lastName": lastName,
    "phoneNumber": phoneNumber,
    "isDefault": isDefault,
    "createdAt": "${createdAt!.year.toString().padLeft(4, '0')}-${createdAt!.month.toString().padLeft(2, '0')}-${createdAt!.day.toString().padLeft(2, '0')}",
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
  };
}

class OrderPaymentMapping {
  int? id;
  int? orderId;
  String? paymentType;
  String? paymenIntentId;
  String? paymentStatus;
  DateTime? createdAt;
  DateTime? updatedAt;

  OrderPaymentMapping({
    this.id,
    this.orderId,
    this.paymentType,
    this.paymenIntentId,
    this.paymentStatus,
    this.createdAt,
    this.updatedAt,
  });

  factory OrderPaymentMapping.fromJson(Map<String, dynamic> json) => OrderPaymentMapping(
    id: json["id"],
    orderId: json["orderId"],
    paymentType: json["paymentType"],
    paymenIntentId: json["paymenIntentId"],
    paymentStatus: json["payment_status"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "paymentType": paymentType,
    "paymenIntentId": paymenIntentId,
    "payment_status": paymentStatus,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}

class SellerElement {
  SellerSeller? seller;
  int? subCost;
  List<Order>? orders;

  SellerElement({
    this.seller,
    this.subCost,
    this.orders,
  });

  factory SellerElement.fromJson(Map<String, dynamic> json) => SellerElement(
    seller: json["seller"] == null ? null : SellerSeller.fromJson(json["seller"]),
    subCost: json["subCost"],
    orders: json["orders"] == null ? [] : List<Order>.from(json["orders"]!.map((x) => Order.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "seller": seller?.toJson(),
    "subCost": subCost,
    "orders": orders == null ? [] : List<dynamic>.from(orders!.map((x) => x.toJson())),
  };
}

class Order {
  bool? isSelected;
  int? id;
  int? orderId;
  int? sellerStoreId;
  int? productId;
  int? productVariationId;
  String? productName;
  String? productDescription;
  String? productImage;
  int? salePrice;
  int? maxRetailPrice;
  String? shippingMethod;
  String? status;
  int? quantity;
  ProductDetailsInJson? productDetailsInJson;
  List<OrderedItemStatus>? orderedItemStatuses;
  ProductVariation? productVariation;

  Order({
    this.isSelected = false,
    this.id,
    this.orderId,
    this.sellerStoreId,
    this.productId,
    this.productVariationId,
    this.productName,
    this.productDescription,
    this.productImage,
    this.salePrice,
    this.maxRetailPrice,
    this.shippingMethod,
    this.status,
    this.quantity,
    this.productDetailsInJson,
    this.orderedItemStatuses,
    this.productVariation,
  });

  factory Order.fromJson(Map<String, dynamic> json) => Order(
    id: json["id"],
    orderId: json["orderId"],
    sellerStoreId: json["sellerStoreId"],
    productId: json["productId"],
    productVariationId: json["productVariationId"],
    productName: json["productName"],
    productDescription: json["productDescription"],
    productImage: json["productImage"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    shippingMethod: json["shippingMethod"],
    status: json["status"],
    quantity: json["quantity"],
    productDetailsInJson: json["productDetailsInJSON"] == null ? null : ProductDetailsInJson.fromJson(json["productDetailsInJSON"]),
    orderedItemStatuses: json["ordered_item_statuses"] == null ? [] : List<OrderedItemStatus>.from(json["ordered_item_statuses"]!.map((x) => OrderedItemStatus.fromJson(x))),
    productVariation: json["productVariation"] == null ? null : ProductVariation.fromJson(json["productVariation"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "sellerStoreId": sellerStoreId,
    "productId": productId,
    "productVariationId": productVariationId,
    "productName": productName,
    "productDescription": productDescription,
    "productImage": productImage,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "shippingMethod": shippingMethod,
    "status": status,
    "quantity": quantity,
    "productDetailsInJSON": productDetailsInJson?.toJson(),
    "ordered_item_statuses": orderedItemStatuses == null ? [] : List<OrderedItemStatus>.from(orderedItemStatuses!.map((x) => x.toJson())),
    "productVariation": productVariation?.toJson(),
  };
}

class ProductDetailsInJson {
  DeliveryAddress? deliveryAddress;
  PickupAddress? pickupAddress;
  List<Size>? sizes;

  ProductDetailsInJson({
    this.deliveryAddress,
    this.pickupAddress,
    this.sizes,
  });

  factory ProductDetailsInJson.fromJson(Map<String, dynamic> json) => ProductDetailsInJson(
    deliveryAddress: json["deliveryAddress"] == null ? null : DeliveryAddress.fromJson(json["deliveryAddress"]),
    pickupAddress: json["pickupAddress"] == null ? null : PickupAddress.fromJson(json["pickupAddress"]),
    sizes: json["sizes"] == null ? [] : List<Size>.from(json["sizes"]!.map((x) => Size.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "deliveryAddress": deliveryAddress?.toJson(),
    "pickupAddress": pickupAddress?.toJson(),
    "sizes": sizes == null ? [] : List<dynamic>.from(sizes!.map((x) => x.toJson())),
  };
}

class PickupAddress {
  String? name;
  String? addressLine1;
  String? addressLine2;
  String? city;
  String? country;
  String? postCode;
  String? contact;

  PickupAddress({
    this.name,
    this.addressLine1,
    this.addressLine2,
    this.city,
    this.country,
    this.postCode,
    this.contact,
  });

  factory PickupAddress.fromJson(Map<String, dynamic> json) => PickupAddress(
    name: json["name"],
    addressLine1: json["addressLine1"],
    addressLine2: json["addressLine2"],
    city: json["city"],
    country: json["country"],
    postCode: json["postCode"],
    contact: json["contact"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "country": country,
    "postCode": postCode,
    "contact": contact,
  };
}

class Size {
  int? variationId;
  Attributes? attributes;

  Size({
    this.variationId,
    this.attributes,
  });

  factory Size.fromJson(Map<String, dynamic> json) => Size(
    variationId: json["variationId"],
    attributes: json["attributes"] == null ? null : Attributes.fromJson(json["attributes"]),
  );

  Map<String, dynamic> toJson() => {
    "variationId": variationId,
    "attributes": attributes?.toJson(),
  };
}

class ProductVariation {
  dynamic weightInPound;

  ProductVariation({
    this.weightInPound,
  });

  factory ProductVariation.fromJson(Map<String, dynamic> json) => ProductVariation(
    weightInPound: json["weightInPound"],
  );

  Map<String, dynamic> toJson() => {
    "weightInPound": weightInPound,
  };
}

class Attributes {
  String? size;

  Attributes({
    this.size,
  });

  factory Attributes.fromJson(Map<String, dynamic> json) => Attributes(
    size: json["size"],
  );

  Map<String, dynamic> toJson() => {
    "size": size,
  };
}

class SellerSeller {
  int? id;
  int? userId;
  String? name;
  String? email;
  String? addressLine1;
  String? addressLine2;
  String? city;
  String? storeImage;
  String? country;
  String? postCode;
  String? about;
  dynamic bankName;
  dynamic bankAddress;
  dynamic accountNumber;
  int? isFreeShippingEnabled;
  int? isPickupFromStoreEnabled;
  int? freeShippingMinimumCost;
  int? pickupFromStoreHandlingCharges;
  String? description;
  int? isVerified;
  int? isDocumentVerified;
  int? isActive;
  String? contact;
  dynamic sellerStatus;
  dynamic rejectionReason;
  DateTime? createdAt;
  DateTime? updatedAt;

  SellerSeller({
    this.id,
    this.userId,
    this.name,
    this.email,
    this.addressLine1,
    this.addressLine2,
    this.city,
    this.storeImage,
    this.country,
    this.postCode,
    this.about,
    this.bankName,
    this.bankAddress,
    this.accountNumber,
    this.isFreeShippingEnabled,
    this.isPickupFromStoreEnabled,
    this.freeShippingMinimumCost,
    this.pickupFromStoreHandlingCharges,
    this.description,
    this.isVerified,
    this.isDocumentVerified,
    this.isActive,
    this.contact,
    this.sellerStatus,
    this.rejectionReason,
    this.createdAt,
    this.updatedAt,
  });

  factory SellerSeller.fromJson(Map<String, dynamic> json) => SellerSeller(
    id: json["id"],
    userId: json["userId"],
    name: json["name"],
    email: json["email"],
    addressLine1: json["addressLine1"],
    addressLine2: json["addressLine2"],
    city: json["city"],
    storeImage: json["storeImage"],
    country: json["country"],
    postCode: json["postCode"],
    about: json["about"],
    bankName: json["bankName"],
    bankAddress: json["bankAddress"],
    accountNumber: json["accountNumber"],
    isFreeShippingEnabled: json["isFreeShippingEnabled"],
    isPickupFromStoreEnabled: json["isPickupFromStoreEnabled"],
    freeShippingMinimumCost: json["freeShippingMinimumCost"],
    pickupFromStoreHandlingCharges: json["pickupFromStoreHandlingCharges"],
    description: json["description"],
    isVerified: json["isVerified"],
    isDocumentVerified: json["isDocumentVerified"],
    isActive: json["isActive"],
    contact: json["contact"],
    sellerStatus: json["sellerStatus"],
    rejectionReason: json["rejectionReason"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "name": name,
    "email": email,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "storeImage": storeImage,
    "country": country,
    "postCode": postCode,
    "about": about,
    "bankName": bankName,
    "bankAddress": bankAddress,
    "accountNumber": accountNumber,
    "isFreeShippingEnabled": isFreeShippingEnabled,
    "isPickupFromStoreEnabled": isPickupFromStoreEnabled,
    "freeShippingMinimumCost": freeShippingMinimumCost,
    "pickupFromStoreHandlingCharges": pickupFromStoreHandlingCharges,
    "description": description,
    "isVerified": isVerified,
    "isDocumentVerified": isDocumentVerified,
    "isActive": isActive,
    "contact": contact,
    "sellerStatus": sellerStatus,
    "rejectionReason": rejectionReason,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}

class ShippingCostDetail {
  int? sellerId;
  int? totalWeightShippingCost;
  int? totalhandlingCharges;
  int? subCost;
  double? tax;

  ShippingCostDetail({
    this.sellerId,
    this.totalWeightShippingCost,
    this.totalhandlingCharges,
    this.subCost,
    this.tax,
  });

  factory ShippingCostDetail.fromJson(Map<String, dynamic> json) => ShippingCostDetail(
    sellerId: json["sellerId"],
    totalWeightShippingCost: json["totalWeightShippingCost"],
    totalhandlingCharges: json["totalhandlingCharges"],
    subCost: json["subCost"],
    tax: json["tax"]?.toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "sellerId": sellerId,
    "totalWeightShippingCost": totalWeightShippingCost,
    "totalhandlingCharges": totalhandlingCharges,
    "subCost": subCost,
    "tax": tax,
  };
}

class ShippingSummary {
  SellerSeller? seller;
  int? subCost;
  int? totalWeight;
  int? pickupFromStoreHandlingCharges;
  String? shippingMethod;
  int? totalWeightShippingCost;
  bool? freeShipping;

  ShippingSummary({
    this.seller,
    this.subCost,
    this.totalWeight,
    this.pickupFromStoreHandlingCharges,
    this.shippingMethod,
    this.totalWeightShippingCost,
    this.freeShipping,
  });

  factory ShippingSummary.fromJson(Map<String, dynamic> json) => ShippingSummary(
    seller: json["seller"] == null ? null : SellerSeller.fromJson(json["seller"]),
    subCost: json["subCost"],
    totalWeight: json["totalWeight"],
    pickupFromStoreHandlingCharges: json["pickupFromStoreHandlingCharges"],
    shippingMethod: json["shippingMethod"],
    totalWeightShippingCost: json["totalWeightShippingCost"],
    freeShipping: json["freeShipping"],
  );

  Map<String, dynamic> toJson() => {
    "seller": seller?.toJson(),
    "subCost": subCost,
    "totalWeight": totalWeight,
    "pickupFromStoreHandlingCharges": pickupFromStoreHandlingCharges,
    "shippingMethod": shippingMethod,
    "totalWeightShippingCost": totalWeightShippingCost,
    "freeShipping": freeShipping,
  };
}