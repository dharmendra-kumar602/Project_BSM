import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PutChangeCartQuantityResponse putChangeCartQuantityResponseFromJson(String str) => PutChangeCartQuantityResponse.fromJson(json.decode(str));

String putChangeCartQuantityResponseToJson(PutChangeCartQuantityResponse data) => json.encode(data.toJson());

class PutChangeCartQuantityResponse {
  final ResponseHeader responseHeader;

  PutChangeCartQuantityResponse({
    required this.responseHeader,
  });

  factory PutChangeCartQuantityResponse.fromJson(Map<String, dynamic> json) => PutChangeCartQuantityResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
  };
}