import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetNotificationsResponse getNotificationsResponseFromJson(String str) => GetNotificationsResponse.fromJson(json.decode(str));

String getNotificationsResponseToJson(GetNotificationsResponse data) => json.encode(data.toJson());

class GetNotificationsResponse {
  ResponseHeader? responseHeader;
  List<NotificationData>? data;

  GetNotificationsResponse({
    this.responseHeader,
    this.data,
  });

  factory GetNotificationsResponse.fromJson(Map<String, dynamic> json) => GetNotificationsResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? [] : List<NotificationData>.from(json["data"]!.map((x) => NotificationData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class NotificationData {
  int? id;
  int? isRead;
  int? fromUserId;
  int? toUserId;
  String? text;
  String? notificationType;
  DateTime? createdAt;
  DateTime? updatedAt;
  dynamic price;
  String? subText;
  String? title;
  String? userRole;
  String? notificationRelatedTo;
  int? notificationRelationId;
  String? image;

  NotificationData({
    this.id,
    this.isRead,
    this.fromUserId,
    this.toUserId,
    this.text,
    this.notificationType,
    this.createdAt,
    this.updatedAt,
    this.price,
    this.subText,
    this.title,
    this.userRole,
    this.notificationRelatedTo,
    this.notificationRelationId,
    this.image,
  });

  factory NotificationData.fromJson(Map<String, dynamic> json) => NotificationData(
    id: json["id"],
    isRead: json["isRead"],
    fromUserId: json["fromUserId"],
    toUserId: json["toUserId"],
    text: json["text"],
    notificationType: json["notificationType"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    price: json["price"],
    subText: json["subText"],
    title: json["title"],
    userRole: json["userRole"],
    notificationRelatedTo: json["notificationRelatedTo"],
    notificationRelationId: json["notificationRelationId"],
    image: json["image "],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "isRead": isRead,
    "fromUserId": fromUserId,
    "toUserId": toUserId,
    "text": text,
    "notificationType": notificationType,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "price": price,
    "subText": subText,
    "title": title,
    "userRole": userRole,
    "notificationRelatedTo": notificationRelatedTo,
    "notificationRelationId": notificationRelationId,
    "image ": image,
  };
}