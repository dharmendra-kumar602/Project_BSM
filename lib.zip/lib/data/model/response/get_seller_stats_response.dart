import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerMediaStatsResponse getSellerMediaStatsResponseFromJson(String str) => GetSellerMediaStatsResponse.fromJson(json.decode(str));

String getSellerMediaStatsResponseToJson(GetSellerMediaStatsResponse data) => json.encode(data.toJson());

class GetSellerMediaStatsResponse {
  ResponseHeader? responseHeader;
  StatsData? data;

  GetSellerMediaStatsResponse({
    this.responseHeader,
    this.data,
  });

  factory GetSellerMediaStatsResponse.fromJson(Map<String, dynamic> json) => GetSellerMediaStatsResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : StatsData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class StatsData {
  int? mediaCount;
  int? docsCount;
  double? usedSize;
  double? media;
  double? documents;
  int? allowedStorage;

  StatsData({
    this.mediaCount,
    this.docsCount,
    this.usedSize,
    this.media,
    this.documents,
    this.allowedStorage,
  });

  factory StatsData.fromJson(Map<String, dynamic> json) => StatsData(
    mediaCount: json["mediaCount"],
    docsCount: json["docsCount"],
    usedSize: json["usedSize"]?.toDouble(),
    media: json["media"]?.toDouble(),
    documents: json["documents"]?.toDouble(),
    allowedStorage: json["allowedStorage"],
  );

  Map<String, dynamic> toJson() => {
    "mediaCount": mediaCount,
    "docsCount": docsCount,
    "usedSize": usedSize,
    "media": media,
    "documents": documents,
    "allowedStorage": allowedStorage,
  };
}