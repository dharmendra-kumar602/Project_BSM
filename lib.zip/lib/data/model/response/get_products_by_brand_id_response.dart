import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetBrandProductsListResponse getBrandProductsListResponseFromJson(String str) => GetBrandProductsListResponse.fromJson(json.decode(str));

String getBrandListResponseToJson(GetBrandProductsListResponse data) => json.encode(data.toJson());

class GetBrandProductsListResponse {
  ResponseHeader? responseHeader;
  List<BrandProductData>? data;

  GetBrandProductsListResponse({
    this.responseHeader,
    this.data,
  });

  factory GetBrandProductsListResponse.fromJson(Map<String, dynamic> json) => GetBrandProductsListResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? [] : List<BrandProductData>.from(json["data"]!.map((x) => BrandProductData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class BrandProductData {
  bool? isLiked;
  int? id;
  String? title;
  int? sellerStoreId;
  String? description;
  int? badgeId;
  String? processingTime;
  DateTime? createdAt;
  DateTime? updatedAt;
  List<BProductVariation>? productVariations;
  BBadge? badge;
  Brand? brand;
  bool? isInCart;

  BrandProductData({
    this.isLiked,
    this.id,
    this.title,
    this.sellerStoreId,
    this.description,
    this.badgeId,
    this.processingTime,
    this.createdAt,
    this.updatedAt,
    this.productVariations,
    this.badge,
    this.brand,
    this.isInCart,
  });

  factory BrandProductData.fromJson(Map<String, dynamic> json) => BrandProductData(
    id: json["id"],
    title: json["title"],
    sellerStoreId: json["sellerStoreId"],
    description: json["description"],
    badgeId: json["badgeId"],
    processingTime: json["processingTime"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    productVariations: json["product_variations"] == null ? [] : List<BProductVariation>.from(json["product_variations"]!.map((x) => BProductVariation.fromJson(x))),
    badge: json["badge"] == null ? null : BBadge.fromJson(json["badge"]),
    brand: json["brand"] == null ? null : Brand.fromJson(json["brand"]),
    isInCart: json["isInCart"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "sellerStoreId": sellerStoreId,
    "description": description,
    "badgeId": badgeId,
    "processingTime": processingTime,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
    "product_variations": productVariations == null ? [] : List<dynamic>.from(productVariations!.map((x) => x.toJson())),
    "badge": badge?.toJson(),
    "brand": brand?.toJson(),
    "isInCart": isInCart,
  };
}

class BBadge {
  String? name;
  String? title;
  String? image;
  String? description;

  BBadge({
    this.name,
    this.title,
    this.image,
    this.description,
  });

  factory BBadge.fromJson(Map<String, dynamic> json) => BBadge(
    name: json["name"],
    title: json["title"],
    image: json["image"],
    description: json["description"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "title": title,
    "image": image,
    "description": description,
  };
}

class Brand {
  int? id;
  String? name;

  Brand({
    this.id,
    this.name,
  });

  factory Brand.fromJson(Map<String, dynamic> json) => Brand(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}

class BProductVariation {
  int? id;
  dynamic? salePrice;
  dynamic? maxRetailPrice;
  dynamic discountInPercent;
  int? isInWishlist;
  String? approvalStatus;
  String? condition;
  dynamic? weight;
  dynamic? height;
  dynamic? width;
  dynamic? length;
  List<BProductImage>? productImages;
  List<ProductAttributeMapping>? productAttributeMappings;

  BProductVariation({
    this.id,
    this.salePrice,
    this.maxRetailPrice,
    this.discountInPercent,
    this.isInWishlist,
    this.approvalStatus,
    this.condition,
    this.weight,
    this.height,
    this.width,
    this.length,
    this.productImages,
    this.productAttributeMappings,
  });

  factory BProductVariation.fromJson(Map<String, dynamic> json) => BProductVariation(
    id: json["id"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    discountInPercent: json["discountInPercent"],
    isInWishlist: json["isInWishlist"],
    approvalStatus: json["approvalStatus"],
    condition: json["condition"],
    weight: json["weight"],
    height: json["height"],
    width: json["width"],
    length: json["length"],
    productImages: json["product_images"] == null ? [] : List<BProductImage>.from(json["product_images"]!.map((x) => BProductImage.fromJson(x))),
    productAttributeMappings: json["product_attribute_mappings"] == null ? [] : List<ProductAttributeMapping>.from(json["product_attribute_mappings"]!.map((x) => ProductAttributeMapping.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "discountInPercent": discountInPercent,
    "isInWishlist": isInWishlist,
    "approvalStatus": approvalStatus,
    "condition": condition,
    "weight": weight,
    "height": height,
    "width": width,
    "length": length,
    "product_images": productImages == null ? [] : List<dynamic>.from(productImages!.map((x) => x.toJson())),
    "product_attribute_mappings": productAttributeMappings == null ? [] : List<dynamic>.from(productAttributeMappings!.map((x) => x.toJson())),
  };
}

class ProductAttributeMapping {
  int? attributeId;
  String? value;

  ProductAttributeMapping({
    this.attributeId,
    this.value,
  });

  factory ProductAttributeMapping.fromJson(Map<String, dynamic> json) => ProductAttributeMapping(
    attributeId: json["attributeId"],
    value: json["value"],
  );

  Map<String, dynamic> toJson() => {
    "attributeId": attributeId,
    "value": value,
  };
}

class BProductImage {
  String? imageName;

  BProductImage({
    this.imageName,
  });

  factory BProductImage.fromJson(Map<String, dynamic> json) => BProductImage(
    imageName: json["imageName"],
  );

  Map<String, dynamic> toJson() => {
    "imageName": imageName,
  };
}