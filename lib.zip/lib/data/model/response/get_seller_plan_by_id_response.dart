import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerPlanByIdResponse getSellerPlanByIdResponseFromJson(String str) => GetSellerPlanByIdResponse.fromJson(json.decode(str));

String getSellerPlanByIdResponseToJson(GetSellerPlanByIdResponse data) => json.encode(data.toJson());

class GetSellerPlanByIdResponse {
  final ResponseHeader responseHeader;
  final PlanData data;

  GetSellerPlanByIdResponse({
    required this.responseHeader,
    required this.data,
  });

  factory GetSellerPlanByIdResponse.fromJson(Map<String, dynamic> json) => GetSellerPlanByIdResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    data: PlanData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": data.toJson(),
  };
}

class PlanData {
  final int id;
  final String title;
  final String description;
  final int cost;
  final dynamic image;
  final DateTime createdAt;
  final DateTime updatedAt;

  PlanData({
    required this.id,
    required this.title,
    required this.description,
    required this.cost,
    this.image,
    required this.createdAt,
    required this.updatedAt,
  });

  factory PlanData.fromJson(Map<String, dynamic> json) => PlanData(
    id: json["id"],
    title: json["title"],
    description: json["description"],
    cost: json["cost"],
    image: json["image"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "description": description,
    "cost": cost,
    "image": image,
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
  };
}