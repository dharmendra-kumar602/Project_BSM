import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetTopSellerResponse getTopSellerResponseFromJson(String str) => GetTopSellerResponse.fromJson(json.decode(str));

String getTopSellerResponseToJson(GetTopSellerResponse data) => json.encode(data.toJson());

class GetTopSellerResponse {
  ResponseHeader? responseHeader;
  TopSellerData? data;

  GetTopSellerResponse({
    this.responseHeader,
    this.data,
  });

  factory GetTopSellerResponse.fromJson(Map<String, dynamic> json) => GetTopSellerResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : TopSellerData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class TopSellerData {
  int? storeId;
  String? name;
  int? userId;
  String? description;
  int? orders;
  int? isTopSeller;
  String? profilePicture;

  TopSellerData({
    this.storeId,
    this.name,
    this.userId,
    this.description,
    this.orders,
    this.isTopSeller,
    this.profilePicture,
  });

  factory TopSellerData.fromJson(Map<String, dynamic> json) => TopSellerData(
    storeId: json["storeId"],
    name: json["name"],
    userId: json["userId"],
    description: json["description"],
    orders: json["orders"],
    isTopSeller: json["isTopSeller"],
    profilePicture: json["profilePicture"],
  );

  Map<String, dynamic> toJson() => {
    "storeId": storeId,
    "name": name,
    "userId": userId,
    "description": description,
    "orders": orders,
    "isTopSeller": isTopSeller,
    "profilePicture": profilePicture,
  };
}