import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostLoginResponse postLoginResponseFromJson(String str) => PostLoginResponse.fromJson(json.decode(str));

class PostLoginResponse {
  final ResponseHeader? responseHeader;
  final String? verificationStatus;
  final String? token;

  PostLoginResponse({
    this.responseHeader,
    this.verificationStatus,
    this.token,
  });

  factory PostLoginResponse.fromJson(Map<String, dynamic> json) => PostLoginResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    verificationStatus: json["verificationStatus"],
    token: json["jwt_token"] ?? "",
  );
}