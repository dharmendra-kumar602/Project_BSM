import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetProductFiltersResponse getProductFiltersResponseFromJson(String str) => GetProductFiltersResponse.fromJson(json.decode(str));

String getProductFiltersResponseToJson(GetProductFiltersResponse data) => json.encode(data.toJson());

class GetProductFiltersResponse {
  ResponseHeader? responseHeader;
  FilterData? data;

  GetProductFiltersResponse({
    this.responseHeader,
    this.data,
  });

  factory GetProductFiltersResponse.fromJson(Map<String, dynamic> json) => GetProductFiltersResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : FilterData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class FilterData {
  List<FilterCategory>? categories;
  List<Brand>? brands;
  List<Location>? location;
  List<Color>? color;
  List<Color>? size;
  List<Color>? material;
  List<Color>? tackType;
  List<Color>? filling;

  FilterData({
    this.categories,
    this.brands,
    this.location,
    this.color,
    this.size,
    this.material,
    this.tackType,
    this.filling,
  });

  factory FilterData.fromJson(Map<String, dynamic> json) => FilterData(
    categories: json["categories"] == null ? [] : List<FilterCategory>.from(json["categories"]!.map((x) => FilterCategory.fromJson(x))),
    brands: json["brands"] == null ? [] : List<Brand>.from(json["brands"]!.map((x) => Brand.fromJson(x))),
    location: json["location"] == null ? [] : List<Location>.from(json["location"]!.map((x) => Location.fromJson(x))),
    color: json["Colour"] == null ? [] : List<Color>.from(json["Colour"]!.map((x) => Color.fromJson(x))),
    size: json["Size"] == null ? [] : List<Color>.from(json["Size"]!.map((x) => Color.fromJson(x))),
    material: json["Material"] == null ? [] : List<Color>.from(json["Material"]!.map((x) => Color.fromJson(x))),
    tackType: json["Tack Type"] == null ? [] : List<Color>.from(json["Tack Type"]!.map((x) => Color.fromJson(x))),
    filling: json["Filling"] == null ? [] : List<Color>.from(json["Filling"]!.map((x) => Color.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "categories": categories == null ? [] : List<FilterCategory>.from(categories!.map((x) => x.toJson())),
    "brands": brands == null ? [] : List<dynamic>.from(brands!.map((x) => x.toJson())),
    "location": location == null ? [] : List<dynamic>.from(location!.map((x) => x.toJson())),
    "Colour": color == null ? [] : List<dynamic>.from(color!.map((x) => x.toJson())),
    "Size": size == null ? [] : List<dynamic>.from(size!.map((x) => x.toJson())),
    "Material": material == null ? [] : List<dynamic>.from(material!.map((x) => x.toJson())),
    "Tack Type": tackType == null ? [] : List<dynamic>.from(tackType!.map((x) => x.toJson())),
    "Filling": filling == null ? [] : List<dynamic>.from(filling!.map((x) => x.toJson())),
  };
}

class Brand {
  int? id;
  String? name;
  bool isSelected;

  Brand({
    this.id,
    this.name,
    this.isSelected = false
  });

  factory Brand.fromJson(Map<String, dynamic> json) => Brand(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}

class FilterCategory {
  int? id;
  String? name;
  int? parentCategory;
  String? imageName;
  String? iconName;
  String? description;
  String? thumbnailName;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? isActive;
  bool isSelected;

  FilterCategory({
    this.id,
    this.name,
    this.parentCategory,
    this.imageName,
    this.iconName,
    this.description,
    this.thumbnailName,
    this.createdAt,
    this.updatedAt,
    this.isActive,
    this.isSelected = false
  });

  factory FilterCategory.fromJson(Map<String, dynamic> json) => FilterCategory(
    id: json["id"],
    name: json["name"],
    parentCategory: json["parentCategory"],
    imageName: json["imageName"],
    iconName: json["iconName"],
    description: json["description"],
    thumbnailName: json["thumbnailName"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    isActive: json["isActive"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "parentCategory": parentCategory,
    "imageName": imageName,
    "iconName": iconName,
    "description": description,
    "thumbnailName": thumbnailName,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "isActive": isActive,
  };
}

class Color {
  int? id;
  String? value;
  bool isSelected;

  Color({
    this.id,
    this.value,
    this.isSelected = false
  });

  factory Color.fromJson(Map<String, dynamic> json) => Color(
    id: json["id"],
    value: json["value"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "value": value,
  };
}

class Location {
  int? id;
  int? sellerStoreId;
  String? address1;
  String? address2;
  String? postCode;
  String? city;
  String? state;
  String? country;
  String? street;
  String? firstName;
  String? phoneNumber;
  String? lastName;
  DateTime? createdAt;
  DateTime? updatedAt;
  bool isSelected;

  Location({
    this.id,
    this.sellerStoreId,
    this.address1,
    this.address2,
    this.postCode,
    this.city,
    this.state,
    this.country,
    this.street,
    this.firstName,
    this.phoneNumber,
    this.lastName,
    this.createdAt,
    this.updatedAt,
    this.isSelected = false
  });

  factory Location.fromJson(Map<String, dynamic> json) => Location(
    id: json["id"],
    sellerStoreId: json["sellerStoreId"],
    address1: json["address1"],
    address2: json["address2"],
    postCode: json["postCode"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
    street: json["street"],
    firstName: json["firstName"],
    phoneNumber: json["phoneNumber"],
    lastName: json["lastName"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "sellerStoreId": sellerStoreId,
    "address1": address1,
    "address2": address2,
    "postCode": postCode,
    "city": city,
    "state": state,
    "country": country,
    "street": street,
    "firstName": firstName,
    "phoneNumber": phoneNumber,
    "lastName": lastName,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}