import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerOrdersResponse getSellerOrdersResponseFromJson(String str) => GetSellerOrdersResponse.fromJson(json.decode(str));

String getSellerOrdersResponseToJson(GetSellerOrdersResponse data) => json.encode(data.toJson());

class GetSellerOrdersResponse {
  ResponseHeader? responseHeader;
  List<SellerOrderData>? data;

  GetSellerOrdersResponse({
    this.responseHeader,
    this.data,
  });

  factory GetSellerOrdersResponse.fromJson(Map<String, dynamic> json) => GetSellerOrdersResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? [] : List<SellerOrderData>.from(json["data"]!.map((x) => SellerOrderData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class SellerOrderData {
  int? id;
  int? userId;
  dynamic? paymentStatus;
  dynamic? cartSubCost;
  dynamic? paymentMethod;
  DateTime? createdAt;
  DateTime? updatedAt;
  List<OrderedItem>? orderedItems;
  User? user;
  List<OrderPaymentMapping>? orderPaymentMappings;
  dynamic? weight;
  dynamic? status;
  dynamic? shippingMethod;
  dynamic? vat;
  dynamic? pickupCharges;
  dynamic? totalAmount;
  dynamic? orderAmount;
  dynamic? shippingCharges;

  SellerOrderData({
    this.id,
    this.userId,
    this.paymentStatus,
    this.cartSubCost,
    this.paymentMethod,
    this.createdAt,
    this.updatedAt,
    this.orderedItems,
    this.user,
    this.orderPaymentMappings,
    this.weight,
    this.status,
    this.shippingMethod,
    this.vat,
    this.pickupCharges,
    this.totalAmount,
    this.orderAmount,
    this.shippingCharges,
  });

  factory SellerOrderData.fromJson(Map<String, dynamic> json) => SellerOrderData(
    id: json["id"],
    userId: json["userId"],
    paymentStatus: json["paymentStatus"],
    cartSubCost: json["cartSubCost"],
    paymentMethod: json["paymentMethod"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    orderedItems: json["ordered_items"] == null ? [] : List<OrderedItem>.from(json["ordered_items"]!.map((x) => OrderedItem.fromJson(x))),
    user: json["user"] == null ? null : User.fromJson(json["user"]),
    orderPaymentMappings: json["order_payment_mappings"] == null ? [] : List<OrderPaymentMapping>.from(json["order_payment_mappings"]!.map((x) => OrderPaymentMapping.fromJson(x))),
    weight: json["weight"],
    status: json["status"],
    shippingMethod: json["shippingMethod"],
    vat: json["VAT"]?.toDouble(),
    pickupCharges: json["pickupCharges"],
    totalAmount: json["totalAmount"]?.toDouble(),
    orderAmount: json["orderAmount"]?.toDouble(),
    shippingCharges: json["shippingCharges"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "paymentStatus": paymentStatus,
    "cartSubCost": cartSubCost,
    "paymentMethod": paymentMethod,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "ordered_items": orderedItems == null ? [] : List<dynamic>.from(orderedItems!.map((x) => x.toJson())),
    "user": user?.toJson(),
    "order_payment_mappings": orderPaymentMappings == null ? [] : List<dynamic>.from(orderPaymentMappings!.map((x) => x.toJson())),
    "weight": weight,
    "status": status,
    "shippingMethod": shippingMethod,
    "VAT": vat,
    "pickupCharges": pickupCharges,
    "totalAmount": totalAmount,
    "orderAmount": orderAmount,
    "shippingCharges": shippingCharges,
  };
}

class OrderPaymentMapping {
  int? id;
  int? orderId;
  String? paymentType;
  String? paymenIntentId;
  String? paymentStatus;
  DateTime? createdAt;
  DateTime? updatedAt;

  OrderPaymentMapping({
    this.id,
    this.orderId,
    this.paymentType,
    this.paymenIntentId,
    this.paymentStatus,
    this.createdAt,
    this.updatedAt,
  });

  factory OrderPaymentMapping.fromJson(Map<String, dynamic> json) => OrderPaymentMapping(
    id: json["id"],
    orderId: json["orderId"],
    paymentType: json["paymentType"],
    paymenIntentId: json["paymenIntentId"],
    paymentStatus: json["payment_status"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "paymentType": paymentType,
    "paymenIntentId": paymenIntentId,
    "payment_status": paymentStatus,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}

class OrderedItem {
  int? id;
  int? orderId;
  int? sellerStoreId;
  int? productId;
  int? productVariationId;
  dynamic? salePrice;
  dynamic? maxRetailPrice;
  dynamic? shippingMethod;
  ProductdetailsInJson? productdetailsInJson;
  dynamic? status;
  int? quantity;
  String? productName;
  String? productDescription;
  String? productImage;
  ProductVariation? productVariation;

  OrderedItem({
    this.id,
    this.orderId,
    this.sellerStoreId,
    this.productId,
    this.productVariationId,
    this.salePrice,
    this.maxRetailPrice,
    this.shippingMethod,
    this.productdetailsInJson,
    this.status,
    this.quantity,
    this.productName,
    this.productDescription,
    this.productImage,
    this.productVariation,
  });

  factory OrderedItem.fromJson(Map<String, dynamic> json) => OrderedItem(
    id: json["id"],
    orderId: json["orderId"],
    sellerStoreId: json["sellerStoreId"],
    productId: json["productId"],
    productVariationId: json["productVariationId"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    shippingMethod: json["shippingMethod"],
    productdetailsInJson: json["productdetailsInJSON"] == null ? null : ProductdetailsInJson.fromJson(jsonDecode(json["productdetailsInJSON"])),
    status: json["status"],
    quantity: json["quantity"],
    productName: json["productName"],
    productDescription: json["productDescription"],
    productImage: json["productImage"],
    productVariation: json["productVariation"] == null ? null : ProductVariation.fromJson(json["productVariation"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "sellerStoreId": sellerStoreId,
    "productId": productId,
    "productVariationId": productVariationId,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "shippingMethod": shippingMethod,
    "productdetailsInJSON": productdetailsInJson?.toJson(),
    "status": status,
    "quantity": quantity,
    "productName": productName,
    "productDescription": productDescription,
    "productImage": productImage,
    "productVariation": productVariation?.toJson(),
  };
}

class ProductVariation {
  dynamic? weightInPound;

  ProductVariation({
    this.weightInPound,
  });

  factory ProductVariation.fromJson(Map<String, dynamic> json) => ProductVariation(
    weightInPound: json["weightInPound"],
  );

  Map<String, dynamic> toJson() => {
    "weightInPound": weightInPound,
  };
}

class ProductdetailsInJson {
  DeliveryAddress? deliveryAddress;
  PickupAddress? pickupAddress;
  List<Size>? sizes;

  ProductdetailsInJson({
    this.deliveryAddress,
    this.pickupAddress,
    this.sizes,
  });

  factory ProductdetailsInJson.fromJson(Map<String, dynamic> json) => ProductdetailsInJson(
    deliveryAddress: json["deliveryAddress"] == null ? null : DeliveryAddress.fromJson(json["deliveryAddress"]),
    pickupAddress: json["pickupAddress"] == null ? null : PickupAddress.fromJson(json["pickupAddress"]),
    sizes: json["sizes"] == null ? [] : List<Size>.from(json["sizes"]!.map((x) => Size.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "deliveryAddress": deliveryAddress?.toJson(),
    "pickupAddress": pickupAddress?.toJson(),
    "sizes": sizes == null ? [] : List<dynamic>.from(sizes!.map((x) => x.toJson())),
  };
}

class DeliveryAddress {
  int? id;
  int? userId;
  String? address1;
  dynamic address2;
  String? postCode;
  dynamic? city;
  String? state;
  dynamic? country;
  String? street;
  dynamic? firstName;
  dynamic lastName;
  String? phoneNumber;
  int? isDefault;
  DateTime? createdAt;
  DateTime? updatedAt;

  DeliveryAddress({
    this.id,
    this.userId,
    this.address1,
    this.address2,
    this.postCode,
    this.city,
    this.state,
    this.country,
    this.street,
    this.firstName,
    this.lastName,
    this.phoneNumber,
    this.isDefault,
    this.createdAt,
    this.updatedAt,
  });

  factory DeliveryAddress.fromJson(Map<String, dynamic> json) => DeliveryAddress(
    id: json["id"],
    userId: json["userId"],
    address1: json["address1"],
    address2: json["address2"],
    postCode: json["postCode"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
    street: json["street"],
    firstName: json["firstName"],
    lastName: json["lastName"],
    phoneNumber: json["phoneNumber"],
    isDefault: json["isDefault"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "address1": address1,
    "address2": address2,
    "postCode": postCode,
    "city": city,
    "state": state,
    "country": country,
    "street": street,
    "firstName": firstName,
    "lastName": lastName,
    "phoneNumber": phoneNumber,
    "isDefault": isDefault,
    "createdAt": "${createdAt!.year.toString().padLeft(4, '0')}-${createdAt!.month.toString().padLeft(2, '0')}-${createdAt!.day.toString().padLeft(2, '0')}",
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
  };
}

class PickupAddress {
  dynamic? name;
  dynamic? addressLine1;
  dynamic? addressLine2;
  dynamic? city;
  dynamic? country;
  String? postCode;
  String? contact;

  PickupAddress({
    this.name,
    this.addressLine1,
    this.addressLine2,
    this.city,
    this.country,
    this.postCode,
    this.contact,
  });

  factory PickupAddress.fromJson(Map<String, dynamic> json) => PickupAddress(
    name: json["name"],
    addressLine1: json["addressLine1"],
    addressLine2: json["addressLine2"],
    city: json["city"],
    country: json["country"],
    postCode: json["postCode"],
    contact: json["contact"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "country": country,
    "postCode": postCode,
    "contact": contact,
  };
}

class Size {
  int? variationId;
  Attributes? attributes;

  Size({
    this.variationId,
    this.attributes,
  });

  factory Size.fromJson(Map<String, dynamic> json) => Size(
    variationId: json["variationId"],
    attributes: json["attributes"] == null ? null : Attributes.fromJson(json["attributes"]),
  );

  Map<String, dynamic> toJson() => {
    "variationId": variationId,
    "attributes": attributes?.toJson(),
  };
}

class Attributes {
  String? size;

  Attributes({
    this.size,
  });

  factory Attributes.fromJson(Map<String, dynamic> json) => Attributes(
    size: json["size"],
  );

  Map<String, dynamic> toJson() => {
    "size": size,
  };
}

class User {
  dynamic? firstName;
  dynamic middleName;
  dynamic? lastName;

  User({
    this.firstName,
    this.middleName,
    this.lastName,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    firstName: json["firstName"],
    middleName: json["middleName"],
    lastName: json["lastName"],
  );

  Map<String, dynamic> toJson() => {
    "firstName": firstName,
    "middleName": middleName,
    "lastName": lastName,
  };
}
