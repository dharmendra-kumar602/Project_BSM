import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetDeliveryAddressResponse getDeliveryAddressResponseFromJson(String str) => GetDeliveryAddressResponse.fromJson(json.decode(str));

String getDeliveryAddressResponseToJson(GetDeliveryAddressResponse data) => json.encode(data.toJson());

class GetDeliveryAddressResponse {
  final ResponseHeader responseHeader;
  List<AddressData>? data;

  GetDeliveryAddressResponse({
    required this.responseHeader,
    this.data,
  });

  factory GetDeliveryAddressResponse.fromJson(Map<String, dynamic> json) {
    if (json["data"] == null) {
      return GetDeliveryAddressResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return GetDeliveryAddressResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: List<AddressData>.from(json["data"].map((x) => AddressData.fromJson(x))),
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class AddressData {
  final int id;
  final int userId;
  final String address1;
  final String address2;
  final String postCode;
  final String city;
  final String state;
  final String country;
  final String street;
  final String firstName;
  final String phoneNumber;
  final String lastName;
  final int isDefault;
  final DateTime createdAt;
  final DateTime updatedAt;

  AddressData({
    required this.id,
    required this.userId,
    required this.address1,
    required this.address2,
    required this.postCode,
    required this.city,
    required this.state,
    required this.country,
    required this.street,
    required this.firstName,
    required this.phoneNumber,
    required this.lastName,
    required this.isDefault,
    required this.createdAt,
    required this.updatedAt,
  });

  factory AddressData.fromJson(Map<String, dynamic> json) => AddressData(
    id: json["id"],
    userId: json["userId"],
    address1: json["address1"] ?? "",
    address2: json["address2"] ?? "",
    postCode: json["postCode"],
    city: json["city"] ?? "",
    state: json["state"] ?? "",
    country: json["country"] ?? "",
    street: json["street"] ?? "",
    firstName: json["firstName"] ?? "",
    phoneNumber: json["phoneNumber"] ?? "",
    lastName: json["lastName"] ?? "",
    isDefault: json["isDefault"] ?? "",
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "address1": address1,
    "address2": address2,
    "postCode": postCode,
    "city": city,
    "state": state,
    "country": country,
    "street": street,
    "firstName": firstName,
    "phoneNumber": phoneNumber,
    "lastName": lastName,
    "isDefault": isDefault,
    "createdAt": "${createdAt.year.toString().padLeft(4, '0')}-${createdAt.month.toString().padLeft(2, '0')}-${createdAt.day.toString().padLeft(2, '0')}",
    "updatedAt": "${updatedAt.year.toString().padLeft(4, '0')}-${updatedAt.month.toString().padLeft(2, '0')}-${updatedAt.day.toString().padLeft(2, '0')}",
  };
}