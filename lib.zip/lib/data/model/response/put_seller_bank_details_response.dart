import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PutSellerBankDetailsResponse putSellerBankDetailsResponseFromJson(String str) => PutSellerBankDetailsResponse.fromJson(json.decode(str));

String putSellerBankDetailsResponseToJson(PutSellerBankDetailsResponse data) => json.encode(data.toJson());

class PutSellerBankDetailsResponse {
  ResponseHeader? responseHeader;
  List<int>? data;

  PutSellerBankDetailsResponse({
    this.responseHeader,
    this.data,
  });

  factory PutSellerBankDetailsResponse.fromJson(Map<String, dynamic> json) => PutSellerBankDetailsResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? [] : List<int>.from(json["data"]!.map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x)),
  };
}