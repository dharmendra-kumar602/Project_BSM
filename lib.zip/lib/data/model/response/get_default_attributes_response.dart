import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetDefaultAttributesResponse getDefaultAttributesResponseFromJson(String str) => GetDefaultAttributesResponse.fromJson(json.decode(str));

String getDefaultAttributesResponseToJson(GetDefaultAttributesResponse data) => json.encode(data.toJson());

class GetDefaultAttributesResponse {
  final ResponseHeader responseHeader;
  final List<AttributeData> data;

  GetDefaultAttributesResponse({
    required this.responseHeader,
    required this.data,
  });

  factory GetDefaultAttributesResponse.fromJson(Map<String, dynamic> json) => GetDefaultAttributesResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    data: List<AttributeData>.from(json["data"].map((x) => AttributeData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class AttributeData {
  final int id;
  final String attributeName;
  final String attributeType;
  final String attributeValues;
  final int storeId;
  final int isDefault;
  final DateTime updatedAt;
  final DateTime createdAt;
  bool isSelected;
  String selectedOption;

  AttributeData({
    required this.id,
    required this.attributeName,
    required this.attributeType,
    required this.attributeValues,
    required this.storeId,
    required this.isDefault,
    required this.updatedAt,
    required this.createdAt,
    this.isSelected = false,
    this.selectedOption = "",
  });

  factory AttributeData.fromJson(Map<String, dynamic> json) => AttributeData(
    id: json["id"],
    attributeName: json["attributeName"],
    attributeType: json["attributeType"],
    attributeValues: json["attributeValues"],
    storeId: json["storeId"],
    isDefault: json["isDefault"],
    updatedAt: DateTime.parse(json["updatedAt"]),
    createdAt: DateTime.parse(json["createdAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "attributeName": attributeName,
    "attributeType": attributeType,
    "attributeValues": attributeValues,
    "storeId": storeId,
    "isDefault": isDefault,
    "updatedAt": updatedAt.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
  };
}