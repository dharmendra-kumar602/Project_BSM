import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostAddToWishlistResponse postAddToWishlistResponseFromJson(String str) => PostAddToWishlistResponse.fromJson(json.decode(str));

class PostAddToWishlistResponse {
  final ResponseHeader responseHeader;
  List<Datum>? data;

  PostAddToWishlistResponse({
    required this.responseHeader,
    this.data,
  });

  factory PostAddToWishlistResponse.fromJson(Map<String, dynamic> json) {
    if (json["data"] == null) {
      return PostAddToWishlistResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return PostAddToWishlistResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );
    }
  }
}

class Datum {
  final int id;
  final int userId;
  final int productId;
  final int variationId;
  final DateTime createdAt;
  final DateTime updatedAt;

  Datum({
    required this.id,
    required this.userId,
    required this.productId,
    required this.variationId,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    userId: json["userId"],
    productId: json["productId"],
    variationId: json["variationId"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "productId": productId,
    "variationId": variationId,
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
  };
}