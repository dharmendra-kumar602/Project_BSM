import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerRegisterStatus getSellerRegisterStatusFromJson(String str) => GetSellerRegisterStatus.fromJson(json.decode(str));

String getSellerRegisterStatusToJson(GetSellerRegisterStatus data) => json.encode(data.toJson());

class GetSellerRegisterStatus {
  final ResponseHeader responseHeader;
  SellerState? sellerState;

  GetSellerRegisterStatus({
    required this.responseHeader,
    this.sellerState,
  });

  factory GetSellerRegisterStatus.fromJson(Map<String, dynamic> json) {
    if (json["sellerState"] == null) {
      return GetSellerRegisterStatus(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return GetSellerRegisterStatus(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        sellerState: SellerState.fromJson(json["sellerState"]),
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "sellerState": sellerState?.toJson(),
  };
}

class SellerState {
  String? state;
  final int storeId;

  SellerState({
    this.state,
    required this.storeId,
  });

  factory SellerState.fromJson(Map<String, dynamic> json) {
    if (json["state"] == null) {
      return SellerState(
        storeId: json["storeId"],
      );
    } else {
      return SellerState(
        state: json["state"],
        storeId: json["storeId"],
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "state": state,
    "storeId": storeId,
  };
}
