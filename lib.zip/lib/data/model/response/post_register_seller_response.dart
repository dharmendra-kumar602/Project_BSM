import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostRegisterSellerResponse postRegisterSellerResponseFromJson(String str) => PostRegisterSellerResponse.fromJson(json.decode(str));

String postRegisterSellerResponseToJson(PostRegisterSellerResponse data) => json.encode(data.toJson());

class PostRegisterSellerResponse {
  final ResponseHeader responseHeader;
  Store? store;

  PostRegisterSellerResponse({
    required this.responseHeader,
    this.store,
  });

  factory PostRegisterSellerResponse.fromJson(Map<String, dynamic> json) {
    if (json["store"] == null) {
      return PostRegisterSellerResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return PostRegisterSellerResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        store: Store.fromJson(json["store"]),
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "store": store?.toJson(),
  };
}

class Store {
  final int isVerified;
  final int isDocumentVerified;
  final int isActive;
  final int id;
  final int userId;
  final String name;
  final String email;
  final String addressLine1;
  final String addressLine2;
  final String city;
  final String storeImage;
  final String country;
  final String postCode;
  final String contact;
  final String about;
  final DateTime updatedAt;
  final DateTime createdAt;

  Store({
    required this.isVerified,
    required this.isDocumentVerified,
    required this.isActive,
    required this.id,
    required this.userId,
    required this.name,
    required this.email,
    required this.addressLine1,
    required this.addressLine2,
    required this.city,
    required this.storeImage,
    required this.country,
    required this.postCode,
    required this.contact,
    required this.about,
    required this.updatedAt,
    required this.createdAt,
  });

  factory Store.fromJson(Map<String, dynamic> json) => Store(
    isVerified: json["isVerified"],
    isDocumentVerified: json["isDocumentVerified"],
    isActive: json["isActive"],
    id: json["id"],
    userId: json["userId"],
    name: json["name"],
    email: json["email"],
    addressLine1: json["addressLine1"],
    addressLine2: json["addressLine2"],
    city: json["city"],
    storeImage: json["storeImage"],
    country: json["country"],
    postCode: json["postCode"],
    contact: json["contact"],
    about: json["about"],
    updatedAt: DateTime.parse(json["updatedAt"]),
    createdAt: DateTime.parse(json["createdAt"]),
  );

  Map<String, dynamic> toJson() => {
    "isVerified": isVerified,
    "isDocumentVerified": isDocumentVerified,
    "isActive": isActive,
    "id": id,
    "userId": userId,
    "name": name,
    "email": email,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "storeImage": storeImage,
    "country": country,
    "postCode": postCode,
    "contact": contact,
    "about": about,
    "updatedAt": updatedAt.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
  };
}
