import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetBuyerProfileResponse getBuyerProfileResponseFromJson(String str) => GetBuyerProfileResponse.fromJson(json.decode(str));

String getBuyerProfileResponseToJson(GetBuyerProfileResponse data) => json.encode(data.toJson());

class GetBuyerProfileResponse {
  final ResponseHeader responseHeader;
  BuyerData? data;

  GetBuyerProfileResponse({
    required this.responseHeader,
    this.data,
  });

  factory GetBuyerProfileResponse.fromJson(Map<String, dynamic> json) {
    if (json["data"] == null) {
      return GetBuyerProfileResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return GetBuyerProfileResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: BuyerData.fromJson(json["data"]),
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": data?.toJson(),
  };
}

class BuyerData {
  final int id;
  final String firstName;
  final String lastName;
  final String contact;
  final String email;
  final String latitude;
  final String longitude;
  final String gender;
  final String profilePicture;

  BuyerData({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.contact,
    required this.email,
    required this.latitude,
    required this.longitude,
    required this.gender,
    required this.profilePicture,
  });

  factory BuyerData.fromJson(Map<String, dynamic> json) => BuyerData(
    id: json["id"],
    firstName: json["firstName"],
    lastName: json["lastName"],
    contact: json["contact"] ?? "",
    email: json["email"],
    latitude: json["latitude"] ?? "",
    longitude: json["longitude"] ?? "",
    gender: json["gender"] ?? "",
    profilePicture: json["profilePicture"] ?? "",
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "firstName": firstName,
    "lastName": lastName,
    "contact": contact,
    "email": email,
    "latitude": latitude,
    "longitude": longitude,
    "gender": gender,
    "profilePicture": profilePicture,
  };
}