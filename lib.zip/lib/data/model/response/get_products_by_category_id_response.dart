import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetProductsByCategoryIdResponse getProductsByCategoryIdResponseFromJson(String str) => GetProductsByCategoryIdResponse.fromJson(json.decode(str));

String getProductsByCategoryIdResponseToJson(GetProductsByCategoryIdResponse data) => json.encode(data.toJson());

class GetProductsByCategoryIdResponse {
  ResponseHeader? responseHeader;
  List<CategoryDatum>? data;

  GetProductsByCategoryIdResponse({
    this.responseHeader,
    this.data,
  });

  factory GetProductsByCategoryIdResponse.fromJson(Map<String, dynamic> json) => GetProductsByCategoryIdResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? [] : List<CategoryDatum>.from(json["data"]!.map((x) => CategoryDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class CategoryDatum {
  bool? isLiked = false;
  int? id;
  String? title;
  int? sellerStoreId;
  String? description;
  int? badgeId;
  String? processingTime;
  DateTime? createdAt;
  DateTime? updatedAt;
  List<CProductVariation>? productVariations;
  CBadge? badge;
  Brand? brand;
  bool? isInCart;

  CategoryDatum({
    this.isLiked,
    this.id,
    this.title,
    this.sellerStoreId,
    this.description,
    this.badgeId,
    this.processingTime,
    this.createdAt,
    this.updatedAt,
    this.productVariations,
    this.badge,
    this.brand,
    this.isInCart,
  });

  factory CategoryDatum.fromJson(Map<String, dynamic> json) => CategoryDatum(
    id: json["id"],
    title: json["title"],
    sellerStoreId: json["sellerStoreId"],
    description: json["description"],
    badgeId: json["badgeId"],
    processingTime: json["processingTime"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    productVariations: json["product_variations"] == null ? [] : List<CProductVariation>.from(json["product_variations"]!.map((x) => CProductVariation.fromJson(x))),
    badge: json["badge"] == null ? null : CBadge.fromJson(json["badge"]),
    brand: json["brand"] == null ? null : Brand.fromJson(json["brand"]),
    isInCart: json["isInCart"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "sellerStoreId": sellerStoreId,
    "description": description,
    "badgeId": badgeId,
    "processingTime": processingTime,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
    "product_variations": productVariations == null ? [] : List<dynamic>.from(productVariations!.map((x) => x.toJson())),
    "badge": badge?.toJson(),
    "brand": brand?.toJson(),
    "isInCart": isInCart,
  };
}

class CBadge {
  String? name;
  String? title;
  String? image;
  String? description;

  CBadge({
    this.name,
    this.title,
    this.image,
    this.description,
  });

  factory CBadge.fromJson(Map<String, dynamic> json) => CBadge(
    name: json["name"],
    title: json["title"],
    image: json["image"],
    description: json["description"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "title": title,
    "image": image,
    "description": description,
  };
}

class Brand {
  int? id;
  String? name;

  Brand({
    this.id,
    this.name,
  });

  factory Brand.fromJson(Map<String, dynamic> json) => Brand(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}

class CProductVariation {
  int? id;
  dynamic? salePrice;
  dynamic? maxRetailPrice;
  dynamic discountInPercent;
  int? isInWishlist;
  String? approvalStatus;
  String? condition;
  dynamic? weight;
  dynamic? height;
  dynamic? width;
  dynamic? length;
  List<CProductImage>? productImages;
  List<ProductAttributeMapping>? productAttributeMappings;

  CProductVariation({
    this.id,
    this.salePrice,
    this.maxRetailPrice,
    this.discountInPercent,
    this.isInWishlist,
    this.approvalStatus,
    this.condition,
    this.weight,
    this.height,
    this.width,
    this.length,
    this.productImages,
    this.productAttributeMappings,
  });

  factory CProductVariation.fromJson(Map<String, dynamic> json) => CProductVariation(
    id: json["id"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    discountInPercent: json["discountInPercent"],
    isInWishlist: json["isInWishlist"],
    approvalStatus: json["approvalStatus"],
    condition: json["condition"],
    weight: json["weight"],
    height: json["height"],
    width: json["width"],
    length: json["length"],
    productImages: json["product_images"] == null ? [] : List<CProductImage>.from(json["product_images"]!.map((x) => CProductImage.fromJson(x))),
    productAttributeMappings: json["product_attribute_mappings"] == null ? [] : List<ProductAttributeMapping>.from(json["product_attribute_mappings"]!.map((x) => ProductAttributeMapping.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "discountInPercent": discountInPercent,
    "isInWishlist": isInWishlist,
    "approvalStatus": approvalStatus,
    "condition": condition,
    "weight": weight,
    "height": height,
    "width": width,
    "length": length,
    "product_images": productImages == null ? [] : List<dynamic>.from(productImages!.map((x) => x.toJson())),
    "product_attribute_mappings": productAttributeMappings == null ? [] : List<dynamic>.from(productAttributeMappings!.map((x) => x.toJson())),
  };
}

class ProductAttributeMapping {
  int? attributeId;
  String? value;

  ProductAttributeMapping({
    this.attributeId,
    this.value,
  });

  factory ProductAttributeMapping.fromJson(Map<String, dynamic> json) => ProductAttributeMapping(
    attributeId: json["attributeId"],
    value: json["value"],
  );

  Map<String, dynamic> toJson() => {
    "attributeId": attributeId,
    "value": value,
  };
}

class CProductImage {
  String? imageName;

  CProductImage({
    this.imageName,
  });

  factory CProductImage.fromJson(Map<String, dynamic> json) => CProductImage(
    imageName: json["imageName"],
  );

  Map<String, dynamic> toJson() => {
    "imageName": imageName,
  };
}