import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetNewsLetterStatusResponse getNewsLetterStatusResponseFromJson(String str) => GetNewsLetterStatusResponse.fromJson(json.decode(str));

String getNewsLetterStatusResponseToJson(GetNewsLetterStatusResponse data) => json.encode(data.toJson());

class GetNewsLetterStatusResponse {
  ResponseHeader? responseHeader;
  int? data;

  GetNewsLetterStatusResponse({
    this.responseHeader,
    this.data,
  });

  factory GetNewsLetterStatusResponse.fromJson(Map<String, dynamic> json) => GetNewsLetterStatusResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"],
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data,
  };
}