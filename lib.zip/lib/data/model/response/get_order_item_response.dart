import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/model/response/get_buyer_order_detail_response.dart';

GetOrderItemResponse getOrderItemResponseFromJson(String str) => GetOrderItemResponse.fromJson(json.decode(str));

String getOrderItemResponseToJson(GetOrderItemResponse data) => json.encode(data.toJson());

class GetOrderItemResponse {
  ResponseHeader? responseHeader;
  OrderItemDetails? orderDetails;

  GetOrderItemResponse({
    this.responseHeader,
    this.orderDetails,
  });

  factory GetOrderItemResponse.fromJson(Map<String, dynamic> json) => GetOrderItemResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    orderDetails: json["orderDetails"] == null ? null : OrderItemDetails.fromJson(json["orderDetails"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "orderDetails": orderDetails?.toJson(),
  };
}

class OrderItemDetails {
  int? id;
  int? orderId;
  int? sellerStoreId;
  int? productId;
  int? productVariationId;
  String? productName;
  String? productDescription;
  String? productImage;
  int? salePrice;
  int? maxRetailPrice;
  ProductDetailsInJson? productDetailsInJson;
  String? shippingMethod;
  String? status;
  int? quantity;
  String? paymentMethod;
  String? rejectionReason;
  DateTime? createdAt;
  DateTime? updatedAt;
  PayStatus? order;
  SellerStore? sellerStore;
  List<OrderedItemStatus>? orderedItemStatuses;

  OrderItemDetails({
    this.id,
    this.orderId,
    this.sellerStoreId,
    this.productId,
    this.productVariationId,
    this.productName,
    this.productDescription,
    this.productImage,
    this.salePrice,
    this.maxRetailPrice,
    this.productDetailsInJson,
    this.shippingMethod,
    this.status,
    this.quantity,
    this.paymentMethod,
    this.rejectionReason,
    this.createdAt,
    this.updatedAt,
    this.order,
    this.sellerStore,
    this.orderedItemStatuses,
  });

  factory OrderItemDetails.fromJson(Map<String, dynamic> json) => OrderItemDetails(
    id: json["id"],
    orderId: json["orderId"],
    sellerStoreId: json["sellerStoreId"],
    productId: json["productId"],
    productVariationId: json["productVariationId"],
    productName: json["productName"],
    productDescription: json["productDescription"],
    productImage: json["productImage"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    productDetailsInJson: json["productDetailsInJSON"] == null ? null : ProductDetailsInJson.fromJson(json["productDetailsInJSON"]),
    shippingMethod: json["shippingMethod"],
    status: json["status"],
    quantity: json["quantity"],
    paymentMethod: json["paymentMethod"],
    rejectionReason: json["rejectionReason"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    order: json["order"] == null ? null : PayStatus.fromJson(json["order"]),
    sellerStore: json["sellerStore"] == null ? null : SellerStore.fromJson(json["sellerStore"]),
    orderedItemStatuses: json["ordered_item_statuses"] == null ? [] : List<OrderedItemStatus>.from(json["ordered_item_statuses"]!.map((x) => OrderedItemStatus.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "sellerStoreId": sellerStoreId,
    "productId": productId,
    "productVariationId": productVariationId,
    "productName": productName,
    "productDescription": productDescription,
    "productImage": productImage,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "productDetailsInJSON": productDetailsInJson?.toJson(),
    "shippingMethod": shippingMethod,
    "status": status,
    "quantity": quantity,
    "paymentMethod": paymentMethod,
    "rejectionReason": rejectionReason,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "order": order?.toJson(),
    "sellerStore": sellerStore?.toJson(),
    "ordered_item_statuses": orderedItemStatuses == null ? [] : List<dynamic>.from(orderedItemStatuses!.map((x) => x)),
  };
}

class PayStatus {
  int? id;
  List<OrderPaymentMapping>? orderPaymentMappings;

  PayStatus({
    this.id,
    this.orderPaymentMappings,
  });

  factory PayStatus.fromJson(Map<String, dynamic> json) => PayStatus(
    id: json["id"],
    orderPaymentMappings: json["order_payment_mappings"] == null ? [] : List<OrderPaymentMapping>.from(json["order_payment_mappings"]!.map((x) => OrderPaymentMapping.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "order_payment_mappings": orderPaymentMappings == null ? [] : List<dynamic>.from(orderPaymentMappings!.map((x) => x.toJson())),
  };
}

class OrderPaymentMapping {
  int? id;
  int? orderId;
  String? paymentType;
  String? paymenIntentId;
  String? paymentStatus;
  DateTime? createdAt;
  DateTime? updatedAt;

  OrderPaymentMapping({
    this.id,
    this.orderId,
    this.paymentType,
    this.paymenIntentId,
    this.paymentStatus,
    this.createdAt,
    this.updatedAt,
  });

  factory OrderPaymentMapping.fromJson(Map<String, dynamic> json) => OrderPaymentMapping(
    id: json["id"],
    orderId: json["orderId"],
    paymentType: json["paymentType"],
    paymenIntentId: json["paymenIntentId"],
    paymentStatus: json["payment_status"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "paymentType": paymentType,
    "paymenIntentId": paymenIntentId,
    "payment_status": paymentStatus,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}

class OrderedItemStatus {
  int? id;
  int? orderedItemId;
  int? reasonId;
  String? otherReasonText;
  String? status;
  DateTime? createdAt;
  Reason? reason;

  OrderedItemStatus({
    this.id,
    this.orderedItemId,
    this.reasonId,
    this.otherReasonText,
    this.status,
    this.createdAt,
    this.reason,
  });

  factory OrderedItemStatus.fromJson(Map<String, dynamic> json) => OrderedItemStatus(
    id: json["id"],
    orderedItemId: json["orderedItemId"],
    reasonId: json["reasonId"],
    otherReasonText: json["otherReasonText"],
    status: json["status"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    reason: json["reason"] == null ? null : Reason.fromJson(json["reason"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderedItemId": orderedItemId,
    "reasonId": reasonId,
    "otherReasonText": otherReasonText,
    "status": status,
    "createdAt": createdAt?.toIso8601String(),
    "reason": reason?.toJson(),
  };
}

class Reason {
  int? id;
  String? reasonType;
  String? text;

  Reason({
    this.id,
    this.reasonType,
    this.text,
  });

  factory Reason.fromJson(Map<String, dynamic> json) => Reason(
    id: json["id"],
    reasonType: json["reasonType"],
    text: json["text"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "reasonType": reasonType,
    "text": text,
  };
}

class DeliveryAddress {
  int? id;
  int? userId;
  String? address1;
  dynamic address2;
  String? postCode;
  String? city;
  String? state;
  String? country;
  String? street;
  String? firstName;
  dynamic lastName;
  String? phoneNumber;
  int? isDefault;
  DateTime? createdAt;
  DateTime? updatedAt;

  DeliveryAddress({
    this.id,
    this.userId,
    this.address1,
    this.address2,
    this.postCode,
    this.city,
    this.state,
    this.country,
    this.street,
    this.firstName,
    this.lastName,
    this.phoneNumber,
    this.isDefault,
    this.createdAt,
    this.updatedAt,
  });

  factory DeliveryAddress.fromJson(Map<String, dynamic> json) => DeliveryAddress(
    id: json["id"],
    userId: json["userId"],
    address1: json["address1"],
    address2: json["address2"],
    postCode: json["postCode"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
    street: json["street"],
    firstName: json["firstName"],
    lastName: json["lastName"],
    phoneNumber: json["phoneNumber"],
    isDefault: json["isDefault"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "address1": address1,
    "address2": address2,
    "postCode": postCode,
    "city": city,
    "state": state,
    "country": country,
    "street": street,
    "firstName": firstName,
    "lastName": lastName,
    "phoneNumber": phoneNumber,
    "isDefault": isDefault,
    "createdAt": "${createdAt!.year.toString().padLeft(4, '0')}-${createdAt!.month.toString().padLeft(2, '0')}-${createdAt!.day.toString().padLeft(2, '0')}",
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
  };
}

class PickupAddress {
  String? name;
  String? addressLine1;
  String? addressLine2;
  String? city;
  String? country;
  String? postCode;
  String? contact;

  PickupAddress({
    this.name,
    this.addressLine1,
    this.addressLine2,
    this.city,
    this.country,
    this.postCode,
    this.contact,
  });

  factory PickupAddress.fromJson(Map<String, dynamic> json) => PickupAddress(
    name: json["name"],
    addressLine1: json["addressLine1"],
    addressLine2: json["addressLine2"],
    city: json["city"],
    country: json["country"],
    postCode: json["postCode"],
    contact: json["contact"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "country": country,
    "postCode": postCode,
    "contact": contact,
  };
}

class SellerStore {
  int? id;
  String? name;

  SellerStore({
    this.id,
    this.name,
  });

  factory SellerStore.fromJson(Map<String, dynamic> json) => SellerStore(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}