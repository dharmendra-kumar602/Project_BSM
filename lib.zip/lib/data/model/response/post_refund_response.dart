import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostRefundRequestResponse postRefundRequestResponseFromJson(String str) => PostRefundRequestResponse.fromJson(json.decode(str));

String postRefundRequestResponseToJson(PostRefundRequestResponse data) => json.encode(data.toJson());

class PostRefundRequestResponse {
  ResponseHeader? responseHeader;
  List<OrderStatus>? orderStatus;

  PostRefundRequestResponse({
    this.responseHeader,
    this.orderStatus,
  });

  factory PostRefundRequestResponse.fromJson(Map<String, dynamic> json) => PostRefundRequestResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    orderStatus: json["orderStatus"] == null ? [] : List<OrderStatus>.from(json["orderStatus"]!.map((x) => OrderStatus.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "orderStatus": orderStatus == null ? [] : List<dynamic>.from(orderStatus!.map((x) => x.toJson())),
  };
}

class OrderStatus {
  int? id;
  int? orderId;
  int? sellerStoreId;
  String? productName;
  String? productDescription;
  int? salePrice;
  String? productImage;
  Order? order;

  OrderStatus({
    this.id,
    this.orderId,
    this.sellerStoreId,
    this.productName,
    this.productDescription,
    this.salePrice,
    this.productImage,
    this.order,
  });

  factory OrderStatus.fromJson(Map<String, dynamic> json) => OrderStatus(
    id: json["id"],
    orderId: json["orderId"],
    sellerStoreId: json["sellerStoreId"],
    productName: json["productName"],
    productDescription: json["productDescription"],
    salePrice: json["salePrice"],
    productImage: json["productImage"],
    order: json["order"] == null ? null : Order.fromJson(json["order"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "sellerStoreId": sellerStoreId,
    "productName": productName,
    "productDescription": productDescription,
    "salePrice": salePrice,
    "productImage": productImage,
    "order": order?.toJson(),
  };
}

class Order {
  int? userId;

  Order({
    this.userId,
  });

  factory Order.fromJson(Map<String, dynamic> json) => Order(
    userId: json["userId"],
  );

  Map<String, dynamic> toJson() => {
    "userId": userId,
  };
}