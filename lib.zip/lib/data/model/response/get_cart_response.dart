import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetCartProductsResponse getCartProductsResponseFromJson(String str) =>
    GetCartProductsResponse.fromJson(json.decode(str));

String getCartProductsResponseToJson(GetCartProductsResponse data) =>
    json.encode(data.toJson());

class GetCartProductsResponse {
  final ResponseHeader responseHeader;
  final CartData data;

  GetCartProductsResponse({
    required this.responseHeader,
    required this.data,
  });

  factory GetCartProductsResponse.fromJson(Map<String, dynamic> json) =>
      GetCartProductsResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: CartData.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "responseHeader": responseHeader.toJson(),
        "data": data.toJson(),
      };
}

class CartData {
  final List<Seller> sellers;
  final List<String> sizes;
  final List<CartFinalDatum> cartFinalData;
  final int tax;
  int? cartId;

  CartData({
    required this.sellers,
    required this.sizes,
    required this.cartFinalData,
    required this.tax,
    this.cartId,
  });

  factory CartData.fromJson(Map<String, dynamic> json) => CartData(
        sellers:
            List<Seller>.from(json["sellers"].map((x) => Seller.fromJson(x))),
        sizes: json["sizes"] != null
            ? List<String>.from(json["sizes"].map((x) => x ?? ""))
            : [],
        cartFinalData: List<CartFinalDatum>.from(
            json["cartSummary"].map((x) => CartFinalDatum.fromJson(x))),
        tax: json["tax"] ?? 0,
    cartId: json["cartId"] ?? 0,
      );

  Map<String, dynamic> toJson() => {
        "sellers": List<dynamic>.from(sellers.map((x) => x.toJson())),
        "sizes": List<dynamic>.from(sizes.map((x) => x)),
        "cartSummary": List<dynamic>.from(cartFinalData.map((x) => x.toJson())),
        "tax": tax,
        "cartId": cartId,
      };
}

class CartFinalDatum {
  final int sellerId;
  final List<String> productNames;
  final String sellerName;
  final dynamic subCost;
  final dynamic totalWeight;
  dynamic? pickupFromStoreHandlingCharges;
  final dynamic totalWeightShippingCost;

  CartFinalDatum({
    required this.sellerId,
    required this.productNames,
    required this.sellerName,
    required this.subCost,
    required this.totalWeight,
    this.pickupFromStoreHandlingCharges,
    required this.totalWeightShippingCost,
  });

  factory CartFinalDatum.fromJson(Map<String, dynamic> json) => CartFinalDatum(
        sellerId: json["sellerId"],
        productNames: List<String>.from(json["productNames"].map((x) => x)),
        sellerName: json["sellerName"],
        subCost: json["subCost"],
        totalWeight: json["totalWeight"],
    pickupFromStoreHandlingCharges: json["pickupFromStoreHandlingCharges"],
        totalWeightShippingCost: json["totalWeightShippingCost"],
      );

  Map<String, dynamic> toJson() => {
        "sellerId": sellerId,
        "productNames": List<dynamic>.from(productNames.map((x) => x)),
        "sellerName": sellerName,
        "subCost": subCost,
        "totalWeight": totalWeight,
        "pickupFromStoreHandlingCharges": pickupFromStoreHandlingCharges,
        "totalWeightShippingCost": totalWeightShippingCost,
      };
}

class Seller {
  final int id;
  final String name;
  String pickupOrDelivery;
  final List<Product> products;
  final SellerStore sellerStore;

  Seller({
    required this.id,
    required this.name,
    required this.pickupOrDelivery,
    required this.products,
    required this.sellerStore,
  });

  factory Seller.fromJson(Map<String, dynamic> json) => Seller(
        id: json["id"],
        name: json["name"],
        products: List<Product>.from(
            json["products"].map((x) => Product.fromJson(x))),
        sellerStore: SellerStore.fromJson(json["sellerStore"]),
        pickupOrDelivery: json["pickupOrDelivery"] ?? "DELIVERY",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "pickupOrDelivery": pickupOrDelivery,
        "products": List<dynamic>.from(products.map((x) => x.toJson())),
        "sellerStore": sellerStore.toJson(),
      };
}

class Product {
  final int id;
  final int cartItemId;
  final String title;
  String? selectedSize;
  int quantity;
  final String description;
  final List<SizeClass> sizes;
  final ProductVariation productVariation;

  Product({
    required this.id,
    required this.cartItemId,
    required this.title,
    this.selectedSize,
    required this.quantity,
    required this.description,
    required this.sizes,
    required this.productVariation,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json["id"],
        title: json["title"],
        cartItemId: json["cartItemId"],
        selectedSize: json["selectedSize"],
        quantity: json["quantity"],
        description: json["description"],
        sizes: List<SizeClass>.from(
            json["sizes"].map((x) => SizeClass.fromJson(x))),
        productVariation: ProductVariation.fromJson(json["productVariation"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "cartItemId": cartItemId,
        "quantity": quantity,
        "description": description,
        "sizes": List<dynamic>.from(sizes.map((x) => x.toJson())),
        "productVariation": productVariation.toJson(),
      };
}

class ProductVariation {
  final int id;
  final dynamic salePrice;
  final dynamic maxRetailPrice;
  final List<String> productImages;
  final dynamic weightInPound;

  ProductVariation({
    required this.id,
    required this.salePrice,
    required this.maxRetailPrice,
    required this.productImages,
    required this.weightInPound,
  });

  factory ProductVariation.fromJson(Map<String, dynamic> json) =>
      ProductVariation(
        id: json["id"],
        salePrice: json["salePrice"],
        maxRetailPrice: json["maxRetailPrice"],
        productImages: List<String>.from(json["product_images"].map((x) => x)),
        weightInPound: json["weightInPound"] ?? 0,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "salePrice": salePrice,
        "maxRetailPrice": maxRetailPrice,
        "product_images": List<dynamic>.from(productImages.map((x) => x)),
        "weightInPound": weightInPound,
      };
}

class SizeClass {
  final int variationId;
  final Attributes attributes;

  SizeClass({
    required this.variationId,
    required this.attributes,
  });

  factory SizeClass.fromJson(Map<String, dynamic> json) => SizeClass(
        variationId: json["variationId"],
        attributes: Attributes.fromJson(json["attributes"]),
      );

  Map<String, dynamic> toJson() => {
        "variationId": variationId,
        "attributes": attributes.toJson(),
      };
}

class Attributes {
  final String size;

  Attributes({
    required this.size,
  });

  factory Attributes.fromJson(Map<String, dynamic> json) => Attributes(
        size: json["size"] ?? "",
      );

  Map<String, dynamic> toJson() => {
        "size": size,
      };
}

class SellerStore {
  final int id;
  final int userId;
  final String name;
  final String email;
  final String addressLine1;
  final String addressLine2;
  final String city;
  final String country;
  final String postCode;
  final String about;
  final String description;
  final String contact;
  final int isFreeShippingEnabled;
  final int freeShippingMinimumCost;
  final int isPickupFromStoreEnabled;
  final int pickupFromStoreHandlingCharges;
  final List<dynamic> sellerShippings;
  List<String> deliveryItems;

  SellerStore({
    required this.id,
    required this.userId,
    required this.name,
    required this.email,
    required this.addressLine1,
    required this.addressLine2,
    required this.city,
    required this.country,
    required this.postCode,
    required this.about,
    required this.description,
    required this.contact,
    required this.isFreeShippingEnabled,
    required this.freeShippingMinimumCost,
    required this.isPickupFromStoreEnabled,
    required this.pickupFromStoreHandlingCharges,
    required this.sellerShippings,
    this.deliveryItems = const [],
  });

  factory SellerStore.fromJson(Map<String, dynamic> json) => SellerStore(
        id: json["id"],
        userId: json["userId"] ?? 0,
        name: json["name"] ?? "",
        isFreeShippingEnabled: json["isFreeShippingEnabled"] ?? 1,
        freeShippingMinimumCost: json["freeShippingMinimumCost"] ?? 1,
        isPickupFromStoreEnabled: json["isPickupFromStoreEnabled"] ?? 1,
        pickupFromStoreHandlingCharges:
            json["pickupFromStoreHandlingCharges"] ?? 1,
        sellerShippings:
            List<dynamic>.from(json["seller_shippings"].map((x) => x)),
        addressLine1: json["addressLine1"] ?? "",
        addressLine2: json["addressLine2"] ?? "",
        city: json["city"] ?? "",
        country: json["country"] ?? "",
        postCode: json["postCode"] ?? "",
        about: json["about"] ?? "",
        description: json["description"] ?? "",
        contact: json["contact"] ?? "",
        email: json["email"] ?? "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "userId": userId,
        "name": name,
        "email": email,
        "addressLine1": addressLine1,
        "addressLine2": addressLine2,
        "city": city,
        "country": country,
        "postCode": postCode,
        "about": about,
        "description": description,
        "contact": contact,
        "isFreeShippingEnabled": isFreeShippingEnabled,
        "freeShippingMinimumCost": freeShippingMinimumCost,
        "isPickupFromStoreEnabled": isPickupFromStoreEnabled,
        "pickupFromStoreHandlingCharges": pickupFromStoreHandlingCharges,
        "seller_shippings": List<dynamic>.from(sellerShippings.map((x) => x)),
      };
}
