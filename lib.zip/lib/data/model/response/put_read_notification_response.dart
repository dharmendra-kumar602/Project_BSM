import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PutReadNotificationResponse putReadNotificationResponseFromJson(String str) => PutReadNotificationResponse.fromJson(json.decode(str));

String putReadNotificationResponseToJson(PutReadNotificationResponse data) => json.encode(data.toJson());

class PutReadNotificationResponse {
  ResponseHeader? responseHeader;
  List<int>? data;

  PutReadNotificationResponse({
    this.responseHeader,
    this.data,
  });

  factory PutReadNotificationResponse.fromJson(Map<String, dynamic> json) => PutReadNotificationResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? [] : List<int>.from(json["data"]!.map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x)),
  };
}
