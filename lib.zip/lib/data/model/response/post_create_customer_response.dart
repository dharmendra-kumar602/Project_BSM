import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostCreateCustomerResponse postCreateCustomerResponseFromJson(String str) => PostCreateCustomerResponse.fromJson(json.decode(str));

String postCreateCustomerResponseToJson(PostCreateCustomerResponse data) => json.encode(data.toJson());

class PostCreateCustomerResponse {
  final ResponseHeader responseHeader;
  String? customerId;

  PostCreateCustomerResponse({
    required this.responseHeader,
    this.customerId,
  });

  factory PostCreateCustomerResponse.fromJson(Map<String, dynamic> json) {
    if (json["customerId"] == null) {
      return PostCreateCustomerResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return PostCreateCustomerResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        customerId: json["customerId"],
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "customerId": customerId,
  };
}