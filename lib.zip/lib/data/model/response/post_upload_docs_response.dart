import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostUploadDocsResponse postUploadDocsResponseFromJson(String str) => PostUploadDocsResponse.fromJson(json.decode(str));

String postUploadDocsResponseToJson(PostUploadDocsResponse data) => json.encode(data.toJson());

class PostUploadDocsResponse {
  final ResponseHeader responseHeader;
  List<Datum>? data;

  PostUploadDocsResponse({
    required this.responseHeader,
    this.data,
  });

  factory PostUploadDocsResponse.fromJson(Map<String, dynamic> json) {
    if (json["data"] == null) {
      return PostUploadDocsResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return PostUploadDocsResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  final int id;
  final String url;
  final String title;
  final String description;
  final int sellerStoreId;
  final DateTime createdAt;
  final DateTime updatedAt;

  Datum({
    required this.id,
    required this.url,
    required this.title,
    required this.description,
    required this.sellerStoreId,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    url: json["url"],
    title: json["title"],
    description: json["description"],
    sellerStoreId: json["sellerStoreId"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "url": url,
    "title": title,
    "description": description,
    "sellerStoreId": sellerStoreId,
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
  };
}