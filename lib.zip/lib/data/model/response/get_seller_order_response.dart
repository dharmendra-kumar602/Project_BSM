import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSellerOrderDetailsResponse getSellerOrderDetailsResponseFromJson(String str) => GetSellerOrderDetailsResponse.fromJson(json.decode(str));

String getSellerOrderDetailsResponseToJson(GetSellerOrderDetailsResponse data) => json.encode(data.toJson());

class GetSellerOrderDetailsResponse {
  ResponseHeader? responseHeader;
  SellerOrderDetails? data;

  GetSellerOrderDetailsResponse({
    this.responseHeader,
    this.data,
  });

  factory GetSellerOrderDetailsResponse.fromJson(Map<String, dynamic> json) => GetSellerOrderDetailsResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : SellerOrderDetails.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class SellerOrderDetails {
  int? id;
  int? userId;
  String? paymentStatus;
  int? cartSubCost;
  int? taxInPercentage;
  dynamic deliveryAddressId;
  String? paymentMethod;
  String? shippingCostDetails;
  int? totalHandlingCharges;
  int? totalShippingCharges;
  dynamic paymentIntentId;
  DateTime? createdAt;
  DateTime? updatedAt;
  List<OrderedItem>? orderedItems;
  User? user;
  List<OrderPaymentMapping>? orderPaymentMappings;
  String? status;
  String? shippingMethod;
  DeliveryAddress? deliveryAddress;
  List<OrderedItemStatus>? orderedItemStatuses;

  SellerOrderDetails({
    this.id,
    this.userId,
    this.paymentStatus,
    this.cartSubCost,
    this.taxInPercentage,
    this.deliveryAddressId,
    this.paymentMethod,
    this.shippingCostDetails,
    this.totalHandlingCharges,
    this.totalShippingCharges,
    this.paymentIntentId,
    this.createdAt,
    this.updatedAt,
    this.orderedItems,
    this.user,
    this.orderPaymentMappings,
    this.status,
    this.shippingMethod,
    this.deliveryAddress,
    this.orderedItemStatuses,
  });

  factory SellerOrderDetails.fromJson(Map<String, dynamic> json) => SellerOrderDetails(
    id: json["id"],
    userId: json["userId"],
    paymentStatus: json["paymentStatus"],
    cartSubCost: json["cartSubCost"],
    taxInPercentage: json["taxInPercentage"],
    deliveryAddressId: json["deliveryAddressId"],
    paymentMethod: json["paymentMethod"],
    shippingCostDetails: json["shippingCostDetails"],
    totalHandlingCharges: json["totalHandlingCharges"],
    totalShippingCharges: json["totalShippingCharges"],
    paymentIntentId: json["paymentIntentId"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    orderedItems: json["ordered_items"] == null ? [] : List<OrderedItem>.from(json["ordered_items"]!.map((x) => OrderedItem.fromJson(x))),
    user: json["user"] == null ? null : User.fromJson(json["user"]),
    orderPaymentMappings: json["order_payment_mappings"] == null ? [] : List<OrderPaymentMapping>.from(json["order_payment_mappings"]!.map((x) => OrderPaymentMapping.fromJson(x))),
    status: json["status"],
    shippingMethod: json["shippingMethod"],
    deliveryAddress: json["deliveryAddress"] == null ? null : DeliveryAddress.fromJson(json["deliveryAddress"]),
    orderedItemStatuses: json["ordered_item_statuses"] == null ? [] : List<OrderedItemStatus>.from(json["ordered_item_statuses"]!.map((x) => OrderedItemStatus.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "paymentStatus": paymentStatus,
    "cartSubCost": cartSubCost,
    "taxInPercentage": taxInPercentage,
    "deliveryAddressId": deliveryAddressId,
    "paymentMethod": paymentMethod,
    "shippingCostDetails": shippingCostDetails,
    "totalHandlingCharges": totalHandlingCharges,
    "totalShippingCharges": totalShippingCharges,
    "paymentIntentId": paymentIntentId,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "ordered_items": orderedItems == null ? [] : List<dynamic>.from(orderedItems!.map((x) => x.toJson())),
    "user": user?.toJson(),
    "order_payment_mappings": orderPaymentMappings == null ? [] : List<dynamic>.from(orderPaymentMappings!.map((x) => x.toJson())),
    "status": status,
    "shippingMethod": shippingMethod,
    "deliveryAddress": deliveryAddress?.toJson(),
    "ordered_item_statuses": orderedItemStatuses == null ? [] : List<dynamic>.from(orderedItemStatuses!.map((x) => x.toJson())),
  };
}

class OrderPaymentMapping {
  int? id;
  int? orderId;
  String? paymentType;
  String? paymenIntentId;
  String? paymentStatus;
  DateTime? createdAt;
  DateTime? updatedAt;

  OrderPaymentMapping({
    this.id,
    this.orderId,
    this.paymentType,
    this.paymenIntentId,
    this.paymentStatus,
    this.createdAt,
    this.updatedAt,
  });

  factory OrderPaymentMapping.fromJson(Map<String, dynamic> json) => OrderPaymentMapping(
    id: json["id"],
    orderId: json["orderId"],
    paymentType: json["paymentType"],
    paymenIntentId: json["paymenIntentId"],
    paymentStatus: json["payment_status"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "paymentType": paymentType,
    "paymenIntentId": paymenIntentId,
    "payment_status": paymentStatus,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
  };
}

class OrderedItemStatus {
  int? id;
  int? orderedItemId;
  dynamic reasonId;
  String? otherReasonText;
  String? status;
  DateTime? createdAt;
  DateTime? updatedAt;
  Reason? reason;

  OrderedItemStatus({
    this.id,
    this.orderedItemId,
    this.reasonId,
    this.otherReasonText,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.reason,
  });

  factory OrderedItemStatus.fromJson(Map<String, dynamic> json) => OrderedItemStatus(
    id: json["id"],
    orderedItemId: json["orderedItemId"],
    reasonId: json["reasonId"],
    otherReasonText: json["otherReasonText"],
    status: json["status"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    reason: json["reason"] == null ? null : Reason.fromJson(json["reason"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderedItemId": orderedItemId,
    "reasonId": reasonId,
    "otherReasonText": otherReasonText,
    "status": status,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "reason": reason?.toJson(),
  };
}
class Reason {
  int? id;
  String? reasonType;
  String? text;

  Reason({
    this.id,
    this.reasonType,
    this.text,
  });

  factory Reason.fromJson(Map<String, dynamic> json) => Reason(
    id: json["id"],
    reasonType: json["reasonType"],
    text: json["text"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "reasonType": reasonType,
    "text": text,
  };
}


class OrderedItem {
  int? id;
  int? orderId;
  int? sellerStoreId;
  int? productId;
  int? productVariationId;
  String? productName;
  String? productDescription;
  String? productImage;
  int? salePrice;
  int? maxRetailPrice;
  ProductDetailsInJson? productDetailsInJson;
  String? shippingMethod;
  String? status;
  int? quantity;
  DateTime? createdAt;
  DateTime? updatedAt;
  ProductVariation? productVariation;

  OrderedItem({
    this.id,
    this.orderId,
    this.sellerStoreId,
    this.productId,
    this.productVariationId,
    this.productName,
    this.productDescription,
    this.productImage,
    this.salePrice,
    this.maxRetailPrice,
    this.productDetailsInJson,
    this.shippingMethod,
    this.status,
    this.quantity,
    this.createdAt,
    this.updatedAt,
    this.productVariation,
  });

  factory OrderedItem.fromJson(Map<String, dynamic> json) => OrderedItem(
    id: json["id"],
    orderId: json["orderId"],
    sellerStoreId: json["sellerStoreId"],
    productId: json["productId"],
    productVariationId: json["productVariationId"],
    productName: json["productName"],
    productDescription: json["productDescription"],
    productImage: json["productImage"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    productDetailsInJson: json["productDetailsInJSON"] == null ? null : ProductDetailsInJson.fromJson(json["productDetailsInJSON"]),
    shippingMethod: json["shippingMethod"],
    status: json["status"],
    quantity: json["quantity"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    productVariation: json["productVariation"] == null ? null : ProductVariation.fromJson(json["productVariation"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderId": orderId,
    "sellerStoreId": sellerStoreId,
    "productId": productId,
    "productVariationId": productVariationId,
    "productName": productName,
    "productDescription": productDescription,
    "productImage": productImage,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "productDetailsInJSON": productDetailsInJson?.toJson(),
    "shippingMethod": shippingMethod,
    "status": status,
    "quantity": quantity,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "productVariation": productVariation?.toJson(),
  };
}

class ProductDetailsInJson {
  DeliveryAddress? deliveryAddress;
  PickupAddress? pickupAddress;
  List<dynamic>? sizes;

  ProductDetailsInJson({
    this.deliveryAddress,
    this.pickupAddress,
    this.sizes,
  });

  factory ProductDetailsInJson.fromJson(Map<String, dynamic> json) => ProductDetailsInJson(
    deliveryAddress: json["deliveryAddress"] == null ? null : DeliveryAddress.fromJson(json["deliveryAddress"]),
    pickupAddress: json["pickupAddress"] == null ? null : PickupAddress.fromJson(json["pickupAddress"]),
    sizes: json["sizes"] == null ? [] : List<dynamic>.from(json["sizes"]!.map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "deliveryAddress": deliveryAddress?.toJson(),
    "pickupAddress": pickupAddress?.toJson(),
    "sizes": sizes == null ? [] : List<dynamic>.from(sizes!.map((x) => x)),
  };
}

class DeliveryAddress {
  int? id;
  int? userId;
  String? address1;
  dynamic address2;
  String? postCode;
  String? city;
  String? state;
  String? country;
  String? street;
  String? firstName;
  dynamic lastName;
  String? phoneNumber;
  int? isDefault;
  DateTime? createdAt;
  DateTime? updatedAt;

  DeliveryAddress({
    this.id,
    this.userId,
    this.address1,
    this.address2,
    this.postCode,
    this.city,
    this.state,
    this.country,
    this.street,
    this.firstName,
    this.lastName,
    this.phoneNumber,
    this.isDefault,
    this.createdAt,
    this.updatedAt,
  });

  factory DeliveryAddress.fromJson(Map<String, dynamic> json) => DeliveryAddress(
    id: json["id"],
    userId: json["userId"],
    address1: json["address1"],
    address2: json["address2"],
    postCode: json["postCode"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
    street: json["street"],
    firstName: json["firstName"],
    lastName: json["lastName"],
    phoneNumber: json["phoneNumber"],
    isDefault: json["isDefault"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "address1": address1,
    "address2": address2,
    "postCode": postCode,
    "city": city,
    "state": state,
    "country": country,
    "street": street,
    "firstName": firstName,
    "lastName": lastName,
    "phoneNumber": phoneNumber,
    "isDefault": isDefault,
    "createdAt": "${createdAt!.year.toString().padLeft(4, '0')}-${createdAt!.month.toString().padLeft(2, '0')}-${createdAt!.day.toString().padLeft(2, '0')}",
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
  };
}

class PickupAddress {
  String? name;
  String? addressLine1;
  String? addressLine2;
  String? city;
  String? country;
  String? postCode;
  String? contact;

  PickupAddress({
    this.name,
    this.addressLine1,
    this.addressLine2,
    this.city,
    this.country,
    this.postCode,
    this.contact,
  });

  factory PickupAddress.fromJson(Map<String, dynamic> json) => PickupAddress(
    name: json["name"],
    addressLine1: json["addressLine1"],
    addressLine2: json["addressLine2"],
    city: json["city"],
    country: json["country"],
    postCode: json["postCode"],
    contact: json["contact"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "country": country,
    "postCode": postCode,
    "contact": contact,
  };
}

class ProductVariation {
  int? id;
  List<ProductAttributeMapping>? productAttributeMappings;

  ProductVariation({
    this.id,
    this.productAttributeMappings,
  });

  factory ProductVariation.fromJson(Map<String, dynamic> json) => ProductVariation(
    id: json["id"],
    productAttributeMappings: json["product_attribute_mappings"] == null ? [] : List<ProductAttributeMapping>.from(json["product_attribute_mappings"]!.map((x) => ProductAttributeMapping.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_attribute_mappings": productAttributeMappings == null ? [] : List<dynamic>.from(productAttributeMappings!.map((x) => x.toJson())),
  };
}

class ProductAttributeMapping {
  int? id;
  int? variationId;
  int? attributeId;
  String? value;
  DateTime? createdAt;
  DateTime? updatedAt;
  Attribute? attribute;

  ProductAttributeMapping({
    this.id,
    this.variationId,
    this.attributeId,
    this.value,
    this.createdAt,
    this.updatedAt,
    this.attribute,
  });

  factory ProductAttributeMapping.fromJson(Map<String, dynamic> json) => ProductAttributeMapping(
    id: json["id"],
    variationId: json["variationId"],
    attributeId: json["attributeId"],
    value: json["value"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    attribute: json["attribute"] == null ? null : Attribute.fromJson(json["attribute"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "variationId": variationId,
    "attributeId": attributeId,
    "value": value,
    "createdAt": "${createdAt!.year.toString().padLeft(4, '0')}-${createdAt!.month.toString().padLeft(2, '0')}-${createdAt!.day.toString().padLeft(2, '0')}",
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
    "attribute": attribute?.toJson(),
  };
}

class Attribute {
  int? id;
  String? attributeName;

  Attribute({
    this.id,
    this.attributeName,
  });

  factory Attribute.fromJson(Map<String, dynamic> json) => Attribute(
    id: json["id"],
    attributeName: json["attributeName"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "attributeName": attributeName,
  };
}

class User {
  String? firstName;
  String? lastName;
  dynamic middleName;
  String? email;
  dynamic contact;

  User({
    this.firstName,
    this.lastName,
    this.middleName,
    this.email,
    this.contact,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    firstName: json["firstName"],
    lastName: json["lastName"],
    middleName: json["middleName"],
    email: json["email"],
    contact: json["contact"],
  );

  Map<String, dynamic> toJson() => {
    "firstName": firstName,
    "lastName": lastName,
    "middleName": middleName,
    "email": email,
    "contact": contact,
  };
}