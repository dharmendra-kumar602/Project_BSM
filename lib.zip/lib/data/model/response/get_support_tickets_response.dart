import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetSupportTicketsResponse getSupportTicketsResponseFromJson(String str) => GetSupportTicketsResponse.fromJson(json.decode(str));

String getSupportTicketsResponseToJson(GetSupportTicketsResponse data) => json.encode(data.toJson());

class GetSupportTicketsResponse {
  final ResponseHeader responseHeader;
  final List<Ticket> tickets;

  GetSupportTicketsResponse({
    required this.responseHeader,
    required this.tickets,
  });

  factory GetSupportTicketsResponse.fromJson(Map<String, dynamic> json) => GetSupportTicketsResponse(
    responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
    tickets: List<Ticket>.from(json["tickets"].map((x) => Ticket.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "tickets": List<dynamic>.from(tickets.map((x) => x.toJson())),
  };
}

class Ticket {
  final int id;
  final String title;
  final String description;
  String status;
  final int userId;
  final DateTime createdAt;
  final DateTime updatedAt;

  Ticket({
    required this.id,
    required this.title,
    required this.description,
    required this.status,
    required this.userId,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Ticket.fromJson(Map<String, dynamic> json) => Ticket(
    id: json["id"],
    title: json["title"],
    description: json["description"],
    status: json["status"],
    userId: json["userId"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "description": description,
    "status": status,
    "userId": userId,
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
  };
}