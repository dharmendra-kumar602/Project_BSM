import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

GetWishlistResponse getWishlistResponseFromJson(String str) => GetWishlistResponse.fromJson(json.decode(str));

class GetWishlistResponse {
  final ResponseHeader responseHeader;
  List<WishlistDatum>? data;

  GetWishlistResponse({
    required this.responseHeader,
    this.data,
  });

  factory GetWishlistResponse.fromJson(Map<String, dynamic> json) {
    if (json["data"] == null) {
      return GetWishlistResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return GetWishlistResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: List<WishlistDatum>.from(json["data"].map((x) => WishlistDatum.fromJson(x))),
      );
    }
  }
}

class WishlistDatum {
  final DateTime createdAt;
  final DateTime updatedAt;
  final Variation variation;

  WishlistDatum({
    required this.createdAt,
    required this.updatedAt,
    required this.variation,
  });

  factory WishlistDatum.fromJson(Map<String, dynamic> json) => WishlistDatum(
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    variation: Variation.fromJson(json["variation"]),
  );

  Map<String, dynamic> toJson() => {
    "createdAt": "${createdAt.year.toString().padLeft(4, '0')}-${createdAt.month.toString().padLeft(2, '0')}-${createdAt.day.toString().padLeft(2, '0')}",
    "updatedAt": "${updatedAt.year.toString().padLeft(4, '0')}-${updatedAt.month.toString().padLeft(2, '0')}-${updatedAt.day.toString().padLeft(2, '0')}",
    "variation": variation.toJson(),
  };
}

class Variation {
  final int id;
  final dynamic salePrice;
  final dynamic maxRetailPrice;
  final dynamic weightInPound;
  final List<WishlistProductImage> productImages;
  final WishlistProduct product;

  Variation({
    required this.id,
    required this.salePrice,
    required this.maxRetailPrice,
    required this.weightInPound,
    required this.productImages,
    required this.product,
  });

  factory Variation.fromJson(Map<String, dynamic> json) => Variation(
    id: json["id"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    weightInPound: json["weightInPound"] ?? 0,
    productImages: List<WishlistProductImage>.from(json["product_images"].map((x) => WishlistProductImage.fromJson(x))),
    product: WishlistProduct.fromJson(json["product"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "weightInPound": weightInPound,
    "product_images": List<dynamic>.from(productImages.map((x) => x.toJson())),
    "product": product.toJson(),
  };
}

class WishlistProduct {
  final int id;
  final String title;
  final String description;
  final WishlistSellerStore sellerStore;

  WishlistProduct({
    required this.id,
    required this.title,
    required this.description,
    required this.sellerStore,
  });

  factory WishlistProduct.fromJson(Map<String, dynamic> json) => WishlistProduct(
    id: json["id"],
    title: json["title"],
    description: json["description"],
    sellerStore: WishlistSellerStore.fromJson(json["sellerStore"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "description": description,
    "sellerStore": sellerStore.toJson(),
  };
}

class WishlistSellerStore {
  final int id;

  WishlistSellerStore({
    required this.id,
  });

  factory WishlistSellerStore.fromJson(Map<String, dynamic> json) => WishlistSellerStore(
    id: json["id"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
  };
}

class WishlistProductImage {
  final String imageName;

  WishlistProductImage({
    required this.imageName,
  });

  factory WishlistProductImage.fromJson(Map<String, dynamic> json) => WishlistProductImage(
    imageName: json["imageName"],
  );

  Map<String, dynamic> toJson() => {
    "imageName": imageName,
  };
}