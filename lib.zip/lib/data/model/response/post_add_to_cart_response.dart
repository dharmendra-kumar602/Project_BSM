import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostAddToCartResponse postAddToCartResponseFromJson(String str) => PostAddToCartResponse.fromJson(json.decode(str));

String postAddToCartResponseToJson(PostAddToCartResponse data) => json.encode(data.toJson());

class PostAddToCartResponse {
  final ResponseHeader responseHeader;
  List<Datum>? data;

  PostAddToCartResponse({
    required this.responseHeader,
    this.data,
  });

  factory PostAddToCartResponse.fromJson(Map<String, dynamic> json) {
    if (json["data"] == null) {
      return PostAddToCartResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
      );
    } else {
      return PostAddToCartResponse(
        responseHeader: ResponseHeader.fromJson(json["responseHeader"]),
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  final int id;
  final int productId;
  final int productVariationId;
  final int cartId;
  final int quantity;
  final String createdAt;
  final String updatedAt;

  Datum({
    required this.id,
    required this.productId,
    required this.productVariationId,
    required this.cartId,
    required this.quantity,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    productId: json["productId"],
    productVariationId: json["productVariationId"],
    cartId: json["cartId"],
    quantity: json["quantity"],
    createdAt: json["createdAt"],
    updatedAt: json["updatedAt"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "productId": productId,
    "productVariationId": productVariationId,
    "cartId": cartId,
    "quantity": quantity,
    "createdAt": createdAt,
    "updatedAt": updatedAt,
  };
}