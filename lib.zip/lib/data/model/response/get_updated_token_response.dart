import 'dart:convert';

GetUpdatedTokenResponse getUpdatedTokenResponseFromJson(String str) => GetUpdatedTokenResponse.fromJson(json.decode(str));

String getUpdatedTokenResponseToJson(GetUpdatedTokenResponse data) => json.encode(data.toJson());

class GetUpdatedTokenResponse {
  final UTResponseHeader responseHeader;
  final Token token;

  GetUpdatedTokenResponse({
    required this.responseHeader,
    required this.token,
  });

  factory GetUpdatedTokenResponse.fromJson(Map<String, dynamic> json) => GetUpdatedTokenResponse(
    responseHeader: UTResponseHeader.fromJson(json["responseHeader"]),
    token: Token.fromJson(json["token"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader.toJson(),
    "token": token.toJson(),
  };
}

class UTResponseHeader {
  final String requestId;
  final String responseId;
  final String message;
  final String status;

  UTResponseHeader({
    required this.requestId,
    required this.responseId,
    required this.message,
    required this.status,
  });

  factory UTResponseHeader.fromJson(Map<String, dynamic> json) => UTResponseHeader(
    requestId: json["requestId"],
    responseId: json["responseId"],
    message: json["message"],
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "requestId": requestId,
    "responseId": responseId,
    "message": message,
    "status": status,
  };
}

class Token {
  final String verificationStatus;
  final String jwtToken;

  Token({
    required this.verificationStatus,
    required this.jwtToken,
  });

  factory Token.fromJson(Map<String, dynamic> json) => Token(
    verificationStatus: json["verificationStatus"],
    jwtToken: json["jwt_token"],
  );

  Map<String, dynamic> toJson() => {
    "verificationStatus": verificationStatus,
    "jwt_token": jwtToken,
  };
}
