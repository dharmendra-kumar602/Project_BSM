import 'dart:convert';

import 'package:take_my_tack/core/model/response_header.dart';

PostDeleteProductResponse postDeleteProductResponseFromJson(String str) => PostDeleteProductResponse.fromJson(json.decode(str));

String postDeleteProductResponseToJson(PostDeleteProductResponse data) => json.encode(data.toJson());

class PostDeleteProductResponse {
  ResponseHeader? responseHeader;
  Data? data;

  PostDeleteProductResponse({
    this.responseHeader,
    this.data,
  });

  factory PostDeleteProductResponse.fromJson(Map<String, dynamic> json) => PostDeleteProductResponse(
    responseHeader: json["responseHeader"] == null ? null : ResponseHeader.fromJson(json["responseHeader"]),
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "responseHeader": responseHeader?.toJson(),
    "data": data?.toJson(),
  };
}

class Data {
  int? id;
  int? productId;
  dynamic? salePrice;
  dynamic? maxRetailPrice;
  dynamic? heightInCentimeter;
  dynamic? widthInCentimeter;
  dynamic? lengthInCentimeter;
  String? condition;
  dynamic discountInPercent;
  dynamic? weightInPound;
  int? isActive;
  String? approvalStatus;
  int? inStock;
  int? initialStock;
  dynamic rejectionReason;
  DateTime? createdAt;
  DateTime? updatedAt;

  Data({
    this.id,
    this.productId,
    this.salePrice,
    this.maxRetailPrice,
    this.heightInCentimeter,
    this.widthInCentimeter,
    this.lengthInCentimeter,
    this.condition,
    this.discountInPercent,
    this.weightInPound,
    this.isActive,
    this.approvalStatus,
    this.inStock,
    this.initialStock,
    this.rejectionReason,
    this.createdAt,
    this.updatedAt,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    productId: json["productId"],
    salePrice: json["salePrice"],
    maxRetailPrice: json["maxRetailPrice"],
    heightInCentimeter: json["heightInCentimeter"],
    widthInCentimeter: json["widthInCentimeter"],
    lengthInCentimeter: json["lengthInCentimeter"],
    condition: json["condition"],
    discountInPercent: json["discountInPercent"],
    weightInPound: json["weightInPound"],
    isActive: json["isActive"],
    approvalStatus: json["approvalStatus"],
    inStock: json["inStock"],
    initialStock: json["initialStock"],
    rejectionReason: json["rejectionReason"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "productId": productId,
    "salePrice": salePrice,
    "maxRetailPrice": maxRetailPrice,
    "heightInCentimeter": heightInCentimeter,
    "widthInCentimeter": widthInCentimeter,
    "lengthInCentimeter": lengthInCentimeter,
    "condition": condition,
    "discountInPercent": discountInPercent,
    "weightInPound": weightInPound,
    "isActive": isActive,
    "approvalStatus": approvalStatus,
    "inStock": inStock,
    "initialStock": initialStock,
    "rejectionReason": rejectionReason,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": "${updatedAt!.year.toString().padLeft(4, '0')}-${updatedAt!.month.toString().padLeft(2, '0')}-${updatedAt!.day.toString().padLeft(2, '0')}",
  };
}