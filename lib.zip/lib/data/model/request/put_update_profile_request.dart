import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PutUpdateProfileRequest putUpdateProfileRequestFromJson(String str) => PutUpdateProfileRequest.fromJson(json.decode(str));

String putUpdateProfileRequestToJson(PutUpdateProfileRequest data) => json.encode(data.toJson());

class PutUpdateProfileRequest {
  final RequestHeader requestHeader;
  String? contact;
  String? firstName;
  String? lastName;
  String? email;

  PutUpdateProfileRequest({
    required this.requestHeader,
    this.contact,
    this.firstName,
    this.lastName,
    this.email,
  });

  factory PutUpdateProfileRequest.fromJson(Map<String, dynamic> json) {
    if (json["contact"] != null) {
      return PutUpdateProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        contact: json["contact"],
      );
    }
    if (json["firstName"] != null) {
      return PutUpdateProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        firstName: json["firstName"],
      );
    }
    if (json["lastName"] != null) {
      return PutUpdateProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        lastName: json["lastName"],
      );
    }
    if (json["email"] != null) {
      return PutUpdateProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        email: json["email"],
      );
    }

    return PutUpdateProfileRequest(
      requestHeader: RequestHeader.fromJson(json["requestHeader"]),
      contact: json["contact"],
      firstName: json["firstName"],
      lastName: json["lastName"],
      email: json["email"],
    );
  }

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "contact": contact,
    "firstName": firstName,
    "lastName": lastName,
    "email": email,
  };
}