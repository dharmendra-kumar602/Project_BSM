import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostResendSellerRegistrationOtpRequest postResendSignupOtpRequestFromJson(String str) => PostResendSellerRegistrationOtpRequest.fromJson(json.decode(str));

String postResendSignupOtpRequestToJson(PostResendSellerRegistrationOtpRequest data) => json.encode(data.toJson());

class PostResendSellerRegistrationOtpRequest {
  final RequestHeader requestHeader;
  final String storeId;

  PostResendSellerRegistrationOtpRequest({
    required this.requestHeader,
    required this.storeId,
  });

  factory PostResendSellerRegistrationOtpRequest.fromJson(Map<String, dynamic> json) => PostResendSellerRegistrationOtpRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    storeId: json["storeId"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "storeId": storeId,
  };
}