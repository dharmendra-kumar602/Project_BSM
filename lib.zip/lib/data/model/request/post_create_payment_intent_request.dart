import 'dart:convert';

PostCreatePaymentIntentRequest postCreatePaymentIntentRequestFromJson(String str) => PostCreatePaymentIntentRequest.fromJson(json.decode(str));

String postCreatePaymentIntentRequestToJson(PostCreatePaymentIntentRequest data) => json.encode(data.toJson());

class PostCreatePaymentIntentRequest {
  final int amount;
  final List<String> paymentMethod;
  final String orderId;
  final PRShipping shipping;

  PostCreatePaymentIntentRequest({
    required this.amount,
    required this.paymentMethod,
    required this.orderId,
    required this.shipping,
  });

  factory PostCreatePaymentIntentRequest.fromJson(Map<String, dynamic> json) => PostCreatePaymentIntentRequest(
    amount: json["amount"],
    paymentMethod: List<String>.from(json["payment_method"].map((x) => x)),
    orderId: json["orderId"],
    shipping: PRShipping.fromJson(json["shipping"]),
  );

  Map<String, dynamic> toJson() => {
    "amount": amount,
    "payment_method": List<dynamic>.from(paymentMethod.map((x) => x)),
    "orderId": orderId,
    "shipping": shipping.toJson(),
  };
}

class PRShipping {
  final PRAddress address;

  PRShipping({
    required this.address,
  });

  factory PRShipping.fromJson(Map<String, dynamic> json) => PRShipping(
    address: PRAddress.fromJson(json["address"]),
  );

  Map<String, dynamic> toJson() => {
    "address": address.toJson(),
  };
}

class PRAddress {
  final String line1;
  final String line2;
  final String postalCode;
  final String city;
  final String state;
  final String country;

  PRAddress({
    required this.line1,
    required this.line2,
    required this.postalCode,
    required this.city,
    required this.state,
    required this.country,
  });

  factory PRAddress.fromJson(Map<String, dynamic> json) => PRAddress(
    line1: json["line1"],
    line2: json["line2"],
    postalCode: json["postal_code"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
  );

  Map<String, dynamic> toJson() => {
    "line1": line1,
    "line2": line2,
    "postal_code": postalCode,
    "city": city,
    "state": state,
    "country": country,
  };
}
