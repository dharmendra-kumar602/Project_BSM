import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostAddToCartRequest postAddToCartRequestFromJson(String str) => PostAddToCartRequest.fromJson(json.decode(str));

String postAddToCartRequestToJson(PostAddToCartRequest data) => json.encode(data.toJson());

class PostAddToCartRequest {
  final RequestHeader requestHeader;
  final int variationId;
  final int productId;

  PostAddToCartRequest({
    required this.requestHeader,
    required this.variationId,
    required this.productId,
  });

  factory PostAddToCartRequest.fromJson(Map<String, dynamic> json) => PostAddToCartRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    variationId: json["variationId"],
    productId: json["productId"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "variationId": variationId,
    "productId": productId,
  };
}

/// For buck items ----------------------------------------------
PostAddBulkToCartRequest postAddBulkToCartRequestFromJson(String str) => PostAddBulkToCartRequest.fromJson(json.decode(str));

String postAddBulkToCartRequestToJson(PostAddBulkToCartRequest data) => json.encode(data.toJson());

class PostAddBulkToCartRequest {
  final RequestHeader requestHeader;
  final List<CartItem> items;

  PostAddBulkToCartRequest({
    required this.requestHeader,
    required this.items,
  });

  factory PostAddBulkToCartRequest.fromJson(Map<String, dynamic> json) => PostAddBulkToCartRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    items: List<CartItem>.from(json["items"].map((x) => CartItem.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class CartItem {
  final int productId;
  final int productVariationId;
  final int quantity;

  CartItem({
    required this.productId,
    required this.productVariationId,
    required this.quantity,
  });

  factory CartItem.fromJson(Map<String, dynamic> json) => CartItem(
    productId: json["productId"],
    productVariationId: json["productVariationId"],
    quantity: json["quantity"],
  );

  Map<String, dynamic> toJson() => {
    "productId": productId,
    "productVariationId": productVariationId,
    "quantity": quantity,
  };
}