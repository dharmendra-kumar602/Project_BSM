import 'dart:convert';
import 'dart:io';

import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';

String postUpdateProductRequestToJson(PostUpdateProductRequest data) => json.encode(data.toJson());

class PostUpdateProductRequest {
  int? productId;
  int? categoryId;
  String? productName;
  String? productDescription;
  String? brandName;
  int? variationId;
  dynamic? variationPrice;
  dynamic? variationWeight;
  dynamic? variationLength;
  dynamic? variationHeight;
  dynamic? variationWidth;
  String? variationCondition;
  String? variationProcessingTime;
  List<VariationAttribute>? variationAttributes;
  final List<File?> productImages;

  PostUpdateProductRequest({
    this.productId,
    this.categoryId,
    this.productName,
    this.productDescription,
    this.brandName,
    this.variationId,
    this.variationPrice,
    this.variationWeight,
    this.variationLength,
    this.variationHeight,
    this.variationWidth,
    this.variationCondition,
    this.variationProcessingTime,
    this.variationAttributes,
    required this.productImages
  });

  Future<Map<String, dynamic>> toJson() async {
    Map<String, dynamic> v = {
      "productId": productId,
      "categoryId": categoryId,
      "productName": productName,
      "productDescription": productDescription,
      "brandName": brandName,
      "variationId": variationId,
      "variationPrice": variationPrice,
      "variationWeight": variationWeight,
      "variationLength": variationLength,
      "variationHeight": variationHeight,
      "variationWidth": variationWidth,
      "variationCondition": variationCondition,
      "variationProcessingTime": variationProcessingTime,
      "variationAttributes": variationAttributes == null ? [] : List<dynamic>.from(variationAttributes!.map((x) => x.toJson())),
    };
    for (int i=0; i<productImages.length; i++) {
      v.addAll(await DioUtils.createProductImagesRequestByMultipart(productImages[i], i));
    }
    return v;
  }
}

class VariationAttribute {
  int? id;
  String? name;
  String? value;

  VariationAttribute({
    this.id,
    this.name,
    this.value,
  });

  factory VariationAttribute.fromJson(Map<String, dynamic> json) => VariationAttribute(
    id: json["id"],
    name: json["name"],
    value: json["value"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "value": value,
  };
}
