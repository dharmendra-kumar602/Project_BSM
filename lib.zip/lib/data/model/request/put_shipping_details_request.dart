import 'dart:convert';

PutShippingDetailsRequest putShippingDetailsRequestFromJson(String str) => PutShippingDetailsRequest.fromJson(json.decode(str));

String putShippingDetailsRequestToJson(PutShippingDetailsRequest data) => json.encode(data.toJson());

class PutShippingDetailsRequest {
  int? isFreeShippingEnabled;
  int? freeShippingMinimumCost;
  int? isPickupFromStoreEnabled;
  int? pickupFromStoreHandlingCharges;
  List<CountryWiseShipping>? countryWiseShipping;

  PutShippingDetailsRequest({
    this.isFreeShippingEnabled,
    this.freeShippingMinimumCost,
    this.isPickupFromStoreEnabled,
    this.pickupFromStoreHandlingCharges,
    this.countryWiseShipping,
  });

  factory PutShippingDetailsRequest.fromJson(Map<String, dynamic> json) => PutShippingDetailsRequest(
    isFreeShippingEnabled: json["isFreeShippingEnabled"],
    freeShippingMinimumCost: json["freeShippingMinimumCost"],
    isPickupFromStoreEnabled: json["isPickupFromStoreEnabled"],
    pickupFromStoreHandlingCharges: json["pickupFromStoreHandlingCharges"],
    countryWiseShipping: json["countryWiseShipping"] == null ? [] : List<CountryWiseShipping>.from(json["countryWiseShipping"]!.map((x) => CountryWiseShipping.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "isFreeShippingEnabled": isFreeShippingEnabled,
    "freeShippingMinimumCost": freeShippingMinimumCost,
    "isPickupFromStoreEnabled": isPickupFromStoreEnabled,
    "pickupFromStoreHandlingCharges": pickupFromStoreHandlingCharges,
    "countryWiseShipping": countryWiseShipping == null ? [] : List<dynamic>.from(countryWiseShipping!.map((x) => x.toJson())),
  };
}

class CountryWiseShipping {
  String? country;
  int? defaultCost;
  List<ShippingRule>? rules;

  CountryWiseShipping({
    this.country,
    this.defaultCost,
    this.rules,
  });

  factory CountryWiseShipping.fromJson(Map<String, dynamic> json) => CountryWiseShipping(
    country: json["country"],
    defaultCost: json["defaultCost"],
    rules: json["rules"] == null ? [] : List<ShippingRule>.from(json["rules"]!.map((x) => ShippingRule.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "country": country,
    "defaultCost": defaultCost,
    "rules": rules == null ? [] : List<dynamic>.from(rules!.map((x) => x.toJson())),
  };
}

class ShippingRule {
  String? ruleType;
  int? ruleWeight;
  int? ruleCost;

  ShippingRule({
    this.ruleType,
    this.ruleWeight,
    this.ruleCost,
  });

  factory ShippingRule.fromJson(Map<String, dynamic> json) => ShippingRule(
    ruleType: json["ruleType"],
    ruleWeight: json["ruleWeight"],
    ruleCost: json["ruleCost"],
  );

  Map<String, dynamic> toJson() => {
    "ruleType": ruleType,
    "ruleWeight": ruleWeight,
    "ruleCost": ruleCost,
  };
}
