
class GetProductsBySellerIdRequest {
  final int pageSize;
  final int pageNumber;
  int? sellerId;
  String? approvalStatus;
  String? sortId;
  List? filtersIds;
  List? filtersValues;

  GetProductsBySellerIdRequest(
      {required this.pageSize,
      required this.pageNumber,
      this.sellerId,
      this.approvalStatus,
      this.sortId,
        this.filtersIds,
        this.filtersValues
      });

  Map<String, dynamic> toJson() {
    Map<String, dynamic> map = {};
    if (sortId == null) {
      map = {
        "pageSize": pageSize,
        "pageNumber": pageNumber,
      };
    } else {
      map = {
        "pageSize": pageSize,
        "pageNumber": pageNumber,
        "sortId": sortId,
      };
    }
    for (int i=0; i<(filtersIds?.length ?? 0); i++) {
      map.addAll({
        "filter[$i][attributeId]" : filtersIds?[i],
        "filter[$i][value]" : filtersValues?[i],
      });
    }
    return map;
  }
}
