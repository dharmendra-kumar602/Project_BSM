import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

UpdateBuyerPasswordRequest updateBuyerPasswordRequestFromJson(String str) => UpdateBuyerPasswordRequest.fromJson(json.decode(str));

String updateBuyerPasswordRequestToJson(UpdateBuyerPasswordRequest data) => json.encode(data.toJson());

class UpdateBuyerPasswordRequest {
  final RequestHeader requestHeader;
  final String oldPassword;
  final String newPassword;

  UpdateBuyerPasswordRequest({
    required this.requestHeader,
    required this.oldPassword,
    required this.newPassword,
  });

  factory UpdateBuyerPasswordRequest.fromJson(Map<String, dynamic> json) => UpdateBuyerPasswordRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    oldPassword: json["oldPassword"],
    newPassword: json["newPassword"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "oldPassword": oldPassword,
    "newPassword": newPassword,
  };
}
