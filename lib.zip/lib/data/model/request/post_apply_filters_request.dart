import 'dart:convert';

PostProductFiltersReruest postProductFiltersReruestFromJson(String str) => PostProductFiltersReruest.fromJson(json.decode(str));

String postProductFiltersReruestToJson(PostProductFiltersReruest data) => json.encode(data.toJson());

class PostProductFiltersReruest {
  List<int>? categoryIds;
  List<int>? brands;
  List<int>? sellers;
  List<int>? locationIds;
  List<Attribute> attributes;
  int pageSize;
  int pageNumber;
  String sortId;
  bool isTrending;

  PostProductFiltersReruest({
    this.categoryIds,
    this.brands,
    this.sellers,
    this.locationIds,
    required this.attributes,
    required this.pageSize,
    required this.pageNumber,
    required this.sortId,
    required this.isTrending
  });

  factory PostProductFiltersReruest.fromJson(Map<String, dynamic> json) => PostProductFiltersReruest(
    categoryIds: List<int>.from(json["categoryIds"].map((x) => x)),
    brands: List<int>.from(json["brands"].map((x) => x)),
    sellers: List<int>.from(json["storeId"].map((x) => x)),
    locationIds: List<int>.from(json["locationIds"].map((x) => x)),
    attributes: List<Attribute>.from(json["attributes"].map((x) => Attribute.fromJson(x))),
    pageSize: json["pageSize"],
    pageNumber: json["pageNumber"],
    sortId: json["sortId"], isTrending: json["isTrending"],
  );

  Map<String, dynamic> toJson() => {
    "categoryIds": categoryIds == null ? [] : List<dynamic>.from(categoryIds!.map((x) => x)),
    "brands": brands == null ? [] : List<dynamic>.from(brands!.map((x) => x)),
    "storeId": sellers == null ? [] : List<dynamic>.from(sellers!.map((x) => x)),
    "locationIds": locationIds == null ? [] : List<dynamic>.from(locationIds!.map((x) => x)),
    "attributes": List<dynamic>.from(attributes.map((x) => x.toJson())),
    "pageSize": pageSize,
    "pageNumber": pageNumber,
    "sortId": sortId,
    "isTrending": isTrending,
  };
}

class Attribute {
  final int id;
  final String name;
  final List<String> values;

  Attribute({
    required this.id,
    required this.name,
    required this.values,
  });

  factory Attribute.fromJson(Map<String, dynamic> json) => Attribute(
    id: json["id"],
    name: json["name"],
    values: List<String>.from(json["values"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "values": List<dynamic>.from(values.map((x) => x)),
  };
}
