import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostValidateOtpRequest postValidateOtpRequestFromJson(String str) => PostValidateOtpRequest.fromJson(json.decode(str));

String postValidateOtpRequestToJson(PostValidateOtpRequest data) => json.encode(data.toJson());

class PostValidateOtpRequest {
  final RequestHeader requestHeader;
  final String email;
  final String otp;
  final int otpType;

  PostValidateOtpRequest({
    required this.requestHeader,
    required this.email,
    required this.otp,
    required this.otpType,
  });

  factory PostValidateOtpRequest.fromJson(Map<String, dynamic> json) => PostValidateOtpRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    email: json["email"],
    otp: json["otp"],
    otpType: json["otpType"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "email": email,
    "otp": otp,
    "otpType": otpType,
  };
}