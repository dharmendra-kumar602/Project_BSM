import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostResendSignupOtpRequest postResendSignupOtpRequestFromJson(String str) => PostResendSignupOtpRequest.fromJson(json.decode(str));

String postResendSignupOtpRequestToJson(PostResendSignupOtpRequest data) => json.encode(data.toJson());

class PostResendSignupOtpRequest {
  final RequestHeader requestHeader;
  final String email;

  PostResendSignupOtpRequest({
    required this.requestHeader,
    required this.email,
  });

  factory PostResendSignupOtpRequest.fromJson(Map<String, dynamic> json) => PostResendSignupOtpRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    email: json["email"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "email": email,
  };
}