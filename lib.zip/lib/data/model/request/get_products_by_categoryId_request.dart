class GetProductsByCategoryIdRequest {
  final int pageSize;
  final int pageNumber;
  int? categoryId;
  final String sortId;

  GetProductsByCategoryIdRequest(
      {required this.pageSize,
      required this.pageNumber,
      this.categoryId,
      required this.sortId});

  factory GetProductsByCategoryIdRequest.fromJson(Map<String, dynamic> json) =>
      GetProductsByCategoryIdRequest(
        pageSize: json["pageSize"],
        pageNumber: json["pageNumber"],
        sortId: json["sortId"],
      );

  Map<String, dynamic> toJson() => {
    "pageSize": pageSize,
    "pageNumber": pageNumber,
    "sortId": sortId,
  };
}

class GetProductsByBrandIdRequest {
  final int pageSize;
  final int pageNumber;
  String? brandId;
  final String sortId;

  GetProductsByBrandIdRequest(
      {required this.pageSize,
        required this.pageNumber,
        this.brandId,
        required this.sortId});

  factory GetProductsByBrandIdRequest.fromJson(Map<String, dynamic> json) =>
      GetProductsByBrandIdRequest(
        pageSize: json["pageSize"],
        pageNumber: json["pageNumber"],
        sortId: json["sortId"],
      );

  Map<String, dynamic> toJson() => {
    "pageSize": pageSize,
    "pageNumber": pageNumber,
    "sortId": sortId,
  };
}