import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PutUpdateSellerProfileRequest putUpdateProfileRequestFromJson(String str) => PutUpdateSellerProfileRequest.fromJson(json.decode(str));

String putUpdateSellerProfileRequestToJson(PutUpdateSellerProfileRequest data) => json.encode(data.toJson());

class PutUpdateSellerProfileRequest {
  final RequestHeader requestHeader;
  String? contact;
  String? firstName;
  String? lastName;
  String? email;
  String? addressLine1;
  String? addressLine2;
  String? city;
  String? country;
  String? county;
  String? postCode;

  PutUpdateSellerProfileRequest({
    required this.requestHeader,
    this.contact,
    this.firstName,
    this.lastName,
    this.email,
    this.addressLine1,
    this.addressLine2,
    this.city,
    this.country,
    this.county,
    this.postCode,
  });

  factory PutUpdateSellerProfileRequest.fromJson(Map<String, dynamic> json) {
    if (json["contact"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        contact: json["contact"],
      );
    }
    if (json["firstName"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        firstName: json["firstName"],
      );
    }
    if (json["lastName"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        lastName: json["lastName"],
      );
    }
    if (json["email"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        email: json["email"],
      );
    }
    if (json["addressLine1"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        addressLine1: json["addressLine1"],
      );
    }
    if (json["addressLine2"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        addressLine2: json["addressLine2"],
      );
    }
    if (json["city"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        addressLine2: json["city"],
      );
    }
    if (json["country"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        country: json["country"],
      );
    }
    if (json["county"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        county: json["county"],
      );
    }
    if (json["postCode"] != null) {
      return PutUpdateSellerProfileRequest(
        requestHeader: RequestHeader.fromJson(json["requestHeader"]),
        postCode: json["postCode"],
      );
    }

    return PutUpdateSellerProfileRequest(
      requestHeader: RequestHeader.fromJson(json["requestHeader"]),
      contact: json["contact"],
      firstName: json["firstName"],
      lastName: json["lastName"],
      email: json["email"],
      addressLine1: json["addressLine1"],
      addressLine2: json["addressLine2"],
      city: json["city"],
      country: json["country"],
      county: json["county"],
      postCode: json["postCode"],
    );
  }

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "contact": contact,
    "firstName": firstName,
    "lastName": lastName,
    "email": email,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "country": country,
    "county": county,
    "postCode": postCode,
  };
}