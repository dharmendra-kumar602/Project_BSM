import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostRegisterRequest postRegisterRequestFromJson(String str) => PostRegisterRequest.fromJson(json.decode(str));

String postRegisterRequestToJson(PostRegisterRequest data) => json.encode(data.toJson());

class PostRegisterRequest {
  final RequestHeader requestHeader;
  final String firstName;
  final String lastName;
  final String email;
  final String password;
  final bool termOfServicesConsent;
  final String role;
  final String gender;

  PostRegisterRequest({
    required this.requestHeader,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.password,
    required this.termOfServicesConsent,
    required this.role,
    required this.gender,
  });

  factory PostRegisterRequest.fromJson(Map<String, dynamic> json) => PostRegisterRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    firstName: json["firstName"],
    lastName: json["lastName"],
    email: json["email"],
    password: json["password"],
    termOfServicesConsent: json["termOfServicesConsent"],
    role: json["role"],
    gender: json["gender"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "firstName": firstName,
    "lastName": lastName,
    "email": email,
    "password": password,
    "termOfServicesConsent": termOfServicesConsent,
    "role": role,
    "gender": gender,
  };
}