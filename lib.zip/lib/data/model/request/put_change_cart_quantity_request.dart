import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PutChangeCartQuantityRequest putChangeCartQuantityRequestFromJson(String str) => PutChangeCartQuantityRequest.fromJson(json.decode(str));

String putChangeCartQuantityRequestToJson(PutChangeCartQuantityRequest data) => json.encode(data.toJson());

class PutChangeCartQuantityRequest {
  final RequestHeader requestHeader;
  final int variationId;

  PutChangeCartQuantityRequest({
    required this.requestHeader,
    required this.variationId,
  });

  factory PutChangeCartQuantityRequest.fromJson(Map<String, dynamic> json) => PutChangeCartQuantityRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    variationId: json["variationId"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "variationId": variationId,
  };
}