import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostRegisterSellerRequest postForgotPasswordRequestFromJson(String str) => PostRegisterSellerRequest.fromJson(json.decode(str));

String postForgotPasswordRequestToJson(PostRegisterSellerRequest data) => json.encode(data.toJson());

class PostRegisterSellerRequest {
  final String storeName;
  final String email;
  final String addressLine1;
  final String addressLine2;
  final String city;
  final String storeImage;
  final String country;
  final String postCode;
  final String contact;
  final String about;
  final String dob;
  final String county;

  PostRegisterSellerRequest({
    required this.storeName,
    required this.email,
    required this.addressLine1,
    required this.addressLine2,
    required this.city,
    required this.storeImage,
    required this.country,
    required this.postCode,
    required this.contact,
    required this.about,
    required this.dob,
    required this.county,
  });

  factory PostRegisterSellerRequest.fromJson(Map<String, dynamic> json) => PostRegisterSellerRequest(
    storeName: json["storeName"],
    email: json["email"],
    addressLine1: json["addressLine1"],
    addressLine2: json["addressLine2"],
    city: json["city"],
    storeImage: json["storeImage"],
    country: json["country"],
    postCode: json["postCode"],
    contact: json["contact"],
    about: json["about"],
    dob: json["dob"],
    county: json["county"],
  );

  Map<String, dynamic> toJson() => {
    "storeName": storeName,
    "email": email,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "city": city,
    "storeImage": storeImage,
    "country": country,
    "postCode": postCode,
    "contact": contact,
    "about": about,
    "dob": dob,
    "county": county,
  };
}