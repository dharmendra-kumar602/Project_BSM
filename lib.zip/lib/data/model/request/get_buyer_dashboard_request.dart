class GetBuyerDashboardRequest {

  final int limit;
  final int offSet;

  GetBuyerDashboardRequest({required this.limit, required this.offSet});

  factory GetBuyerDashboardRequest.fromJson(Map<String, dynamic> json) => GetBuyerDashboardRequest(
    limit: json["limit"],
    offSet: json["offSet"],
  );

  Map<String, dynamic> toJson() => {
    "limit": limit,
    "offSet": offSet,
  };
}