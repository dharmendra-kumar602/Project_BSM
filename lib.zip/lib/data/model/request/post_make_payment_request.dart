import 'dart:convert';

PostMakePaymentOffSessionRequest postMakePaymentOffSessionRequestFromJson(String str) => PostMakePaymentOffSessionRequest.fromJson(json.decode(str));

String postMakePaymentOffSessionRequestToJson(PostMakePaymentOffSessionRequest data) => json.encode(data.toJson());

class PostMakePaymentOffSessionRequest {
  final int amount;
  final String paymentMethodId;
  final String orderId;
  final PORShipping shipping;

  PostMakePaymentOffSessionRequest({
    required this.amount,
    required this.paymentMethodId,
    required this.orderId,
    required this.shipping,
  });

  factory PostMakePaymentOffSessionRequest.fromJson(Map<String, dynamic> json) => PostMakePaymentOffSessionRequest(
    amount: json["amount"],
    paymentMethodId: json["paymentMethodId"],
    orderId: json["orderId"],
    shipping: PORShipping.fromJson(json["shipping"]),
  );

  Map<String, dynamic> toJson() => {
    "amount": amount,
    "paymentMethodId": paymentMethodId,
    "orderId": orderId,
    "shipping": shipping.toJson(),
  };
}

class PORShipping {
  final POAddress address;

  PORShipping({
    required this.address,
  });

  factory PORShipping.fromJson(Map<String, dynamic> json) => PORShipping(
    address: POAddress.fromJson(json["address"]),
  );

  Map<String, dynamic> toJson() => {
    "address": address.toJson(),
  };
}

class POAddress {
  final String line1;
  final String line2;
  final String postalCode;
  final String city;
  final String state;
  final String country;

  POAddress({
    required this.line1,
    required this.line2,
    required this.postalCode,
    required this.city,
    required this.state,
    required this.country,
  });

  factory POAddress.fromJson(Map<String, dynamic> json) => POAddress(
    line1: json["line1"],
    line2: json["line2"],
    postalCode: json["postal_code"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
  );

  Map<String, dynamic> toJson() => {
    "line1": line1,
    "line2": line2,
    "postal_code": postalCode,
    "city": city,
    "state": state,
    "country": country,
  };
}
