import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PutUpdateDeliveryTypeRequest putUpdateDeliveryTypeRequestFromJson(String str) => PutUpdateDeliveryTypeRequest.fromJson(json.decode(str));

String putUpdateDeliveryTypeRequestToJson(PutUpdateDeliveryTypeRequest data) => json.encode(data.toJson());

class PutUpdateDeliveryTypeRequest {
  final RequestHeader requestHeader;
  final String pickupOrDelivery;
  final List<int> cartItemIds;

  PutUpdateDeliveryTypeRequest({
    required this.requestHeader,
    required this.pickupOrDelivery,
    required this.cartItemIds,
  });

  factory PutUpdateDeliveryTypeRequest.fromJson(Map<String, dynamic> json) => PutUpdateDeliveryTypeRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    pickupOrDelivery: json["pickupOrDelivery"],
    cartItemIds: List<int>.from(json["cartItemIds"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "pickupOrDelivery": pickupOrDelivery,
    "cartItemIds": List<dynamic>.from(cartItemIds.map((x) => x)),
  };
}