import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostSupportTicketRequest postSupportTicketRequestFromJson(String str) => PostSupportTicketRequest.fromJson(json.decode(str));

String postSupportTicketRequestToJson(PostSupportTicketRequest data) => json.encode(data.toJson());

class PostSupportTicketRequest {
  final RequestHeader requestHeader;
  final String title;
  final String description;
  int? pageSize;
  int? pageNumber;
  String? time;

  PostSupportTicketRequest({
    required this.requestHeader,
    required this.title,
    required this.description,
    this.pageSize,
    this.pageNumber,
    this.time,
  });

  factory PostSupportTicketRequest.fromJson(Map<String, dynamic> json) => PostSupportTicketRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    title: json["title"],
    description: json["description"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "title": title,
    "description": description,
  };
}