import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PutUpdateFcmTokenRequest putUpdateFcmTokenFromJson (String str) => PutUpdateFcmTokenRequest.fromJson(json.decode(str));

String putUpdateFcmTokenToJson (PutUpdateFcmTokenRequest data) => json.encode(data.toJson());

class PutUpdateFcmTokenRequest {
  final RequestHeader requestHeader;
  final String fcmToken;
  final String userId;

  PutUpdateFcmTokenRequest({
    required this.requestHeader,
    required this.fcmToken,
    required this.userId,
  });

  factory PutUpdateFcmTokenRequest.fromJson(Map<String, dynamic> json) => PutUpdateFcmTokenRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
      fcmToken : json["fcmToken"],
    userId : json["userId"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "fcmToken" : fcmToken,
    "userId" : userId,
  };
}