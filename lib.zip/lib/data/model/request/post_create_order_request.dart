import 'dart:convert';

PostCreateOrderRequest postCreateOrderRequestFromJson(String str) => PostCreateOrderRequest.fromJson(json.decode(str));

String postCreateOrderRequestToJson(PostCreateOrderRequest data) => json.encode(data.toJson());

class PostCreateOrderRequest {
  final int cartId;
  final int deliveryAddressId;

  PostCreateOrderRequest({
    required this.cartId,
    required this.deliveryAddressId,
  });

  factory PostCreateOrderRequest.fromJson(Map<String, dynamic> json) => PostCreateOrderRequest(
    cartId: json["cartId"],
    deliveryAddressId: json["deliveryAddressId"],
  );

  Map<String, dynamic> toJson() => {
    "cartId": cartId,
    "deliveryAddressId": deliveryAddressId,
  };
}
