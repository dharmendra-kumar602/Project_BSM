import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostAddDeliveryAddressRequest postAddDeliveryAddressRequestFromJson(String str) => PostAddDeliveryAddressRequest.fromJson(json.decode(str));

String postAddDeliveryAddressRequestToJson(PostAddDeliveryAddressRequest data) => json.encode(data.toJson());

class PostAddDeliveryAddressRequest {
  final RequestHeader requestHeader;
  final String city;
  String? addressId;
  final String state;
  final String country;
  final String postCode;
  final bool isDefault;
  final String address1;
  final String street;
  final String firstName;
  final String phoneNumber;

  PostAddDeliveryAddressRequest({
    required this.requestHeader,
    required this.city,
    this.addressId,
    required this.state,
    required this.country,
    required this.postCode,
    required this.isDefault,
    required this.address1,
    required this.street,
    required this.firstName,
    required this.phoneNumber,
  });

  factory PostAddDeliveryAddressRequest.fromJson(Map<String, dynamic> json) => PostAddDeliveryAddressRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    city: json["city"],
    state: json["state"],
    country: json["country"],
    postCode: json["postCode"],
    isDefault: json["isDefault"],
    address1: json["address1"],
    street: json["street"],
    firstName: json["firstName"],
    phoneNumber: json["phoneNumber"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "city": city,
    "state": state,
    "country": country,
    "postCode": postCode,
    "isDefault": isDefault,
    "address1": address1,
    "street": street,
    "firstName": firstName,
    "phoneNumber": phoneNumber,
  };
}