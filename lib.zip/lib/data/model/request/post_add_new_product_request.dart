import 'dart:convert';
import 'dart:io';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';

class PostAddNewProductRequest {
  final String title;
  final String description;
  final String brandName;
  final int categoryId;
  final int badgeId;
  final String additionalDetails;
  final dynamic maxRetailPrice;
  final dynamic salePrice;
  final String condition;
  final dynamic weightInPound;
  final dynamic length;
  final dynamic width;
  final dynamic height;
  final String processingTime;
  final List<ProductAttributes> attributes;
  final List<File?> productImages;

  PostAddNewProductRequest({required this.title, required this.description, required this.brandName, required this.categoryId, required this.badgeId, required this.additionalDetails, required this.maxRetailPrice, required this.salePrice, required this.condition, required this.weightInPound, required this.length, required this.width, required this.height, required this.processingTime, required this.attributes, required this.productImages});

  Future<Map<String, dynamic>> toJson() async {
    Map<String, dynamic> v = {
      "title" : title,
      "description" : description,
      "brandName" : brandName,
      "categoryId" : categoryId,
      "badgeId" : badgeId,
      "additionalDetails" : additionalDetails,
      "processingTime" : processingTime,
      "varients[0][maxRetailPrice]" : maxRetailPrice,
      "varients[0][salePrice]" : salePrice,
      "varients[0][condition]" : condition,
      "varients[0][weightInPound]" : weightInPound,
      "varients[0][dimension][length]" : length,
      "varients[0][dimension][width]" : width,
      "varients[0][dimension][height]" : height,
    };

    for (int i=0; i<attributes.length; i++) {
      v.addAll(await DioUtils.createAttributesRequestByMultipart(attributes[i], i));
    }

    for (int i=0; i<productImages.length; i++) {
      v.addAll(await DioUtils.createProductImagesRequestByMultipart(productImages[i], i));
    }

    return v;
  }
}

class ProductAttributes {
  final int id;
  final String name;
  final String value;

  ProductAttributes(this.id, this.name, this.value);
}