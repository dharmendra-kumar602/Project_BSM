import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostValidateSellerOtpRequest postValidateSellerOtpRequestFromJson(String str) => PostValidateSellerOtpRequest.fromJson(json.decode(str));

String postValidateSellerOtpRequestToJson(PostValidateSellerOtpRequest data) => json.encode(data.toJson());

class PostValidateSellerOtpRequest {
  final RequestHeader requestHeader;
  final int storeId;
  final String otp;
  final int otpType;

  PostValidateSellerOtpRequest({
    required this.requestHeader,
    required this.storeId,
    required this.otp,
    required this.otpType,
  });

  factory PostValidateSellerOtpRequest.fromJson(Map<String, dynamic> json) => PostValidateSellerOtpRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    storeId: json["storeId"],
    otp: json["otp"],
    otpType: json["otpType"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "storeId": storeId,
    "otp": otp,
    "otpType": otpType,
  };
}