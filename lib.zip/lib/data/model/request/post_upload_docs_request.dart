import 'dart:convert';
import 'dart:io';

import 'package:take_my_tack/core/model/request_header.dart';

PostUploadDocsRequest postAddToWishlistRequestFromJson(String str) => PostUploadDocsRequest.fromJson(json.decode(str));

String postAddToWishlistRequestToJson(PostUploadDocsRequest data) => json.encode(data.toJson());

class PostUploadDocsRequest {
  final String description;
  final String title;
  final File file;

  PostUploadDocsRequest({
    required this.description,
    required this.title,
    required this.file,
  });

  factory PostUploadDocsRequest.fromJson(Map<String, dynamic> json) => PostUploadDocsRequest(
      description: json["document[0][description]"],
      title: json["document[0][title]"],
      file: json["document[0][file"]
  );

  Map<String, dynamic> toJson() => {
    "document[0][description]": description,
    "document[0][title]": title,
    "document[0][file": file,
  };
}