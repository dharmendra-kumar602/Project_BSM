class GetProductByProductIdRequest {
  final int productId;

  GetProductByProductIdRequest(
      {required this.productId});

  factory GetProductByProductIdRequest.fromJson(Map<String, dynamic> json) =>
      GetProductByProductIdRequest(
        productId: json["productId"],
      );

  Map<String, dynamic> toJson() => {
    "productId": productId,
  };
}
