import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostResetPasswordRequest postResetPasswordRequestFromJson(String str) => PostResetPasswordRequest.fromJson(json.decode(str));

String postResetPasswordRequestToJson(PostResetPasswordRequest data) => json.encode(data.toJson());

class PostResetPasswordRequest {
  final RequestHeader requestHeader;
  final String email;
  final String password;

  PostResetPasswordRequest({
    required this.requestHeader,
    required this.email,
    required this.password,
  });

  factory PostResetPasswordRequest.fromJson(Map<String, dynamic> json) => PostResetPasswordRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    email: json["email"],
    password: json["password"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "email": email,
    "password": password,
  };
}