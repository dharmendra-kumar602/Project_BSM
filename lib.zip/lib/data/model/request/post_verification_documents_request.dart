import 'dart:io';

import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';

class VerificationDocument {
  final String description;
  final String title;
  final List<File> file;

  VerificationDocument({
    required this.description,
    required this.title,
    required this.file,
  });

  Future<Map<String, dynamic>> toJson() async {
    Map<String, dynamic> v = {};
    for (int i = 0; i<(file.length); i++) {
      final result = await DioUtils.createFileRequestByMultipart(i, file[i]);
      v.addAll(result);
    }
    for (int j = 0; j<(file.length); j++) {
      final titles = {
        'document[$j][description]': "description",
        'document[$j][title]': file[j].path.split('/').last,
      };
      v.addAll(titles);
    }
    return v;
  }
}
