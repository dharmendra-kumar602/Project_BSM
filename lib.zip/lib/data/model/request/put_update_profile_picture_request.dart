import 'dart:convert';
import 'dart:io';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';

PutUpdateProfilePictureRequest putUpdateProfileRequestFromJson(String str) => PutUpdateProfilePictureRequest.fromJson(json.decode(str));

class PutUpdateProfilePictureRequest {
  final File profilePicture;

  PutUpdateProfilePictureRequest({
    required this.profilePicture,
  });

  factory PutUpdateProfilePictureRequest.fromJson(Map<String, dynamic> json) {
    return PutUpdateProfilePictureRequest(
      profilePicture: json["profilePicture"],
    );
  }

  Future<Map<String, dynamic>> toJson(File profile) async {
    Map<String, dynamic> v = {};
    v.addAll(await DioUtils.createProfileRequestByMultipart(profile));
    return v;
  }
}