import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PutSellerBankDetailsRequest putSellerBankDetailsRequestFromJson(String str) => PutSellerBankDetailsRequest.fromJson(json.decode(str));

String putSellerBankDetailsRequestToJson(PutSellerBankDetailsRequest data) => json.encode(data.toJson());

class PutSellerBankDetailsRequest {
  RequestHeader? requestHeader;
  String? bankName;
  String? ifsc;
  String? accountNumber;
  String? accountHolderName;

  PutSellerBankDetailsRequest({
    this.requestHeader,
    this.bankName,
    this.ifsc,
    this.accountNumber,
    this.accountHolderName,
  });

  factory PutSellerBankDetailsRequest.fromJson(Map<String, dynamic> json) => PutSellerBankDetailsRequest(
    requestHeader: json["requestHeader"] == null ? null : RequestHeader.fromJson(json["requestHeader"]),
    bankName: json["bankName"],
    ifsc: json["IFSC"],
    accountNumber: json["accountNumber"],
    accountHolderName: json["accountHolderName"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader?.toJson(),
    "bankName": bankName,
    "IFSC": ifsc,
    "accountNumber": accountNumber,
    "accountHolderName": accountHolderName,
  };
}