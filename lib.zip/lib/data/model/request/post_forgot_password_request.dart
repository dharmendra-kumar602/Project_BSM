import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostForgotPasswordRequest postForgotPasswordRequestFromJson(String str) => PostForgotPasswordRequest.fromJson(json.decode(str));

String postForgotPasswordRequestToJson(PostForgotPasswordRequest data) => json.encode(data.toJson());

class PostForgotPasswordRequest {
  final RequestHeader requestHeader;
  final String email;

  PostForgotPasswordRequest({
    required this.requestHeader,
    required this.email,
  });

  factory PostForgotPasswordRequest.fromJson(Map<String, dynamic> json) => PostForgotPasswordRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    email: json["email"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "email": email,
  };
}