class GetAllCategoriesRequest {

  final int limit;
  final int offSet;

  GetAllCategoriesRequest({required this.limit, required this.offSet});

  factory GetAllCategoriesRequest.fromJson(Map<String, dynamic> json) => GetAllCategoriesRequest(
    limit: json["limit"],
    offSet: json["offSet"],
  );

  Map<String, dynamic> toJson() => {
    "limit": limit,
    "offSet": offSet,
  };
}