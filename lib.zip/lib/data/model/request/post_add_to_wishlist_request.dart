import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostAddToWishlistRequest postAddToWishlistRequestFromJson(String str) => PostAddToWishlistRequest.fromJson(json.decode(str));

String postAddToWishlistRequestToJson(PostAddToWishlistRequest data) => json.encode(data.toJson());

class PostAddToWishlistRequest {
  final RequestHeader requestHeader;
  final List<Item> items;

  PostAddToWishlistRequest({
    required this.requestHeader,
    required this.items,
  });

  factory PostAddToWishlistRequest.fromJson(Map<String, dynamic> json) => PostAddToWishlistRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  final int productId;
  final int variationId;

  Item({
    required this.productId,
    required this.variationId,
  });

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    productId: json["productId"],
    variationId: json["variationId"],
  );

  Map<String, dynamic> toJson() => {
    "productId": productId,
    "variationId": variationId,
  };
}