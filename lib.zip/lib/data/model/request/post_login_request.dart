import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostLoginRequest postLoginRequestFromJson(String str) => PostLoginRequest.fromJson(json.decode(str));

String postLoginRequestToJson(PostLoginRequest data) => json.encode(data.toJson());

class PostLoginRequest {
  final RequestHeader requestHeader;
  final String email;
  final String password;

  PostLoginRequest({
    required this.requestHeader,
    required this.email,
    required this.password,
  });

  factory PostLoginRequest.fromJson(Map<String, dynamic> json) => PostLoginRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    email: json["email"],
    password: json["password"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "email": email,
    "password": password,
  };
}