import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostSendTicketMessageRequest postSendTicketMessageRequestFromJson(String str) => PostSendTicketMessageRequest.fromJson(json.decode(str));

String postSendTicketMessageRequestToJson(PostSendTicketMessageRequest data) => json.encode(data.toJson());

class PostSendTicketMessageRequest {
  final String message;
  final String userType;
  final RequestHeader requestHeader;

  PostSendTicketMessageRequest({
    required this.message,
    required this.userType,
    required this.requestHeader,
  });

  factory PostSendTicketMessageRequest.fromJson(Map<String, dynamic> json) => PostSendTicketMessageRequest(
    message: json["message"],
    userType: json["userType"],
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
  );

  Map<String, dynamic> toJson() => {
    "message": message,
    "userType": userType,
    "requestHeader": requestHeader.toJson(),
  };
}