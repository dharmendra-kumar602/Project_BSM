import 'dart:convert';

import 'package:take_my_tack/core/model/request_header.dart';

PostSubscribeToSellerPlanRequest postSubscribeToSellerPlanRequestFromJson(String str) => PostSubscribeToSellerPlanRequest.fromJson(json.decode(str));

String postSubscribeToSellerPlanRequestToJson(PostSubscribeToSellerPlanRequest data) => json.encode(data.toJson());

class PostSubscribeToSellerPlanRequest {
  final RequestHeader requestHeader;
  final int planId;
  final String sellerStoreId;

  PostSubscribeToSellerPlanRequest({
    required this.requestHeader,
    required this.planId,
    required this.sellerStoreId,
  });

  factory PostSubscribeToSellerPlanRequest.fromJson(Map<String, dynamic> json) => PostSubscribeToSellerPlanRequest(
    requestHeader: RequestHeader.fromJson(json["requestHeader"]),
    planId: json["planId"],
    sellerStoreId: json["sellerStoreId"],
  );

  Map<String, dynamic> toJson() => {
    "requestHeader": requestHeader.toJson(),
    "planId": planId,
    "sellerStoreId": sellerStoreId,
  };
}