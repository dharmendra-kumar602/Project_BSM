import 'dart:convert';
import 'package:dartz/dartz.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/error/exceptions.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/datasource/remote/services/apis.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/rest_client.dart';
import 'package:take_my_tack/data/model/request/post_forgot_password_request.dart';
import 'package:take_my_tack/data/model/request/post_login_request.dart';
import 'package:take_my_tack/data/model/request/post_register-seller_request.dart';
import 'package:take_my_tack/data/model/request/post_register_request.dart';
import 'package:take_my_tack/data/model/request/post_resend_registration_seller_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_resend_signup_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_reset_password_request.dart';
import 'package:take_my_tack/data/model/request/post_subscribe_to_seller_request.dart';
import 'package:take_my_tack/data/model/request/post_validate_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_validate_seller_otp_request.dart';
import 'package:take_my_tack/data/model/response/get_all_seller_plans_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_by_id_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_status_response.dart';
import 'package:take_my_tack/data/model/response/get_updated_token_response.dart';
import 'package:take_my_tack/data/model/response/post_login_response.dart';
import 'package:take_my_tack/data/model/response/post_register_seller_response.dart';
import 'package:take_my_tack/domain/repository/auth_repository.dart';

import '../model/response/get_seller_register_status.dart';

class AuthRepositoryImpl implements AuthRepository {

  final _restClient = Get.find<RestClient>();

  @override
  Future<Either<Failure, ResponseHeader>> forgotPasswordOtp(PostForgotPasswordRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postForgetPasswordOTP, request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> register(PostRegisterRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postRegister, request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> resetPassword(PostResetPasswordRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postResetPassword, request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> validateOTP(PostValidateOtpRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postValidateOTP, request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostLoginResponse>> login(PostLoginRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postLogin, request: params.toJson());
      return Right(postLoginResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> resendSignUpOTP(PostResendSignupOtpRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.resendSignUpOTP, request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> resendForgotOTP(PostResendSignupOtpRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postResendResetPasswordOtp, request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> logout() async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postLogout, request: {});
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostRegisterSellerResponse>> registerSeller(PostRegisterSellerRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postRegisterSeller, request: params.toJson());
      return Right(postRegisterSellerResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> postVerifyOTP(PostValidateSellerOtpRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postVerifySellerOTP, request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> resendSellerOTP(PostResendSellerRegistrationOtpRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postSellerResendResetPasswordOtp, request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetAllSellerPlansResponse>> getAllSellersPlan() async {
    try {
      final response = await _restClient.get(url: Apis.baseUrl+Apis.getAllPlans);
      return Right(getAllSellerPlansResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerPlanByIdResponse>> getSellerPlanById(String id) async {
    try {
      final response = await _restClient.get(url: Apis.baseUrl+Apis.getPlanById(id));
      return Right(getSellerPlanByIdResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> postSubscribeToPlan(PostSubscribeToSellerPlanRequest params) async {
    try {
      final response = await _restClient.post(url: Apis.baseUrl+Apis.postSubscribeToPlan, request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerRegisterStatus>> getSellerRegisterStatus() async {
    try {
      final response = await _restClient.get(url: Apis.baseUrl+Apis.sellerRegistrationState);
      return Right(getSellerRegisterStatusFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetUpdatedTokenResponse>> getUpdateToken() async {
    try {
      final response = await _restClient.put(url: Apis.baseUrl+Apis.getUpdateToken, request: {});
      return Right(getUpdatedTokenResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }
}
