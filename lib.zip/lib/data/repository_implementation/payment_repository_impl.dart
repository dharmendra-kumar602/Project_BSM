import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/error/exceptions.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/datasource/remote/services/apis.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/rest_client.dart';
import 'package:take_my_tack/data/model/request/post_add_new_product_request.dart';
import 'package:take_my_tack/data/model/request/post_create_payment_intent_request.dart';
import 'package:take_my_tack/data/model/request/post_make_payment_request.dart';
import 'package:take_my_tack/data/model/request/post_verification_documents_request.dart';
import 'package:take_my_tack/data/model/response/get_cards_response.dart';
import 'package:take_my_tack/data/model/response/get_default_attributes_response.dart';
import 'package:take_my_tack/data/model/response/get_document_status_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_dashboard_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_status_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_profile_response.dart';
import 'package:take_my_tack/data/model/response/post_create_customer_response.dart';
import 'package:take_my_tack/data/model/response/post_create_payment_intent_response.dart';
import 'package:take_my_tack/data/model/response/post_payment_off_session_response.dart';
import 'package:take_my_tack/data/model/response/post_upload_docs_response.dart';
import 'package:take_my_tack/domain/repository/payment_repository.dart';
import 'package:take_my_tack/domain/repository/seller_repository.dart';

class PaymentRepositoryImpl implements PaymentRepository {

  final _restClient = Get.find<RestClient>();

  @override
  Future<Either<Failure, GetCardsResponse>> getCards() async {
    try {
      final response = await _restClient.get(
          url: Apis.baseUrl + Apis.stripeCards);
      return Right(getCardsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostCreateCustomerResponse>> postCreateCustomer() async {
    try {
      final response = await _restClient.post(
          url: Apis.baseUrl + Apis.stripeCustomer, request: {});
      return Right(postCreateCustomerResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostCreatePaymentIntentResponse>> postCreatePaymentIntent(PostCreatePaymentIntentRequest params) async {
    try {
      /// for testing purpose
      /*{
        "amount": 3000,
    "payment_method": ["cards"],
    "orderId": "14",
    "shipping": {
    "address": {
    "line1": "Regus Business Centre",
    "line2": "Fort Dunlop Fort Parkway Fort Pkwy",
    "postal_code": "B249FD",
    "city": "Birmingham ",
    "state": "Birmingham ",
    "country": "United Kingdom"
    }
    }
    }*/
      final response = await _restClient.post(
          url: Apis.baseUrl + Apis.stripePaymentIntent, request: params.toJson());
      return Right(postCreatePaymentIntentResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostPaymentOffSessionResponse>> postPaymentOffSession(PostMakePaymentOffSessionRequest params) async {
    try {
      final response = await _restClient.post(
          url: Apis.baseUrl + Apis.stripeMakePaymentOffSession, request: params.toJson());
      return Right(postPaymentOffSessionResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }
}
