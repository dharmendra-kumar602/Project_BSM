import 'dart:convert';
import 'package:dartz/dartz.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/error/exceptions.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/datasource/remote/services/apis.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/rest_client.dart';
import 'package:take_my_tack/data/model/request/get_all_categories_request.dart';
import 'package:take_my_tack/data/model/request/get_buyer_dashboard_request.dart';
import 'package:take_my_tack/data/model/request/get_products_by_categoryId_request.dart';
import 'package:take_my_tack/data/model/request/get_products_by_sellerid_request.dart';
import 'package:take_my_tack/data/model/request/post_add_delivery_address_request.dart';
import 'package:take_my_tack/data/model/request/post_send_message_request.dart';
import 'package:take_my_tack/data/model/request/post_support_ticket_request.dart';
import 'package:take_my_tack/data/model/request/put_update_fcm_token_request.dart';
import 'package:take_my_tack/data/model/request/put_update_password_request.dart';
import 'package:take_my_tack/data/model/request/put_update_profile_picture_request.dart';
import 'package:take_my_tack/data/model/request/put_update_profile_request.dart';
import 'package:take_my_tack/data/model/response/get_address_by_post_code_response.dart';
import 'package:take_my_tack/data/model/response/get_all_categories_response.dart';
import 'package:take_my_tack/data/model/response/get_brands_response.dart';
import 'package:take_my_tack/data/model/response/get_buyer_dashboard_response.dart';
import 'package:take_my_tack/data/model/response/get_buyer_profile_response.dart';
import 'package:take_my_tack/data/model/response/get_countries_list_response.dart';
import 'package:take_my_tack/data/model/response/get_delivery_address_response.dart';
import 'package:take_my_tack/data/model/response/get_newsletter_status_response.dart';
import 'package:take_my_tack/data/model/response/get_notifications_response.dart';
import 'package:take_my_tack/data/model/response/get_products_by_category_id_response.dart';
import 'package:take_my_tack/data/model/response/get_products_by_seller_id_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_list_response.dart';
import 'package:take_my_tack/data/model/response/get_support_tickets_response.dart';
import 'package:take_my_tack/data/model/response/get_ticket_chat_response.dart';
import 'package:take_my_tack/data/model/response/get_top_seller_response.dart';
import 'package:take_my_tack/data/model/response/post_add_delivery_address_response.dart';
import 'package:take_my_tack/data/model/response/post_support_ticket_response.dart';
import 'package:take_my_tack/data/model/response/put_read_notification_response.dart';
import 'package:take_my_tack/domain/repository/dashboard_repository.dart';

class DashboardRepositoryImpl implements DashboardRepository {

  final _restClient = Get.find<RestClient>();

  @override
  Future<Either<Failure, GetBuyerDashboardResponse>> getDashboardDetails(
      GetBuyerDashboardRequest params) async {
    try {
      final response = await _restClient.get(
          url: Apis.baseUrl + Apis.getBuyerDashboardData,
          params: params.toJson());
      return Right(getBuyerDashboardResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetAllCategoriesResponse>> getAllCategories(
      GetAllCategoriesRequest params) async {
    try {
      final response = await _restClient.get(
          url: Apis.baseUrl + Apis.getAllCategories, params: params.toJson());
      return Right(getAllCategoriesResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<
      Either<Failure, GetProductsByCategoryIdResponse>> getProductsByCategoryId(
      GetProductsByCategoryIdRequest params) async {
    try {
      final response = await _restClient.get(
          url: Apis.baseUrl + Apis.getProductsByCategoryId(params.categoryId!),
          params: params.toJson());
      return Right(getProductsByCategoryIdResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetProductsBySellerIdResponse>> getProductsBySellerId(GetProductsBySellerIdRequest params) async {
    try {
      var url = "";
      if (params.approvalStatus != null) {
        if (params.approvalStatus == "All") {
          url = "${Apis.baseUrl}${Apis.getProductsBySellerId(params.sellerId!)}";
        } else {
          url = "${Apis.baseUrl}${Apis.getProductsBySellerId(params.sellerId!)}?approvalStatus=${params.approvalStatus!}";
        }
      } else {
        url = Apis.baseUrl + Apis.getProductsBySellerId(params.sellerId!);
      }
      final response = await _restClient.get(
          url: url, params: params.toJson());
      return Right(getProductsBySellerIdResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetProductsBySellerIdResponse>> getSellerProducts(GetProductsBySellerIdRequest params) async {
    try {
      var url = "";
      if (params.approvalStatus != null) {
        if (params.approvalStatus == "All") {
          url = "${Apis.baseUrl}${Apis.getSellerProducts(params.sellerId!)}";
        } else {
          url = "${Apis.baseUrl}${Apis.getSellerProducts(params.sellerId!)}?approvalStatus=${params.approvalStatus!}";
        }
      } else {
        url = Apis.baseUrl + Apis.getSellerProducts(params.sellerId!);
      }
      final response = await _restClient.get(
          url: url, params: params.toJson());
      return Right(getProductsBySellerIdResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetProductsByCategoryIdResponse>> getProducts() async {
    try {
      final response = await _restClient.get(
          url: Apis.baseUrl + Apis.getAllProducts);
      return Right(getProductsByCategoryIdResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostSupportTicketResponse>> postSupportTicket(PostSupportTicketRequest params) async {
    try {
      final response = await _restClient.post(
          url: Apis.baseUrl + Apis.postTicket, request: params.toJson());
      return Right(postSupportTicketResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSupportTicketsResponse>> getSupportTickets(PostSupportTicketRequest params) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getTickets}?pageSize=${params.pageSize}&pageNumber=${params.pageNumber}&time=${params.time}");
      return Right(getSupportTicketsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetTicketChatByUserIdResponse>> getTicketDetailsByUserId(PostSupportTicketRequest params, String ticketId) async {
    try {
      final response = await _restClient.get(
          url: Apis.baseUrl + Apis.getTicketChatByUserId(ticketId));
      return Right(getTicketChatByUserIdResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> postSendTicketMessage(PostSendTicketMessageRequest params, String ticketId) async {
    try {
      final response = await _restClient.post(
          url: Apis.baseUrl + Apis.postSendTicketMessage(ticketId), request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetBuyerProfileResponse>> getBuyerUserProfile() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getBuyerProfile}");
      return Right(getBuyerProfileResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> updateBuyerProfile(PutUpdateProfileRequest params) async {
    try {
      final response = await _restClient.put(
        url: "${Apis.baseUrl}${Apis.updateBuyerProfile}", request: params.toJson(),);
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> updateBuyerPasswordRequest(UpdateBuyerPasswordRequest params) async {
    try {
      final response = await _restClient.put(
        url: "${Apis.baseUrl}${Apis.updateBuyerPassword}", request: params.toJson(),);
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> updateSellerPasswordRequest(UpdateBuyerPasswordRequest params) async {
    try {
      final response = await _restClient.put(
        url: "${Apis.baseUrl}${Apis.updateSellerPassword}", request: params.toJson(),);
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> putUpdateFcmToken(PutUpdateFcmTokenRequest params) async {
    try {
      final response = await _restClient.put(
        url: "${Apis.baseUrl}${Apis.putUpdateFcmToken}", request: params.toJson(),);
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> updateBuyerProfilePicture(PutUpdateProfilePictureRequest params) async {
    try {
      final response = await _restClient.putFormData(
        url: "${Apis.baseUrl}${Apis.updateBuyerProfilePicture}", request: await params.toJson(params.profilePicture),);
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> deleteDeliveryAddress(int id) async {
    try {
      final response = await _restClient.delete(
        url: "${Apis.baseUrl}${Apis.deleteDeliveryAddress(id)}");
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetDeliveryAddressResponse>> getDeliveryAddress() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getDeliveryAddress}");
      return Right(getDeliveryAddressResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostAddDeliveryAddressResponse>> postAddDeliveryAddress(PostAddDeliveryAddressRequest params) async {
    try {
      final response = await _restClient.post(
          url: Apis.baseUrl + Apis.addDeliveryAddress, request: params.toJson());
      return Right(postAddDeliveryAddressResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> putUpdateDeliveryAddress(PostAddDeliveryAddressRequest params) async {
    try {
      final response = await _restClient.put(
        url: "${Apis.baseUrl}${Apis.updateDeliveryAddress}?addressId=${params.addressId}", request: params.toJson(),);
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> postSetDefaultAddress(int addressId) async {
    try {
      final response = await _restClient.put(
        url: "${Apis.baseUrl}${Apis.postSetDefaultAddress}", request: {
          "requestHeader":{
            "requestId": "random-uuid"
          },
        "addressId": addressId
      },);
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetDeliveryAddressResponse>> getDefaultAddress() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getDefaultAddress}");
      return Right(getDeliveryAddressResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetNotificationsResponse>> getNotifications() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getNotifications}");
      return Right(getNotificationsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetNewsLetterStatusResponse>> getNewsLetterStatus(String id) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getNewsLetterStatus(id)}");
      return Right(getNewsLetterStatusResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> postNewsLetterStatus(String userId, bool status) async {
    try {
      var url = "";
      if (status) {
        url = "${Apis.baseUrl}${Apis.unScribeNewsLetterStatus}";
      } else {
        url = "${Apis.baseUrl}${Apis.subscribeNewsLetterStatus}";
      }
      final response = await _restClient.post(url: url, request: {
        "userId": userId
      });
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetCountriesListResponse>> getCountriesList() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getCountriesList}");
      return Right(getCountriesListResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerListResponse>> getSellerList() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getSellerList}");
      return Right(getSellerListResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetBrandListResponse>> getBrandList() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getBrandList}");
      return Right(getBrandListResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetTopSellerResponse>> getTopSellerList() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getTopSellers}");
      return Right(getTopSellerResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PutReadNotificationResponse>> putReadNotification(String id) async {
    try {
      final response = await _restClient.put(
          url: "${Apis.baseUrl}${Apis.putReadNotification(id)}", request: {});
      return Right(putReadNotificationResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> deleteAccount() async {
    try {
      final response = await _restClient.delete(
          url: "${Apis.baseUrl}${Apis.deleteAccount}");
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetAddressByPostIdResponse>> getAddressByPostCode(String postCode) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getAddressByPostCode(postCode)}");
      return Right(getAddressByPostIdResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }
}
