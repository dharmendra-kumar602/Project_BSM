import 'dart:convert';
import 'package:dartz/dartz.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/error/exceptions.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/datasource/remote/services/apis.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/rest_client.dart';
import 'package:take_my_tack/data/model/request/post_add_new_product_request.dart';
import 'package:take_my_tack/data/model/request/post_update_product_request.dart';
import 'package:take_my_tack/data/model/request/post_verification_documents_request.dart';
import 'package:take_my_tack/data/model/request/put_bank_details_request.dart';
import 'package:take_my_tack/data/model/request/put_shipping_details_request.dart';
import 'package:take_my_tack/data/model/request/put_update_seller_profile_request.dart';
import 'package:take_my_tack/data/model/response/get_default_attributes_response.dart';
import 'package:take_my_tack/data/model/response/get_document_status_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_bank_details_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_dashboard_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_order_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_orders_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_status_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_product_details_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_profile_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_stats_response.dart';
import 'package:take_my_tack/data/model/response/get_shipping_details_response.dart';
import 'package:take_my_tack/data/model/response/post_delete_product_response.dart';
import 'package:take_my_tack/data/model/response/post_upload_docs_response.dart';
import 'package:take_my_tack/data/model/response/put_seller_bank_details_response.dart';
import 'package:take_my_tack/domain/repository/seller_repository.dart';

class SellerRepositoryImpl implements SellerRepository {

  final _restClient = Get.find<RestClient>();

  @override
  Future<Either<Failure, GetSellerProfileResponse>> getSellerUserProfile() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getSellerProfile}");
      return Right(getSellerProfileResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostUploadDocsResponse>> postUploadVerificationDocs(VerificationDocument params) async {
    try {
      final response = await _restClient.postFormData(
          url: "${Apis.baseUrl}${Apis.postUploadDocument}", request: await params.toJson(),);
      return Right(postUploadDocsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetDocumentStusResponse>> getDocumentStatus(String storeId) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getSellerVerificationDocument(storeId)}");
      return Right(getDocumentStusResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerDashboardResponse>> getSellerDashboard() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getSellerDashboard}");
      return Right(getSellerDashboardResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> postAddNewProducts(PostAddNewProductRequest params) async {
    try {
      final response = await _restClient.postFormData(
          url: "${Apis.baseUrl}${Apis.postAddNewProducts}", request: await params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetDefaultAttributesResponse>> getDefaultAttributes() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getDefaultAttributes}");
      return Right(getDefaultAttributesResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> postEditProduct(PostUpdateProductRequest params) async {
    try {
      final response = await _restClient.postFormData(
          url: "${Apis.baseUrl}${Apis.postEitSellerProduct}", request: await params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerProductDetailsResponse>> getSellerProductDetails(var productId) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getSellerProductDetailsById(productId)}");
      return Right(getSellerProductDetailsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerOrdersResponse>> getSellerOrders({String? status}) async {
    try {
      var url = "${Apis.baseUrl}${Apis.getBuyerOrders}";
      if (status?.isEmpty ?? true) {
        url = "${Apis.baseUrl}${Apis.getSellerOrders}";
      } else {
        url = "${Apis.baseUrl}${Apis.getSellerOrders}?status=$status";
      }
      final response = await _restClient.get(
          url: url);
      return Right(getSellerOrdersResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> updateSellerProfile(PutUpdateSellerProfileRequest params, String id) async {
    try {
      final response = await _restClient.put(
          url: "${Apis.baseUrl}${Apis.updateSellerProfile(id)}", request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerBankDetailsResponse>> getSellerBankDetails() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getBankDetails}");
      return Right(getSellerBankDetailsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetShippingDetailsResponse>> getShippingMethods(String id) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getShippingMethods(id)}");
      return Right(getShippingDetailsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PutSellerBankDetailsResponse>> putSellerBankDetails(PutSellerBankDetailsRequest params) async {
    try {
      final response = await _restClient.put(
          url: "${Apis.baseUrl}${Apis.updateBankDetails}", request: params.toJson());
      return Right(putSellerBankDetailsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> putShippingMethods(PutShippingDetailsRequest params, String id) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.postShippingMethods(id)}", request: params.toJson());
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerOrderDetailsResponse>> getSellerOrderDetails(String orderId) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getSellerOrderDetails(orderId)}");
      return Right(getSellerOrderDetailsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> acceptOrder(String orderId) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.acceptOrder}", request: {
        "requestHeader": {
          "requestId": "random-uuid"
        },
        "orderId": orderId,
        "status": "ACCEPTED"
      });
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> rejectOrder(String orderId, String reason) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.acceptOrder}", request: {
        "requestHeader": {
          "requestId": "random-uuid"
        },
        "orderId": orderId,
        "status": "REJECTED",
        "otherReasonText": reason,
      });
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> orderStatusUpdate(String orderId, String status) async {
    try {
      final response = await _restClient.put(
          url: "${Apis.baseUrl}${Apis.sellerOrderStatusUpdate}", request: {
        "requestHeader": {
          "requestId": "random-uuid"
        },
        "orderId": orderId,
        "status": status,
      });
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerMediaStatsResponse>> getSellerMediaStats(String sellerStoreId) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getMediaStats(sellerStoreId)}");
      return Right(getSellerMediaStatsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerPlanStatusResponse>> getSubscribedPlansStatus() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getSubscribedPlans}");
      return Right(getSellerPlanStatusResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostDeleteProductResponse>> postDeleteProduct(int variationId) async {
    try {
      final response = await _restClient.delete(
          url: "${Apis.baseUrl}${Apis.postDeleteSellerProduct(variationId.toString())}", request: {});
      return Right(postDeleteProductResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }
}
