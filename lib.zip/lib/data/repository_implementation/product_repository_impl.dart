import 'dart:convert';
import 'package:dartz/dartz.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/error/exceptions.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/datasource/remote/services/apis.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/rest_client.dart';
import 'package:take_my_tack/data/model/request/get_product_by_productId_request.dart';
import 'package:take_my_tack/data/model/request/get_products_by_categoryId_request.dart';
import 'package:take_my_tack/data/model/request/post_add_to_cart_request.dart';
import 'package:take_my_tack/data/model/request/post_add_to_wishlist_request.dart';
import 'package:take_my_tack/data/model/request/post_apply_filters_request.dart';
import 'package:take_my_tack/data/model/request/post_create_order_request.dart';
import 'package:take_my_tack/data/model/request/put_change_cart_quantity_request.dart';
import 'package:take_my_tack/data/model/request/put_update_cart_delivery_type_request.dart';
import 'package:take_my_tack/data/model/response/delete_cart_response.dart';
import 'package:take_my_tack/data/model/response/get_buyer_order_detail_response.dart';
import 'package:take_my_tack/data/model/response/get_buyer_orders_response.dart';
import 'package:take_my_tack/data/model/response/get_cancel_reasons_response.dart';
import 'package:take_my_tack/data/model/response/get_cart_response.dart';
import 'package:take_my_tack/data/model/response/get_filtered_products_response.dart';
import 'package:take_my_tack/data/model/response/get_order_item_response.dart';
import 'package:take_my_tack/data/model/response/get_product_by_product_id_response.dart';
import 'package:take_my_tack/data/model/response/get_product_filters_response.dart';
import 'package:take_my_tack/data/model/response/get_products_by_brand_id_response.dart';
import 'package:take_my_tack/data/model/response/get_refund_reasons_response.dart';
import 'package:take_my_tack/data/model/response/get_search_products_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_details_response.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/data/model/response/post_add_to_cart_response.dart';
import 'package:take_my_tack/data/model/response/post_add_to_wishlist_response.dart';
import 'package:take_my_tack/data/model/response/post_create_order_response.dart';
import 'package:take_my_tack/data/model/response/post_refund_response.dart';
import 'package:take_my_tack/data/model/response/put_change_cart_quantity_response.dart';
import 'package:take_my_tack/domain/repository/product_repository.dart';

class ProductRepositoryImpl implements ProductRepository {

  final _restClient = Get.find<RestClient>();

  @override
  Future<Either<Failure, GetProductByProductIdResponse>> getProductByProductId(GetProductByProductIdRequest params) async {
    try {
      final response = await _restClient.get(
          url: Apis.baseUrl + Apis.getProductByProductId(params.productId));
      return Right(getProductByProductIdResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetCartProductsResponse>> getCart() async {
    try {
      final response = await _restClient.get(
          url: Apis.baseUrl + Apis.getCart);
      return Right(getCartProductsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSellerDetailsResponse>> getSellerDetails(int sellerId) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getSeller(sellerId)}");
      return Right(getSellerDetailsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostAddToCartResponse>> addToCart(PostAddToCartRequest params) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.postAddToCart}", request: params.toJson());
      return Right(postAddToCartResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, DeleteCartItemResponse>> removeFromCart(int cartItemId) async {
    try {
      final response = await _restClient.delete(
          url: "${Apis.baseUrl}${Apis.postAddToCart}/$cartItemId");
      return Right(deleteCartItemResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostAddToWishlistResponse>> addToWishList(PostAddToWishlistRequest params) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.postAddToWishlist}", request: params.toJson());
      return Right(postAddToWishlistResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetWishlistResponse>> getWishList() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getWishlist}");
      return Right(getWishlistResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PutChangeCartQuantityResponse>> putUpdateCartQuantity(PutChangeCartQuantityRequest params, String cartItemId, String quantity) async {
    try {
      final response = await _restClient.put(
          url: "${Apis.baseUrl}${Apis.putUpdateCartQuantity(cartItemId, quantity)}", request: params.toJson());
      return Right(putChangeCartQuantityResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PutChangeCartQuantityResponse>> putUpdateCartSize(PutChangeCartQuantityRequest params, String cartItemId, String productId, String size) async {
    try {
      final response = await _restClient.put(
          url: "${Apis.baseUrl}${Apis.putUpdateCartSize(cartItemId, productId, size)}", request: params.toJson());
      return Right(putChangeCartQuantityResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PutChangeCartQuantityResponse>> putUpdateCartDeliveryOption(PutUpdateDeliveryTypeRequest params) async {
    try {
      final response = await _restClient.put(
          url: "${Apis.baseUrl}${Apis.putUpdateCartDeliveryItem}", request: params.toJson());
      return Right(putChangeCartQuantityResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> removeFromWishList(String variationId) async {
    try {
      final response = await _restClient.delete(
          url: "${Apis.baseUrl}${Apis.deleteWishlist(variationId)}");
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetCartProductsResponse>> getBulkCart(PostAddBulkToCartRequest params) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.getCartBulk}", request: params.toJson());
      return Right(getCartProductsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetSearchProductsResponse>> getSearchProducts(String searchTerm, int pageSize, int pageNumber) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.searchProducts}?searchTerm=$searchTerm&?pageSize=$pageSize&pageNumber=$pageNumber");
      return Right(getSearchProductsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetProductFiltersResponse>> getProductFilters() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getProductFilters}");
      return Right(getProductFiltersResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetFilteredProductsResponse>> postApplyFilters(PostProductFiltersReruest params) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.applyProductFilters}", request: params.toJson());
      return Right(getFilteredProductsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostCreateOrderResponse>> postCreateOrder(PostCreateOrderRequest params) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.postCreateOrder}", request: params.toJson());
      return Right(postCreateOrderResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetBuyerOrdersResponse>> getBuyerOrders(String? status, String? time) async {
    try {
      var url = "${Apis.baseUrl}${Apis.getBuyerOrders}";
      if (status != null && time != null) {
        if (time == "Last 30 day") {
          url = "${Apis.baseUrl}${Apis.getBuyerOrders}?status=$status&timeInDays=30";
        } else {
          url = "${Apis.baseUrl}${Apis.getBuyerOrders}?status=$status&year=$time";
        }
      } else if (status != null) {
        url = "${Apis.baseUrl}${Apis.getBuyerOrders}?status=$status";
      } else if (time != null) {
        if (time == "Last 30 day") {
          url = "${Apis.baseUrl}${Apis.getBuyerOrders}?timeInDays=30";
        } else {
          url = "${Apis.baseUrl}${Apis.getBuyerOrders}?year=$time";
        }
      }
      final response = await _restClient.get(
          url: url);
      return Right(getBuyerOrdersResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetOrderDetailResponse>> getOrderDetailsById(int orderId) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getBuyerOrderDetails(orderId)}");
      return Right(getOrderDetailResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> postCancelOrder(int sellerId, int orderId, int reasonId, String otherReasonText) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.cancelOrder}", request: {
        "requestHeader": {
          "requestId": "random-uuid"
        },
        "orderId": orderId,
        "sellerId": sellerId,
        "reasonId": reasonId,
        "otherReasonText": otherReasonText
      });
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, PostRefundRequestResponse>> postRefundOrder(List<int> orderIds, int reasonId, String otherReasonText) async {
    try {
      final response = await _restClient.post(
          url: "${Apis.baseUrl}${Apis.refundRequest}", request: {
        "requestHeader": {
          "requestId": "random-uuid"
        },
        "orderIds": orderIds,
        "reasonId": reasonId,
        "otherReasonText": otherReasonText
      });
      return Right(postRefundRequestResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetCancelReasonsResponse>> getCancelRequestReasons() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getCancelReasons}");
      return Right(getCancelReasonsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetRefundReasonsResponse>> getRefundRequestReasons() async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getRefundReasons}");
      return Right(getRefundReasonsResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetOrderItemResponse>> getOrderItemDetailsById(int orderId) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getBuyerOrderItemDetails(orderId)}");
      return Right(getOrderItemResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, ResponseHeader>> downloadOrderInvoice(String orderId) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getOrderInvoice(orderId)}");
      return Right(ResponseHeader.fromJson(json.decode(response)["responseHeader"]));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, GetBrandProductsListResponse>> getProductsByBrandId(GetProductsByBrandIdRequest params) async {
    try {
      final response = await _restClient.get(
          url: "${Apis.baseUrl}${Apis.getProductsByBrandId(params.brandId ?? "0")}", params: params.toJson());
      return Right(getBrandProductsListResponseFromJson(response));
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }
}
