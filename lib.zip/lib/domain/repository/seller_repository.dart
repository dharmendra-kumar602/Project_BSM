import 'package:dartz/dartz.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/model/request/post_add_new_product_request.dart';
import 'package:take_my_tack/data/model/request/post_update_product_request.dart';
import 'package:take_my_tack/data/model/request/post_verification_documents_request.dart';
import 'package:take_my_tack/data/model/request/put_bank_details_request.dart';
import 'package:take_my_tack/data/model/request/put_shipping_details_request.dart';
import 'package:take_my_tack/data/model/request/put_update_seller_profile_request.dart';
import 'package:take_my_tack/data/model/response/get_default_attributes_response.dart';
import 'package:take_my_tack/data/model/response/get_document_status_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_bank_details_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_dashboard_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_order_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_orders_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_status_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_product_details_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_profile_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_stats_response.dart';
import 'package:take_my_tack/data/model/response/get_shipping_details_response.dart';
import 'package:take_my_tack/data/model/response/post_delete_product_response.dart';
import 'package:take_my_tack/data/model/response/post_upload_docs_response.dart';
import 'package:take_my_tack/data/model/response/put_seller_bank_details_response.dart';

abstract class SellerRepository {
  Future<Either<Failure, GetSellerProfileResponse>> getSellerUserProfile();
  Future<Either<Failure, PostUploadDocsResponse>> postUploadVerificationDocs(VerificationDocument params);
  Future<Either<Failure, GetDocumentStusResponse>> getDocumentStatus(String storeId);
  Future<Either<Failure, GetSellerDashboardResponse>> getSellerDashboard();
  Future<Either<Failure, ResponseHeader>> postAddNewProducts(PostAddNewProductRequest params);
  Future<Either<Failure, GetDefaultAttributesResponse>> getDefaultAttributes();
  Future<Either<Failure, GetSellerProductDetailsResponse>> getSellerProductDetails(var productId);
  Future<Either<Failure, ResponseHeader>> postEditProduct(PostUpdateProductRequest params);
  Future<Either<Failure, PostDeleteProductResponse>> postDeleteProduct(int variationId);
  Future<Either<Failure, ResponseHeader>> updateSellerProfile(PutUpdateSellerProfileRequest params, String id);
  Future<Either<Failure, GetSellerMediaStatsResponse>> getSellerMediaStats(String sellerStoreId);
  /// orders
  Future<Either<Failure, GetSellerOrdersResponse>> getSellerOrders({String? status});
  Future<Either<Failure, GetSellerOrderDetailsResponse>> getSellerOrderDetails(String orderId);
  Future<Either<Failure, ResponseHeader>> acceptOrder(String orderId);
  Future<Either<Failure, ResponseHeader>> rejectOrder(String orderId, String reason);
  Future<Either<Failure, ResponseHeader>> orderStatusUpdate(String orderId, String status);
  /// shipping
  Future<Either<Failure, GetShippingDetailsResponse>> getShippingMethods(String id);
  Future<Either<Failure, ResponseHeader>> putShippingMethods(PutShippingDetailsRequest params, String id);
  /// bank
  Future<Either<Failure, GetSellerBankDetailsResponse>> getSellerBankDetails();
  Future<Either<Failure, PutSellerBankDetailsResponse>> putSellerBankDetails(PutSellerBankDetailsRequest params);
  Future<Either<Failure, GetSellerPlanStatusResponse>> getSubscribedPlansStatus();
}