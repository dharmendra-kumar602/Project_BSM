import 'package:dartz/dartz.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/model/request/post_forgot_password_request.dart';
import 'package:take_my_tack/data/model/request/post_login_request.dart';
import 'package:take_my_tack/data/model/request/post_register-seller_request.dart';
import 'package:take_my_tack/data/model/request/post_register_request.dart';
import 'package:take_my_tack/data/model/request/post_resend_registration_seller_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_resend_signup_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_reset_password_request.dart';
import 'package:take_my_tack/data/model/request/post_subscribe_to_seller_request.dart';
import 'package:take_my_tack/data/model/request/post_validate_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_validate_seller_otp_request.dart';
import 'package:take_my_tack/data/model/response/get_all_seller_plans_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_by_id_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_status_response.dart';
import 'package:take_my_tack/data/model/response/get_updated_token_response.dart';
import 'package:take_my_tack/data/model/response/post_login_response.dart';
import 'package:take_my_tack/data/model/response/post_register_seller_response.dart';

abstract class AuthRepository {
  Future<Either<Failure, PostLoginResponse>> login(PostLoginRequest params);
  Future<Either<Failure, ResponseHeader>> register(PostRegisterRequest params);
  Future<Either<Failure, ResponseHeader>> forgotPasswordOtp(PostForgotPasswordRequest params);
  Future<Either<Failure, ResponseHeader>> validateOTP(PostValidateOtpRequest params);
  Future<Either<Failure, ResponseHeader>> resetPassword(PostResetPasswordRequest params);
  Future<Either<Failure, ResponseHeader>> resendSignUpOTP(PostResendSignupOtpRequest params);
  Future<Either<Failure, ResponseHeader>> resendForgotOTP(PostResendSignupOtpRequest params);
  Future<Either<Failure, ResponseHeader>> logout();

  /// Seller
  Future<Either<Failure, PostRegisterSellerResponse>> registerSeller(PostRegisterSellerRequest params);
  Future<Either<Failure, ResponseHeader>> postVerifyOTP(PostValidateSellerOtpRequest params);
  Future<Either<Failure, ResponseHeader>> resendSellerOTP(PostResendSellerRegistrationOtpRequest params);
  Future<Either<Failure, GetAllSellerPlansResponse>> getAllSellersPlan();
  Future<Either<Failure, GetSellerPlanByIdResponse>> getSellerPlanById(String id);
  Future<Either<Failure, ResponseHeader>> postSubscribeToPlan(PostSubscribeToSellerPlanRequest params);
  Future<Either<Failure, GetUpdatedTokenResponse>> getUpdateToken();
}