import 'package:dartz/dartz.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/response_header.dart';
import 'package:take_my_tack/data/model/request/post_create_payment_intent_request.dart';
import 'package:take_my_tack/data/model/request/post_make_payment_request.dart';
import 'package:take_my_tack/data/model/response/get_cards_response.dart';
import 'package:take_my_tack/data/model/response/post_create_customer_response.dart';
import 'package:take_my_tack/data/model/response/post_create_payment_intent_response.dart';
import 'package:take_my_tack/data/model/response/post_payment_off_session_response.dart';

abstract class PaymentRepository {
  Future<Either<Failure, PostCreateCustomerResponse>> postCreateCustomer();
  Future<Either<Failure, PostCreatePaymentIntentResponse>> postCreatePaymentIntent(PostCreatePaymentIntentRequest params);
  Future<Either<Failure, GetCardsResponse>> getCards();
  Future<Either<Failure, PostPaymentOffSessionResponse>> postPaymentOffSession(PostMakePaymentOffSessionRequest params);
}