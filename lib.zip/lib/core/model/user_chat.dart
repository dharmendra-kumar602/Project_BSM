import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';

class UserChat {
  int id;
  String photoUrl;
  String senderName;
  String receiverName;
  String lastMessage;
  String sentAt;
  bool seen;
  int chattingWith;
  String productId;
  String productImage;
  String productName;
  String productPrice;
  String groupChatId;

  UserChat({required this.id, required this.photoUrl, required this.senderName, required this.receiverName, required this.lastMessage, required this.sentAt, required this.seen, required this.chattingWith, required this.productId, required this.productName, required this.productPrice, required this.productImage, required this.groupChatId});

  Map<String, dynamic> toJson() {
    return {
      FirestoreConstants.id: id,
      "senderName": senderName,
      "receiverName": receiverName,
      FirestoreConstants.photoUrl: photoUrl,
      FirestoreConstants.lastMessage: lastMessage,
      FirestoreConstants.sentAt: sentAt,
      FirestoreConstants.seen: seen,
      FirestoreConstants.chattingWith: chattingWith,
      "productId" : productId,
      "productName" : productName,
      "productPrice" : productPrice,
      "productImage" : productImage,
      "groupChatId" : groupChatId,
    };
  }

  factory UserChat.fromDocument(DocumentSnapshot? doc) {
    int id = 0;
    String photoUrl = "";
    String senderName = "";
    String receiverName = "";
    String lastMessage = "";
    String sentAt = "";
    bool seen = false;
    int chattingWith = 0;
    String productId = "";
    String productName = "";
    String productPrice = "";
    String productImage = "";
    String groupChatId = "";
    try {
      id = doc!.get(FirestoreConstants.id);
    } catch (e) {}
    try {
      photoUrl = doc!.get(FirestoreConstants.photoUrl);
    } catch (e) {}
    try {
      senderName = doc!.get("senderName");
    } catch (e) {}
    try {
      receiverName = doc!.get("receiverName");
    } catch (e) {}
    try {
      lastMessage = doc!.get(FirestoreConstants.lastMessage);
    } catch (e) {}
    try {
      sentAt = doc!.get(FirestoreConstants.sentAt);
    } catch (e) {}
    try {
      seen = doc!.get(FirestoreConstants.seen);
    } catch (e) {}
    try {
      chattingWith = doc!.get(FirestoreConstants.chattingWith);
    } catch (e) {}
    try {
      productId = doc!.get("productId");
    } catch (e) {}
    try {
      productName = doc!.get("productName");
    } catch (e) {}
    try {
      productPrice = doc!.get("productPrice");
    } catch (e) {}
    try {
      productImage = doc!.get("productImage");
    } catch (e) {}
    try {
      groupChatId = doc!.get("groupChatId");
    } catch (e) {}
    return UserChat(
      id: id,
      photoUrl: photoUrl,
      senderName: senderName,
      receiverName: receiverName,
      lastMessage: lastMessage,
      sentAt: sentAt,
      seen: seen,
      chattingWith: chattingWith, productId: productId, productName: productName, productPrice: productPrice, productImage: productImage, groupChatId: groupChatId,
    );
  }
}
