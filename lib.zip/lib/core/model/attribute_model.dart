class AttributeModel {
  String name;
  bool isSelected;

  AttributeModel({required this.name, required this.isSelected});
}