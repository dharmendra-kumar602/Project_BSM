import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';

class WishlistModel {
  int productId;
  int variationId;
  bool isLiked;
  Variation? variation;


  WishlistModel({
    required this.productId,
    required this.variationId,
    required this.variation,
    this.isLiked = false,
});

  Map<String, dynamic> toJson() {
    return {
      'productId': productId,
      'variationId': variationId,
      'variation': variation
    };
  }
}