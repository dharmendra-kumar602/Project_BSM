class FilterFinalModel {
  int id;
  int name;
  bool isSelected;

  FilterFinalModel({required this.id, required this.name, required this.isSelected});
}