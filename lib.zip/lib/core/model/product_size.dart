class ProductSize {
  String size;
  int id;

  ProductSize(this.size, this.id);
}

class ProductSizes {
  int selectedSize;
  List<ProductSize> sizes;

  ProductSizes(this.selectedSize, this.sizes);
}
