class RequestHeader {
  final String requestId;

  RequestHeader({
    required this.requestId,
  });

  factory RequestHeader.fromJson(Map<String, dynamic> json) => RequestHeader(
    requestId: json["requestId"],
  );

  Map<String, dynamic> toJson() => {
    "requestId": requestId,
  };
}