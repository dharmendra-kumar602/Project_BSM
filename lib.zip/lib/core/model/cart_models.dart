class CartModel {
  int productId;
  int productVariationId;
  int quantity;

  CartModel({required this.productId, required this.productVariationId, required this.quantity});


  Map<String, dynamic> toJson() {
    return {
      'productId': productId,
      'productVariationId': productVariationId,
      'quantity': quantity,
    };
  }
}