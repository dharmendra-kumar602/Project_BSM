class ResponseHeader {
  final String requestId;
  final String responseId;
  Error? error;
  final String status;
  final String message;

  ResponseHeader({
    required this.requestId,
    required this.responseId,
    this.error,
    required this.status,
    required this.message,
  });

  factory ResponseHeader.fromJson(Map<String, dynamic> json) {
    if  (json["error"] == null) {
      return ResponseHeader(
        requestId: json["requestId"],
        responseId: json["responseId"],
        status: json["status"],
        message: json["message"],
      );
    } else {
      return ResponseHeader(
        requestId: json["requestId"],
        responseId: json["responseId"],
        error: Error.fromJson(json["error"]),
        status: json["status"],
        message: json["message"],
      );
    }
  }

  Map<String, dynamic> toJson() => {
    "requestId": requestId,
    "responseId": responseId,
    "error": error?.toJson(),
    "status": status,
    "message": message,
  };
}

class Error {
  final List<String> messages;
  final int statusCode;

  Error({
    required this.messages,
    required this.statusCode,
  });

  factory Error.fromJson(Map<String, dynamic> json) => Error(
    messages: json["message"] != null ? List<String>.from(json["message"].map((x) => x)) : [],
    statusCode: json["statusCode"],
  );

  Map<String, dynamic> toJson() => {
    "message": List<dynamic>.from(messages.map((x) => x)),
    "statusCode": statusCode,
  };
}