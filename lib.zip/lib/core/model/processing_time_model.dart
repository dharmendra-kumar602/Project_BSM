class ProcessingTimeModel {
  String name;
  int value;
  int index;

  ProcessingTimeModel({required this.name, required this.value, required this.index});
}