import 'package:flutter/material.dart';

class ProductColor {
  Color color;
  String name;
  int id;

  ProductColor({required this.color, required this.id, required this.name});
}

class ProductColors {
  int selectedColor;
  List<ProductColor> colors;

  ProductColors(this.selectedColor, this.colors);
}
