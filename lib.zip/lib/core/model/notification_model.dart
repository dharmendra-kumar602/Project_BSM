class Notifications {
  int? id;
  int? fromUserId;
  int? toUserId;
  String? text;
  String? notificationType;
  String? title;
  String? createdAt;
  String? updatedAt;
  String? price;
  String? subText;

  Notifications(
      {
        this.id,
        this.fromUserId,
        this.toUserId,
        this.text,
        this.notificationType,
        this.title,
        this.createdAt,
        this.updatedAt,
        this.price,
        this.subText,
        });

  Notifications.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    fromUserId = json['fromUserId'];
    toUserId = json['toUserId'];
    text = json['text'] ?? "";
    notificationType = json['notificationType'] ?? "";
    title = json['title'] ?? "";
    createdAt = json['createdAt'] ?? "";
    updatedAt = json['updatedAt'] ?? "";
    price = json['price'] ?? "";
    subText = json['subText'] ?? "";
  }

  // To JSON method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['fromUserId'] = fromUserId;
    data['toUserId'] = toUserId;
    data['text'] = text;
    data['notificationType'] = notificationType;
    data['title'] = title;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['price'] = price;
    data['subText'] = subText;
    return data;
  }
}