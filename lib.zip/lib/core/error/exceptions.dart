class ServerException implements Exception {
  String? message;

  ServerException(this.message);

  @override
  String toString() {
    return message.toString();
  }
}

class LogoutException implements Exception {
  String? message;

  LogoutException(this.message);

  @override
  String toString() {
    return message.toString();
  }
}

class CustomMessageException implements Exception {
  String? message;

  CustomMessageException(this.message);

  @override
  String toString() {
    return message.toString();
  }
}

class ApiFailedException implements Exception {
  String? message;

  ApiFailedException(this.message);

  @override
  String toString() {
    return message.toString();
  }
}

class CacheException implements Exception {}
