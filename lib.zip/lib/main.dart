import 'dart:async';
import 'dart:ui';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get_storage/get_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/rest_client.dart';
import 'package:take_my_tack/data/service/firebase_messaging_service.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/getx/routes/app_screens.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/dashboard/seller_dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/font_family.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp().then((value) {});

  /// getX singleton instance
  Get.put(RestClient(), permanent: true);

  /// Set status bar icon color
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
    ),
  );

  /// for initializing local storage
  await GetStorage.init();

  runZonedGuarded(
    /// Lock device orientation to portrait
    () => SystemChrome.setPreferredOrientations(
      [
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ],
    ).then((_) async {
      runApp(const MyApp());
    }),
    (error, stackTrace) async {},
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<StatefulWidget> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  FirebaseDynamicLinks dynamicLinks = FirebaseDynamicLinks.instance;

  @override
  void initState() {
    final firebaseMessaging = FirebaseMessagingService();
    firebaseMessaging.registerNotifications(context);
    firebaseMessaging.checkForInitialMessage(context);

    Get.put(DashboardController());
    Get.put(SellerDashboardController());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        useInheritedMediaQuery: true,
        minTextAdapt: true,
        splitScreenMode: true,
        builder: (context, child) {
          return GetMaterialApp(
            theme: ThemeData(fontFamily: TMTFontFamily.fontPoppins),
            initialRoute: AppRoutes.splashScreen,
            debugShowCheckedModeBanner: false,
            title: TMTConstant.appName,
            getPages: AppPages.list,
          );
        });
  }
}