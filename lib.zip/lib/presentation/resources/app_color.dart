import 'package:flutter/material.dart';

class AppColor {
  static const white = Color(0xFFFFFFFF);
  static const green = Color(0xFF10BB69);
  static const transparent = Colors.transparent;
  static const bottomSheet = Color(0xFFF5F5F5);
  static const primary = Color(0xFFE20613);
  static const primaryBG = Color(0xFFED2024);
  static const headingColor = Color(0xFF000000);
  static const textColor = Color(0xFF595959);
  static const borderColor = Color(0xFF595959);
  static const primaryToast = Color(0xFFFBC7C8);
  static const greenToast = Color(0xFFC3EEDA);
  static const dividerColor = Color(0xFFE6E6E6);
  static const lightGrey = Color(0xFFEEEEEE);
  static const arrowColor = Color(0xFF428DD8);
  static const yellowColor = Color(0xFFF3A200);

  /// Neutral
  static const neutral = Color(0xFFF7F9FC);
  static const neutral_800 = Color(0xFF000000);
  static const neutral_700 = Color(0xFF3E3F40);
  static const neutral_600 = Color(0xFF7D7E80);
  static const neutral_500 = Color(0xFFC8C9CC);
  static const neutral_400 = Color(0xFFE1E2E5);
  static const neutral_300 = Color(0xFFEDEFF2);
  static const neutral_200 = Color(0xFFF7F9FC);
  static const neutral_100 = Color(0xFFFFFFFF);
  static const sliderIndicatorDisabledColor = Color(0xFFD9D9D9);
}