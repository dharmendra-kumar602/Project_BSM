class TMTConstant {
  static const appName = 'Take My Tack';
  static const String firstIntroScreenDescription = 'Buy new or second-hand horse tack by verified sellers near and far. Easily find tack by location, category, color and condition. Buying via Take My Tack is safe and secure and ever so easy!';
  static const String sectionIntroScreenDescription = ' Become a seller and list your new or second-hand horse tack items for an easy sell to customers all over! Simply upload your product, set your shipping amount and get selling.';
  static const String thirdIntroScreenDescription = 'Chat with fellow horse lovers in the chat forum: ask questions, start topics and be part of the trending conversations. Visit www.tacktalk.co.uk for a site full of content, articles and our blogs!';
  static const String sell = "Sell";
  static const String buy = "Buy";
  static const String getReward = "Get Reward";
  static const captchaMethodChannel = 'flutter.native/helper';
  static const String captchaId = 'showCaptchaPopup';
  static const String someThingWentWrong = 'Something went wrong.';
  static const String responseError = 'ERROR';
  static const String take = 'Take';
  static const String trade = 'Trade';
  static const String talk = 'Talk';
  static const String responseSuccess = 'SUCCESS';
  static const String roleBuyer = 'BUYER';
  static const String roleSeller = 'SELLER';
  static const String genderMale = 'MALE';
  static const String genderFemale = 'FEMALE';
  static const String genderOther = 'OTHER';
}

/// Getx Controller builder constants.
class GetControllerBuilders {
  static String introPageController = 'introPageController';
  static String loginPageController = 'loginPageController';
  static String signUpPageController = 'signUpPageController';
  static String forgotPasswordPageController = 'forgotPasswordPageController';
  static String verifyOTPController = 'verifyOTPController';
  static String verifyForgotOTPController = 'verifyForgotOTPController';
  static String resetPasswordController = 'resetPasswordController';
  static String dashboardController = 'dashboardController';
  static String homePageController = 'homePageController';
  static String productDetailController = 'productDetailController';
  static String productSellerDetailController = 'productSellerDetailController';
  static String categoryScreenController = 'categoryScreenController';
  static String cartScreenController = 'cartScreenController';
  static String cartAddressCheckoutScreenController = 'cartAddressCheckoutScreenController';
  static String cartChangeAddressScreenController = 'cartChangeAddressScreenController';
  static String sellerProductsListingScreenController = 'sellerProductsListingScreenController';
  static String registerToSellController = 'registerToSellController';
  static String sellerOTPScreenController = 'sellerOTPScreenController';
  static String supportTicketController = 'supportTicketController';
  static String sellerPlanDetailScreenController = 'sellerPlanDetailScreenController';
  static String sellerDocumentVerificationController = 'sellerDocumentVerificationController';
  static String sellerProfileController = 'sellerProfileController';
  static String documentRequestAwaitedScreenController = 'documentRequestAwaitedScreenController';
  static String searchScreenController = 'searchScreenController';
  static String productFiltersController = 'productFiltersController';
  static String sellerDashboardController = 'sellerDashboardController';
  static String addProductScreenController = 'addProductScreenController';
  static String addProductAttributeScreenController = 'addProductAttributeScreenController';
  static String addProductShipmentScreenController = 'addProductShipmentScreenController';
  static String addProductCategoryScreenController = 'addProductCategoryScreenController';
  static String productListingScreenController = 'productListingScreenController';
  static String addressListingScreenController = 'addressListingScreenController';
  static String addNewAddressScreenController = 'addNewAddressScreenController';
  static String notificationControllerScreen = 'notificationControllerScreen';
  static String checkPaymentDetailScreenController = 'checkPaymentDetailScreenController';
  static String orderListingScreenController = 'orderListingScreenController';
  static String orderDetailsScreenController = 'orderDetailsScreenController';
  static String orderItemDetailsScreenController = 'orderItemDetailsScreenController';
  static String checkoutCardsScreenController = 'checkoutCardsScreenController';
  static String cancelOrderScreenController = 'cancelOrderScreenController';
  static String refundOrderScreenController = 'refundOrderScreenController';
  static String sellerProductDetailController = 'sellerProductDetailController';
  static String sellerOrderListingScreenController = 'sellerOrderListingScreenController';
  static String sellerOrderDetailsScreenController = 'sellerOrderDetailsScreenController';
  static String addBankController = 'addBankController';
  static String sellerProfileScreenController = 'sellerProfileScreenController';
  static String editSellerProfileScreenController = 'editSellerProfileScreenController';
  static String sellerBankDetailsScreenController = 'sellerBankDetailsScreenController';
  static String sellerShippingDetailsScreenController = 'sellerShippingDetailsScreenController';
  static String storageMediaStatsController = 'storageMediaStatsController';
  static String productsByBrandIdScreenController = 'productsByBrandIdScreenController';
  static String sellersProductListingController = 'sellersProductListingController';
  static String ordersCardsCheckoutScreen = 'ordersCardsCheckoutScreen';
}

class GetXStorageConstants {
  static String login = 'login';
  static String rememberMe = 'rememberMe';
  static String jwtToken = 'jwtToken';
  static String loggedInTime = 'loggedInTime';
  static String userEmail = 'userEmail';
  static String userType = 'userType';
  static String wishlist = 'wishlist';
  static String cart = 'cart';
  static String notifications = 'notifications';
  static String recentlyViewed = 'recentlyViewed';
  static String showIntroPage = 'showIntroPage';
  static String userId = 'userId';
  static String getSellerStatus = 'getSellerStatus';
  static String getSellerId = 'getSellerId';
  static String fcm = 'fcm';
}

/// FirestoreConstants
class FirestoreConstants{
  static const pathUserCollection = "users";
  static const pathMessageCollection = "messages";
  static const nickname = "nickname";
  static const aboutMe = "aboutMe";
  static const photoUrl = "photoUrl";
  static const id = "id";
  static const chattingWith = "chattingWith";
  static const idFrom = "idFrom";
  static const idTo = "idTo";
  static const timestamp = "timestamp";
  static const content = "content";
  static const type = "type";
  static const lastMessage = "lastMessage";
  static const sentAt = "sentAt";
  static const seen = "seen";
  static const replyTo = "replyTo";
  static const replyMessage = "replyMessage";
  static const replyMessageType = "replyMessageType";
  static const fcmToken = "pushToken";
}