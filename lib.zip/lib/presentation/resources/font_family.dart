class TMTFontFamily {
  static const fontPoppins = 'Poppins';
  static const fontTeen = 'Teen';
  static const fontIcons = 'TMTAppIcons';
  static const fontHarbinger = 'Harbinger';
}