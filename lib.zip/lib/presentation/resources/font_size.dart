import 'package:flutter_screenutil/flutter_screenutil.dart';

class TMTFontSize {
  static final sp_6 = 6.0.sp;
  static final sp_8 = 8.0.sp;
  static final sp_9 = 9.0.sp;
  static final sp_10 = 10.0.sp;
  static final sp_11 = 11.0.sp;
  static final sp_12 = 12.0.sp;
  static final sp_13 = 13.0.sp;
  static final sp_14 = 14.0.sp;
  static final sp_15 = 15.0.sp;
  static final sp_16 = 16.0.sp;
  static final sp_18 = 18.0.sp;
  static final sp_19 = 19.0.sp;
  static final sp_20 = 20.0.sp;
  static final sp_22 = 22.0.sp;
  static final sp_23 = 23.0.sp;
  static final sp_24 = 24.0.sp;
  static final sp_25 = 25.0.sp;
  static final sp_26 = 26.0.sp;
  static final sp_28 = 28.0.sp;
  static final sp_30 = 30.0.sp;
  static final sp_32 = 32.0.sp;
  static final sp_35 = 35.0.sp;
}