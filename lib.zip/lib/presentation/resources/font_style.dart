import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/resources/font_family.dart';
import 'app_color.dart';
import 'font_size.dart';

class TMTFontStyles {

  /// common font style for all text
  static text({double? fontSize, Color? color, FontWeight? fontWeight, TextDecoration? textDecoration}) => TextStyle(
      fontSize: fontSize ?? TMTFontSize.sp_12,
      color: color ?? AppColor.textColor,
      fontWeight: fontWeight ?? FontWeight.w500,
    fontFamily: TMTFontFamily.fontPoppins,
      decoration: textDecoration,
      );

  /// common font style for all text with teen font family
  static textTeen({double? fontSize, Color? color, FontWeight? fontWeight, TextDecoration? textDecoration}) => TextStyle(
      fontSize: fontSize ?? TMTFontSize.sp_12,
      color: color ?? AppColor.textColor,
      fontWeight: fontWeight ?? FontWeight.w500,
      fontFamily: TMTFontFamily.fontTeen,
    decoration: textDecoration
  );

  /// common font style for all text with harbinger font family
  static textHarbinger({double? fontSize, Color? color, FontWeight? fontWeight, TextDecoration? textDecoration}) => TextStyle(
      fontSize: fontSize ?? TMTFontSize.sp_12,
      color: color ?? AppColor.textColor,
      fontWeight: fontWeight ?? FontWeight.w500,
      fontFamily: TMTFontFamily.fontHarbinger,
      decoration: textDecoration
  );

  /// common font style for small text
  static textSmall({double? fontSize, Color? color, FontWeight? fontWeight}) => TextStyle(
      fontSize: fontSize ?? TMTFontSize.sp_10,
      color: color ?? AppColor.textColor,
      fontWeight: fontWeight ?? FontWeight.normal
  );

  /// common font style for extra small text
  static textXSmall({double? fontSize, Color? color, FontWeight? fontWeight}) => TextStyle(
      fontSize: fontSize ?? TMTFontSize.sp_8,
      color: color ?? AppColor.textColor,
      fontWeight: fontWeight ?? FontWeight.normal
  );

  /// common font style for medium size text
  static textMedium({double? fontSize, Color? color, FontWeight? fontWeight}) => TextStyle(
      fontSize: fontSize ?? TMTFontSize.sp_14,
      color: color ?? AppColor.textColor,
      fontWeight: fontWeight ?? FontWeight.normal
  );

  /// common font style for large text
  static textLarge({double? fontSize, Color? color, FontWeight? fontWeight}) => TextStyle(
      fontSize: fontSize ?? TMTFontSize.sp_16,
      color: color ?? AppColor.textColor,
      fontWeight: fontWeight ?? FontWeight.normal
  );

  /// common font style for extra large text
  static textXLarge({double? fontSize, Color? color, FontWeight? fontWeight}) => TextStyle(
      fontSize: fontSize ?? TMTFontSize.sp_18,
      color: color ?? AppColor.textColor,
      fontWeight: fontWeight ?? FontWeight.normal
  );
}
