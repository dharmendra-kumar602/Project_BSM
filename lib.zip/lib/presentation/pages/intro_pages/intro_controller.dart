import 'package:carousel_slider/carousel_controller.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';

class IntroPageController extends GetxController {
  final CarouselController carouselController = CarouselController();
  var isCurrentIndex = 0;

  /// Method use to change current index.
  changeCurrentIndexValue(int index) {
    isCurrentIndex = index;
    carouselController.animateToPage(index);
    update([GetControllerBuilders.introPageController]);
  }
}