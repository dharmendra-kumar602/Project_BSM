import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_description_slider.dart';
import 'package:take_my_tack/presentation/widgets/tmt_image_indicator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'intro_controller.dart';

class IntroScreen extends StatefulWidget {
  const IntroScreen({Key? key}) : super(key: key);

  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

/// list for scrolling intro image.
final List<String> images = [
  TMTImages.introSliderGraphic1,
  TMTImages.introSliderGraphic2,
  TMTImages.introSliderGraphic3,
];

/// list for scrolling intro description.
final List<String> titles = [
  TMTConstant.take,
  TMTConstant.trade,
  TMTConstant.talk,
];

/// list for scrolling intro description.
final List<String> description = [
  TMTConstant.firstIntroScreenDescription,
  TMTConstant.sectionIntroScreenDescription,
  TMTConstant.thirdIntroScreenDescription,
];

class _IntroScreenState extends State<IntroScreen> {

  final IntroPageController _introPageController = Get.put(IntroPageController());

  ///Build UI
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GetBuilder<IntroPageController>(
          id: GetControllerBuilders.introPageController,
          init: _introPageController,
          builder: (controller) {
          return SingleChildScrollView(
            child: Stack(
              children: [
                Column(
                    children: [
                      VerticalSpacing(SizeConfig.safeBlockVertical * 5),
                      Row(
                        children: [
                          const Spacer(),
                          GestureDetector(
                              behavior: HitTestBehavior.opaque,
                            onTap: (){
                              Get.offNamed(AppRoutes.dashBoardScreen);
                            },
                              child: TMTTextWidget(title: "Skip", style: TMTFontStyles.textHarbinger(fontWeight: FontWeight.w600, fontSize: TMTFontSize.sp_16, color: AppColor.neutral_700),)),
                          HorizontalSpacing(WidthDimension.w_20),
                        ],
                      ),
                      VerticalSpacing(HeightDimension.h_60),
                      TMTCarouselTextSlider(title: titles, introPageController: controller, description: description, images: images,),
                      VerticalSpacing(HeightDimension.h_15),
                       TMTTextButton(
                         onTap: (){
                           if (_introPageController.isCurrentIndex == images.length-1) {
                             Get.offNamed(AppRoutes.dashBoardScreen);
                             return;
                           }
                           _introPageController.carouselController.nextPage();
                         },
                        buttonTitle: _introPageController.isCurrentIndex == images.length-1 ? "GET STARTED" : "NEXT",
                          margin: EdgeInsets.only(right: WidthDimension.w_15, left: WidthDimension.w_15),),
                      VerticalSpacing(HeightDimension.h_10),
                      TMTImagesIndicator(images: images, introPageController: controller),
                      VerticalSpacing(HeightDimension.h_15),
                ]),
                Positioned(
                  top: SizeConfig.safeBlockVertical * 6,
                  left: 0,
                  right: 0,
                  child: IgnorePointer(
                    ignoring: true,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: SizeConfig.safeBlockVertical * 13,
                          width: HeightDimension.h_90,
                          child: Image.asset(TMTImages.logo),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        }
      ),
    );
  }
}

