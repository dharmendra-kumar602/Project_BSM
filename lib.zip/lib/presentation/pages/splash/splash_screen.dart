import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/images.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => SplashState();
}

class SplashState extends State<SplashScreen> {

  ///Method use for initial action.
  @override
  void initState() {
    super.initState();
    _loadWidget();
  }

  /// build method.
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return _buildScreen(context);
  }

  /// Method to load widget in delay.
  _loadWidget() async {
    var duration = const Duration(seconds: 3);
    return Timer(duration, _checkSignInStatus);
  }

  /// build UI
  _buildScreen(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: double.infinity,
        width: double.infinity,
        child: Image.asset(TMTImages.backgroundSplash, fit: BoxFit.fill,),
      ),
    );
  }

  /// perform local or remote operation here
  void _checkSignInStatus() {
    bool showIntroPage = TMTLocalStorage.getBool(GetXStorageConstants.showIntroPage) ?? true;
    if (showIntroPage) {
      TMTLocalStorage.save(GetXStorageConstants.showIntroPage, false);
      Get.offNamed(AppRoutes.introPage);
    } else {
      Get.offNamed(AppRoutes.dashBoardScreen);
    }
  }
}
