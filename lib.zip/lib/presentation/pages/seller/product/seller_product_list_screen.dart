import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/dashboard/seller_dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/product/add_product_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_notification/tmt_notification_bell.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';

class SellerProductListScreen extends StatefulWidget {
  const SellerProductListScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SellerProductListScreenState();
}

class _SellerProductListScreenState extends State<SellerProductListScreen> {

  final AddProductScreenController _addProductScreenController =
  Get.put(AddProductScreenController());

  final DashboardController _dashboardController =
  Get.put(DashboardController());

  int selectedSortFilter = 0;
  int addedProducts = 0;
  int allowedProducts = 0;
  int verificationStatus = 0;

  List<String> filters = [
    "All",
    "Pending",
    "Approved",
    "Rejected",
  ];

  @override
  void initState() {
    _callApis();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return TMTBackButton(
      onWillPop: (){
        Get.offNamed(AppRoutes.sellerDashboard);
        return Future.value(false);
      },
      child: Scaffold(
        body: GetBuilder<AddProductScreenController>(
            id: GetControllerBuilders.sellerProductsListingScreenController,
            init: _addProductScreenController,
            builder: (controller) {
              return Column(
                children: [
                  Container(
                    height: MediaQuery.of(context).size.height/9.3,
                    decoration: BoxDecoration(boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 3,
                        offset: const Offset(0, 3), // changes position of shadow
                      ),
                    ], color: AppColor.neutral_100),
                    child: Padding(
                      padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Row(
                          children: [
                            InkWell(
                              onTap: () {
                                Get.offNamed(AppRoutes.sellerDashboard);
                              },
                              child: Row(
                                children: [
                                  HorizontalSpacing(WidthDimension.w_6),
                                  SizedBox(
                                    width: WidthDimension.w_40,
                                    height: HeightDimension.h_30,
                                    child: Center(
                                      child: Image.asset(
                                        TMTImages.icBack,
                                        color: AppColor.neutral_800,
                                        fit: BoxFit.contain,
                                        scale: 3.4,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            TMTTextWidget(
                              title: "Products List",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_20),
                            const Spacer(),
                            GestureDetector(
                              onTap: () async {
                                await Get.toNamed(AppRoutes.notificationScreen,
                                    arguments: "SELLER");
                              },
                              child: TMTNotificationBell(isBuyer: false),
                            ),
                            HorizontalSpacing(WidthDimension.w_20),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Visibility(
                          visible: (verificationStatus != 1),
                          child: Padding(
                            padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_15),
                            child: Text.rich(
                              TextSpan(
                                children: [
                                  TextSpan(text: 'Note: ', style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_12,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w600,
                                  )),
                                  const TextSpan(text: 'Adding products without verification is limited to two. To add more products, you must complete the verification process. Click '),
                                  TextSpan(text: 'HERE', style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_14,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w600,
                                    textDecoration: TextDecoration.underline
                                  ), recognizer: TapGestureRecognizer()
                                    ..onTap = () {
                                    Get.toNamed(AppRoutes.uploadDocumentScreen);
                                    },),
                                  const TextSpan(text: ' to get your document verified.'),
                                ],
                              ),
                              style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.textColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_20),
                        SizedBox(
                          width: double.infinity,
                          height: HeightDimension.h_30,
                          child: ListView.builder(
                            padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  setState(() {
                                    selectedSortFilter = index;
                                    _callApis();
                                  });
                                },
                                child: TMTRoundedCornersContainer(
                                  width: WidthDimension.w_90,
                                  margin: EdgeInsets.only(
                                      left: WidthDimension.w_4,
                                      right: WidthDimension.w_4),
                                  padding: EdgeInsets.only(
                                      top: HeightDimension.h_4,
                                      bottom: HeightDimension.h_4),
                                  bgColor: AppColor.neutral_100,
                                  borderColor: index ==
                                      selectedSortFilter
                                      ? AppColor.primary
                                      : AppColor.neutral_500,
                                  borderWidth: 1.5,
                                  child: Center(
                                      child: TMTTextWidget(
                                        title:
                                        filters[index] ?? "",
                                        style: TMTFontStyles.text(
                                            color: index ==
                                                selectedSortFilter
                                                ? AppColor.primary
                                                : AppColor.textColor),
                                      )),
                                ),
                              );
                            },
                            itemCount: filters.length,
                            shrinkWrap: true,
                            scrollDirection: Axis.horizontal,
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_20),
                        Expanded(
                          child: ListView.builder(itemBuilder: (context, index){
                            return GestureDetector(
                              onTap: () async {
                                await Get.toNamed(AppRoutes.sellerProductDetailScreen, arguments: [_addProductScreenController.data[index].id,
                                  _addProductScreenController.data[index].status == "PENDING" ? "PENDING" :
                                  _addProductScreenController.data[index].productVariations?.first.approvalStatus == "APPROVED" ?  "APPROVED" : "REJECTED"]);
                                _callApis();
                              },
                              child: TMTRoundedCornersContainer(
                                borderRadius: BorderRadius.zero,
                                borderColor: AppColor.neutral_400,
                                width: double.infinity,
                                height: HeightDimension.h_92,
                                padding: const EdgeInsets.all(15),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: HeightDimension.h_70,
                                      width: HeightDimension.h_70,
                                      child: TMTCachedImage.networkImage(_addProductScreenController.data[index].productVariations?.first.productImages?.first.imageName ?? ""),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_20),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Container(
                                                constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width / 2),
                                                child: TMTTextWidget(title: _addProductScreenController.data[index].title ?? "", style: TMTFontStyles.text(
                                                  fontSize: TMTFontSize.sp_15,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w500,
                                                ), maxLines: 1,),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_6),
                                              SizedBox(
                                                height: HeightDimension.h_15,
                                                width: HeightDimension.h_15,
                                                child: Image.asset((_addProductScreenController.data[index].status == "PENDING") ?
                                                  TMTImages.icReqWait :
                                                          _addProductScreenController.data[index].status == "APPROVED" ?
                                                          TMTImages.icReqApprove : TMTImages.icRequestCancel),
                                              )
                                            ],
                                          ),
                                          TMTTextWidget(title: _addProductScreenController.data[index].description ?? "", style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ), maxLines: 1,),
                                          TMTTextWidget(title: "Price £${_addProductScreenController.data[index].productVariations?.first.salePrice?.toStringAsFixed(2) ?? 0}", style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w500,
                                          ),),
                                        ],
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_20),
                                  ],
                                ),
                              ),
                            );
                          }, itemCount: _addProductScreenController.data.length, scrollDirection: Axis.vertical, shrinkWrap: true, padding: EdgeInsets.zero,),
                        ),
                        _addProductScreenController.data.isNotEmpty ? VerticalSpacing(HeightDimension.h_10) : const SizedBox.shrink(),
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.only(
                              top: HeightDimension.h_10,
                              bottom: HeightDimension.h_10,
                              left: WidthDimension.w_18,
                              right: WidthDimension.w_15),
                          child: TMTTextButton(
                            color: AppColor.transparent,
                            border: Border.all(color: AppColor.neutral_800),
                            onTap: () async {
                              if (verificationStatus != 1) {
                                showDialog(context: context, builder: (context){
                                  return Material(
                                    color: AppColor.transparent,
                                    child: Center(
                                      child: TMTRoundedCornersContainer(
                                        height: HeightDimension.h_180,
                                        width: HeightDimension.h_250,
                                        bgColor: AppColor.neutral_100,
                                        padding: const EdgeInsets.all(TMTDimension.padding_15),
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            TMTTextWidget(title: "Complete the verification process to add more products.", style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_16,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w600,
                                            ), textAlign: TextAlign.center, maxLines: 8,),
                                            VerticalSpacing(HeightDimension.h_10),
                                            GestureDetector(
                                              onTap: (){
                                                Navigator.pop(context);
                                              },
                                              child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "DONE", textStyle: TMTFontStyles.textTeen(
                                                fontSize: TMTFontSize.sp_18,
                                                color: AppColor.neutral_100,
                                                fontWeight: FontWeight.w700,
                                              ),)),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                });
                              }  else {
                                if (addedProducts < allowedProducts) {
                                  await Get.toNamed(AppRoutes.addProductScreen);
                                  _callApis();
                                } else {
                                  showDialog(context: context, builder: (context){
                                    return Material(
                                      color: AppColor.transparent,
                                      child: Center(
                                        child: TMTRoundedCornersContainer(
                                          height: HeightDimension.h_180,
                                          width: HeightDimension.h_250,
                                          bgColor: AppColor.neutral_100,
                                          padding: const EdgeInsets.all(TMTDimension.padding_15),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              TMTTextWidget(title: "You can not add more products in this plan.", style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_16,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w600,
                                              ), textAlign: TextAlign.center, maxLines: 8,),
                                              VerticalSpacing(HeightDimension.h_20),
                                              GestureDetector(
                                                onTap: (){
                                                  Navigator.pop(context);
                                                },
                                                child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "OK", textStyle: TMTFontStyles.textTeen(
                                                  fontSize: TMTFontSize.sp_18,
                                                  color: AppColor.neutral_100,
                                                  fontWeight: FontWeight.w700,
                                                ),)),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  });
                                }
                              }
                            },
                            buttonTitle: "ADD PRODUCT",
                            textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_800, fontSize: TMTFontSize.sp_16, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              );
            }
        ),
        bottomNavigationBar: CommonSellerBottomNavigationBar(
            currentSelectedItem: 2, onTap: (index) async {
          if (index == 4) {
            Get.offNamed(AppRoutes.sellerProfileScreen);
          } else if (index == 0) {
            Get.offNamed(AppRoutes.sellerDashboard);
          } else if (index == 1) {
            Get.offNamed(AppRoutes.sellerOrderListingScreen);
          } else if (index == 3) {
            Get.offNamed(AppRoutes.sellerSupportTicketsScreen);
          }
        }),
      ),
    );
  }

  /// call apis
  void _callApis() {
    _addProductScreenController.getProductsBySellerId(context, TMTLocalStorage.getSellerId(), filters[selectedSortFilter], (products){
      Future.delayed(const Duration(milliseconds: 250)).then((value) {
        _dashboardController.getSubscribedPlansStatus(context, (data) {
          setState(() {
            if(_addProductScreenController.data.length < (data?.productsAllowed?.value ?? 0)) {
              verificationStatus = 1;
            } else {
              verificationStatus = data?.seller?.isDocumentVerified ?? 0;
            }
            addedProducts = data?.productsCount ?? 0;
            allowedProducts = data?.productsAllowed?.value ?? 0;
          });
        });
      });
    });
  }
}