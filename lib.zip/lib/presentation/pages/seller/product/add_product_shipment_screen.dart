import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/pages/seller/product/add_product_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_dropdown.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/shipping_input_formatter.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_popup/src/custom_pop_up_menu.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class AddProductShipmentScreen extends StatefulWidget {
  const AddProductShipmentScreen({super.key});

  @override
  State<StatefulWidget> createState() => _AddProductShipmentScreenState();

}

class _AddProductShipmentScreenState extends State<AddProductShipmentScreen> {

  final _formKey = GlobalKey<FormState>();

  final AddProductScreenController _addProductScreenController =
  Get.find<AddProductScreenController>();

  List args = Get.arguments ?? [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<AddProductScreenController>(
          id: GetControllerBuilders.addProductShipmentScreenController,
          init: _addProductScreenController,
          builder: (controller) {
          return Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_6),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: args.isNotEmpty ? "Edit Product" : "Add Product",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                          left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_20
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.all(Radius.circular(25)),
                              bgColor: AppColor.green,
                              height: HeightDimension.h_37,
                              width: HeightDimension.h_37,
                              child: Center(
                                child: TMTTextWidget(title: "1", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_100,
                                  fontWeight: FontWeight.w700,
                                ),),
                              ),
                            ),
                            Container(
                              height: HeightDimension.h_37,
                              width: WidthDimension.w_60,
                              child: Center(
                                child: Container(height: 1, width: double.infinity, color: AppColor.green,),
                              ),
                            ),
                            TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.all(Radius.circular(25)),
                              bgColor: AppColor.green,
                              borderColor: AppColor.green,
                              height: HeightDimension.h_37,
                              width: HeightDimension.h_37,
                              child: Center(
                                child: TMTTextWidget(title: "2", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_100,
                                  fontWeight: FontWeight.w700,
                                ),),
                              ),
                            ),
                            Container(
                              height: HeightDimension.h_37,
                              width: WidthDimension.w_60,
                              child: Center(
                                child: Container(height: 1, width: double.infinity, color: AppColor.green,),
                              ),
                            ),
                            TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.all(Radius.circular(25)),
                              bgColor: AppColor.neutral_100,
                              borderColor: AppColor.green,
                              height: HeightDimension.h_37,
                              width: HeightDimension.h_37,
                              child: Center(
                                child: TMTTextWidget(title: "3", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.green,
                                  fontWeight: FontWeight.w700,
                                ),),
                              ),
                            ),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_20),
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                        child: TMTTextWidget(title: "Select Shipping Methods", style: TMTFontStyles.textTeen(
                          fontSize: TMTFontSize.sp_18,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w700,
                        ),),
                      ),
                      VerticalSpacing(HeightDimension.h_20),
                      Form(
                        key: _formKey,
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_10,
                              right: WidthDimension.w_10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: Row(
                                      children: [
                                        TMTTextWidget(title: "Weight (KG)*", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                        ),),
                                        HorizontalSpacing(WidthDimension.w_6),
                                        CustomPopupMenu(
                                          menuBuilder: () => Container(
                                            margin: EdgeInsets.only(left: WidthDimension.w_100),
                                            width: WidthDimension.w_220,
                                            color: AppColor.arrowColor,
                                            child: Column(
                                              children: [
                                                Container(
                                                  width: double.infinity,
                                                  color: AppColor.arrowColor,
                                                  padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                  child: TMTTextWidget(title: "Please put approx. weight of the item. This is important for setting your shipping cost.", style: TMTFontStyles.text(
                                                    fontSize: TMTFontSize.sp_12,
                                                    color: AppColor.neutral_100,
                                                    fontWeight: FontWeight.w500,
                                                  ),),
                                                ),
                                              ],
                                            ),
                                          ),
                                          barrierColor: Colors.transparent,
                                          pressType: PressType.singleClick,
                                          arrowColor: AppColor.arrowColor,
                                          position: PreferredPosition.top,
                                          child: SizedBox(
                                            height: HeightDimension.h_15,
                                            width: HeightDimension.h_15,
                                            child: Image.asset(TMTImages.icInfo),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_10),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TextFormField(
                                      autovalidateMode: AutovalidateMode.onUserInteraction,
                                      controller: _addProductScreenController.weightTextController,
                                      validator: Validator.weightValidate,
                                      keyboardType: const TextInputType.numberWithOptions(signed: true, decimal: true),
                                      inputFormatters: [DoubleTextInputFormatter()],
                                      textInputAction: TextInputAction.done,
                                      onChanged: (v){
                                      },
                                      onFieldSubmitted: (v) {
                                        TMTUtilities.closeKeyboard(context);
                                      },
                                      decoration: InputDecoration(
                                          fillColor: AppColor.neutral_100,
                                          focusedErrorBorder:  CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          errorBorder:  CustomOutlineInputBorder(
                                              borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          enabledBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          floatingLabelBehavior: FloatingLabelBehavior.auto,
                                          focusedBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 12),
                                          border: CustomOutlineInputBorder(
                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
                                          ),
                                          errorMaxLines: 3,
                                          filled: true,
                                          labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                      ),
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: Row(
                                      children: [
                                        TMTTextWidget(title: "Dimensions(cm)", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                        ),),
                                        HorizontalSpacing(WidthDimension.w_6),
                                        CustomPopupMenu(
                                          menuBuilder: () => Container(
                                            margin: EdgeInsets.only(left: WidthDimension.w_100),
                                            width: WidthDimension.w_220,
                                            color: AppColor.arrowColor,
                                            child: Column(
                                              children: [
                                                Container(
                                                  width: double.infinity,
                                                  color: AppColor.arrowColor,
                                                  padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                  child: TMTTextWidget(title: "Enter the approx. dimensions of the package you will use. If not known, enter 40 x 30 x 5", style: TMTFontStyles.text(
                                                    fontSize: TMTFontSize.sp_12,
                                                    color: AppColor.neutral_100,
                                                    fontWeight: FontWeight.w500,
                                                  ),),
                                                ),
                                              ],
                                            ),
                                          ),
                                          barrierColor: Colors.transparent,
                                          pressType: PressType.singleClick,
                                          arrowColor: AppColor.arrowColor,
                                          position: PreferredPosition.top,
                                          child: SizedBox(
                                            height: HeightDimension.h_15,
                                            width: HeightDimension.h_15,
                                            child: Image.asset(TMTImages.icInfo),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_5),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: TMTTextField(
                                              hintText: "Length",
                                              controller: _addProductScreenController.lengthTextController,
                                              keyboardType: const TextInputType.numberWithOptions(signed: true, decimal: true),
                                              inputFormatters: [DoubleTextInputFormatter()],
                                              textInputAction: TextInputAction.done,
                                              focusNode:
                                              _addProductScreenController.lengthFocusNode,
                                              onChanged: (v){
                                                setState(() {

                                                });
                                              },
                                              validator: Validator.lengthValidate,
                                              onFieldSubmitted: (v) {
                                                _addProductScreenController.widthFocusNode.requestFocus();
                                              }
                                          ),
                                        ),
                                        Expanded(
                                          child: TMTTextField(
                                              hintText: "Width",
                                              controller: _addProductScreenController.widthTextController,
                                              keyboardType: const TextInputType.numberWithOptions(signed: true, decimal: true),
                                              inputFormatters: [DoubleTextInputFormatter()],
                                              textInputAction: TextInputAction.done,
                                              focusNode:
                                              _addProductScreenController.widthFocusNode,
                                              onChanged: (v){
                                                setState(() {

                                                });
                                              },
                                              validator: Validator.widthValidate,
                                              onFieldSubmitted: (v) {
                                                _addProductScreenController.heightFocusNode.requestFocus();
                                              }
                                          ),
                                        ),
                                        Expanded(
                                          child: TMTTextField(
                                              hintText: "Height",
                                              controller: _addProductScreenController.heightTextController,
                                              keyboardType: const TextInputType.numberWithOptions(signed: true, decimal: true),
                                              inputFormatters: [DoubleTextInputFormatter()],
                                              textInputAction: TextInputAction.done,
                                              focusNode:
                                              _addProductScreenController.heightFocusNode,
                                              onChanged: (v){
                                                setState(() {

                                                });
                                              },
                                              validator: Validator.heightValidate,
                                              onFieldSubmitted: (v) {
                                                TMTUtilities.closeKeyboard(context);
                                              }
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: Row(
                                      children: [
                                        TMTTextWidget(title: "Processing Time", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                        ),),
                                        HorizontalSpacing(WidthDimension.w_6),
                                        CustomPopupMenu(
                                          menuBuilder: () => Container(
                                            margin: EdgeInsets.only(left: WidthDimension.w_100),
                                            width: WidthDimension.w_220,
                                            color: AppColor.arrowColor,
                                            child: Column(
                                              children: [
                                                Container(
                                                  width: double.infinity,
                                                  color: AppColor.arrowColor,
                                                  padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                  child: TMTTextWidget(title: "Set the time it will take for you to pack and send the item once a buyer has bought it from you.", style: TMTFontStyles.text(
                                                    fontSize: TMTFontSize.sp_12,
                                                    color: AppColor.neutral_100,
                                                    fontWeight: FontWeight.w500,
                                                  ),),
                                                ),
                                              ],
                                            ),
                                          ),
                                          barrierColor: Colors.transparent,
                                          pressType: PressType.singleClick,
                                          arrowColor: AppColor.arrowColor,
                                          position: PreferredPosition.top,
                                          child: SizedBox(
                                            height: HeightDimension.h_15,
                                            width: HeightDimension.h_15,
                                            child: Image.asset(TMTImages.icInfo),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_8),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: CustomDropdown.getCustomDataTypeDropdown(context, _addProductScreenController.processingTime == -1 ? "Ready to ship in..." : _addProductScreenController.processingTimesList[_addProductScreenController.processingTime].name, _addProductScreenController.processingTimesList, (value){if (value == null) {
                                      if (_addProductScreenController.processingTime == -1) {
                                        return 'Please select processing time.';
                                      }
                                    }
                                    return null;}, (v){
                                      setState(() {
                                        _addProductScreenController.processingTime = v;
                                      });
                                    }),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: Row(
                                      children: [
                                        TMTTextWidget(title: "Shipping Type", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                        ),),
                                        HorizontalSpacing(WidthDimension.w_6),
                                        CustomPopupMenu(
                                          menuBuilder: () => Container(
                                            margin: EdgeInsets.only(left: WidthDimension.w_100),
                                            width: WidthDimension.w_190,
                                            color: AppColor.arrowColor,
                                            child: Column(
                                              children: [
                                                Container(
                                                  width: double.infinity,
                                                  color: AppColor.arrowColor,
                                                  padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                  child: TMTTextWidget(title: "Enter shipping type. ", style: TMTFontStyles.text(
                                                    fontSize: TMTFontSize.sp_12,
                                                    color: AppColor.neutral_100,
                                                    fontWeight: FontWeight.w500,
                                                  ),),
                                                ),
                                              ],
                                            ),
                                          ),
                                          barrierColor: Colors.transparent,
                                          pressType: PressType.singleClick,
                                          arrowColor: AppColor.arrowColor,
                                          position: PreferredPosition.top,
                                          child: SizedBox(
                                            height: HeightDimension.h_15,
                                            width: HeightDimension.h_15,
                                            child: Image.asset(TMTImages.icInfo),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_8),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: CustomDropdown.getCustomDropdown(context, _addProductScreenController.shipmentType.isEmpty ? "Shipping Type" : _addProductScreenController.shipmentType, _addProductScreenController.shipmentTypeList, (value){if (value == null) {
                                      if (_addProductScreenController.shipmentType.isEmpty) {
                                        return 'Please select shipping type.';
                                      }
                                    }
                                    return null;}, (v){
                                      setState(() {
                                        _addProductScreenController.shipmentType = v;
                                      });
                                    }),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_10,
                    bottom: HeightDimension.h_10,
                    left: WidthDimension.w_15,
                    right: WidthDimension.w_15),
                child: TMTTextButton(
                  onTap: (){
                    if (_formKey.currentState!.validate()) {
                      if (_addProductScreenController.processingTime == -1) {
                        TMTToast.showErrorToast(context, "Please select processing time.", title: "Alert");
                        return;
                      }
                      if (_addProductScreenController.shipmentType.isEmpty) {
                        TMTToast.showErrorToast(context, "Please select shipping type.", title: "Alert");
                        return;
                      }
                      if (args.isEmpty) {
                        _addProductScreenController.addNewProduct(context);
                      } else {
                        _addProductScreenController.updateProduct(context, args[0], args[1]);
                      }
                    }
                    TMTUtilities.closeKeyboard(context);
                  },
                  buttonTitle: args.isEmpty ? "ADD PRODUCT" : "EDIT PRODUCT",
                ),
              )
            ],
          );
        }
      ),
    );
  }
}