import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/processing_time_model.dart';
import 'package:take_my_tack/data/model/request/get_all_categories_request.dart';
import 'package:take_my_tack/data/model/request/get_products_by_sellerid_request.dart';
import 'package:take_my_tack/data/model/request/post_add_new_product_request.dart';
import 'package:take_my_tack/data/model/request/post_update_product_request.dart';
import 'package:take_my_tack/data/model/response/get_default_attributes_response.dart';
import 'package:take_my_tack/data/model/response/get_product_by_product_id_response.dart';
import 'package:take_my_tack/data/model/response/get_products_by_seller_id_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_product_details_response.dart';
import 'package:take_my_tack/data/repository_implementation/dashboard_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/seller_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

import '../../../../data/model/response/get_all_categories_response.dart';

class AddProductScreenController extends GetxController {

  final SellerRepositoryImpl _sellerRepositoryImpl = SellerRepositoryImpl();
  final DashboardRepositoryImpl _dashboardRepositoryImpl = DashboardRepositoryImpl();

  /// add product category screen stuff
  int selectedCategory = -1;
  int selectedSubCategory = -1;
  int selectedChildCategory = -1;

  int productCondition = -1;

  List<CategoryObj> categories = [];

  List<CategoryObj> subCategories = [];

  List<CategoryObj> childCategories = [];

  List<CategoryObj> categoriesData = [];

  /// add product screen stuff
  var productNameTextController = TextEditingController();
  var productNameNode = FocusNode();
  var productDescriptionTextController = TextEditingController();
  var productDescriptionNode = FocusNode();
  var brandNameTextController = TextEditingController();
  var brandNameNode = FocusNode();

  var priceTextController = TextEditingController();
  var priceNameNode = FocusNode();

  File? mainImage;
  File? image2;
  File? image3;
  File? image4;

  List<AttributeData> attributeData = [];

  /// add shipment details screen stuff
  var sPriceTextController = TextEditingController();
  var weightTextController = TextEditingController();
  var sPriceNameNode = FocusNode();
  var weightFocusNode = FocusNode();
  var widthTextController = TextEditingController(text: "30");
  var heightTextController = TextEditingController(text: "5");
  var lengthTextController = TextEditingController(text: "40");
  var lengthFocusNode = FocusNode();
  var widthFocusNode = FocusNode();
  var heightFocusNode = FocusNode();

  int processingTime = -1;
  List<ProcessingTimeModel> processingTimesList = [
    ProcessingTimeModel(name: "1 business day", value: 1, index: 0),
    ProcessingTimeModel(name: "1-2 business days", value: 2, index: 1),
    ProcessingTimeModel(name: "1-3 business days", value: 3, index: 2),
    ProcessingTimeModel(name: "3-5 business days", value: 5, index: 3),
    ProcessingTimeModel(name: "1-2 weeks", value: 14, index: 4),
    ProcessingTimeModel(name: "2-3 weeks", value: 21, index: 5),
    ProcessingTimeModel(name: "3-4 weeks", value: 28, index: 6),
    ProcessingTimeModel(name: "4-6 weeks", value: 42, index: 7),
    ProcessingTimeModel(name: "6-8 weeks", value: 56, index: 8),
  ];

  String shipmentType = "";
  List<String> shipmentTypeList = ["Free shipping", "Shipping by weight"];

  /// Seller product listing screen stuff
  List<SellerProducts> data = [];

  /// product detail page
  List<String> bannersTop = [];
  List<SellerProductAttributeMapping> sizes = [];
  List<SellerProductAttributeMapping> colors = [];
  List<SellerProductAttributeMapping> material = [];
  List<SellerProductAttributeMapping> tackType = [];
  List<SellerProductAttributeMapping> filling = [];

  List<ProductAttributeMapping> productColors = [];
  var isCurrentIndex = 0;
  SellerProductData? sellerProductData;
  int selectedVariation = 0;
  String selectedColor = "";
  String selectedSize = "";
  String selectedMaterial = "";
  String selectedTackType = "";
  String selectedFilling = "";

  /*
   Method use to add new product.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void addNewProduct(BuildContext context) {
    var params = PostAddNewProductRequest(title: productNameTextController.text, description: productDescriptionTextController.text, brandName: brandNameTextController.text, categoryId: childCategories[selectedChildCategory].id, badgeId: 1, additionalDetails: "Details", maxRetailPrice: _parseInt(priceTextController.text.toString()), salePrice: _parseInt(priceTextController.text.toString()), condition: productCondition == 0 ? "NEW" : productCondition == 1 ? "LIKE NEW" : productCondition == 2 ? "GOOD" : "USED", weightInPound: _parseInt(weightTextController.text.toString()), length: _parseInt(lengthTextController.text.toString()), width: _parseInt(widthTextController.text.toString()), height: _parseInt(heightTextController.text.toString()), processingTime: processingTimesList[processingTime].name, attributes: attributeData.where((element) => element.selectedOption.isNotEmpty).toList().map((e) => ProductAttributes(e.id, e.attributeName, e.selectedOption)).toList(), productImages: [mainImage, image2, image3, image4]);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.postAddNewProducts(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              showDialog(
                barrierDismissible: false,
                  context: context, builder: (c){
                return WillPopScope(
                  onWillPop: () {
                    return Future.value(false);
                  },
                  child: Material(
                    color: AppColor.transparent,
                    child: Center(
                      child: TMTRoundedCornersContainer(
                        height: HeightDimension.h_215,
                        width: HeightDimension.h_250,
                        bgColor: AppColor.neutral_100,
                        padding: const EdgeInsets.all(TMTDimension.padding_15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            TMTTextWidget(title: "This product has been sent for approval. Once the product has been approved, you will receive the notification.", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w600,
                            ), textAlign: TextAlign.center, maxLines: 8,),
                            VerticalSpacing(HeightDimension.h_10),
                            GestureDetector(
                              onTap: (){
                                clearControllers();
                                Navigator.pop(c);
                                Navigator.pop(context);
                                Navigator.pop(context);
                                Navigator.pop(context);
                                Get.offNamed(AppRoutes.sellerProductListScreen);
                              },
                              child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "DONE", textStyle: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_100,
                                fontWeight: FontWeight.w700,
                              ),)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              });
            } else {
              if (right.error?.statusCode == 400) {
                showDialog(context: context, builder: (context){
                  return Material(
                    color: AppColor.transparent,
                    child: Center(
                      child: TMTRoundedCornersContainer(
                        height: HeightDimension.h_180,
                        width: HeightDimension.h_250,
                        bgColor: AppColor.neutral_100,
                        padding: const EdgeInsets.all(TMTDimension.padding_15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            TMTTextWidget(title: "You can not add more products in this plan.", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w600,
                            ), textAlign: TextAlign.center, maxLines: 8,),
                            VerticalSpacing(HeightDimension.h_20),
                            GestureDetector(
                              onTap: (){
                                clearControllers();
                                Navigator.pop(context);
                                Navigator.pop(context);
                                Navigator.pop(context);
                                Navigator.pop(context);
                              },
                              child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "OK", textStyle: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_100,
                                fontWeight: FontWeight.w700,
                              ),)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                });
              } else {
                TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update product.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void updateProduct(BuildContext context, int productId, int variationId) {
    var params = PostUpdateProductRequest(
      productId : productId,
      categoryId : childCategories[selectedChildCategory].id,
      productName : productNameTextController.text,
      productDescription: productDescriptionTextController.text,
      brandName: brandNameTextController.text,
      variationId: variationId,
      variationPrice: _parseInt(priceTextController.text.toString()),
      variationWeight: _parseInt(weightTextController.text.toString()),
      variationLength: _parseInt(lengthTextController.text.toString()),
      variationHeight: _parseInt(heightTextController.text.toString()),
      variationWidth: _parseInt(widthTextController.text.toString()),
      variationCondition: productCondition == 0 ? "NEW" : productCondition == 1 ? "LIKE NEW" : productCondition == 2 ? "GOOD" : "USED",
      variationProcessingTime: processingTimesList[processingTime].name,
      variationAttributes: attributeData.where((element) => element.selectedOption.isNotEmpty).toList().map((e) => VariationAttribute(id: e.id, name: e.attributeName, value: e.selectedOption)).toList(), productImages: [mainImage, image2, image3, image4],
    );

    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.postEditProduct(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              showDialog(
                  barrierDismissible: false,
                  context: context, builder: (c){
                return WillPopScope(
                  onWillPop: () {
                    return Future.value(false);
                  },
                  child: Material(
                    color: AppColor.transparent,
                    child: Center(
                      child: TMTRoundedCornersContainer(
                        height: HeightDimension.h_215,
                        width: HeightDimension.h_250,
                        bgColor: AppColor.neutral_100,
                        padding: const EdgeInsets.all(TMTDimension.padding_15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            TMTTextWidget(title: "Updated product has been sent for approval. Once the product has been approved, you will receive the notification.", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w600,
                            ), textAlign: TextAlign.center, maxLines: 8,),
                            VerticalSpacing(HeightDimension.h_10),
                            GestureDetector(
                              onTap: (){
                                clearControllers();
                                Navigator.pop(c);
                                Navigator.pop(context);
                                Navigator.pop(context);
                                Navigator.pop(context);
                                Get.offNamed(AppRoutes.sellerProductListScreen);
                              },
                              child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "DONE", textStyle: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_100,
                                fontWeight: FontWeight.w700,
                              ),)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              });
            } else {
              if (right.error?.statusCode == 400) {
                showDialog(context: context, builder: (context){
                  return Material(
                    color: AppColor.transparent,
                    child: Center(
                      child: TMTRoundedCornersContainer(
                        height: HeightDimension.h_180,
                        width: HeightDimension.h_250,
                        bgColor: AppColor.neutral_100,
                        padding: const EdgeInsets.all(TMTDimension.padding_15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            TMTTextWidget(title: "You can not add more products in this plan.", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w600,
                            ), textAlign: TextAlign.center, maxLines: 8,),
                            VerticalSpacing(HeightDimension.h_20),
                            GestureDetector(
                              onTap: (){
                                clearControllers();
                                Navigator.pop(context);
                                Navigator.pop(context);
                                Navigator.pop(context);
                                Navigator.pop(context);
                              },
                              child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "OK", textStyle: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_100,
                                fontWeight: FontWeight.w700,
                              ),)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                });
              } else {
                TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get Products By Seller Id.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getProductsBySellerId (BuildContext context, int sellerStoreId, String status, Function(List<SellerProducts> data) callback) {
    var params = GetProductsBySellerIdRequest(pageSize: 50, pageNumber: 0, sellerId: sellerStoreId, approvalStatus: status);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _dashboardRepositoryImpl.getSellerProducts(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              data = right.data ?? [];

              data = data.where((product) {
                var statuses = product.productVariations?.map((e) => e
                    .approvalStatus).toList();
                return !(statuses!.contains("EDIT_REQUEST") || statuses.contains("DELETED"));
              }).toList();

              data.forEach((element) {
                var e = element.productVariations?.map((e) => e.approvalStatus).toList();
                if (e?.contains("PENDING") ?? false) {
                  element.status = "PENDING";
                } else if (e?.contains("IN_EDIT") ?? false) {
                  element.status = "PENDING";
                } else if (e?.contains("DELETE_REQUESTED") ?? false) {
                  element.status = "PENDING";
                } else if (e?.contains("EDIT_APPROVED") ?? false) {
                  element.status = "APPROVED";
                } else if (e?.contains("APPROVED") ?? false) {
                  element.status = "APPROVED";
                } else {
                  element.status = "REJECTED";
                }

              });
              callback.call(data);
              update([GetControllerBuilders.sellerProductsListingScreenController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get all categories.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getAllCategories (BuildContext context, Function callback) {
    var request = GetAllCategoriesRequest(limit: 50, offSet: 0
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _dashboardRepositoryImpl.getAllCategories(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              categoriesData = right.data!.categories;

              categories.clear();
              subCategories.clear();
              childCategories.clear();

              right.data!.categories.forEach((element) {
                categories.add(element);
                element.sub.forEach((subElement) {
                  subCategories.add(subElement);
                  subElement.sub.forEach((childElement) {
                    childCategories.add(childElement);
                  });
                });
              });

              update([GetControllerBuilders.addProductCategoryScreenController]);
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get default attributes.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getDefaultAttributes (BuildContext context, {Function? callback}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.getDefaultAttributes();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              attributeData = right.data;
              if (callback == null) {
                update([GetControllerBuilders.addProductAttributeScreenController]);
              } else {
                callback.call();
              }
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// clear controller
  void clearControllers() {
    selectedCategory = -1;
    selectedSubCategory = -1;
    selectedChildCategory = -1;
    productCondition = -1;
    categories = [];
    subCategories = [];
    childCategories = [];
    categoriesData = [];
    /// add product screen stuff
    productNameTextController.clear();
    productDescriptionTextController.clear();
    brandNameTextController.clear();
    priceTextController.clear();
    mainImage = null;
    image2 = null;
    image3 = null;
    image4 = null;
    attributeData = [];

    sPriceTextController.clear();
    weightTextController.clear();
    processingTime = -1;

    shipmentType = "";
  }

  /*
   Method use to get Product detail By Id.
   Parameter- BuildContext context, int id
   Return -> No Return type.
  */
  void getProductDetailById (BuildContext context, int id) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.getSellerProductDetails(id);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {

              sellerProductData = null;
              sizes.clear();
              colors.clear();
              material.clear();
              tackType.clear();
              filling.clear();

              sellerProductData = right.data;
              var e = sellerProductData?.productVariations?.map((e) => e.approvalStatus).toList();
              var r = sellerProductData?.productVariations?.where((element) => element.approvalStatus == "REJECTED");
              if (r?.isNotEmpty ?? false) {
                sellerProductData?.reason = r?.first.rejectionReason ?? "";
              }
              if (e?.contains("PENDING") ?? false) {
                sellerProductData?.status = "PENDING";
              } else if (e?.contains("REJECTED") ?? false) {
                sellerProductData?.status = "REJECTED";
              } else {
                sellerProductData?.status = "APPROVED";
              }

              bannersTop = right.data?.productVariations?[selectedVariation].productImages?.map((e) => e.imageName ?? "").toList() ?? [];
              right.data?.productVariations?.forEach((element) {
                element.productAttributeMappings?.forEach((attElement) {
                  if (attElement.attribute?.attributeName == "Size") {
                    sizes.add(attElement);
                  }
                  if (attElement.attribute?.attributeName == "Color") {
                    colors.add(attElement);
                  }
                  if (attElement.attribute?.attributeName == "Material") {
                    material.add(attElement);
                  }
                  if (attElement.attribute?.attributeName == "TackType") {
                    tackType.add(attElement);
                  }
                  if (attElement.attribute?.attributeName == "Filling") {
                    filling.add(attElement);
                  }
                });
              });

              sizes = removeDuplicates(sizes);
              colors = removeDuplicates(colors);
              material = removeDuplicates(material);
              tackType = removeDuplicates(tackType);
              filling = removeDuplicates(filling);

              if (sizes.isNotEmpty) {
                selectedSize = sizes.first.value ?? "";
              }
              if (colors.isNotEmpty) {
                selectedColor = colors.first.value ?? "";
              }
              if (material.isNotEmpty) {
                selectedMaterial = material.first.value ?? "";
              }
              if (tackType.isNotEmpty) {
                selectedTackType = tackType.first.value ?? "";
              }
              if (filling.isNotEmpty) {
                selectedFilling = filling.first.value ?? "";
              }

              update([GetControllerBuilders.sellerProductDetailController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// remove duplicates
  static List<SellerProductAttributeMapping> removeDuplicates(List<SellerProductAttributeMapping> list) {
    Set<String> seenAttributeNames = <String>{};
    List<SellerProductAttributeMapping> uniqueList = [];

    for (var item in list) {
      if (!seenAttributeNames.contains(item.value)) {
        seenAttributeNames.add(item.value ?? "");
        uniqueList.add(item);
      }
    }
    return uniqueList;
  }

  /// String to int
  double _parseInt(String value) {
    try {
      return double.parse(value);
    } catch (e) {
      var v = double.parse(value);
      return v;
    }
  }

  /*
   Method use to delete Product By Variation Id.
   Parameter- BuildContext context, int variationId
   Return -> No Return type.
  */
  void postDeleteOrder (BuildContext context, int variationId, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.postDeleteProduct(variationId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              callback.call();
            } else {
              if (right.responseHeader?.error?.statusCode == 400) {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
              else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}