import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/pages/seller/product/add_product_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_tabs/custom_tab_bar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_tabs/indicator/custom_indicator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_tabs/indicator/linear_indicator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_tabs/transform/color_transform.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';

class SelectCategoryScreen extends StatefulWidget {
  const SelectCategoryScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SelectCategoryScreenState();

}

class _SelectCategoryScreenState extends State<SelectCategoryScreen> {

  final AddProductScreenController _addProductScreenController =
  Get.find<AddProductScreenController>();

  late PageController _controller;
  final CustomTabBarController _tabBarController = CustomTabBarController();

  @override
  void initState() {
    if (_addProductScreenController.selectedCategory == -1) {
      _addProductScreenController.selectedCategory = 0;
      _addProductScreenController.selectedSubCategory = 0;
      _addProductScreenController.selectedChildCategory = 0;
      if (_addProductScreenController.categories.isNotEmpty) {
        _addProductScreenController.subCategories = _addProductScreenController.categories.first.sub;
      }
      if (_addProductScreenController.subCategories.isNotEmpty) {
        _addProductScreenController.childCategories = _addProductScreenController.subCategories.first.sub;
      }
    }
    _controller = PageController(initialPage: _addProductScreenController.selectedCategory);
    super.initState();
  }

  Widget getTabBarChild(BuildContext context, int index) {
    return TabBarItem(
      index: index,
      transform: ColorsTransform(
          highlightColor: Colors.pink,
          normalColor: Colors.black,
          builder: (context, color) {
            return Container(
              margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
              alignment: Alignment.center,
              constraints: const BoxConstraints(minWidth: 70),
              child: TMTTextWidget(title: _addProductScreenController.categories[index].name, style: TMTFontStyles.textTeen(
                fontSize: TMTFontSize.sp_16,
                color: _tabBarController.currentIndex == index ? AppColor.neutral_800 : AppColor.textColor,
                fontWeight: FontWeight.w700,
              ),),
            );
          }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return TMTBackButton(
      onWillPop: (){
        setState(() {
          _addProductScreenController.selectedCategory = -1;
          _addProductScreenController.selectedSubCategory = -1;
          _addProductScreenController.selectedChildCategory = -1;
        });
        return Future.value(true);
      },
      child: Scaffold(
        appBar: PreferredSize(
            preferredSize: Size.fromHeight(SizeConfig.safeBlockVertical * 9.3),
            child: Container(
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 1,
                  blurRadius: 2,
                  offset: const Offset(0, 2), // changes position of shadow
                ),
              ], color: AppColor.neutral_100),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Row(
                    children: [
                      InkWell(
                        onTap: (){
                          setState(() {
                            _addProductScreenController.selectedCategory = -1;
                            _addProductScreenController.selectedSubCategory = -1;
                            _addProductScreenController.selectedChildCategory = -1;
                          });
                          Get.back();
                           },
                        child: Row(
                          children: [
                            HorizontalSpacing(WidthDimension.w_10),
                            SizedBox(
                              width: WidthDimension.w_40,
                              height: HeightDimension.h_30,
                              child: Center(
                                child: Image.asset(
                                  TMTImages.icBack,
                                  color: AppColor.neutral_800,
                                  fit: BoxFit.contain,
                                  scale: 3.4,
                                ),
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_2),
                          ],
                        ),
                      ),
                      TMTTextWidget(
                        title: "Categories",
                        style: TMTFontStyles.textTeen(
                          fontSize: TMTFontSize.sp_18,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const Spacer(),
                      HorizontalSpacing(WidthDimension.w_20),
                    ],
                  ),
                  VerticalSpacing(HeightDimension.h_8),
                ],
              ),
            )),
        body: GetBuilder<AddProductScreenController>(
            id: GetControllerBuilders.addProductCategoryScreenController,
            init: _addProductScreenController,
            builder: (controller) {
            return Column(
              children: [
                Container(
                  decoration: BoxDecoration(boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 1,
                      offset: const Offset(0, 1), // changes position of shadow
                    ),
                  ], color: AppColor.neutral_100),
                  child: CustomTabBar(
                    onTapItem: (index){

                    },
                    tabBarController: _tabBarController,
                    height: HeightDimension.h_40,
                    itemCount: _addProductScreenController.categories.length,
                    builder: getTabBarChild,
                    indicator: LinearIndicator(color: Colors.pink, bottom: 3, width: WidthDimension.w_100),
                    pageController: _controller,
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                      controller: _controller,
                      itemCount: _addProductScreenController.categories.length,
                      onPageChanged: (int page){
                        setState(() {
                          _addProductScreenController.selectedCategory = page;
                          _addProductScreenController.selectedSubCategory = 0;
                          _addProductScreenController.selectedChildCategory = 0;
                          _addProductScreenController.subCategories = _addProductScreenController.categoriesData[_addProductScreenController.selectedCategory].sub;
                          _addProductScreenController.childCategories = _addProductScreenController.categoriesData[_addProductScreenController.selectedCategory].sub[_addProductScreenController.selectedChildCategory].sub;
                        });
                      },
                      itemBuilder: (context, index) {
                        return SizedBox(
                          height: double.infinity,
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                color: AppColor.lightGrey,
                                width: WidthDimension.w_122,
                                height: double.infinity,
                                child: ListView.builder(itemBuilder: (context, index){
                                  return InkWell(
                                    onTap: (){
                                      setState(() {
                                        _addProductScreenController.selectedSubCategory = index;
                                        _addProductScreenController.selectedChildCategory = 0;
                                        _addProductScreenController.childCategories = _addProductScreenController.subCategories[_addProductScreenController.selectedSubCategory].sub;
                                       });
                                    },
                                    child: Container(
                                      padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_8, bottom: HeightDimension.h_8),
                                      color: _addProductScreenController.selectedSubCategory == index ? AppColor.neutral_100 : AppColor.lightGrey,
                                      width: double.infinity,
                                      child: Center(
                                        child: TMTTextWidget(title: _addProductScreenController.subCategories[index].name, textAlign: TextAlign.center, style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_13,
                                          color: _addProductScreenController.selectedSubCategory == index ? AppColor.neutral_800 : AppColor.textColor,
                                        ),),
                                      ),
                                    ),
                                  );
                                }, scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  itemCount: _addProductScreenController.subCategories.length,
                                  padding: EdgeInsets.zero,),
                              ),
                              Expanded(
                                child: _addProductScreenController.childCategories.isNotEmpty ? ListView.builder(itemBuilder: (context, index){
                                  return InkWell(
                                    onTap: (){
                                      setState(() {
                                        _addProductScreenController.selectedChildCategory = index;
                                      });
                                    },
                                    child: Container(
                                      width: double.infinity,
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Padding(
                                            padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_10),
                                            child: Row(
                                                children: [
                                                  SizedBox(
                                                    width: HeightDimension.h_15,
                                                    height: HeightDimension.h_15,
                                                    child: _addProductScreenController.selectedChildCategory == index ? const TMTRoundedCornersContainer(
                                                      borderColor: AppColor.primaryBG,
                                                      padding: EdgeInsets.all(2),
                                                      child: TMTRoundedCornersContainer(
                                                        borderColor: AppColor.primaryBG,
                                                        bgColor: AppColor.primaryBG,
                                                      ),
                                                    ) : const TMTRoundedCornersContainer(
                                                      borderColor: AppColor.neutral_800,
                                                    ),
                                                  ),
                                                  HorizontalSpacing(WidthDimension.w_10),
                                                  Expanded(child: TMTTextWidget(title: _addProductScreenController.childCategories[index].name)),
                                                  HorizontalSpacing(WidthDimension.w_10),
                                                ],
                                            ),
                                          ),
                                          VerticalSpacing(HeightDimension.h_12),
                                          Container(
                                            margin: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                            width: double.infinity,
                                            height: 0.5,
                                            color: const Color(0xFFD1D1D1),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                }, shrinkWrap: true,
                                  itemCount: _addProductScreenController.childCategories.length,
                                  scrollDirection: Axis.vertical, padding: EdgeInsets.only(top: HeightDimension.h_10),)
                                : Center(child: TMTTextWidget(title: "No data found", style: TMTFontStyles.text(color: AppColor.neutral_600, fontSize: TMTFontSize.sp_10),)),
                              ),
                            ],
                          ),
                        );
                      }),
                ),
                Container(
                  margin: EdgeInsets.only(top: HeightDimension.h_15, bottom: HeightDimension.h_15, left: WidthDimension.w_15, right: WidthDimension.w_15),
                  color: AppColor.neutral_100,
                  height: HeightDimension.h_37,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Expanded(
                        child: TMTTextButton(
                          border: Border.all(color: AppColor.neutral_800),
                          color: AppColor.neutral_100,
                          textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_800, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                          onTap: () {
                           setState(() {
                             _addProductScreenController.selectedCategory = -1;
                             _addProductScreenController.selectedSubCategory = -1;
                             _addProductScreenController.selectedChildCategory = -1;
                           });
                            Navigator.pop(context);
                          }, buttonTitle: 'CANCEL',
                        ),
                      ),
                      HorizontalSpacing(WidthDimension.w_8),
                      Expanded(
                        child: TMTTextButton(
                          onTap: () {
                            if (_addProductScreenController.categories.length <= _addProductScreenController.selectedCategory) {
                              _addProductScreenController.selectedCategory = -1;
                            }
                            if (_addProductScreenController.subCategories.length <= _addProductScreenController.selectedSubCategory) {
                              _addProductScreenController.selectedSubCategory = -1;
                            }
                            if (_addProductScreenController.childCategories.length <= _addProductScreenController.selectedChildCategory) {
                              _addProductScreenController.selectedChildCategory = -1;
                            }
                            if (_addProductScreenController.selectedCategory == -1 || _addProductScreenController.selectedSubCategory == -1 || _addProductScreenController.selectedChildCategory == -1  ) {
                              _addProductScreenController.selectedCategory = -1;
                              _addProductScreenController.selectedSubCategory = -1;
                              _addProductScreenController.selectedChildCategory = -1;
                            }
                            Navigator.pop(context);
                          }, buttonTitle: 'APPLY',
                          textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            );
          }
        ),
      ),
    );
  }
}