import 'dart:io';
import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/product/add_product_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_dropdown.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/shipping_input_formatter.dart';
import 'package:take_my_tack/presentation/utils/tmt_media_picker.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class AddProductAttributesScreen extends StatefulWidget {
  const AddProductAttributesScreen({super.key});

  @override
  State<StatefulWidget> createState() => _AddProductAttributesScreenState();

}

class _AddProductAttributesScreenState extends State<AddProductAttributesScreen> {

  final _formKey = GlobalKey<FormState>();

  final AddProductScreenController _addProductScreenController =
  Get.find<AddProductScreenController>();

  List args = Get.arguments ?? [];

  @override
  void initState() {
    if (args.isEmpty) {
      _addProductScreenController.getDefaultAttributes(context);
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GetBuilder<AddProductScreenController>(
          id: GetControllerBuilders.addProductAttributeScreenController,
          init: _addProductScreenController,
          builder: (controller) {
          return Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_6),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: args.isNotEmpty ? "Edit Product" : "Add Product",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                          left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_20
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.all(Radius.circular(25)),
                              bgColor: AppColor.green,
                              height: HeightDimension.h_37,
                              width: HeightDimension.h_37,
                              child: Center(
                                child: TMTTextWidget(title: "1", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_100,
                                  fontWeight: FontWeight.w700,
                                ),),
                              ),
                            ),
                            Container(
                              height: HeightDimension.h_37,
                              width: WidthDimension.w_60,
                              child: Center(
                                child: Container(height: 1, width: double.infinity, color: AppColor.green,),
                              ),
                            ),
                            TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.all(Radius.circular(25)),
                              bgColor: AppColor.neutral_100,
                              borderColor: AppColor.textColor,
                              height: HeightDimension.h_37,
                              width: HeightDimension.h_37,
                              child: Center(
                                child: TMTTextWidget(title: "2", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w700,
                                ),),
                              ),
                            ),
                            Container(
                              height: HeightDimension.h_37,
                              width: WidthDimension.w_60,
                              child: const Center(
                                child: DottedLine(),
                              ),
                            ),
                            TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.all(Radius.circular(25)),
                              bgColor: AppColor.neutral_100,
                              borderColor: AppColor.textColor,
                              height: HeightDimension.h_37,
                              width: HeightDimension.h_37,
                              child: Center(
                                child: TMTTextWidget(title: "3", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w700,
                                ),),
                              ),
                            ),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_20),
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            TMTTextWidget(title: "Add Attributes", style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),),
                            InkWell(
                              onTap: (){
                                showDialog(
                                    barrierDismissible: false,
                                    context: context, builder: (context){
                                  return WillPopScope(
                                    onWillPop: () { return Future.value(false); },
                                    child: StatefulBuilder(
                                      builder: (c, setState) {
                                        return Material(
                                          color: AppColor.transparent,
                                          child: Center(
                                            child: TMTRoundedCornersContainer(
                                              height: HeightDimension.h_500,
                                              width: double.infinity,
                                              margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                              bgColor: AppColor.neutral_100,
                                              padding: const EdgeInsets.all(TMTDimension.padding_20),
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  TMTTextWidget(title: "Select Attribute", style: TMTFontStyles.textTeen(
                                                    fontSize: TMTFontSize.sp_18,
                                                    color: AppColor.neutral_800,
                                                    fontWeight: FontWeight.w700,
                                                  )),
                                                  Expanded(
                                                    child: ListView.builder(itemBuilder: (context, index) {
                                                      return InkWell(
                                                        onTap: (){
                                                          setState(() {
                                                            _addProductScreenController.attributeData[index].isSelected = !_addProductScreenController.attributeData[index].isSelected;
                                                          });
                                                        },
                                                        child: TMTRoundedCornersContainer(
                                                          padding: const EdgeInsets.all(10),
                                                          margin: const EdgeInsets.only(top: 4, bottom: 4),
                                                          borderRadius: BorderRadius.circular(10),
                                                          width: double.infinity,
                                                          height: HeightDimension.h_40,
                                                          bgColor: _addProductScreenController.attributeData[index].isSelected ? AppColor.primaryBG.withOpacity(0.1) : AppColor.neutral_100,
                                                          borderColor: _addProductScreenController.attributeData[index].isSelected ? AppColor.primary : AppColor.neutral_600,
                                                          borderWidth: 0.5,
                                                          child: Row(
                                                            children: [
                                                              HorizontalSpacing(WidthDimension.w_10),
                                                              TMTTextWidget(title: _addProductScreenController.attributeData[index].attributeName, style: TMTFontStyles.text(
                                                                fontSize: TMTFontSize.sp_13,
                                                                color: AppColor.neutral_800,
                                                              ),),
                                                              const Spacer(),
                                                              SizedBox(
                                                                height: HeightDimension.h_10,
                                                                width: HeightDimension.h_10,
                                                                child: Image.asset(TMTImages.icTickThin, color: AppColor.neutral_800,),
                                                              ),
                                                              HorizontalSpacing(WidthDimension.w_10),
                                                            ],
                                                          ),
                                                        ),
                                                      );
                                                    }, itemCount: _addProductScreenController.attributeData.length, shrinkWrap: true, scrollDirection: Axis.vertical, padding: EdgeInsets.only(top: HeightDimension.h_10, bottom: HeightDimension.h_10),),
                                                  ),
                                                  SizedBox(
                                                    height: HeightDimension.h_37,
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.end,
                                                      children: [
                                                        Expanded(
                                                          child: TMTTextButton(
                                                            border: Border.all(color: AppColor.neutral_800),
                                                            color: AppColor.neutral_100,
                                                            textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_800, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                                                            onTap: () {
                                                              setState(() {
                                                                _addProductScreenController.attributeData.forEach((element) {
                                                                  element.isSelected = false;
                                                                });
                                                              });
                                                              Navigator.pop(context);
                                                            }, buttonTitle: 'CANCEL',
                                                          ),
                                                        ),
                                                        HorizontalSpacing(WidthDimension.w_8),
                                                        Expanded(
                                                          child: TMTTextButton(
                                                            onTap: () {
                                                              _addProductScreenController.update([GetControllerBuilders.addProductAttributeScreenController]);
                                                              Navigator.pop(context);
                                                            }, buttonTitle: 'APPLY',
                                                            textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  );
                                });
                              },
                              child: Container(
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    TMTRoundedCornersContainer(
                                      height: HeightDimension.h_25,
                                      width: HeightDimension.h_25,
                                      borderRadius: BorderRadius.circular(25),
                                      bgColor: AppColor.primaryBG,
                                      padding: EdgeInsets.all(8),
                                      child: Image.asset(TMTImages.icPlusPrimary, color: Colors.white,),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_8),
                                    TMTTextWidget(title: "Add", style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_20,
                                      color: AppColor.primary,
                                      fontWeight: FontWeight.w400,
                                    ),)
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_10),
                      Form(
                        key: _formKey,
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_6,
                              right: WidthDimension.w_6),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ListView.builder(
                                padding: EdgeInsets.zero,
                                physics: const NeverScrollableScrollPhysics(),
                                itemBuilder: (context, index){
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                      child: TMTTextWidget(title: _addProductScreenController.attributeData.where((element) => element.isSelected).toList()[index].attributeName, style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_14,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w500,
                                      ),),
                                    ),
                                    VerticalSpacing(HeightDimension.h_8),
                                    Padding(
                                      padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                      child: CustomDropdown.getCustomDropdown(context, _addProductScreenController.attributeData.where((element) => element.isSelected).toList()[index].selectedOption.isNotEmpty ? _addProductScreenController.attributeData.where((element) => element.isSelected).toList()[index].selectedOption : _addProductScreenController.attributeData.where((element) => element.isSelected).toList()[index].attributeName, _addProductScreenController.attributeData.where((element) => element.isSelected).toList()[index].attributeValues.split('|'), (value){if (_addProductScreenController.attributeData.where((element) => element.isSelected).toList()[index].selectedOption.isEmpty) {
                                        return 'Please select attribute value.';
                                      }
                                      return null;}, (v){
                                        setState(() {
                                          _addProductScreenController.attributeData.where((element) => element.isSelected).toList()[index].selectedOption = v;
                                        });
                                      }),
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                  ],
                                );
                              }, shrinkWrap: true, itemCount: _addProductScreenController.attributeData.where((element) => element.isSelected).toList().length,),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TMTTextWidget(title: "Price (£)", style: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_18,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.w700,
                                    )),
                                  ),
                                  VerticalSpacing(HeightDimension.h_8),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TextFormField(
                                      autovalidateMode: AutovalidateMode.onUserInteraction,
                                      controller: _addProductScreenController.priceTextController,
                                      validator: Validator.priceValidate,
                                      inputFormatters: [DoubleTextInputFormatter()],
                                      keyboardType: const TextInputType.numberWithOptions(signed: true, decimal: true),
                                      onChanged: (v){
                                        setState(() {

                                        });
                                      },
                                      onFieldSubmitted: (v) {
                                        TMTUtilities.closeKeyboard(context);
                                      },
                                      decoration: InputDecoration(
                                          fillColor: AppColor.neutral_100,
                                          focusedErrorBorder:  CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          errorBorder:  CustomOutlineInputBorder(
                                              borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          enabledBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          floatingLabelBehavior: FloatingLabelBehavior.auto,
                                          focusedBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 15, bottom: 15),
                                          border: CustomOutlineInputBorder(
                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
                                          ),
                                          errorMaxLines: 3,
                                          filled: true,
                                          labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                      ),
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_20),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                        child: TMTTextWidget(title: "Upload Product Images", style: TMTFontStyles.textTeen(
                          fontSize: TMTFontSize.sp_18,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w700,
                        ),),
                      ),
                      VerticalSpacing(HeightDimension.h_20),
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                        child: _addProductScreenController.mainImage != null ?
                        TMTRoundedCornersContainer(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 2,
                                blurRadius: 3,
                                offset: const Offset(0, 2), // changes position of shadow
                              ),
                            ],
                            borderRadius: const BorderRadius.all(Radius.circular(10)),
                            bgColor: AppColor.neutral_100,
                            height: HeightDimension.h_85,
                            width: HeightDimension.h_90,
                            child: Stack(
                              children: [
                                Positioned(
                                  top: 0,
                                  bottom: 0,
                                  right: 0,
                                  left: 0,
                                  child: Column(
                                    children: [
                                      const Spacer(),
                                      Container(
                                          height: HeightDimension.h_55,
                                          width: HeightDimension.h_55,
                                          child: Image.file(_addProductScreenController.mainImage!, fit: BoxFit.cover,)),
                                      const Spacer(),
                                    ],
                                  ),
                                ),
                                Positioned(
                                  top: 5,
                                  right: 5,
                                  child: GestureDetector(
                                    onTap: (){
                                      setState(() {
                                        _addProductScreenController.mainImage = null;
                                      });
                                    },
                                    child: SizedBox(
                                      height: HeightDimension.h_10,
                                      width: HeightDimension.h_10,
                                      child: Image.asset(TMTImages.icErrorToastCancel, color: AppColor.neutral_800,),
                                    ),
                                  ),
                                ),
                              ],
                            )) : GestureDetector(
                          onTap: (){
                            _pickImage((file){
                              setState(() {
                                _addProductScreenController.mainImage = File(file.path);
                              });
                            });
                          },
                          child: TMTRoundedCornersContainer(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 2,
                                blurRadius: 3,
                                offset: const Offset(0, 2), // changes position of shadow
                              ),
                            ],
                            borderRadius: const BorderRadius.all(Radius.circular(10)),
                            bgColor: AppColor.neutral_100,
                            height: HeightDimension.h_100,
                              width: HeightDimension.h_100,
                              child: Column(
                                children: [
                                  const Spacer(),
                                  Container(
                                    height: HeightDimension.h_55,
                                      width: HeightDimension.h_55,
                                      child: Image.asset(TMTImages.icCameraPlaceholder)),
                                  const Spacer(),
                                  Container(
                                    padding: EdgeInsets.only(top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                    decoration: const BoxDecoration(
                                        color: AppColor.textColor,
                                        borderRadius: BorderRadius.only(bottomRight: Radius.circular(10), bottomLeft: Radius.circular(10))
                                    ),
                                    width: double.infinity,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        TMTTextWidget(title: "Main", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.neutral_100,
                                        ),)
                                      ],
                                    ),
                                  ),
                                ],
                              )),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                        child: Row(
                          children: [
                            _addProductScreenController.image2 != null ?
                            TMTRoundedCornersContainer(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.2),
                                    spreadRadius: 2,
                                    blurRadius: 3,
                                    offset: const Offset(0, 2), // changes position of shadow
                                  ),
                                ],
                                borderRadius: const BorderRadius.all(Radius.circular(10)),
                                bgColor: AppColor.neutral_100,
                                height: HeightDimension.h_85,
                                width: HeightDimension.h_90,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      top: 0,
                                      bottom: 0,
                                      right: 0,
                                      left: 0,
                                      child: Column(
                                        children: [
                                          const Spacer(),
                                          Container(
                                              height: HeightDimension.h_55,
                                              width: HeightDimension.h_55,
                                              child: Image.file(_addProductScreenController.image2!, fit: BoxFit.cover,)),
                                          const Spacer(),
                                        ],
                                      ),
                                    ),
                                    Positioned(
                                      top: 5,
                                      right: 5,
                                      child: GestureDetector(
                                        onTap: (){
                                          setState(() {
                                            _addProductScreenController.image2 = null;
                                          });
                                        },
                                        child: SizedBox(
                                          height: HeightDimension.h_10,
                                          width: HeightDimension.h_10,
                                          child: Image.asset(TMTImages.icErrorToastCancel, color: AppColor.neutral_800,),
                                        ),
                                      ),
                                    ),
                                  ],
                                )) :
                            GestureDetector(
                              onTap: (){
                               _pickImage((file){
                                 setState(() {
                                   _addProductScreenController.image2 = File(file.path);
                                 });
                               });
                              },
                              child: TMTRoundedCornersContainer(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.2),
                                      spreadRadius: 2,
                                      blurRadius: 3,
                                      offset: const Offset(0, 2), // changes position of shadow
                                    ),
                                  ],
                                  borderRadius: const BorderRadius.all(Radius.circular(10)),
                                  bgColor: AppColor.neutral_100,
                                  height: HeightDimension.h_85,
                                  width: HeightDimension.h_90,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        top: 0,
                                        bottom: 0,
                                        right: 0,
                                        left: 0,
                                        child: Column(
                                          children: [
                                            const Spacer(),
                                            Container(
                                                height: HeightDimension.h_45,
                                                width: HeightDimension.h_45,
                                                child: Image.asset(TMTImages.icCameraAdd)),
                                            const Spacer(),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            _addProductScreenController.image3 != null ?
                            TMTRoundedCornersContainer(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.2),
                                    spreadRadius: 2,
                                    blurRadius: 3,
                                    offset: const Offset(0, 2), // changes position of shadow
                                  ),
                                ],
                                borderRadius: const BorderRadius.all(Radius.circular(10)),
                                bgColor: AppColor.neutral_100,
                                height: HeightDimension.h_85,
                                width: HeightDimension.h_90,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      top: 0,
                                      bottom: 0,
                                      right: 0,
                                      left: 0,
                                      child: Column(
                                        children: [
                                          const Spacer(),
                                          Container(
                                              height: HeightDimension.h_55,
                                              width: HeightDimension.h_55,
                                              child: Image.file(_addProductScreenController.image3!, fit: BoxFit.cover,)),
                                          const Spacer(),
                                        ],
                                      ),
                                    ),
                                    Positioned(
                                      top: 5,
                                      right: 5,
                                      child: GestureDetector(
                                        onTap: (){
                                          setState(() {
                                            _addProductScreenController.image3 = null;
                                          });
                                        },
                                        child: SizedBox(
                                          height: HeightDimension.h_10,
                                          width: HeightDimension.h_10,
                                          child: Image.asset(TMTImages.icErrorToastCancel, color: AppColor.neutral_800,),
                                        ),
                                      ),
                                    ),
                                  ],
                                )) :
                            GestureDetector(
                              onTap: (){
                                _pickImage((file){
                                  setState(() {
                                    _addProductScreenController.image3 = File(file.path);
                                  });
                                });
                              },
                              child: TMTRoundedCornersContainer(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.2),
                                      spreadRadius: 2,
                                      blurRadius: 3,
                                      offset: const Offset(0, 2), // changes position of shadow
                                    ),
                                  ],
                                  borderRadius: const BorderRadius.all(Radius.circular(10)),
                                  bgColor: AppColor.neutral_100,
                                  height: HeightDimension.h_85,
                                  width: HeightDimension.h_90,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        top: 0,
                                        bottom: 0,
                                        right: 0,
                                        left: 0,
                                        child: Column(
                                          children: [
                                            const Spacer(),
                                            Container(
                                                height: HeightDimension.h_45,
                                                width: HeightDimension.h_45,
                                                child: Image.asset(TMTImages.icCameraAdd)),
                                            const Spacer(),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            _addProductScreenController.image4 != null ?
                            TMTRoundedCornersContainer(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.2),
                                    spreadRadius: 2,
                                    blurRadius: 3,
                                    offset: const Offset(0, 2), // changes position of shadow
                                  ),
                                ],
                                borderRadius: const BorderRadius.all(Radius.circular(10)),
                                bgColor: AppColor.neutral_100,
                                height: HeightDimension.h_85,
                                width: HeightDimension.h_90,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      top: 0,
                                      bottom: 0,
                                      right: 0,
                                      left: 0,
                                      child: Column(
                                        children: [
                                          const Spacer(),
                                          Container(
                                              height: HeightDimension.h_55,
                                              width: HeightDimension.h_55,
                                              child: Image.file(_addProductScreenController.image4!, fit: BoxFit.cover,)),
                                          const Spacer(),
                                        ],
                                      ),
                                    ),
                                    Positioned(
                                      top: 5,
                                      right: 5,
                                      child: GestureDetector(
                                        onTap: (){
                                          setState(() {
                                            _addProductScreenController.image4 = null;
                                          });
                                        },
                                        child: SizedBox(
                                          height: HeightDimension.h_10,
                                          width: HeightDimension.h_10,
                                          child: Image.asset(TMTImages.icErrorToastCancel, color: AppColor.neutral_800,),
                                        ),
                                      ),
                                    ),
                                  ],
                                )) :
                            GestureDetector(
                              onTap: (){
                                _pickImage((file){
                                  setState(() {
                                    _addProductScreenController.image4 = File(file.path);
                                  });
                                });
                              },
                                  child: TMTRoundedCornersContainer(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.2),
                                      spreadRadius: 2,
                                      blurRadius: 3,
                                      offset: const Offset(0, 2), // changes position of shadow
                                    ),
                                  ],
                                  borderRadius: const BorderRadius.all(Radius.circular(10)),
                                  bgColor: AppColor.neutral_100,
                                  height: HeightDimension.h_85,
                                  width: HeightDimension.h_90,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        top: 0,
                                        bottom: 0,
                                        right: 0,
                                        left: 0,
                                        child: Column(
                                          children: [
                                            const Spacer(),
                                            Container(
                                                height: HeightDimension.h_45,
                                                width: HeightDimension.h_45,
                                                child: Image.asset(TMTImages.icCameraAdd)),
                                            const Spacer(),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )),
                                ),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_20),
                      Padding(
                        padding: EdgeInsets.only(
                            top: HeightDimension.h_10,
                            bottom: HeightDimension.h_10,
                            left: WidthDimension.w_15,
                            right: WidthDimension.w_15),
                        child: TMTTextButton(
                          onTap: (){
                            if (_formKey.currentState!.validate()) {
                              if (_addProductScreenController.attributeData.where((element) => element.selectedOption.isNotEmpty).toList().isEmpty) {
                                TMTToast.showErrorToast(context, "Please select attribute value.", title: "Alert");
                                return;
                              }
                              if (_addProductScreenController.mainImage == null) {
                                TMTToast.showErrorToast(context, "Please add product main image.", title: "Alert");
                                return;
                              }

                              if (args != null) {
                                Get.toNamed(AppRoutes.addProductShipmentScreen, arguments: args);
                              } else {
                                Get.toNamed(AppRoutes.addProductShipmentScreen);
                              }
                            }
                            TMTUtilities.closeKeyboard(context);
                          },
                          buttonTitle: "NEXT",
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          );
        }
      ),
    );
  }

  /// pick image from camera or gallery
 _pickImage (Function(PickedFile file) callback) {
    showDialog(
      context: context,
      builder: (c) => SimpleDialog(
        contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, top: HeightDimension.h_8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        titlePadding: EdgeInsets.only(top: HeightDimension.h_10, left: WidthDimension.w_20, right: WidthDimension.w_20),
        title: const Text('Select Image'),
        children: <Widget>[
          SimpleDialogOption(
            onPressed: () async {
              Navigator.pop(context);
              XFile? pickedFile = await TMTMediaPicker(context).pickImageFromCamera(imageQuality: 80);
              if (pickedFile != null) {
                var v = await TMTUtilities.isFileBiggerThan1MB(pickedFile);
                if (v) {
                  if (!mounted) return;
                  TMTToast.showErrorToast(context, "Image size must be less than 2MB.");
                  return;
                }
                _cropImage(pickedFile, callback);
              }
            },
            child: const Text('Camera'),
          ),
          SimpleDialogOption(
            onPressed: () async {
              Navigator.pop(context);
              XFile? pickedFile = await TMTMediaPicker(context).pickImageFromGallery(imageQuality: 80);
              if (pickedFile != null) {
                var v = await TMTUtilities.isFileBiggerThan1MB(pickedFile);
                if (v) {
                  if (!mounted) return;
                  TMTToast.showErrorToast(context, "Image size must be less than 2MB.");
                  return;
                }
                _cropImage(pickedFile, callback);
              }
            },
            child: const Text('Gallery'),
          ),
        ],
      ),
    );
  }

  /// Crop image to 4:3 aspect ratio
  _cropImage(XFile file, Function(PickedFile file) callback) async {
    CroppedFile? croppedFile = await ImageCropper().cropImage(
      sourcePath: file.path,
      aspectRatioPresets: [
        CropAspectRatioPreset.original,
        CropAspectRatioPreset.ratio4x3, // 4:3 aspect ratio
      ],
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Crop Image',
          toolbarColor: AppColor.primaryBG,
          toolbarWidgetColor: Colors.white,
          statusBarColor: AppColor.primaryBG,
          backgroundColor: Colors.white,),
        IOSUiSettings(
          title: 'Crop Image',
          doneButtonTitle: 'Done',
          cancelButtonTitle: 'Cancel',
          aspectRatioLockEnabled: true,
          aspectRatioPickerButtonHidden: true,
        ),
      ],
    );

    if (croppedFile != null) {
      callback.call(PickedFile(croppedFile.path));
    }
  }
}