import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:take_my_tack/data/model/response/get_seller_product_details_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/product/add_product_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_dropdown.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<StatefulWidget> createState() => _AddProductScreenState();

}

class _AddProductScreenState extends State<AddProductScreen> {

  final _formKey = GlobalKey<FormState>();

  final AddProductScreenController _addProductScreenController =
  Get.put(AddProductScreenController());

  SellerProductData? editProductData = Get.arguments;

  @override
  void initState() {
    _addProductScreenController.getAllCategories(context, (){
      _addProductScreenController.getDefaultAttributes(context, callback: (){
        if (editProductData != null) {
          setDataInController(editProductData!);
        }
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GetBuilder<AddProductScreenController>(
          id: GetControllerBuilders.addProductScreenController,
          init: _addProductScreenController,
          builder: (controller) {
          return Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_6),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: editProductData == null ? "Add Product Details" : "Edit Product Details",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                          left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_20
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.all(Radius.circular(25)),
                              bgColor: AppColor.green,
                              height: HeightDimension.h_37,
                              width: HeightDimension.h_37,
                              child: Center(
                                child: TMTTextWidget(title: "1", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_100,
                                  fontWeight: FontWeight.w700,
                                ),),
                              ),
                            ),
                            Container(
                              height: HeightDimension.h_37,
                              width: WidthDimension.w_60,
                              child: const Center(
                                child: DottedLine(),
                              ),
                            ),
                            TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.all(Radius.circular(25)),
                              bgColor: AppColor.neutral_100,
                              borderColor: AppColor.textColor,
                              height: HeightDimension.h_37,
                              width: HeightDimension.h_37,
                              child: Center(
                                child: TMTTextWidget(title: "2", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w700,
                                ),),
                              ),
                            ),
                            Container(
                              height: HeightDimension.h_37,
                              width: WidthDimension.w_60,
                              child: const Center(
                                child: DottedLine(),
                              ),
                            ),
                            TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.all(Radius.circular(25)),
                              bgColor: AppColor.neutral_100,
                              borderColor: AppColor.textColor,
                              height: HeightDimension.h_37,
                              width: HeightDimension.h_37,
                              child: Center(
                                child: TMTTextWidget(title: "3", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w700,
                                ),),
                              ),
                            ),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_20),
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                        child: TMTTextWidget(title: "Select Category", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_14,
                          color: AppColor.textColor,
                          fontWeight: FontWeight.w500,
                        ),),
                      ),
                      VerticalSpacing(HeightDimension.h_10),
                      GestureDetector(
                        onTap: () async {
                          await Get.toNamed(AppRoutes.selectCategoryScreen);
                          setState(() {

                          });
                        },
                        child: TMTRoundedCornersContainer(
                          borderRadius: BorderRadius.circular(15),
                          borderWidth: 0.5,
                          borderColor: AppColor.borderColor,
                          padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                          margin: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(title: _getSelectedCategoriesTitles(), style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Form(
                        key: _formKey,
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_10,
                              right: WidthDimension.w_10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TMTTextWidget(title: "Product Name", style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w500,
                                    ),),
                                  ),
                                  VerticalSpacing(HeightDimension.h_8),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TextFormField(
                                      autovalidateMode: AutovalidateMode.onUserInteraction,
                                      controller: _addProductScreenController.productNameTextController,
                                      validator: Validator.productNameValidate,
                                      keyboardType: TextInputType.text,
                                      textCapitalization: TextCapitalization.sentences,
                                      onChanged: (v){
                                        setState(() {

                                        });
                                      },
                                      onFieldSubmitted: (v) {
                                        _addProductScreenController.productDescriptionNode.requestFocus();
                                      },
                                      decoration: InputDecoration(
                                          fillColor: AppColor.neutral_100,
                                          focusedErrorBorder:  CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          errorBorder:  CustomOutlineInputBorder(
                                              borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          enabledBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          floatingLabelBehavior: FloatingLabelBehavior.auto,
                                          focusedBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 12),
                                          border: CustomOutlineInputBorder(
                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
                                          ),
                                          errorMaxLines: 3,
                                          filled: true,
                                          labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                      ),
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TMTTextWidget(title: "Product Description", style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w500,
                                    ),),
                                  ),
                                  VerticalSpacing(HeightDimension.h_8),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TextFormField(
                                      textCapitalization: TextCapitalization.sentences,
                                      keyboardType: TextInputType.text,
                                      autovalidateMode: AutovalidateMode.onUserInteraction,
                                      maxLines: 5,
                                      controller: _addProductScreenController.productDescriptionTextController,
                                      validator: Validator.productDescriptionValidate,
                                      onChanged: (v){
                                        setState(() {

                                        });
                                      },
                                      focusNode: _addProductScreenController.productDescriptionNode,
                                      onFieldSubmitted: (v) {
                                        _addProductScreenController.brandNameNode.requestFocus();
                                      },
                                      decoration: InputDecoration(
                                          fillColor: AppColor.neutral_100,
                                          focusedErrorBorder:  CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          errorBorder:  CustomOutlineInputBorder(
                                              borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          enabledBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          floatingLabelBehavior: FloatingLabelBehavior.auto,
                                          focusedBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 12),
                                          border: CustomOutlineInputBorder(
                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
                                          ),
                                          errorMaxLines: 3,
                                          filled: true,
                                          labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                      ),
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TMTTextWidget(title: "Brand Name", style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w500,
                                    ),),
                                  ),
                                  VerticalSpacing(HeightDimension.h_8),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TextFormField(
                                      autovalidateMode: AutovalidateMode.onUserInteraction,
                                      controller: _addProductScreenController.brandNameTextController,
                                      validator: Validator.brandNameValidate,
                                      keyboardType: TextInputType.text,
                                      textCapitalization: TextCapitalization.sentences,
                                      onChanged: (v){
                                        setState(() {

                                        });
                                      },
                                      focusNode: _addProductScreenController.brandNameNode,
                                      onFieldSubmitted: (v) {
                                       TMTUtilities.closeKeyboard(context);
                                      },
                                      decoration: InputDecoration(
                                          fillColor: AppColor.neutral_100,
                                          focusedErrorBorder:  CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          errorBorder:  CustomOutlineInputBorder(
                                              borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          enabledBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          floatingLabelBehavior: FloatingLabelBehavior.auto,
                                          focusedBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                          contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 12),
                                          border: CustomOutlineInputBorder(
                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
                                          ),
                                          errorMaxLines: 3,
                                          filled: true,
                                          labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                      ),
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: TMTTextWidget(title: "Product Condition", style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w500,
                                    ),),
                                  ),
                                  VerticalSpacing(HeightDimension.h_8),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: CustomDropdown.getCustomDropdown(context, _addProductScreenController.productCondition == -1 ? "Product Condition" : _addProductScreenController.productCondition == 0 ? "NEW" : _addProductScreenController.productCondition == 1 ? "LIKE NEW" : _addProductScreenController.productCondition == 2 ? "GOOD" : "USED", ["NEW", "LIKE NEW", "GOOD", "USED"], (value){ if (value == null) {
                                      if (_addProductScreenController.productCondition == -1) {
                                        return 'Please select product condition.';
                                      }
                                    }
                                    return null;},
                                            (v){
                                      setState(() {
                                        if (v == "NEW") {
                                          _addProductScreenController.productCondition = 0;
                                        } else if (v == "LIKE NEW") {
                                          _addProductScreenController.productCondition = 1;
                                        } else if (v == "GOOD") {
                                          _addProductScreenController.productCondition = 2;
                                        } else if (v == "USED") {
                                          _addProductScreenController.productCondition = 3;
                                        } else {
                                          _addProductScreenController.productCondition = -1;
                                        }
                                      });
                                    }),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.only(
                            top: HeightDimension.h_10,
                            bottom: HeightDimension.h_10,
                            left: WidthDimension.w_18,
                            right: WidthDimension.w_15),
                        child: TMTTextButton(
                          onTap: (){
                            if (_formKey.currentState!.validate()) {
                              if (_addProductScreenController.selectedCategory == -1 && _addProductScreenController.selectedSubCategory == -1 && _addProductScreenController.selectedChildCategory == -1) {
                                TMTToast.showErrorToast(context, "Please select category.", title: "Alert");
                                return;
                              }
                              if (_addProductScreenController.productCondition == -1) {
                                TMTToast.showErrorToast(context, "Please select condition.", title: "Alert");
                                return;
                              }
                              if (editProductData != null) {
                                Get.toNamed(AppRoutes.addProductAttributesScreen, arguments: [_addProductScreenController.sellerProductData!.id, _addProductScreenController.sellerProductData!.productVariations![_addProductScreenController.selectedVariation].id]);
                              } else {
                                Get.toNamed(AppRoutes.addProductAttributesScreen);
                              }
                            }
                            TMTUtilities.closeKeyboard(context);
                          },
                          buttonTitle: "NEXT",
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          );
        }
      ),
    );
  }

  /// get categories titles
  _getSelectedCategoriesTitles() {
    try {
      return "${_addProductScreenController.selectedCategory == -1 ? "Select" : _addProductScreenController.categories[_addProductScreenController.selectedCategory].name}  >>  ${_addProductScreenController.selectedSubCategory == -1 ? "Select" : _addProductScreenController.subCategories[_addProductScreenController.selectedSubCategory].name}  >>  ${_addProductScreenController.selectedChildCategory == -1 ? "Select" : _addProductScreenController.childCategories[_addProductScreenController.selectedChildCategory].name}";
    } catch (e) {
      return "Select >> Select >> Select";
    }
  }

  /// set data in controller if came from detail screen
  void setDataInController(SellerProductData editProductData) {
    _setCategoriesIds(editProductData.categoryId);
    _addProductScreenController.selectedChildCategory;
    _addProductScreenController.productNameTextController.text = editProductData.title ?? "";
    _addProductScreenController.productDescriptionTextController.text = editProductData.description ?? "";
    _addProductScreenController.brandNameTextController.text = editProductData.brand?.name ?? "";
    _addProductScreenController.productCondition = _getProductConditionId((editProductData.productVariations)) ;
    _setAttribute(_addProductScreenController.selectedVariation);
    _addProductScreenController.priceTextController.text = editProductData.productVariations?.first.salePrice.toString() ?? "";
    _setupImages(editProductData.productVariations?[_addProductScreenController.selectedVariation].productImages);
    _addProductScreenController.weightTextController.text = editProductData.productVariations?.first.weightInPound.toString() ?? "";
    _addProductScreenController.processingTime = _getProcessingTime(editProductData.processingTime);
    _addProductScreenController.shipmentType = "Shipping by weight";
    _addProductScreenController.lengthTextController.text = editProductData.productVariations?[_addProductScreenController.selectedVariation].lengthInCentimeter.toString() ?? "40cm";
    _addProductScreenController.widthTextController.text = editProductData.productVariations?[_addProductScreenController.selectedVariation].widthInCentimeter.toString() ?? "32cm";
    _addProductScreenController.heightTextController.text = editProductData.productVariations?[_addProductScreenController.selectedVariation].heightInCentimeter.toString() ?? "5cm";
    _addProductScreenController.update([GetControllerBuilders.addProductScreenController]);
  }

  int _getProductConditionId(List<ProductVariation>? productVariations) {
    try {
      var condition = productVariations?.first.condition ?? "";
      return condition == "NEW" ? 0  : condition == "LIKE NEW" ? 1 : condition == "GOOD" ? 2  : 3;
    } catch (e) {
      return 0;
    }
  }

  /// set categories by id
  void _setCategoriesIds(int? categoryId) {
    try {
      if (categoryId != null) {
        for (int i=0; i<(_addProductScreenController.categories.length); i++) {
          if ((_addProductScreenController.categories[i].id == categoryId)) {
            _addProductScreenController.selectedCategory = i;
            _addProductScreenController.selectedSubCategory = 0;
            _addProductScreenController.selectedChildCategory = 0;
            return;
          }
          for (int j=0; j<(_addProductScreenController.subCategories.length); j++) {
            if ((_addProductScreenController.subCategories[j].id == categoryId)) {
              _addProductScreenController.selectedCategory = i;
              _addProductScreenController.selectedSubCategory = j;
              _addProductScreenController.selectedChildCategory = 0;
              return;
            }
            for (int k=0; k<(_addProductScreenController.childCategories.length); k++) {
              if ((_addProductScreenController.childCategories[k].id == categoryId)) {
                _addProductScreenController.selectedCategory = i;
                _addProductScreenController.selectedSubCategory = j;
                _addProductScreenController.selectedChildCategory = k;
                return;
              }
            }
          }
        }
      }
    } catch (e) {
      print(e);
    }
  }

  int _getProcessingTime(String? processingTime) {
    if (processingTime == null) {
      return -1;
    } else {
      try {
        for (int i=0; i<(_addProductScreenController.processingTimesList.length); i++) {
          if (_addProductScreenController.processingTimesList[i].name == processingTime) {
            return i;
          }
        }
      } catch (e) {
        return -1;
      }
    }
    return -1;
  }

  /// set attributes
  void _setAttribute(int selectedVariation) {
    if (_addProductScreenController.colors.isNotEmpty) {
      if(_addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Color") != null){
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Color")?.isSelected = true;
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Color")?.selectedOption = _addProductScreenController.selectedColor;
      }
    }
    if (_addProductScreenController.sizes.isNotEmpty) {
      if(_addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Size") != null){
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Size")?.isSelected = true;
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Size")?.selectedOption = _addProductScreenController.selectedSize;
      }
    }
    if (_addProductScreenController.material.isNotEmpty) {
      if(_addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Material") != null){
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Material")?.isSelected = true;
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Material")?.selectedOption = _addProductScreenController.selectedMaterial;
      }
    }
    if (_addProductScreenController.tackType.isNotEmpty) {
      if(_addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "TackType") != null){
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "TackType")?.isSelected = true;
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "TackType")?.selectedOption = _addProductScreenController.selectedTackType;
      }
    }
    if (_addProductScreenController.filling.isNotEmpty) {
      if(_addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Filling") != null){
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Filling")?.isSelected = true;
        _addProductScreenController.attributeData.firstWhereOrNull((element) => element.attributeName == "Filling")?.selectedOption = _addProductScreenController.selectedFilling;
      }
    }
  }

  /// set images in controller
  Future<void> _setupImages(List<ProductImage>? productImages) async {
    for (int i=0; i<(productImages?.length ?? 0); i++) {
      if (i == 0) {
        _addProductScreenController.mainImage = await _convertUrlToFile(productImages?[i], i);
      }
      if (i == 1) {
        _addProductScreenController.image2 = await _convertUrlToFile(productImages?[i], i);
      }
      if (i == 2) {
        _addProductScreenController.image3 = await _convertUrlToFile(productImages?[i], i);
      }
      if (i == 3) {
        _addProductScreenController.image4 = await _convertUrlToFile(productImages?[i], i);
      }
    }
  }

  /// convert URL into File
  Future<File?> _convertUrlToFile(ProductImage? productImag, int index) async {
      Dio dio = Dio();
      try {
        final response = await dio.get(productImag?.imageName ?? "",
            options: Options(responseType: ResponseType.bytes));
        if (response.statusCode == 200) {
          final bytes = response.data as List<int>;
          final tempDir = await getTemporaryDirectory();
          final file = File('${tempDir.path}/temp_image_$index.png');
          await file.writeAsBytes(bytes);
          return file;
        } else {
          return null;
        }
      } catch (e) {
        print('Error downloading file: $e');
        return null;
      }
  }
}