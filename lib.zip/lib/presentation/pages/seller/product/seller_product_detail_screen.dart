import 'package:app_settings/app_settings.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/model/response/get_seller_product_details_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/product/add_product_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_readmore_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class SellerProductDetailScreen extends StatefulWidget {
  const SellerProductDetailScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SellerProductDetailScreenState();
}

class _SellerProductDetailScreenState extends State<SellerProductDetailScreen> {

  final AddProductScreenController _addProductScreenController =
  Get.find<AddProductScreenController>();
  final CarouselController _carouselController = CarouselController();

  List args = Get.arguments ?? [];

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      _callApi();
    },);
    super.initState();
  }

  /// call apis
  _callApi () {
    if (args.isEmpty) {
      return;
    }
    _addProductScreenController.getProductDetailById(context, args[0]);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AddProductScreenController>(
        id: GetControllerBuilders.sellerProductDetailController,
        init: _addProductScreenController,
        builder: (controller) {
        return AnnotatedRegion(
          value: SystemUiOverlayStyle.dark,
          child: Scaffold(
            body: Column(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height/9.3,
                  decoration: BoxDecoration(boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      spreadRadius: 2,
                      blurRadius: 3,
                      offset: const Offset(0, 3), // changes position of shadow
                    ),
                  ], color: AppColor.neutral_100),
                  child: Padding(
                    padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Row(
                        children: [
                          InkWell(
                            onTap: () {
                              Get.back();
                            },
                            child: Row(
                              children: [
                                HorizontalSpacing(WidthDimension.w_6),
                                SizedBox(
                                  width: WidthDimension.w_40,
                                  height: HeightDimension.h_30,
                                  child: Center(
                                    child: Image.asset(
                                      TMTImages.icBack,
                                      color: AppColor.neutral_800,
                                      fit: BoxFit.contain,
                                      scale: 3.4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          TMTTextWidget(
                            title: "Product Detail",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_20),
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Visibility(
                          visible: args[1] == "PENDING",
                          child: Padding(
                            padding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_15, right: WidthDimension.w_15),
                            child: Text.rich(
                                TextSpan(
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_12,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w800,
                                  ),
                                  text: 'Note: ',
                                  children: [
                                    TextSpan(
                                      text: 'Once the product has been approved, you will be able to edit and promote it. Remember to submit your documents to be verified.',
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                )),
                          ),
                        ),
                        Visibility(
                          visible: args[1] == "REJECTED",
                          child: Padding(
                            padding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_15, right: WidthDimension.w_15),
                            child: Text.rich(
                                TextSpan(
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_12,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w800,
                                  ),
                                  text: 'Request Rejected: ',
                                  children: [
                                    TextSpan(
                                      text: _addProductScreenController.sellerProductData?.reason ?? "",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                )),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        CarouselSlider(
                          items: getBannersWidgetList(1, _addProductScreenController.bannersTop),
                          carouselController: _carouselController,
                          options: CarouselOptions(
                              autoPlayAnimationDuration:
                              const Duration(milliseconds: 1000),
                              autoPlay: true,
                              height: HeightDimension.h_180,
                              viewportFraction: 1.0,
                              enlargeCenterPage: false,
                              onPageChanged: (index, reason) {
                                _addProductScreenController.isCurrentIndex = index;
                                _addProductScreenController.update(
                                    [GetControllerBuilders.sellerProductDetailController]);
                              }),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: _addProductScreenController.bannersTop
                              .asMap()
                              .entries
                              .map((entry) {
                            return Container(
                              width: 14.0,
                              height: 2.0,
                              margin: const EdgeInsets.only(right: 2, left: 2),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color:
                                      _addProductScreenController.isCurrentIndex ==
                                          entry.key
                                          ? AppColor.primary
                                          : AppColor
                                          .sliderIndicatorDisabledColor,
                                      width: 0.5),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(TMTRadius.r_20)),
                                  color: _addProductScreenController.isCurrentIndex ==
                                      entry.key
                                      ? AppColor.primary
                                      : AppColor.sliderIndicatorDisabledColor),
                            );
                          }).toList(),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(title: _addProductScreenController.sellerProductData?.title ?? "", style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_16,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ), textAlign: TextAlign.center,),
                        ),
                        VerticalSpacing(HeightDimension.h_8),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(
                            title: (_addProductScreenController.sellerProductData?.productVariations?.isNotEmpty ?? false) ? "£${_addProductScreenController.sellerProductData?.productVariations?.first.salePrice.toStringAsFixed(2)}" : "",
                            style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.primaryBG,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_10),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: ReadMoreText(
                            _addProductScreenController.sellerProductData?.description ?? "",
                            trimLines: 2,
                            colorClickableText: AppColor.neutral_800,
                            trimMode: TrimMode.Line,
                            trimCollapsedText: 'READ MORE',
                            trimExpandedText: '',
                            style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w400,
                            ),
                            lessStyle: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w600,
                            ),
                            moreStyle: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_14,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w600,
                                textDecoration: TextDecoration.underline),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_10),
                        Visibility(
                          visible: _addProductScreenController.sizes.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(title: "Size", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w600,
                                )),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                height: HeightDimension.h_30,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: ListView.builder(itemBuilder: (context, index){
                                  return GestureDetector(
                                    onTap: (){
                                      for (int i=0; i<(_addProductScreenController.sellerProductData?.productVariations?.length ?? 0); i++) {
                                       if (_addProductScreenController.sellerProductData?.productVariations?[i].id == _addProductScreenController.sizes[index].variationId) {
                                         setState(() {
                                           _addProductScreenController.selectedVariation = i;
                                         });
                                       }
                                      }
                                      _addProductScreenController.selectedSize = _addProductScreenController.sizes[index].value ?? "";
                                    },
                                    child: Container(
                                      padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4, right: WidthDimension.w_4),
                                      decoration: BoxDecoration(
                                          color: _addProductScreenController.selectedSize == (_addProductScreenController.sizes[index].value ?? "")
                                              ? AppColor.primaryBG
                                              : AppColor.neutral_100,
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_30)),
                                          border: Border.all(
                                              color: _addProductScreenController.selectedSize == (_addProductScreenController.sizes[index].value ?? "")
                                                  ? AppColor.primaryBG
                                                  : AppColor.textColor,
                                              width: 1)),
                                      child: Center(
                                        child: TMTTextWidget(
                                          title: _addProductScreenController.sizes[index].value ?? "M",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_10,
                                            color: _addProductScreenController.selectedSize == (_addProductScreenController.sizes[index].value ?? "")
                                                ? AppColor.neutral_100
                                                : AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: _addProductScreenController.sizes.length,),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: _addProductScreenController.colors.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(title: "Color", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w600,
                                )),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                  height: HeightDimension.h_30,
                                  padding: EdgeInsets.only(
                                      left: WidthDimension.w_15, right: WidthDimension.w_15),
                                  child: ListView.builder(
                                    itemBuilder: (context, index){
                                      return GestureDetector(
                                        onTap: (){
                                          for (int i=0; i<(_addProductScreenController.sellerProductData?.productVariations?.length ?? 0); i++) {
                                            if (_addProductScreenController.sellerProductData?.productVariations?[i].id == _addProductScreenController.colors[index].variationId) {
                                              setState(() {
                                                _addProductScreenController.selectedVariation = i;
                                              });
                                            }
                                          }
                                          _addProductScreenController.selectedColor = _addProductScreenController.colors[index].value ?? "";
                                        },
                                        child: _addProductScreenController.selectedColor == (_addProductScreenController.colors[index].value ?? "") ?
                                        Container(
                                          padding: const EdgeInsets.all(2),
                                          margin: EdgeInsets.only(
                                              left: WidthDimension.w_4, right: WidthDimension.w_4),
                                          decoration: BoxDecoration(
                                              borderRadius: const BorderRadius.all(
                                                  Radius.circular(TMTRadius.r_30)),
                                              border: Border.all(
                                                  color: AppColor.primaryBG,
                                                  width: 1)),
                                          child: Container(
                                              height: HeightDimension.h_28,
                                              width: HeightDimension.h_25,
                                              decoration: BoxDecoration(
                                                  color:
                                                  _addProductScreenController.colors.isNotEmpty ? _getColorByName(_addProductScreenController.colors[index]) : Colors.black,
                                                  borderRadius: const BorderRadius.all(
                                                      Radius.circular(TMTRadius.r_30)),
                                                  border: Border.all(
                                                      color: _addProductScreenController.colors.isNotEmpty ? _getColorByName(_addProductScreenController.colors[index]) : Colors.grey,
                                                      width: 1))
                                          ),
                                        ) :
                                        Container(
                                            height: HeightDimension.h_28,
                                            width: HeightDimension.h_30,
                                            margin: EdgeInsets.only(
                                                left: WidthDimension.w_4, right: WidthDimension.w_4),
                                            decoration: BoxDecoration(
                                                color:
                                                _getColorByName(_addProductScreenController.colors[index]),
                                                borderRadius: const BorderRadius.all(
                                                    Radius.circular(TMTRadius.r_30)),
                                                border: Border.all(
                                                    color: _getColorByName(_addProductScreenController.colors[index]),
                                                    width: 1))
                                        ),
                                      );
                                    }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: _addProductScreenController.colors.length,)
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: _addProductScreenController.material.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(title: "Material", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w600,
                                )),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                height: HeightDimension.h_30,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: ListView.builder(itemBuilder: (context, index){
                                  return GestureDetector(
                                    onTap: (){
                                      for (int i=0; i<(_addProductScreenController.sellerProductData?.productVariations?.length ?? 0); i++) {
                                        if (_addProductScreenController.sellerProductData?.productVariations?[i].id == _addProductScreenController.material[index].variationId) {
                                          setState(() {
                                            _addProductScreenController.selectedVariation = i;
                                          });
                                        }
                                      }
                                      _addProductScreenController.selectedMaterial = _addProductScreenController.material[index].value ?? "";
                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4, right: WidthDimension.w_4),
                                      padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      decoration: BoxDecoration(
                                          color: _addProductScreenController.selectedMaterial == (_addProductScreenController.material[index].value ?? "")
                                              ? AppColor.primaryBG
                                              : AppColor.neutral_100,
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_30)),
                                          border: Border.all(
                                              color: _addProductScreenController.selectedMaterial == (_addProductScreenController.material[index].value ?? "")
                                                  ? AppColor.primaryBG
                                                  : AppColor.textColor,
                                              width: 1)),
                                      child: Center(
                                        child: TMTTextWidget(
                                          title: _addProductScreenController.material[index].value ?? "",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_10,
                                            color: _addProductScreenController.selectedMaterial == (_addProductScreenController.material[index].value ?? "")
                                                ? AppColor.neutral_100
                                                : AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: _addProductScreenController.material.length,),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: _addProductScreenController.tackType.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(title: "Tack Type", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w600,
                                )),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                height: HeightDimension.h_30,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: ListView.builder(itemBuilder: (context, index){
                                  return GestureDetector(
                                    onTap: (){
                                      for (int i=0; i<(_addProductScreenController.sellerProductData?.productVariations?.length ?? 0); i++) {
                                        if (_addProductScreenController.sellerProductData?.productVariations?[i].id == _addProductScreenController.tackType[index].variationId) {
                                          setState(() {
                                            _addProductScreenController.selectedVariation = i;
                                          });
                                        }
                                      }
                                      _addProductScreenController.selectedTackType = _addProductScreenController.tackType[index].value ?? "";
                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4, right: WidthDimension.w_4),
                                      padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      decoration: BoxDecoration(
                                          color: _addProductScreenController.selectedTackType == (_addProductScreenController.tackType[index].value ?? "")
                                              ? AppColor.primaryBG
                                              : AppColor.neutral_100,
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_30)),
                                          border: Border.all(
                                              color: _addProductScreenController.selectedTackType == (_addProductScreenController.tackType[index].value ?? "")
                                                  ? AppColor.primaryBG
                                                  : AppColor.textColor,
                                              width: 1)),
                                      child: Center(
                                        child: TMTTextWidget(
                                          title: _addProductScreenController.tackType[index].value ?? "",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_10,
                                            color: _addProductScreenController.selectedTackType == (_addProductScreenController.tackType[index].value ?? "")
                                                ? AppColor.neutral_100
                                                : AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: _addProductScreenController.tackType.length,),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: _addProductScreenController.filling.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(title: "Filling", style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w600,
                                )),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                height: HeightDimension.h_30,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: ListView.builder(itemBuilder: (context, index){
                                  return GestureDetector(
                                    onTap: (){
                                      for (int i=0; i<(_addProductScreenController.sellerProductData?.productVariations?.length ?? 0); i++) {
                                        if (_addProductScreenController.sellerProductData?.productVariations?[i].id == _addProductScreenController.filling[index].variationId) {
                                          setState(() {
                                            _addProductScreenController.selectedVariation = i;
                                          });
                                        }
                                      }
                                      _addProductScreenController.selectedFilling = _addProductScreenController.filling[index].value ?? "";
                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4, right: WidthDimension.w_4),
                                      padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      decoration: BoxDecoration(
                                          color: _addProductScreenController.selectedFilling == (_addProductScreenController.filling[index].value ?? "")
                                              ? AppColor.primaryBG
                                              : AppColor.neutral_100,
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_30)),
                                          border: Border.all(
                                              color: _addProductScreenController.selectedFilling == (_addProductScreenController.filling[index].value ?? "")
                                                  ? AppColor.primaryBG
                                                  : AppColor.textColor,
                                              width: 1)),
                                      child: Center(
                                        child: TMTTextWidget(
                                          title: _addProductScreenController.filling[index].value ?? "",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_10,
                                            color: _addProductScreenController.selectedFilling == (_addProductScreenController.filling[index].value ?? "")
                                                ? AppColor.neutral_100
                                                : AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: _addProductScreenController.filling.length,),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(title: "Category", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_15,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w600,
                          )),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(title: _addProductScreenController.sellerProductData?.category?.name ?? "", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_15,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          )),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Container(
                          margin: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          width: double.infinity,
                          height: 2,
                          color: AppColor.dividerColor,
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(title: "Additional Details", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_15,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w600,
                          )),
                        ),
                        VerticalSpacing(HeightDimension.h_10),
                        Visibility(
                          visible: _addProductScreenController.sellerProductData?.productVariations?.isNotEmpty ?? false,
                          child: Padding(
                            padding: EdgeInsets.only(
                                left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TMTTextWidget(
                                  title: "Condition",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                TMTTextWidget(
                                  title: _addProductScreenController.sellerProductData?.productVariations?.first.condition.toString() ?? "",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Visibility(
                          visible: _addProductScreenController.sellerProductData?.productVariations?.isNotEmpty ?? false,
                          child: Padding(
                            padding: EdgeInsets.only(
                                left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TMTTextWidget(
                                  title: "Weight",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                TMTTextWidget(
                                  title: "${_addProductScreenController.sellerProductData?.productVariations?.first.weightInPound.toString() ?? ""} kg",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TMTTextWidget(
                                title: "Length",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              TMTTextWidget(
                                title: "${_addProductScreenController.sellerProductData?.productVariations?[_addProductScreenController.selectedVariation].lengthInCentimeter.toString() ?? ""} cm",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TMTTextWidget(
                                title: "Width",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              TMTTextWidget(
                                title: "${_addProductScreenController.sellerProductData?.productVariations?[_addProductScreenController.selectedVariation].widthInCentimeter.toString() ?? ""} cm",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TMTTextWidget(
                                title: "Height",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              TMTTextWidget(
                                title: "${_addProductScreenController.sellerProductData?.productVariations?[_addProductScreenController.selectedVariation].heightInCentimeter.toString() ?? ""} cm",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Container(
                          margin: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          width: double.infinity,
                          height: 2,
                          color: AppColor.dividerColor,
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TMTTextWidget(title: "Shipping available methods", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w500,
                              )),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Container(
                          margin: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          width: double.infinity,
                          height: 2,
                          color: AppColor.dividerColor,
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Column(
                          children: [
                            Visibility(
                              visible: _addProductScreenController.sellerProductData?.sellerStore?.isPickupFromStoreEnabled == 1,
                              child: Column(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                    child: Row(
                                      children: [
                                        TMTRoundedCornersContainer(
                                          height: HeightDimension.h_12,
                                          width: HeightDimension.h_12,
                                          bgColor: AppColor.primary,
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        TMTTextWidget(title: "Pickup", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                        ),)
                                      ],
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_8),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                              child: Row(
                                children: [
                                  TMTRoundedCornersContainer(
                                    height: HeightDimension.h_12,
                                    width: HeightDimension.h_12,
                                    bgColor: AppColor.primary,
                                  ),
                                  HorizontalSpacing(WidthDimension.w_10),
                                  TMTTextWidget(title: "Shipping by weight (in KGs)", style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_14,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),)
                                ],
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_8),
                            Padding(
                              padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                              child: Row(
                                children: [
                                  TMTRoundedCornersContainer(
                                    height: HeightDimension.h_12,
                                    width: HeightDimension.h_12,
                                    bgColor: AppColor.primary,
                                  ),
                                  HorizontalSpacing(WidthDimension.w_10),
                                  TMTTextWidget(title: "Ready to ship in ${_addProductScreenController.sellerProductData?.processingTime ?? "2-3 business days"}", style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_14,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),)
                                ],
                              ),
                            ),
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Container(
                          margin: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          width: double.infinity,
                          height: 2,
                          color: AppColor.dividerColor,
                        ),
                      ],
                    ),),
                ),
                Visibility(
                  visible: args[1] != "PENDING",
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: HeightDimension.h_10,
                        left: WidthDimension.w_15,
                        right: WidthDimension.w_15),
                    child: TMTTextButton(
                      textStyle: TMTFontStyles.textTeen(color: AppColor.primary, fontSize: TMTFontSize.sp_16, fontWeight: FontWeight.w600),
                      border: Border.all(color: AppColor.primary),
                      color: AppColor.neutral_100,
                      onTap: (){
                        Get.toNamed(AppRoutes.addProductScreen, arguments: _addProductScreenController.sellerProductData);
                      },
                      buttonTitle: "EDIT PRODUCT",
                    )
                  ),
                ),
                Padding(
                    padding: EdgeInsets.only(
                        top: HeightDimension.h_10,
                        left: WidthDimension.w_15,
                        right: WidthDimension.w_15),
                    child: TMTTextButton(
                      onTap: (){
                        _showConfirmationDialog();
                      },
                      buttonTitle: "DELETE PRODUCT",
                    )
                ),
                VerticalSpacing(HeightDimension.h_10),
              ],
            ),
          ),
        );
      }
    );
  }

  /*
   Method use to get banners widgets list.
   Parameter- List<String> banners.
   Return -> List<Widget>.
  */
  List<Widget> getBannersWidgetList(int typeId, List<String> banners) {
    List<Widget> bannersList = [];
    for (int i=0; i<banners.length; i++) {
      var element = banners[i];
      bannersList.add(Container(
        width: double.infinity,
        height: HeightDimension.h_120,
        child: TMTCachedImage.networkImage(
          element,
          fit: BoxFit.cover,
        ),
      ));
    }
    return bannersList;
  }

  /// get color by name
  Color _getColorByName(SellerProductAttributeMapping color) {
    switch (color.value) {
      case "Black": return Colors.black;
      case "Brown": return Colors.brown;
      case "Tan": return const Color(0xFFD2B48C);
      case "Navy": return const Color(0xFF000080);
      case "Green": return const Color(0xFF00FF00);
      case "White": return const Color(0xFFFFFFFF);
      case "Beige": return const Color(0xFFf5f5dc);
      case "Red": return const Color(0xFFFF0000);
      case "Blue": return Colors.blue;
      case "Yellow": return const Color(0xFFFFFF00);
      case "Orange": return const Color(0xFFFFA500);
      case "Pink": return const Color(0xFFffc0cb);
      case "Rose": return const Color(0xFFFF007F);
      case "Gold": return const Color(0xFFFFD700);
      case "Silver": return const Color(0xFFC0C0C0);
      case "Bronze": return const Color(0xFFCD7F32);
      default: return Colors.black;
    }
  }

  /// confirmation dialog
  void _showConfirmationDialog() {
    showDialog(context: context, builder: (c){
      return AlertDialog(
        contentPadding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_20, right: WidthDimension.w_20, bottom: HeightDimension.h_20),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_10))),
        content: TMTTextWidget(title: "Are you sure you want to delete this product?", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_16, fontWeight: FontWeight.w700, color: AppColor.neutral_800), textAlign: TextAlign.center,),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.green),
                ),
                child: TMTTextWidget(title: 'No' , style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.of(context).pop(false); // Return false when cancelled
                },
              ),
              HorizontalSpacing(WidthDimension.w_8),
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.primaryBG),
                ),
                child: TMTTextWidget(title: 'Yes', style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.of(context).pop(false);
                  _addProductScreenController.postDeleteOrder(context, _addProductScreenController.sellerProductData?.productVariations?[_addProductScreenController.selectedVariation].id ?? 0, (){
                    Get.back();
                  });
                },
              ),
              HorizontalSpacing(WidthDimension.w_10),
            ],
          ),
        ],
        actionsPadding: EdgeInsets.only(bottom: HeightDimension.h_10),
      );
    });
  }
}
