import 'dart:io';
import 'dart:ui';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/document_verification/seller_document_verification_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/order/seller_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class UploadDocumentScreen extends StatefulWidget {
  const UploadDocumentScreen({super.key});

  @override
  State<StatefulWidget> createState() => _UploadDocumentScreenState();
}

class _UploadDocumentScreenState extends State<UploadDocumentScreen> {

  final SellerDocumentVerificationController _sellerDocumentVerificationController =
  Get.put(SellerDocumentVerificationController());

  @override
  void initState() {
    _sellerDocumentVerificationController.getSubscribedPlansStatus(context, (data) {
      if (data?.seller?.isDocumentVerified == 2) {
        Get.offNamed(AppRoutes.documentRequestAwaitedScreen);
      }
      if (data?.seller?.isDocumentVerified == 1) {
        Get.offNamed(AppRoutes.documentRequestApprovedScreen);
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SellerDocumentVerificationController>(
        id: GetControllerBuilders.sellerDocumentVerificationController,
        init: _sellerDocumentVerificationController,
        builder: (controller) {
        return Scaffold(
          backgroundColor: AppColor.lightGrey,
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_10, top: HeightDimension.h_20),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_20),
                              SizedBox(
                                width: WidthDimension.w_18,
                                height: HeightDimension.h_15,
                                child: Image.asset(
                                  TMTImages.icBack,
                                  color: AppColor.neutral_800,
                                  fit: BoxFit.contain,
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_6),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_6),
                        TMTTextWidget(
                          title: "Upload Documents",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_10),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: GetBuilder<SellerDocumentVerificationController>(
                      id: GetControllerBuilders.sellerDocumentVerificationController,
                      init: _sellerDocumentVerificationController,
                      builder: (controller) {
                      return SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Visibility(
                              visible: (_sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 0),
                              child: Container(
                                padding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: Text.rich(
                                    TextSpan(
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      text: 'Note: ',
                                      children: [
                                        TextSpan(
                                          text: 'Adding products without verification is limited to ${_sellerDocumentVerificationController.planList?.productsAllowed?.value ?? "two"}. To add more products, you must complete the verification process.',
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    )),
                              ),
                            ),
                            Visibility(
                              visible: _sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == -1,
                              child: Container(
                                padding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: Text.rich(
                                    TextSpan(
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.primary,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      text: 'Rejected: ',
                                      children: [
                                        TextSpan(
                                          text: 'Your documents were rejected because ${_sellerDocumentVerificationController.planList?.seller?.docsRejectionReason ?? ""}. Please do suggested changes and upload the documents again.',
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.primary,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    )),
                              ),
                            ),
                            Visibility(
                              visible: _sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 1,
                              child: Container(
                                padding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: Text.rich(
                                    TextSpan(
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.green,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      text: 'Approved: ',
                                      children: [
                                        TextSpan(
                                          text: 'Your documents are verified. Yor are eligible to upload up to ${_sellerDocumentVerificationController.planList?.productsAllowed?.value ?? "two"} products.',
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.green,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    )),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: HeightDimension.h_20, left: WidthDimension.w_15, right: WidthDimension.w_15),
                              child: Text(
                                "Upload Documents",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_18,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_25),
                            SizedBox(
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    height: HeightDimension.h_32,
                                    width: HeightDimension.h_32,
                                    child: Image.asset(TMTImages.icUploadDocuments, color: AppColor.textColor,),
                                  ),
                                  VerticalSpacing(HeightDimension.h_10),
                                  SizedBox(
                                    width: WidthDimension.w_150,
                                    height: HeightDimension.h_35,
                                    child: TMTTextButton(buttonTitle: "Upload Documents", textStyle: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_12,
                                      color: AppColor.neutral_100,
                                      fontWeight: FontWeight.w700,
                                    ), onTap: ()
                                    async {
                                      if ((_sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 1 || _sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 2)) {
                                        return;
                                      }
                                      FilePickerResult? result = await FilePicker.platform.pickFiles(allowMultiple: true);
                                      if (result != null) {
                                        _sellerDocumentVerificationController.document = [];
                                        result.files.forEach((element) {
                                          _sellerDocumentVerificationController.document.add(File(element.path!));
                                        });
                                        _sellerDocumentVerificationController.update([GetControllerBuilders.sellerDocumentVerificationController]);
                                      } else {
                                        // User canceled the picker
                                      }
                                    }, color: (_sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 1 || _sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 2) ? AppColor.neutral_500 : AppColor.primaryBG,),
                                  ),
                                  VerticalSpacing(HeightDimension.h_10),
                                  TMTTextWidget(
                                    title: _sellerDocumentVerificationController.document.isEmpty ? "(Please upload your address and ID proof)" : _getDocumentsTitles(),
                                    style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_12,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_20),
                          ],
                        ),
                      );
                    }
                  ),
                ),
              ),
            ],
          ),
          bottomNavigationBar:Container(
            padding: EdgeInsets.only(
                left: WidthDimension.w_15, right: WidthDimension.w_15),
            height: HeightDimension.h_90,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Expanded(
                  child: InkWell(
                    onTap: (){
                      if ((_sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 1 || _sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 2)) {
                        return;
                      }
                      if (_sellerDocumentVerificationController.document.isEmpty) {
                        TMTToast.showErrorToast(context, 'Please select document.', title: "Alert");
                        return;
                      }
                      _sellerDocumentVerificationController.postVerifyDocs(context, _sellerDocumentVerificationController.document);
                    },
                    child: Container(
                      padding: EdgeInsets.only(
                          top: HeightDimension.h_12,
                          bottom: HeightDimension.h_12,
                          left: WidthDimension.w_18,
                          right: WidthDimension.w_18),
                      decoration: BoxDecoration(
                          color: (_sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 1 || _sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 2) ? AppColor.neutral_400 : AppColor.primaryBG,
                          border: Border.all(color: (_sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 1 || _sellerDocumentVerificationController.planList?.seller?.isDocumentVerified == 2) ? AppColor.neutral_400 : AppColor.primaryBG, width: 1),
                          borderRadius: const BorderRadius.all(
                              Radius.circular(TMTRadius.r_30))),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TMTTextWidget(
                            title: "SEND REQUEST",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_100,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    );
  }

  /// return selected documents titles
  String _getDocumentsTitles() {
    var title = '';
    _sellerDocumentVerificationController.document.forEach((element) {
      title = "${element.path.split('/').last}\n$title";
    });
    return title;
  }
}

