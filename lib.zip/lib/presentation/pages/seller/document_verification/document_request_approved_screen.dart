import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/pages/seller/document_verification/seller_document_verification_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class DocumentRequestApprovedScreen extends StatefulWidget {
  const DocumentRequestApprovedScreen({super.key});

  @override
  State<StatefulWidget> createState() => _DocumentRequestApprovedScreenState();
}

class _DocumentRequestApprovedScreenState extends State<DocumentRequestApprovedScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(SizeConfig.safeBlockVertical * 9),
          child: Container(
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 3,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ], color: AppColor.neutral_100),
            child: Column(
              children: [
                VerticalSpacing(SizeConfig.safeBlockVertical * 7),
                Row(
                  children: [
                    InkWell(
                      onTap: (){
                        Get.back();
                      },
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_20),
                          SizedBox(
                            width: WidthDimension.w_18,
                            height: HeightDimension.h_15,
                            child: Image.asset(
                              TMTImages.icBack,
                              color: AppColor.neutral_800,
                              fit: BoxFit.contain,
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_6),
                        ],
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(
                      title: "Approved",
                      style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_20),
                  ],
                ),
              ],
            ),
          )),
      body: SizedBox(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: HeightDimension.h_75,
              width: HeightDimension.h_75,
              child: Image.asset(TMTImages.icRequestApproved),
            ),
            VerticalSpacing(HeightDimension.h_15),
            TMTTextWidget(title: "Congratulations", style: TMTFontStyles.text(
              fontSize: 20,
              color: AppColor.textColor,
              fontWeight: FontWeight.w700,
            ),),
            VerticalSpacing(HeightDimension.h_10),
            Padding(
              padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
              child: TMTTextWidget(
                textAlign: TextAlign.center,
                title: "Documents has been verified.", style: TMTFontStyles.text(
                fontSize: 20,
                color: AppColor.textColor,
                fontWeight: FontWeight.w500,
              ), maxLines: 50,),
            ),
          ],
        ),
      ),
    );
  }
}
