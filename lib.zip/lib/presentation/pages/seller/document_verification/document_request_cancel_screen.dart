import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/tmt_webview.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';

class DocumentRequestCancelScreen extends StatefulWidget {
  const DocumentRequestCancelScreen({super.key});

  @override
  State<StatefulWidget> createState() => _DocumentRequestCancelScreenState();
}

class _DocumentRequestCancelScreenState
    extends State<DocumentRequestCancelScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(SizeConfig.safeBlockVertical * 9),
          child: Container(
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 3,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ], color: AppColor.neutral_100),
            child: Column(
              children: [
                VerticalSpacing(SizeConfig.safeBlockVertical * 7),
                Row(
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_20),
                          SizedBox(
                            width: WidthDimension.w_18,
                            height: HeightDimension.h_15,
                            child: Image.asset(
                              TMTImages.icBack,
                              color: AppColor.neutral_800,
                              fit: BoxFit.contain,
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_6),
                        ],
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(
                      title: "Failed",
                      style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_20),
                  ],
                ),
              ],
            ),
          )),
      body: SizedBox(
        width: double.infinity,
        child: Column(
          children: [
            Spacer(),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: HeightDimension.h_75,
                  width: HeightDimension.h_75,
                  child: Image.asset(TMTImages.icRequestCancel),
                ),
                VerticalSpacing(HeightDimension.h_15),
                TMTTextWidget(
                  title: "Failed",
                  style: TMTFontStyles.text(
                    fontSize: 20,
                    color: AppColor.primaryBG,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                VerticalSpacing(HeightDimension.h_10),
                Padding(
                  padding: EdgeInsets.only(
                      left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: RichText(
                    textAlign: TextAlign.center,
                    maxLines: 50,
                    text: TextSpan(
                        text:
                            "Your documents verification  request failed. Click ",
                        style: TMTFontStyles.text(
                          fontSize: 20,
                          color: AppColor.textColor,
                          fontWeight: FontWeight.w500,
                        ),
                    children: [
                      TextSpan(
                          text: 'SUPPORT',
                          style: TMTFontStyles.text(
                            fontSize: 20,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w700,
                            textDecoration: TextDecoration.underline
                          ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              Navigator.push(context, MaterialPageRoute(builder: (c){
                                return TMTWebView(url: "http://tacktalk.co.uk/");
                              }));
                            }),
                      TextSpan(
                          text: ' to find out why.',
                          style: TMTFontStyles.text(
                            fontSize: 20,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w400,
                          ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              Navigator.push(context, MaterialPageRoute(builder: (c){
                                return TMTWebView(url: "http://tacktalk.co.uk/");
                              }));
                            }),
                    ]
                    ),
                  ),
                ),
              ],
            ),
            Spacer(),
            Padding(
              padding: EdgeInsets.only(
                  left: WidthDimension.w_15, right: WidthDimension.w_15),
              child: TMTTextButton(
                onTap: () {
                  TMTUtilities.closeKeyboard(context);
                },
                buttonTitle: "SUPPORT",
              ),
            ),
            VerticalSpacing(HeightDimension.h_20),
          ],
        ),
      ),
    );
  }
}
