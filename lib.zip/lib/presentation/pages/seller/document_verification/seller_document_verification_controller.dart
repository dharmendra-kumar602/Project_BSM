import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/model/request/post_upload_docs_request.dart';
import 'package:take_my_tack/data/model/request/post_verification_documents_request.dart';
import 'package:take_my_tack/data/model/response/get_document_status_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_status_response.dart';
import 'package:take_my_tack/data/repository_implementation/seller_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

import '../../../../data/model/response/post_upload_docs_response.dart';

class SellerDocumentVerificationController extends GetxController{

  final SellerRepositoryImpl _sellerRepositoryImpl = SellerRepositoryImpl();

  List<Datum>? data;
  List<File> document = [];

  DRDatum? documentStatus;
  PlanList? planList;

  /*
   Method use to upload verification docs.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  Future<void> postVerifyDocs(BuildContext context, List<File> file) async {
    var request = VerificationDocument(description: "", title: "", file: file);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.postUploadVerificationDocs(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              right.data;
              showDialog(context: context, builder: (context){
                return Material(
                  color: AppColor.transparent,
                  child: Center(
                    child: TMTRoundedCornersContainer(
                      height: HeightDimension.h_215,
                      width: HeightDimension.h_250,
                      bgColor: AppColor.neutral_100,
                      padding: const EdgeInsets.all(TMTDimension.padding_15),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          TMTTextWidget(title: "Document verification\nrequest sent to admin", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_16,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w600,
                          ), textAlign: TextAlign.center,),
                          VerticalSpacing(HeightDimension.h_35),
                          GestureDetector(
                            onTap: (){
                              Navigator.pop(context);
                              Get.offNamed(AppRoutes.documentRequestAwaitedScreen, arguments: (right.data?.isEmpty ?? true) ? "35" : right.data?.first.sellerStoreId.toString());
                            },
                            child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "DONE", textStyle: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_100,
                              fontWeight: FontWeight.w700,
                            ),)),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              });
            } else {
              TMTToast.showErrorToast(
                  context, right.responseHeader.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      } else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get verification doc status.
   Parameter- BuildContext context, String storeId.
   Return -> No Return type.
  */
  void getDocumentStatus(BuildContext context, String storeId) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.getDocumentStatus(storeId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              ///TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              if (right.data.isNotEmpty) {
                documentStatus = right.data.first;
                update([GetControllerBuilders.documentRequestAwaitedScreenController]);
              }
            } else {
              /*TMTToast.showErrorToast(
                  context, right.responseHeader.error?.messages.first ?? "");*/
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      } else {
        /// No internet connection dialog
      }
    });
  }

  /// get seller registration status
  void getSubscribedPlansStatus(BuildContext context, Function(PlanList? data) callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.getSubscribedPlansStatus();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) async {
            if (right.responseHeader?.status == "SUCCESS") {
              planList = right.planList;
              if (right.planList?.documents?.isNotEmpty ?? false) {
                for (int i=0; i<(right.planList?.documents?.length ?? 0); i++) {
                  File? result = await _getFileFromUrl(right.planList?.documents?[i].url ?? "", right.planList?.documents?[i].title ?? "", i);
                  if (result != null) {
                    document.add(result);
                  }
                }
              }
              callback.call(right.planList);
              update([GetControllerBuilders.sellerDocumentVerificationController]);
            }
          });
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// get file (pdf) from url
  Future<File?> _getFileFromUrl(String pdfUrl, String title, int index) async {
    Dio dio = Dio();
    try {
      final response = await dio.get(pdfUrl,
          options: Options(responseType: ResponseType.bytes));
      if (response.statusCode == 200) {
        final bytes = response.data as List<int>;
        final tempDir = await getTemporaryDirectory();
        final file = File('${tempDir.path}/${title}_$index.png');
        await file.writeAsBytes(bytes);
        return file;
      } else {
        return null;
      }
    } catch (e) {
      print('Error downloading file: $e');
      return null;
    }
  }

}