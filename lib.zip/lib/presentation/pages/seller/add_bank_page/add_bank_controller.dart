import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/put_bank_details_request.dart';
import 'package:take_my_tack/data/model/response/get_seller_bank_details_response.dart';
import 'package:take_my_tack/data/repository_implementation/seller_repository_impl.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class AddBankController extends GetxController {

  final TextEditingController addAccountNumberController = TextEditingController();
  final TextEditingController ifscCodeController = TextEditingController();
  final TextEditingController accountHolderNameController = TextEditingController();
  final TextEditingController backNameController = TextEditingController();

  final SellerRepositoryImpl _sellerRepositoryImpl = SellerRepositoryImpl();
  BankData? bankData;

  /*
   Method use to get bank details.
   Parameter- BuildContext context, Function callback
   Return -> No Return type.
  */
  void getBankDetails (BuildContext context, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.getSellerBankDetails();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              bankData = right.data;
              backNameController.text = right.data?.bankName ?? "";
              ifscCodeController.text = right.data?.ifsc ?? "";
              addAccountNumberController.text = right.data?.accountNumber ?? "";
              accountHolderNameController.text = right.data?.accountHolderName ?? "";
              update([GetControllerBuilders.sellerBankDetailsScreenController]);
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update bank details.
   Parameter- BuildContext context, Function callback
   Return -> No Return type.
  */
  void updateBankDetails (BuildContext context, Function callback) {
    var params = PutSellerBankDetailsRequest(
      requestHeader: DioUtils.getRequestHeaderModel(),
      bankName: backNameController.text,
      ifsc: ifscCodeController.text,
      accountNumber: addAccountNumberController.text,
      accountHolderName: accountHolderNameController.text,
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.putSellerBankDetails(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              bankData = null;
              backNameController.clear();
              ifscCodeController.clear();
              addAccountNumberController.clear();
              accountHolderNameController.clear();
              TMTToast.showSuccessToast(context, right.responseHeader?.message ?? '');
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}