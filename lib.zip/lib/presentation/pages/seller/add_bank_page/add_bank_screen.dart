import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';
import 'add_bank_controller.dart';

class AddBankScreen extends StatefulWidget {
  const AddBankScreen({Key? key}) : super(key: key);

  @override
  State<AddBankScreen> createState() => _AddBankScreenState();
}

class _AddBankScreenState extends State<AddBankScreen> {

  final AddBankController _addBankController = Get.put(AddBankController());

  @override
  void initState() {
    _addBankController.getBankDetails(context, (){});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      bottomNavigationBar: addShippingButton(),
      body: GetBuilder<AddBankController>(
          id: GetControllerBuilders.addBankController,
          init: _addBankController,
          builder: (controller) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: MediaQuery.of(context).size.height / 9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset:
                    const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(
                      bottom: HeightDimension.h_5,
                      top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              Container(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: "Add Bank",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              VerticalSpacing(HeightDimension.h_10),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: WidthDimension.w_15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                       children: [
                         Visibility(
                           /// to be added in future.
                           visible: false,
                           child: Row(
                             mainAxisAlignment: MainAxisAlignment.end,
                             children: [
                               const Icon(Icons.add, color: AppColor.primaryBG, size: 25,),
                               TMTTextWidget(
                                 title: "Add Bank",
                                 style: TMTFontStyles.textHarbinger(
                                   fontSize: TMTFontSize.sp_18,
                                   color: AppColor.primaryBG,
                                   fontWeight: FontWeight.w400,
                                 ),
                               ),
                             ],
                           ),
                         ),
                         VerticalSpacing(HeightDimension.h_5),
                         Padding(
                           padding: const EdgeInsets.only(left: 8),
                           child: TMTTextWidget(
                             title: "Please Add Your Bank Details",
                             style: TMTFontStyles.textTeen(
                               fontSize: TMTFontSize.sp_16,
                               color: AppColor.neutral_800,
                               fontWeight: FontWeight.bold,
                             ),
                           ),
                         ),
                         VerticalSpacing(HeightDimension.h_15),
                         TMTTextField(
                           hintText: "Bank Name",
                           controller: controller.backNameController,
                           onFieldSubmitted: (value){
                             TMTUtilities.closeKeyboard(context);
                           },
                           textInputAction: TextInputAction.done,
                         ),
                          VerticalSpacing(HeightDimension.h_10),
                         TMTTextField(
                           hintText: "Account Number",
                           controller: controller.addAccountNumberController,
                           inputFormatters: [
                             FilteringTextInputFormatter.deny(RegExp(r'\s'))
                           ],
                           onFieldSubmitted: (value){
                             TMTUtilities.closeKeyboard(context);
                           },
                           textInputAction: TextInputAction.done,
                         ),
                         VerticalSpacing(HeightDimension.h_10),
                         TMTTextField(
                           hintText: "IFSC Code",
                           controller: controller.ifscCodeController,
                           inputFormatters: [
                             FilteringTextInputFormatter.deny(RegExp(r'\s'))
                           ],
                           onFieldSubmitted: (value){
                             TMTUtilities.closeKeyboard(context);
                           },
                           textInputAction: TextInputAction.done,
                         ),
                         VerticalSpacing(HeightDimension.h_10),
                         TMTTextField(
                           hintText: "Account Holder's Name",
                           controller: controller.accountHolderNameController,
                           onFieldSubmitted: (value){
                             TMTUtilities.closeKeyboard(context);
                           },
                           textInputAction: TextInputAction.done,
                         ),
                       ],
                    ),
                  ),
                ),
              )
            ],
          );
        }
      ),
    );
  }

  /// Action button.
  Widget addShippingButton() {
    return GestureDetector(
      onTap: (){
        _addBankController.updateBankDetails(context, (){
          Get.back();
        });
      },
      child: Container(
        height: HeightDimension.h_45,
        width: WidthDimension.w_190,
        margin: EdgeInsets.symmetric(horizontal: HeightDimension.h_15, vertical: HeightDimension.h_10),
        padding: EdgeInsets.only(
            top: HeightDimension.h_12,
            bottom: HeightDimension.h_12),
        decoration: const BoxDecoration(
            color: AppColor.primaryBG,
            borderRadius: BorderRadius.all(
                Radius.circular(TMTRadius.r_30))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TMTTextWidget(
              title: "CONFIRM",
              style: TMTFontStyles.textTeen(
                fontSize: TMTFontSize.sp_18,
                color: AppColor.neutral_100,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
