
import 'package:app_settings/app_settings.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:page_view_dot_indicator/page_view_dot_indicator.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/response/get_buyer_orders_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/dashboard/seller_dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/order/seller_order_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/storage_stats/storage_media_stats_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_notification/tmt_notification_bell.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_circular_seekbar/circular_seek_bar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class StorageMediaStatsScreen extends StatefulWidget {
  const StorageMediaStatsScreen({super.key});

  @override
  State<StatefulWidget> createState() => _StorageMediaStatsScreenState();
}

class _StorageMediaStatsScreenState extends State<StorageMediaStatsScreen> {

  final StorageMediaStatsController _controller = Get.put(StorageMediaStatsController());

  double storageProgress = 0;
  double mediaProgress = 0;
  double documentProgress = 0;
  final ValueNotifier<double> _valueNotifier = ValueNotifier(0);

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(
      context: context,
      widget: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TMTRoundedCornersContainer(
            padding: EdgeInsets.only(
                left: WidthDimension.w_20,
                right: WidthDimension.w_20,
                top: HeightDimension.h_20,
                bottom: HeightDimension.h_20),
            bgColor: AppColor.neutral_100,
            borderRadius: BorderRadius.circular(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text(
                    'No Connection',
                    style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_16,
                      fontWeight: FontWeight.w700,
                      color: AppColor.neutral_800,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text(
                    'Please check your internet connectivity',
                    style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_14,
                      fontWeight: FontWeight.w600,
                      color: AppColor.textColor,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    AppSettings.openAppSettings(type: AppSettingsType.wifi);
                  },
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                    child: Text(
                      'Okay',
                      style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_16,
                        fontWeight: FontWeight.w700,
                        color: AppColor.neutral_700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      callback: () {
        _controller.getStorageStats(context, (data){
          setState(() {
            storageProgress = data?.usedSize ?? 0;
            mediaProgress = data?.media ?? 0;
            documentProgress = data?.documents ?? 0;
          });
        }, TMTUtilities.getSellerStoreIdFromToken(TMTLocalStorage.getString(GetXStorageConstants.jwtToken)));
      },
    );
    super.initState();
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<StorageMediaStatsController>(
        id: GetControllerBuilders.storageMediaStatsController,
        init: _controller,
        builder: (controller) {
          return Scaffold(
            backgroundColor: AppColor.lightGrey,
            body: Column(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height / 9.3,
                  decoration: const BoxDecoration(color: AppColor.neutral_100),
                  child: Padding(
                    padding: EdgeInsets.only(
                        bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Row(
                        children: [
                          InkWell(
                            onTap: () {
                             Get.back();
                            },
                            child: Row(
                              children: [
                                HorizontalSpacing(WidthDimension.w_10),
                                Container(
                                  width: WidthDimension.w_40,
                                  height: HeightDimension.h_30,
                                  child: Center(
                                    child: Image.asset(
                                      TMTImages.icBack,
                                      color: AppColor.neutral_800,
                                      fit: BoxFit.contain,
                                      scale: 3.4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          TMTTextWidget(
                            title: "Storage Stats",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const Spacer(),
                          HorizontalSpacing(WidthDimension.w_10),
                          GestureDetector(
                            onTap: () async {
                              await Get.toNamed(AppRoutes.notificationScreen,
                                  arguments: "SELLER");
                            },
                            child: TMTNotificationBell(isBuyer: false),
                          ),
                          HorizontalSpacing(WidthDimension.w_20),
                        ],
                      ),
                    ),
                  ),
                ),
                VerticalSpacing(HeightDimension.h_30),
                CircularSeekBar(
                  maxProgress: 100,
                  minProgress: 0,
                  interactive: false,
                  barWidth: 25,
                  trackColor: const Color(0xFFE4E2F2),
                  progressColor: const Color(0xFFA382FC),
                  progress: storageProgress,
                  width: double.infinity,
                  height: HeightDimension.h_165,
                  animation: false,
                  animDurationMillis: 200,
                  startAngle: 0,
                  sweepAngle: 360,
                  strokeCap: StrokeCap.round,
                  valueNotifier: _valueNotifier,
                  child: Center(
                    child: ValueListenableBuilder(
                        valueListenable: _valueNotifier,
                        builder: (_, double value, __) {
                          return Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              TMTTextWidget(title: "${((_controller.data?.allowedStorage ?? 100) - (_controller.data?.usedSize ?? 0)).toStringAsFixed(2)} MB", style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_20,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),),
                              TMTTextWidget(title: ((_controller.data?.allowedStorage ?? 0) > (_controller.data?.usedSize ?? 0)) ? "Available" : "Storage Full", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.textColor,
                                fontWeight: FontWeight.w500,
                              ),),
                            ],
                          );
                        } ),
                  ),
                ),
                VerticalSpacing(HeightDimension.h_30),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_40, right: WidthDimension.w_40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        children: [
                          TMTTextWidget(title: "Total", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_12,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w500,
                          ),),
                          TMTTextWidget(title: "${_controller.data?.allowedStorage} MB", style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_22,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),),
                        ],
                      ),
                      Column(
                        children: [
                          TMTTextWidget(title: "Used", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_12,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w500,
                          ),),
                          TMTTextWidget(title: "${_controller.data?.usedSize?.toStringAsFixed(2) ?? 1} MB", style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_22,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),),
                        ],
                      ),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_30),
                Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              TMTTextWidget(title: "Media", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w500,
                              ),),
                              HorizontalSpacing(WidthDimension.w_8),
                              TMTTextWidget(title: "${mediaProgress.toStringAsFixed(1)} MB", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.textColor,
                                fontWeight: FontWeight.w500,
                              ),),
                            ],
                          ),
                          Row(
                            children: [
                              TMTTextWidget(title: "${_controller.data?.mediaCount ?? 1} files", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w500,
                              ),),
                            ],
                          ),
                        ],
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_5),
                    Row(
                      children: [
                        HorizontalSpacing(WidthDimension.w_20),
                        TMTRoundedCornersContainer(
                          padding: const EdgeInsets.all(4),
                          borderRadius: BorderRadius.circular(5),
                          bgColor: const Color(0xFFA382FC),
                          height: HeightDimension.h_25,
                          width: HeightDimension.h_25,
                          child: Image.asset(TMTImages.icStatsShare),
                        ),
                        Expanded(
                          child: TMTRoundedCornersContainer(
                            margin: EdgeInsets.only(right: WidthDimension.w_20),
                            width: double.infinity,
                            height: HeightDimension.h_15,
                            bgColor: const Color(0xFFE4E2F2),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    Flexible(
                                      flex: _controller.data?.media?.toInt() ?? 0,
                                      child: TMTRoundedCornersContainer(
                                        height: HeightDimension.h_8,
                                        bgColor: const Color(0xFFA382FC),
                                      ),
                                    ),
                                    Flexible(
                                      flex: (_controller.data?.allowedStorage ?? 0) - (_controller.data?.usedSize?.toInt() ?? 0),
                                      child: TMTRoundedCornersContainer(
                                        height: HeightDimension.h_8,
                                        bgColor: AppColor.transparent,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                VerticalSpacing(HeightDimension.h_30),
                Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              TMTTextWidget(title: "Documents", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w500,
                              ),),
                              HorizontalSpacing(WidthDimension.w_8),
                              TMTTextWidget(title: "${documentProgress.toStringAsFixed(1)} MB", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.textColor,
                                fontWeight: FontWeight.w500,
                              ),),
                            ],
                          ),
                          Row(
                            children: [
                              TMTTextWidget(title: "${_controller.data?.docsCount ?? 1} Files", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w500,
                              ),),
                            ],
                          ),
                        ],
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_5),
                    Row(
                      children: [
                        HorizontalSpacing(WidthDimension.w_20),
                        TMTRoundedCornersContainer(
                          padding: const EdgeInsets.all(4),
                          borderRadius: BorderRadius.circular(5),
                          bgColor: const Color(0xFFF88150),
                          height: HeightDimension.h_25,
                          width: HeightDimension.h_25,
                          child: Image.asset(TMTImages.icStatsFile),
                        ),
                        Expanded(
                          child: TMTRoundedCornersContainer(
                            margin: EdgeInsets.only(right: WidthDimension.w_20),
                            width: double.infinity,
                            height: HeightDimension.h_15,
                            bgColor: const Color(0xFFE4E2F2),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    Flexible(
                                      flex: _controller.data?.documents?.toInt() ?? 0,
                                      child: TMTRoundedCornersContainer(
                                        height: HeightDimension.h_8,
                                        bgColor: const Color(0xFFF88150),
                                      ),
                                    ),
                                    Flexible(
                                      flex: (_controller.data?.allowedStorage ?? 0) - (_controller.data?.usedSize?.toInt() ?? 0),
                                      child: TMTRoundedCornersContainer(
                                        height: HeightDimension.h_8,
                                        bgColor: AppColor.transparent,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          );
        });
  }
}
