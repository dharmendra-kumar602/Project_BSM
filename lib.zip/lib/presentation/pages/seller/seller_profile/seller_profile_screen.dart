import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/seller_profile/seller_profile_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/tmt_webview.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class SellerProfileScreen extends StatefulWidget {
  const SellerProfileScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SellerProfileScreenState();
}

class _SellerProfileScreenState extends State<SellerProfileScreen> {

  final SellerProfileController _sellerProfileController =
  Get.put(SellerProfileController());

  final DashboardController _dashboardController =
  Get.put(DashboardController());

  bool isSubscribedToNewsLetter = false;
  int addedProducts = 0;
  int allowedProducts = 0;
  int verificationStatus = 0;

  @override
  void initState() {
    _callApis();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SellerProfileController>(
        id: GetControllerBuilders.sellerProfileScreenController,
        init: _sellerProfileController,
        builder: (controller) {
        return TMTBackButton(
          onWillPop: (){
            Get.offNamed(AppRoutes.sellerDashboard);
            return Future.value(false);
          },
          child: Scaffold(
            body: Stack(
              children: [
                Column(
                  children: [
                    Container(
                      height: MediaQuery.of(context).size.height/9.3,
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 2,
                          blurRadius: 3,
                          offset: const Offset(0, 3), // changes position of shadow
                        ),
                      ], color: AppColor.neutral_100),
                      child: Padding(
                        padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Row(
                            children: [
                              InkWell(
                                onTap: () {
                                  Get.offNamed(AppRoutes.sellerDashboard);
                                },
                                child: Row(
                                  children: [
                                    HorizontalSpacing(WidthDimension.w_10),
                                    SizedBox(
                                      width: WidthDimension.w_40,
                                      height: HeightDimension.h_30,
                                      child: Center(
                                        child: Image.asset(
                                          TMTImages.icBack,
                                          color: AppColor.neutral_800,
                                          fit: BoxFit.contain,
                                          scale: 3.4,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              TMTTextWidget(
                                title: "My Profile",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_18,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_20),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            VerticalSpacing(HeightDimension.h_10),
                            Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4,
                                          right: WidthDimension.w_4),
                                      height: HeightDimension.h_110,
                                      width: WidthDimension.w_120,
                                      child: (_sellerProfileController.sellerProfileData?.profilePicture?.isEmpty ?? true) ? ClipRRect(
                                        borderRadius: BorderRadius.circular(8.0),
                                        child: CircleAvatar(
                                          radius: 70,
                                          backgroundColor: AppColor.neutral_100,
                                          child: Image.asset(
                                            _sellerProfileController.sellerProfileData?.gender != "MALE" ? TMTImages.icProfileFemale : TMTImages.icProfileMen,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ) : ClipRRect(
                                        borderRadius: BorderRadius.circular(200.0),
                                        child: TMTCachedImage.networkImage(_sellerProfileController.sellerProfileData?.profilePicture ?? "", fit: BoxFit.cover,),
                                      ),
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_8),
                                TMTTextWidget(
                                  title: _sellerProfileController.sellerProfileData?.firstName == null ? "" : "${_sellerProfileController.sellerProfileData?.firstName} ${_sellerProfileController.sellerProfileData?.lastName}",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_18,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                VerticalSpacing(HeightDimension.h_5),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    GestureDetector(
                                      onTap: (){
                                        Get.toNamed(AppRoutes.sellerEditProfileScreen);
                                      },
                                        child: TMTRoundedCornersContainer(padding: EdgeInsets.only(left: WidthDimension.w_8, right: WidthDimension.w_8, top: HeightDimension.h_2, bottom: HeightDimension.h_2), borderColor: AppColor.textColor,child: TMTTextWidget(title: "Edit profile", style: TMTFontStyles.text(fontSize: TMTFontSize.sp_12),),)),
                                    HorizontalSpacing(WidthDimension.w_8),
                                    GestureDetector(onTap: (){
                                      if (addedProducts < allowedProducts) {
                                        Get.toNamed(AppRoutes.addProductScreen);
                                      } else if (addedProducts >= allowedProducts) {
                                        showDialog(context: context, builder: (context){
                                          return Material(
                                            color: AppColor.transparent,
                                            child: Center(
                                              child: TMTRoundedCornersContainer(
                                                height: HeightDimension.h_180,
                                                width: HeightDimension.h_250,
                                                bgColor: AppColor.neutral_100,
                                                padding: const EdgeInsets.all(TMTDimension.padding_15),
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    TMTTextWidget(title: "You can not add more products in this plan.", style: TMTFontStyles.text(
                                                      fontSize: TMTFontSize.sp_16,
                                                      color: AppColor.textColor,
                                                      fontWeight: FontWeight.w600,
                                                    ), textAlign: TextAlign.center, maxLines: 8,),
                                                    VerticalSpacing(HeightDimension.h_20),
                                                    GestureDetector(
                                                      onTap: (){
                                                        Navigator.pop(context);
                                                      },
                                                      child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "OK", textStyle: TMTFontStyles.textTeen(
                                                        fontSize: TMTFontSize.sp_18,
                                                        color: AppColor.neutral_100,
                                                        fontWeight: FontWeight.w700,
                                                      ),)),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          );
                                        });
                                      } else {
                                        TMTToast.showErrorToast(context, "Please complete the verification process to add more products.", title: "Alert");
                                        Get.toNamed(AppRoutes.uploadDocumentScreen);
                                      }
                                    },child: TMTRoundedCornersContainer(padding: EdgeInsets.only(left: WidthDimension.w_8, right: WidthDimension.w_8, top: HeightDimension.h_2, bottom: HeightDimension.h_2), borderColor: AppColor.textColor,child: TMTTextWidget(title: "Add product", style: TMTFontStyles.text(fontSize: TMTFontSize.sp_12), ),)),
                                  ],
                                )
                              ],
                            ),
                            VerticalSpacing(HeightDimension.h_10),
                            Padding(
                              padding: EdgeInsets.only(
                                  left: WidthDimension.w_20,
                                  right: WidthDimension.w_20,
                                  bottom: HeightDimension.h_20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  VerticalSpacing(HeightDimension.h_10),
                                  InkWell(
                                    onTap: (){
                                      Get.toNamed(AppRoutes.enquiryListingScreenPage, arguments: false);
                                    },
                                    child: Container(
                                      child: Column(
                                        children: [
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: WidthDimension.w_18,
                                                height: HeightDimension.h_18,
                                                child: Image.asset(
                                                  TMTImages.icManageEnquires,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              TMTTextWidget(
                                                title: "Enquiries",
                                                style: TMTFontStyles.textTeen(
                                                  fontSize: TMTFontSize.sp_16,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              const Spacer(),
                                              SizedBox(
                                                width: WidthDimension.w_10,
                                                height: HeightDimension.h_10,
                                                child: Image.asset(
                                                  TMTImages.icNext,
                                                ),
                                              ),
                                            ],
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                        ],
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: (){
                                      Get.toNamed(AppRoutes.sellerSupportTicketsScreen, arguments: true);
                                    },
                                    child: Container(
                                      child: Column(
                                        children: [
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: WidthDimension.w_18,
                                                height: HeightDimension.h_18,
                                                child: Image.asset(
                                                  TMTImages.icSupportTicket,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              TMTTextWidget(
                                                title: "Support Tickets",
                                                style: TMTFontStyles.textTeen(
                                                  fontSize: TMTFontSize.sp_16,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              const Spacer(),
                                              SizedBox(
                                                width: WidthDimension.w_10,
                                                height: HeightDimension.h_10,
                                                child: Image.asset(
                                                  TMTImages.icNext,
                                                ),
                                              ),
                                            ],
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                        ],
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: (){
                                      Get.toNamed(AppRoutes.addBankScreen);
                                    },
                                    child: Container(
                                      child: Column(
                                        children: [
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: WidthDimension.w_18,
                                                height: HeightDimension.h_18,
                                                child: Image.asset(
                                                  TMTImages.icManagePayments,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              TMTTextWidget(
                                                title: "Manage Payments",
                                                style: TMTFontStyles.textTeen(
                                                  fontSize: TMTFontSize.sp_16,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              const Spacer(),
                                              SizedBox(
                                                width: WidthDimension.w_10,
                                                height: HeightDimension.h_10,
                                                child: Image.asset(
                                                  TMTImages.icNext,
                                                ),
                                              ),
                                            ],
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                        ],
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: (){
                                      _launchURL(
                                          "https://tacktalk.co.uk");
                                    },
                                    child: Column(
                                      children: [
                                        Container(
                                          width: double.infinity,
                                          height: 0.8,
                                          color: AppColor.neutral_400,
                                        ),
                                        VerticalSpacing(HeightDimension.h_15),
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: WidthDimension.w_18,
                                              height: HeightDimension.h_18,
                                              child: Image.asset(
                                                TMTImages.icWriteBlog,
                                              ),
                                            ),
                                            HorizontalSpacing(WidthDimension.w_10),
                                            TMTTextWidget(
                                              title: "Contribute to the Blog",
                                              style: TMTFontStyles.textTeen(
                                                fontSize: TMTFontSize.sp_16,
                                                color: AppColor.neutral_800,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                            HorizontalSpacing(WidthDimension.w_10),
                                            const Spacer(),
                                            SizedBox(
                                              width: WidthDimension.w_10,
                                              height: HeightDimension.h_10,
                                              child: Image.asset(
                                                TMTImages.icNext,
                                              ),
                                            ),
                                          ],
                                        ),
                                        VerticalSpacing(HeightDimension.h_15),
                                      ],
                                    ),
                                  ),
                                  InkWell(
                                    onTap: (){
                                      Get.toNamed(AppRoutes.uploadDocumentScreen);
                                    },
                                    child: Column(
                                      children: [
                                        Container(
                                          width: double.infinity,
                                          height: 0.8,
                                          color: AppColor.neutral_400,
                                        ),
                                        VerticalSpacing(HeightDimension.h_15),
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: WidthDimension.w_18,
                                              height: HeightDimension.h_18,
                                              child: Image.asset(
                                                TMTImages.icUploadDocuments,
                                              ),
                                            ),
                                            HorizontalSpacing(WidthDimension.w_10),
                                            TMTTextWidget(
                                              title: "Upload Documents",
                                              style: TMTFontStyles.textTeen(
                                                fontSize: TMTFontSize.sp_16,
                                                color: AppColor.neutral_800,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                            HorizontalSpacing(WidthDimension.w_10),
                                            const Spacer(),
                                            SizedBox(
                                              width: WidthDimension.w_10,
                                              height: HeightDimension.h_10,
                                              child: Image.asset(
                                                TMTImages.icNext,
                                              ),
                                            ),
                                          ],
                                        ),
                                        VerticalSpacing(HeightDimension.h_15),
                                      ],
                                    ),
                                  ),
                                  InkWell(
                                    onTap: (){
                                      try {
                                        Get.toNamed(AppRoutes.sellerProductListScreen);
                                      } catch (e) {

                                      }
                                    },
                                    child: Container(
                                      child: Column(
                                        children: [
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: WidthDimension.w_18,
                                                height: HeightDimension.h_18,
                                                child: Image.asset(
                                                  TMTImages.icManageProducts,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              TMTTextWidget(
                                                title: "Manage Products",
                                                style: TMTFontStyles.textTeen(
                                                  fontSize: TMTFontSize.sp_16,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              const Spacer(),
                                              SizedBox(
                                                width: WidthDimension.w_10,
                                                height: HeightDimension.h_10,
                                                child: Image.asset(
                                                  TMTImages.icNext,
                                                ),
                                              ),
                                            ],
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                        ],
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: (){
                                      _dashboardController.updateNewsLetterStatus(context, isSubscribedToNewsLetter, callBack: (){
                                        if (TMTLocalStorage.getUserLoggedIn()) {
                                          _callApis();
                                        }
                                      });
                                    },
                                    child: Container(
                                      child: Column(
                                        children: [
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: WidthDimension.w_18,
                                                height: HeightDimension.h_18,
                                                child: Image.asset(
                                                  isSubscribedToNewsLetter ? TMTImages.icUnsub : TMTImages.icSub,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              TMTTextWidget(
                                                title: isSubscribedToNewsLetter ? "Unsubscribe News Letter" : "Subscribe News Letter",
                                                style: TMTFontStyles.textTeen(
                                                  fontSize: TMTFontSize.sp_16,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              const Spacer(),
                                              SizedBox(
                                                width: WidthDimension.w_10,
                                                height: HeightDimension.h_10,
                                                child: Image.asset(
                                                  TMTImages.icNext,
                                                ),
                                              ),
                                            ],
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: (){
                                      Get.toNamed(AppRoutes.manageShippingScreen);
                                    },
                                    child: Container(
                                      child: Column(
                                        children: [
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Row(
                                            children: [
                                              SizedBox(
                                                width: WidthDimension.w_18,
                                                height: HeightDimension.h_18,
                                                child: Image.asset(
                                                  TMTImages.icManageShipping,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              TMTTextWidget(
                                                title: "Manage Shipping",
                                                style: TMTFontStyles.textTeen(
                                                  fontSize: TMTFontSize.sp_16,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              const Spacer(),
                                              SizedBox(
                                                width: WidthDimension.w_10,
                                                height: HeightDimension.h_10,
                                                child: Image.asset(
                                                  TMTImages.icNext,
                                                ),
                                              ),
                                            ],
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      _showSwitchProfileDialog();
                                    },
                                    child: Container(
                                      child: Column(
                                        children: [
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Row(
                                            children: [
                                              HorizontalSpacing(WidthDimension.w_10),
                                              TMTTextWidget(
                                                title: "Switch to buyer profile",
                                                style: TMTFontStyles.textTeen(
                                                  fontSize: TMTFontSize.sp_16,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              HorizontalSpacing(WidthDimension.w_10),
                                              const Spacer(),
                                              SizedBox(
                                                width: WidthDimension.w_10,
                                                height: HeightDimension.h_10,
                                                child: Image.asset(
                                                  TMTImages.icNext,
                                                ),
                                              ),
                                            ],
                                          ),
                                          VerticalSpacing(HeightDimension.h_15),
                                          Container(
                                            width: double.infinity,
                                            height: 0.8,
                                            color: AppColor.neutral_400,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                  TMTTextWidget(
                                    title: "About",
                                    style: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_16,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_20),
                                  Column(
                                    children: [
                                      GestureDetector(
                                        onTap: (){
                                          _launchURL(
                                              "https://tacktalk.co.uk/terms-conditions-%f0%9f%a4%9f/");
                                        },
                                        child: TMTRoundedCornersContainer(
                                          width: double.infinity,
                                          borderRadius: const BorderRadius.only(),
                                          bgColor: AppColor.neutral_100,
                                          borderColor: AppColor.dividerColor,
                                          borderWidth: 0.8,
                                          padding: const EdgeInsets.all(15),
                                          child: TMTTextWidget(
                                            title: "Terms & Conditions",
                                            style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_14,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w500,
                                                textDecoration: TextDecoration.underline),
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: (){
                                          _launchURL(
                                              "https://tacktalk.co.uk/privacy-policy");
                                        },
                                        child: TMTRoundedCornersContainer(
                                          width: double.infinity,
                                          borderRadius: const BorderRadius.only(
                                              bottomLeft: Radius.circular(TMTRadius.r_10),
                                              bottomRight: Radius.circular(TMTRadius.r_10)),
                                          bgColor: AppColor.neutral_100,
                                          borderColor: AppColor.dividerColor,
                                          borderWidth: 0.8,
                                          padding: const EdgeInsets.all(15),
                                          child: TMTTextWidget(
                                            title: "Privacy Policy",
                                            style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_14,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w500,
                                                textDecoration: TextDecoration.underline),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  VerticalSpacing(HeightDimension.h_25),
                                  GestureDetector(
                                    onTap: (){
                                      _showLogoutConfirmationDialog(context);
                                    },
                                    child: TMTRoundedCornersContainer(
                                      bgColor: AppColor.neutral_100,
                                      borderColor: AppColor.neutral_800,
                                      borderWidth: 1,
                                      borderRadius: BorderRadius.circular(TMTRadius.r_30),
                                      width: double.infinity,
                                      padding: const EdgeInsets.all(15),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            width: WidthDimension.w_15,
                                            height: HeightDimension.h_15,
                                            child: Image.asset(
                                              TMTImages.icLogout,
                                            ),
                                          ),
                                          HorizontalSpacing(WidthDimension.w_10),
                                          TMTTextWidget(
                                            title: "LOGOUT",
                                            style: TMTFontStyles.textTeen(
                                              fontSize: TMTFontSize.sp_16,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                  GestureDetector(
                                    onTap: (){
                                      _dashboardController.showDeleteConfirmationDialog(context);
                                    },
                                    child: TMTRoundedCornersContainer(
                                      bgColor: AppColor.primaryBG,
                                      borderColor: AppColor.neutral_100,
                                      borderWidth: 1,
                                      borderRadius: BorderRadius.circular(TMTRadius.r_30),
                                      width: double.infinity,
                                      padding: const EdgeInsets.all(15),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          TMTTextWidget(
                                            title: "DELETE ACCOUNT",
                                            style: TMTFontStyles.textTeen(
                                              fontSize: TMTFontSize.sp_16,
                                              color: AppColor.neutral_100,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_20),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Visibility(
                  visible: !TMTLocalStorage.getUserLoggedIn(),
                  child: Material(
                    color: Colors.transparent,
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                      child: Container(
                        decoration: BoxDecoration(color: AppColor.neutral_800.withOpacity(0.5)),
                        width: double.infinity,
                        height: double.infinity,
                        child: Center(
                          child: TMTRoundedCornersContainer(
                            width: WidthDimension.w_286,
                            height: HeightDimension.h_140,
                            bgColor: AppColor.neutral_100,
                            borderRadius:
                                const BorderRadius.all(Radius.circular(TMTRadius.r_15)),
                            padding: const EdgeInsets.only(top: TMTDimension.padding_20, left: TMTDimension.padding_20, right: TMTDimension.padding_20),
                            child: Column(
                              children: [
                                TMTTextWidget(
                                  title: "Please login to continue.",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_18,
                                    color: AppColor.primaryBG,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                                InkWell(
                                  onTap: (){
                                    Get.offAndToNamed(AppRoutes.loginScreen, arguments: AppRoutes.homeScreen);
                                  },
                                    child: Container(height: HeightDimension.h_40, margin: EdgeInsets.only(left: HeightDimension.h_20, right: HeightDimension.h_20),child: const TMTTextButton(buttonTitle: "Login"),)),
                                VerticalSpacing(HeightDimension.h_10),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    TMTTextWidget(
                                      title: "New customer?",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_4),
                                    GestureDetector(
                                      onTap: (){
                                        Get.offAndToNamed(AppRoutes.signUpScreen);
                                      },
                                      child: TMTTextWidget(
                                        title: "Start here.",
                                        style: TMTFontStyles.textTeen(
                                          fontSize: TMTFontSize.sp_12,
                                          color: AppColor.primaryBG,
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
            bottomNavigationBar: CommonSellerBottomNavigationBar(
                currentSelectedItem: 4, onTap: (index) async {
              if (index == 0) {
                Get.offNamed(AppRoutes.sellerDashboard);
              } else if (index == 1) {
                Get.offNamed(AppRoutes.sellerOrderListingScreen);
              } else if (index == 2) {
                Get.offNamed(AppRoutes.sellerProductListScreen);
              } else if (index == 3) {
                Get.offNamed(AppRoutes.sellerSupportTicketsScreen);
              }
            }),
          ),
        );
      }
    );
  }

  /// show confirmation dialog for logout
  void _showLogoutConfirmationDialog(BuildContext context) {
    showDialog(context: context, builder: (c){
      return AlertDialog(
        contentPadding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_20, right: WidthDimension.w_20, bottom: HeightDimension.h_20),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_10))),
        content: TMTTextWidget(title: "Are you sure you want to logout?", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_16, fontWeight: FontWeight.w700, color: AppColor.neutral_800),),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.green),
                ),
                child: TMTTextWidget(title: 'Cancel' , style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.of(context).pop(false); // Return false when cancelled
                },
              ),
             HorizontalSpacing(WidthDimension.w_8),
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.primaryBG),
                ),
                child: TMTTextWidget(title: 'Logout', style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  _sellerProfileController.postLogoutUser(context);
                },
              ),
              HorizontalSpacing(WidthDimension.w_10),
            ],
          ),
        ],
        actionsPadding: EdgeInsets.only(bottom: HeightDimension.h_10),
      );
    });
  }

  /// For launching url
  _launchURL(String url) async {
    Navigator.push(context, MaterialPageRoute(builder: (c){
      return TMTWebView(url: url);
    }));
  }

  /// call apis
  void _callApis() {
    _sellerProfileController.getSellerProfile(context);
    _dashboardController.getNewsLetterStatus(context, callBack: (v){
      setState(() {
        isSubscribedToNewsLetter = v == 1;
      });
    });
    _dashboardController.getSubscribedPlansStatus(context, (data) {
      setState(() {
        verificationStatus = data?.seller?.isDocumentVerified ?? 0;
        addedProducts = data?.productsCount ?? 0;
        allowedProducts = data?.productsAllowed?.value ?? 0;
      });
    });
  }

  void _showSwitchProfileDialog() {
    showDialog(context: context, builder: (c){
      return AlertDialog(
        contentPadding: EdgeInsets.all(20),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_10))),
        content: TMTTextWidget(title: "Are you sure you want to switch to your buyer profile?", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w700, color: AppColor.textColor), textAlign: TextAlign.center,),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.green),
                ),
                child: TMTTextWidget(title: 'Cancel' , style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.of(context).pop(false); // Return false when cancelled
                },
              ),
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.primaryBG),
                ),
                child: TMTTextWidget(title: 'Switch', style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Get.offAllNamed(AppRoutes.dashBoardScreen);
                },
              ),
            ],
          ),
        ],
        actionsPadding: EdgeInsets.only(bottom: HeightDimension.h_10),
      );
    });
  }
}
