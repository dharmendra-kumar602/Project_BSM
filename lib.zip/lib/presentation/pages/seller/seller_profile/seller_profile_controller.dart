import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/put_update_seller_profile_request.dart';
import 'package:take_my_tack/data/model/response/get_seller_profile_response.dart';
import 'package:take_my_tack/data/repository_implementation/auth_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/seller_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';


class SellerProfileController extends GetxController {

  SellerRepositoryImpl sellerRepositoryImpl = SellerRepositoryImpl();
  AuthRepositoryImpl authRepositoryImpl = AuthRepositoryImpl();

  SellerProfileData? sellerProfileData;

  final TextEditingController firstNameTextController = TextEditingController();
  final TextEditingController lastNameTextController = TextEditingController();
  final TextEditingController emailTextController = TextEditingController();
  final TextEditingController sellerCityController = TextEditingController();
  final TextEditingController sellerStateController = TextEditingController();
  final TextEditingController postCodeController = TextEditingController();
  final TextEditingController countryController = TextEditingController();
  final TextEditingController addressLineController = TextEditingController();
  final TextEditingController addressLine2Controller = TextEditingController();
  final TextEditingController contactNumberController = TextEditingController();
  final FocusNode sellerCityNode = FocusNode();
  final FocusNode sellerStateNode = FocusNode();
  final FocusNode postCodeNode = FocusNode();
  final FocusNode countryNode = FocusNode();
  final FocusNode addressLineNode = FocusNode();
  final FocusNode addressLine2Node = FocusNode();
  final FocusNode emailNode = FocusNode();
  final FocusNode firstNameNode = FocusNode();
  final FocusNode lastNameNode = FocusNode();
  final FocusNode contactNumberNode = FocusNode();

  File? imageFile;
  bool isKeyboardVisible = false;
  String selectedCountryDropdown = "";

  /*
   Method use to get seller user profile.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getSellerProfile (BuildContext context) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await sellerRepositoryImpl.getSellerUserProfile();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              sellerProfileData = right.data;
             update([GetControllerBuilders.sellerProfileScreenController]);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get seller user profile.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void setSellerProfileData (BuildContext context) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await sellerRepositoryImpl.getSellerUserProfile();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) async {
            if (right.responseHeader?.error == null) {
              sellerProfileData = right.data;
              await setDataInControllers(right.data);
              update([GetControllerBuilders.sellerProfileScreenController]);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to logout user.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void postLogoutUser (BuildContext context) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await authRepositoryImpl.logout();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              TMTLocalStorage.clear();
              Get.offAllNamed(AppRoutes.dashBoardScreen);
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// update seller profile
  void updateSellerProfile(BuildContext context, Function callback) {
    var params = PutUpdateSellerProfileRequest(
        requestHeader: DioUtils.getRequestHeaderModel(),
      contact: contactNumberController.text,
      firstName: firstNameTextController.text,
      lastName: lastNameTextController.text,
      email: emailTextController.text,
      addressLine1 : addressLineController.text,
      addressLine2: addressLine2Controller.text,
      city: sellerCityController.text,
      country: selectedCountryDropdown,
      county: sellerStateController.text,
      postCode: postCodeController.text,
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await sellerRepositoryImpl.updateSellerProfile(params, TMTLocalStorage.getSellerId().toString());
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.status == "SUCCESS") {
              TMTToast.showSuccessToast(context, right.message ?? '');
              _clearControllers();
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first.toString() ?? "");
            }
          });
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// set data in controllers
  Future<void> setDataInControllers(SellerProfileData? data) async {
    firstNameTextController.text = data?.firstName ?? "";
    lastNameTextController.text = data?.lastName ?? "";
    emailTextController.text = data?.email ?? "";
    addressLineController.text = data?.sellerStores?.first.addressLine1 ?? "";
    addressLine2Controller.text = data?.sellerStores?.first.addressLine2 ?? "";
    addressLine2Controller.text = data?.sellerStores?.first.addressLine2 ?? "";
    sellerCityController.text = data?.sellerStores?.first.city ?? "";
    postCodeController.text = data?.sellerStores?.first.postCode ?? "";
    selectedCountryDropdown = data?.sellerStores?.first.country ?? "";
    sellerStateController.text = data?.sellerStores?.first.county ?? "";
    contactNumberController.text = data?.sellerStores?.first.contact ?? "";
    imageFile = await _convertUrlToFile(data?.profilePicture ?? "");
  }

  /// convert URL into File
  Future<File?> _convertUrlToFile(String url) async {
    Dio dio = Dio();
    try {
      final response = await dio.get(url,
          options: Options(responseType: ResponseType.bytes));
      if (response.statusCode == 200) {
        final bytes = response.data as List<int>;
        final tempDir = await getTemporaryDirectory();
        final file = File('${tempDir.path}/temp_image_profile.png');
        await file.writeAsBytes(bytes);
        return file;
      } else {
        return null;
      }
    } catch (e) {
      print('Error downloading file: $e');
      return null;
    }
  }

  void _clearControllers() {
    firstNameTextController.clear();
    lastNameTextController.clear();
    emailTextController.clear();
    addressLineController.clear();
    addressLine2Controller.clear();
    addressLine2Controller.clear();
    sellerCityController.clear();
    postCodeController.clear();
    sellerStateController.clear();
    selectedCountryDropdown = "";
    contactNumberController.clear();
    imageFile = null;
  }
}