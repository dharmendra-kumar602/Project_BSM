import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:take_my_tack/data/model/request/put_update_profile_picture_request.dart';
import 'package:take_my_tack/data/model/response/get_countries_list_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/seller_profile/seller_profile_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/tmt_media_picker.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/tmt_webview.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_scaffold.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';

class SellerEditProfileScreen extends StatefulWidget {
  const SellerEditProfileScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SellerEditProfileScreenState();
}

class _SellerEditProfileScreenState extends State<SellerEditProfileScreen> {
  final SellerProfileController _controller =
      Get.find<SellerProfileController>();

  final _formKey = GlobalKey<FormState>();

  List<Country> _countryList = [];

  @override
  void initState() {
    super.initState();
    _loadCountryList();
    _controller.setSellerProfileData(context);
  }

  Future<void> _loadCountryList() async {
    Get.find<DashboardController>().getCountriesList(context, (countries) {
      setState(() {
        setState(() {
          _countryList = countries ?? [];
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SellerProfileController>(
        id: GetControllerBuilders.sellerProfileScreenController,
        init: _controller,
        builder: (controller) {
          return Scaffold(
            body: Column(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height / 9.3,
                  decoration: BoxDecoration(boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      spreadRadius: 2,
                      blurRadius: 3,
                      offset: const Offset(0, 3), // changes position of shadow
                    ),
                  ], color: AppColor.neutral_100),
                  child: Padding(
                    padding: EdgeInsets.only(
                        bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Row(
                        children: [
                          InkWell(
                            onTap: () {
                              Get.back();
                            },
                            child: Row(
                              children: [
                                HorizontalSpacing(WidthDimension.w_10),
                                SizedBox(
                                  width: WidthDimension.w_40,
                                  height: HeightDimension.h_30,
                                  child: Center(
                                    child: Image.asset(
                                      TMTImages.icBack,
                                      color: AppColor.neutral_800,
                                      fit: BoxFit.contain,
                                      scale: 3.4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          TMTTextWidget(
                            title: "Edit Profile",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        VerticalSpacing(HeightDimension.h_15),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Stack(
                              children: [
                                SizedBox(
                                  height: HeightDimension.h_110,
                                  width: HeightDimension.h_110,
                                  child: (_controller.imageFile != null)
                                      ? ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100.0),
                                          child: Image.file(
                                            _controller.imageFile!,
                                            fit: BoxFit.cover,
                                          ),
                                        )
                                      : Image.asset(_controller
                                                  .sellerProfileData?.gender ==
                                              "MALE"
                                          ? TMTImages.icProfileMen
                                          : TMTImages.icProfileFemale),
                                ),
                                Positioned(
                                  bottom: 0,
                                  right: 0,
                                  child: GestureDetector(
                                    onTap: () {
                                      _profilePicker(context);
                                    },
                                    child: TMTRoundedCornersContainer(
                                      bgColor: AppColor.neutral_100,
                                      padding: EdgeInsets.all(6),
                                      height: HeightDimension.h_32,
                                      width: HeightDimension.h_32,
                                      child: Image.asset(TMTImages.icCamera),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_25),
                        Form(
                          key: _formKey,
                          child: Padding(
                            padding: EdgeInsets.only(
                                left: WidthDimension.w_10,
                                right: WidthDimension.w_10),
                            child: Column(
                              children: [
                                TMTTextField(
                                    hintText: "First Name",
                                    controller:
                                        _controller.firstNameTextController,
                                    textInputAction: TextInputAction.done,
                                    focusNode: _controller.firstNameNode,
                                    onChanged: (v) {
                                      setState(() {});
                                    },
                                    onFieldSubmitted: (v) {
                                      _controller.lastNameNode.requestFocus();
                                    }),
                                VerticalSpacing(HeightDimension.h_8),
                                TMTTextField(
                                    hintText: "Last Name",
                                    controller:
                                        _controller.lastNameTextController,
                                    textInputAction: TextInputAction.done,
                                    focusNode: _controller.lastNameNode,
                                    onChanged: (v) {
                                      setState(() {});
                                    },
                                    onFieldSubmitted: (v) {
                                      _controller.emailNode.requestFocus();
                                    }),
                                VerticalSpacing(HeightDimension.h_8),
                                TMTTextField(
                                  hintText: "Email Address",
                                  textInputAction: TextInputAction.done,
                                  controller: _controller.emailTextController,
                                  focusNode: _controller.emailNode,
                                  onChanged: (v) {
                                    setState(() {});
                                  },
                                  inputFormatters: [
                                    FilteringTextInputFormatter.deny(
                                        RegExp(r'\s'))
                                  ],
                                  validator: Validator.emailValidate,
                                  keyboardType: TextInputType.emailAddress,
                                  onFieldSubmitted: (v) {
                                    _controller.addressLineNode.requestFocus();
                                  },
                                ),
                                VerticalSpacing(HeightDimension.h_8),
                                TMTTextField(
                                    contentPadding: const EdgeInsets.only(
                                        left: 18,
                                        right: 18,
                                        top: 10,
                                        bottom: 10),
                                    hintText: "Address Line",
                                    controller:
                                        _controller.addressLineController,
                                    focusNode: _controller.addressLineNode,
                                    onChanged: (v) {
                                      setState(() {});
                                    },
                                    validator: Validator.addressLineValidate,
                                    onFieldSubmitted: (v) {
                                      _controller.addressLine2Node
                                          .requestFocus();
                                    }),
                                VerticalSpacing(HeightDimension.h_10),
                                TMTTextField(
                                    contentPadding: const EdgeInsets.only(
                                        left: 18,
                                        right: 18,
                                        top: 10,
                                        bottom: 10),
                                    hintText: "Address Line 2",
                                    controller:
                                        _controller.addressLine2Controller,
                                    isRequired: false,
                                    focusNode: _controller.addressLine2Node,
                                    onChanged: (v) {
                                      setState(() {});
                                    },
                                    onFieldSubmitted: (v) {
                                      _controller.sellerCityNode.requestFocus();
                                    }),
                                VerticalSpacing(HeightDimension.h_10),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Flexible(
                                      flex: 1,
                                      child: TMTTextField(
                                          hintText: "City",
                                          controller:
                                              _controller.sellerCityController,
                                          focusNode: _controller.sellerCityNode,
                                          onChanged: (v) {
                                            setState(() {});
                                          },
                                          validator: Validator.cityValidate,
                                          onFieldSubmitted: (v) {
                                            _controller.sellerStateNode
                                                .requestFocus();
                                          }),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_6),
                                    Flexible(
                                      flex: 1,
                                      child: TMTTextField(
                                          hintText: "County",
                                          controller:
                                              _controller.sellerStateController,
                                          focusNode:
                                              _controller.sellerStateNode,
                                          onChanged: (v) {
                                            setState(() {});
                                          },
                                          validator: Validator.countyValidate,
                                          onFieldSubmitted: (v) {
                                            _controller.postCodeNode
                                                .requestFocus();
                                          }),
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_5),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Flexible(
                                      flex: 1,
                                      child: TMTTextField(
                                          hintText: "Post Code",
                                          controller:
                                              _controller.postCodeController,
                                          focusNode: _controller.postCodeNode,
                                          onChanged: (v) {
                                            setState(() {});
                                          },
                                          keyboardType:
                                              TextInputType.streetAddress,
                                          validator: Validator.postCodeValidate,
                                          onFieldSubmitted: (v) {
                                            _controller.countryNode
                                                .requestFocus();
                                          }),
                                    ),
                                    Flexible(
                                      flex: 1,
                                      child: Container(
                                        padding: EdgeInsets.only(
                                            left: WidthDimension.w_4),
                                        child: DropdownButtonFormField(
                                          padding: EdgeInsets.only(
                                              top: HeightDimension.h_5,
                                              bottom: HeightDimension.h_5,
                                              left: WidthDimension.w_6,
                                              right: WidthDimension.w_2),
                                          hint: TMTTextWidget(
                                              title: _controller
                                                      .selectedCountryDropdown
                                                      .isNotEmpty
                                                  ? _controller
                                                      .selectedCountryDropdown
                                                  : 'Country'),
                                          value: null,
                                          items: _countryList.map((country) {
                                            return DropdownMenuItem<String>(
                                              value: country.name ?? "",
                                              child: TMTTextWidget(
                                                  title: country.name ?? "",
                                                  maxLines: 1,
                                                style: TMTFontStyles.text(color: AppColor.neutral_800, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500),
                                              ),
                                            );
                                          }).toList(),
                                          onChanged: (value) {
                                            setState(() {
                                              _controller
                                                      .selectedCountryDropdown =
                                                  value ?? "";
                                            });
                                          },
                                          isExpanded: true,
                                          decoration: InputDecoration(
                                              contentPadding: EdgeInsets.only(
                                                  left: WidthDimension.w_15,
                                                  right: WidthDimension.w_15,
                                                  top: HeightDimension.h_12,
                                                  bottom: HeightDimension.h_12),
                                              focusedErrorBorder: CustomOutlineInputBorder(
                                                  borderSide: const BorderSide(
                                                      color:
                                                          AppColor.borderColor,
                                                      width: 0.5),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          TMTRadius.r_15)),
                                              errorBorder: CustomOutlineInputBorder(
                                                  borderSide: const BorderSide(
                                                      color:
                                                          AppColor.borderColor,
                                                      width: 0.5),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          TMTRadius.r_15)),
                                              enabledBorder: CustomOutlineInputBorder(
                                                  borderSide: const BorderSide(
                                                      color:
                                                          AppColor.borderColor,
                                                      width: 0.5),
                                                  borderRadius:
                                                      BorderRadius.circular(TMTRadius.r_15)),
                                              floatingLabelBehavior: FloatingLabelBehavior.auto,
                                              focusedBorder: CustomOutlineInputBorder(borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                              border: CustomOutlineInputBorder(
                                                borderSide: const BorderSide(
                                                    color: AppColor.borderColor,
                                                    width: 0.5),
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        TMTRadius.r_15),
                                              ),
                                              labelStyle: TMTFontStyles.text(color: AppColor.neutral_800, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)),
                                        ),
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_4),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_5),
                                TMTTextField(
                                    onTap: () {
                                      setState(() {
                                        _controller.isKeyboardVisible = true;
                                      });
                                    },
                                    contentPadding: const EdgeInsets.only(
                                        left: 18,
                                        right: 18,
                                        top: 10,
                                        bottom: 10),
                                    hintText: "Contact Number",
                                    controller:
                                        _controller.contactNumberController,
                                    focusNode: _controller.contactNumberNode,
                                    onChanged: (v) {
                                      setState(() {});
                                    },
                                    inputFormatters: [
                                      FilteringTextInputFormatter.deny(
                                          RegExp(r'\s'))
                                    ],
                                    keyboardType:
                                        const TextInputType.numberWithOptions(
                                      decimal: true,
                                      signed: true,
                                    ),
                                    validator: Validator.contactNumberValidate,
                                    onFieldSubmitted: (v) {
                                      TMTUtilities.closeKeyboard(context);
                                    }),
                                VerticalSpacing(HeightDimension.h_8),
                                InkWell(
                                  onTap: () {
                                    Get.toNamed(AppRoutes.changePasswordScreen,
                                        arguments: true);
                                  },
                                  child: Container(
                                    margin: EdgeInsets.only(
                                        left: WidthDimension.w_10,
                                        right: WidthDimension.w_10),
                                    padding: EdgeInsets.only(
                                        top: HeightDimension.h_12,
                                        bottom: HeightDimension.h_12,
                                        left: WidthDimension.w_15,
                                        right: WidthDimension.w_15),
                                    decoration: BoxDecoration(
                                        color: AppColor.neutral_100,
                                        border: Border.all(
                                            color: const Color(0xFF595959),
                                            width: 0.5),
                                        borderRadius: const BorderRadius.all(
                                            Radius.circular(TMTRadius.r_10))),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        TMTTextWidget(
                                          title: "CHANGE PASSWORD",
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                VerticalSpacing(HeightDimension.h_10),
                                Row(
                                  children: [
                                    HorizontalSpacing(WidthDimension.w_8),
                                    TMTTextWidget(
                                      title: "Social Links",
                                      style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_18,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_10),
                                Row(
                                  children: [
                                    HorizontalSpacing(WidthDimension.w_8),
                                    GestureDetector(
                                      onTap: () async {
                                        String fbProtocolUrl;
                                        if (Platform.isIOS) {
                                          fbProtocolUrl = 'fb://profile/100063900918126';
                                        } else {
                                          fbProtocolUrl = 'fb://page/100063900918126';
                                        }
                                        String fallbackUrl = 'https://www.facebook.com/takemytack';

                                        try {
                                          bool launched = await launch(fbProtocolUrl, forceSafariVC: false);

                                          if (!launched) {
                                            await launch(fallbackUrl, forceSafariVC: false);
                                          }
                                        } catch (e) {
                                          await launch(fallbackUrl, forceSafariVC: false);
                                        }
                                      },
                                      child: SizedBox(
                                        height: HeightDimension.h_32,
                                        width: HeightDimension.h_32,
                                        child: Image.asset(TMTImages.icFacebook),
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_8),
                                    GestureDetector(
                                      onTap: (){
                                        _launchURL(
                                            "https://www.instagram.com/takemytack");
                                      },
                                      child: SizedBox(
                                        height: HeightDimension.h_32,
                                        width: HeightDimension.h_32,
                                        child: Image.asset(TMTImages.icInsta),
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_8),
                                    GestureDetector(
                                      onTap: () async {
                                        var contact = "+447459063015";
                                        var androidUrl = "whatsapp://send?phone=$contact&text=Hi";
                                        var iosUrl = "https://wa.me/$contact?text=${Uri.parse('Hi')}";

                                        try{
                                          if(Platform.isIOS){
                                            await launchUrl(Uri.parse(iosUrl));
                                          }
                                          else{
                                            await launchUrl(Uri.parse(androidUrl));
                                          }
                                        } on Exception{
                                          launchUrl(Uri.parse('https://wa.me/$contact?text=Hi'),
                                              mode: LaunchMode.externalApplication);
                                        }
                                      },
                                      child: SizedBox(
                                        height: HeightDimension.h_32,
                                        width: HeightDimension.h_32,
                                        child: Image.asset(TMTImages.icWhatsapp),
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_8),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_20),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(
                      left: WidthDimension.w_15,
                      right: WidthDimension.w_15,
                      top: HeightDimension.h_10,
                      bottom: HeightDimension.h_10),
                  decoration: BoxDecoration(boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 3,
                      blurRadius: 5,
                      offset: const Offset(0, 3), // changes position of shadow
                    ),
                  ], color: AppColor.neutral_100),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            if (_formKey.currentState!.validate()) {
                              _controller.updateSellerProfile(context, () {
                                Get.back();
                              });
                            }
                            TMTUtilities.closeKeyboard(context);
                          },
                          child: Container(
                            padding: EdgeInsets.only(
                                top: HeightDimension.h_12,
                                bottom: HeightDimension.h_12,
                                left: WidthDimension.w_18,
                                right: WidthDimension.w_18),
                            decoration: BoxDecoration(
                                color: AppColor.primaryBG,
                                border: Border.all(
                                    color: AppColor.primaryBG, width: 1),
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(TMTRadius.r_30))),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                TMTTextWidget(
                                  title: "SAVE CHANGES",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_18,
                                    color: AppColor.neutral_100,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          );
        });
  }

  /// For launching url
  _launchURL(String url) async {
    final uri = url;
    if (await canLaunchUrlString(uri)) {
      await launchUrlString(uri);
    } else {
      throw 'Could not launch $url';
    }
  }

  /// upload image
  void uploadFile() {
    Get.find<DashboardController>().updateBuyerProfilePicture(context, PutUpdateProfilePictureRequest(profilePicture: _controller.imageFile!), (){
      setState(() {
        _controller.setSellerProfileData(context);
      });
    });
  }

  /// profile picker
  _profilePicker (BuildContext context) {
    showDialog(
      context: context,
      builder: (c) => Material(
        color: Colors.transparent,
        child: Center(
          child: TMTRoundedCornersContainer(
            borderRadius: BorderRadius.circular(20),
            bgColor: AppColor.neutral_100,
            width: double.infinity,
            padding: EdgeInsets.only(top: HeightDimension.h_20, bottom: HeightDimension.h_20),
            margin: EdgeInsets.only(left: WidthDimension.w_50, right: WidthDimension.w_50),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
               InkWell(
                 onTap: () async {
                   Navigator.pop(context);
                   XFile? pickedFile = await TMTMediaPicker(context).pickImageFromCamera(imageQuality: 40);
                   if (pickedFile != null) {
                     var v = await TMTUtilities.isFileBiggerThan1MB(pickedFile);
                     if (v) {
                       if (!mounted) return;
                       TMTToast.showErrorToast(context, "Image size must be less than 2MB.");
                       return;
                     }
                     _controller.imageFile =
                         File(pickedFile.path);
                     if (_controller.imageFile !=
                         null) {
                       if (!mounted) return;

                       ///const Loading().start(context);
                       uploadFile();
                     }
                   }
                 },
                 child: Container(
                   child: Column(
                     children: [
                       VerticalSpacing(HeightDimension.h_8),
                       TMTTextWidget(title: "Take Photo", style: TMTFontStyles.text(
                         fontSize: TMTFontSize.sp_16,
                         color: Colors.blue,
                         fontWeight: FontWeight.w600,
                       ),),
                       VerticalSpacing(HeightDimension.h_8),
                       Container(
                         width: double.infinity,
                         height: 0.5,
                         color: AppColor.neutral_800,
                       ),
                     ],
                   ),
                 ),
               ),
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    XFile? pickedFile = await TMTMediaPicker(context).pickImageFromGallery(imageQuality: 40);
                    if (pickedFile != null) {
                      var v = await TMTUtilities.isFileBiggerThan1MB(pickedFile);
                      if (v) {
                        if (!mounted) return;
                        TMTToast.showErrorToast(context, "Image size must be less than 2MB.");
                        return;
                      }
                      _controller.imageFile =
                          File(pickedFile.path);
                      if (_controller.imageFile !=
                          null) {
                        if (!mounted) return;

                        ///const Loading().start(context);
                        uploadFile();
                      }
                    }
                  },
                  child: Container(
                    child: Column(
                      children: [
                        VerticalSpacing(HeightDimension.h_8),
                        TMTTextWidget(title: "Choose photo", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_16,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),),
                        VerticalSpacing(HeightDimension.h_8),
                        Container(
                          width: double.infinity,
                          height: 0.5,
                          color: AppColor.neutral_800,
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: (){
                    Navigator.pop(context);
                  },
                  child: Container(
                    child: Column(
                      children: [
                        VerticalSpacing(HeightDimension.h_8),
                        TMTTextWidget(title: "Cancel", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_16,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),),
                        VerticalSpacing(HeightDimension.h_8),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
