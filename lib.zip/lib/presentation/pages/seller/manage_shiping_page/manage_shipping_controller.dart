import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/model/request/put_shipping_details_request.dart';
import 'package:take_my_tack/data/model/response/get_shipping_details_response.dart';
import 'package:take_my_tack/data/repository_implementation/seller_repository_impl.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';


class ManageShippingController extends GetxController {

  final SellerRepositoryImpl _sellerRepositoryImpl = SellerRepositoryImpl();
  ShippingData? data;

  bool isFreeShipping = false;
  bool isLocalShipping = false;

  TextEditingController minimumAmountController = TextEditingController();
  TextEditingController localPickupCost = TextEditingController();

  List<ShippingMethod> shippingMethods = [];

  /// enable free shipping.
  enableFreeShipping(bool value) {
    isFreeShipping = value;
    update([GetControllerBuilders.sellerShippingDetailsScreenController,]);
  }

  /// enable local pickup shipping.
  enableLocalPickupShipping(bool value) {
    isLocalShipping = value;
    update([GetControllerBuilders.sellerShippingDetailsScreenController,]);
  }

  /*
   Method use to get shipping details.
   Parameter- BuildContext context, Function callback
   Return -> No Return type.
  */
  void getShippingDetails (BuildContext context, Function callback, String id) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.getShippingMethods(id);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              data = right.data;
              shippingMethods = right.data?.shippingMethods ?? [];
              _setData(right.data);
              update([GetControllerBuilders.sellerShippingDetailsScreenController]);
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update shipping details.
   Parameter- BuildContext context, Function callback
   Return -> No Return type.
  */
  void updateShippingDetails (BuildContext context, Function callback, String id) {
    var params = PutShippingDetailsRequest(
      isFreeShippingEnabled: isFreeShipping ? 1 : 0,
      freeShippingMinimumCost: data?.freeShippingMinimumCost ?? 0,
      isPickupFromStoreEnabled: isLocalShipping ? 1 : 0,
      pickupFromStoreHandlingCharges: data?.pickupFromStoreHandlingCharges ?? 0,
        countryWiseShipping: shippingMethods.map((e) => CountryWiseShipping(
            country: e.country,
            defaultCost: e.defaultPrice,
            rules: e.rules?.map((re) => ShippingRule(
              ruleType: re.ruleType,
              ruleWeight: re.weightOnRule,
              ruleCost: re.costOnRule,
            )).toList()
        )).toList()
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.putShippingMethods(params, id);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              if (right.message != "Shipment Rules has been created successfully.") {
                TMTToast.showErrorToast(context, right.message);
              } else {
                TMTToast.showSuccessToast(context, right.message);
                callback.call();
              }
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// set data in controller
  void _setData(ShippingData? data) {
    if (data == null) {
      return;
    }
    isFreeShipping = data.isFreeShippingEnabled == 1;
    isLocalShipping = data.isPickupFromStoreEnabled == 1;
    minimumAmountController.text = data.freeShippingMinimumCost?.toStringAsFixed(2) ?? "";
    localPickupCost.text = data.pickupFromStoreHandlingCharges?.toStringAsFixed(2) ?? "";
  }
}