import 'dart:convert';

import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/response/get_countries_list_response.dart';
import 'package:take_my_tack/data/model/response/get_shipping_details_response.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/shipping_input_formatter.dart';
import 'package:take_my_tack/presentation/widgets/tmt_popup/custom_pop_up_menu.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'manage_shipping_controller.dart';

class ManageShippingScreen extends StatefulWidget {
  const ManageShippingScreen({Key? key}) : super(key: key);

  @override
  State<ManageShippingScreen> createState() => _ManageShippingScreenState();
}

class _ManageShippingScreenState extends State<ManageShippingScreen> {

  final ManageShippingController _manageShippingController = Get.put(ManageShippingController());

  List<Country> _countryList = [];

  @override
  void initState() {
    _manageShippingController.getShippingDetails(context, (){}, TMTLocalStorage.getSellerId().toString());
    _loadCountryList();
    super.initState();
  }

  Future<void> _loadCountryList() async {
    Get.find<DashboardController>().getCountriesList(context, (countries) {
      setState(() {
        setState(() {
          _countryList = countries ?? [];
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        bottomNavigationBar: addShippingButton(),
        body: GetBuilder<ManageShippingController>(
            id: GetControllerBuilders.sellerShippingDetailsScreenController,
            init: _manageShippingController,
            builder: (controller) {
              return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: MediaQuery.of(context).size.height / 9.3,
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 2,
                          blurRadius: 3,
                          offset:
                              const Offset(0, 3), // changes position of shadow
                        ),
                      ], color: AppColor.neutral_100),
                      child: Padding(
                        padding: EdgeInsets.only(
                            bottom: HeightDimension.h_5,
                            top: HeightDimension.h_25),
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Row(
                            children: [
                              InkWell(
                                onTap: () {
                                  Get.back();
                                },
                                child: Row(
                                  children: [
                                    HorizontalSpacing(WidthDimension.w_10),
                                    Container(
                                      width: WidthDimension.w_40,
                                      height: HeightDimension.h_30,
                                      child: Center(
                                        child: Image.asset(
                                          TMTImages.icBack,
                                          color: AppColor.neutral_800,
                                          fit: BoxFit.contain,
                                          scale: 3.4,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              TMTTextWidget(
                                title: "Manage Shipping",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_18,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_20),
                            ],
                          ),
                        ),
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_10),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_15,
                              right: WidthDimension.w_15,
                              top: HeightDimension.h_10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TMTTextWidget(
                                    title: "Select Shipping Methods",
                                    style: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_18,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(right: WidthDimension.w_15),
                                    child: CustomPopupMenu(
                                      menuBuilder: () => TMTRoundedCornersContainer(
                                        padding: EdgeInsets.all(8),
                                        borderRadius: BorderRadius.zero,
                                        margin: EdgeInsets.only(left: WidthDimension.w_100),
                                        width: WidthDimension.w_190,
                                        bgColor: AppColor.arrowColor,
                                        borderColor: AppColor.arrowColor,
                                        child: TMTTextWidget(
                                          maxLines: 15,
                                          title: "Select the country you ship too, set the default cost if you want the same shipping cost for all your products or leave at 0. Press the plus sign to add the weight-cost rule shipping charges, i.e. up to 10kg is GBP3 and more than 10 kg up to 20 kg is GBP5",
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.neutral_100,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                      barrierColor: Colors.transparent,
                                      pressType: PressType.singleClick,
                                      arrowColor: AppColor.arrowColor,
                                      position: PreferredPosition.bottom,
                                      child: SizedBox(
                                        height: HeightDimension.h_15,
                                        width: HeightDimension.h_15,
                                        child: Image.asset(TMTImages.icInfo),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              VerticalSpacing(HeightDimension.h_18),
                              TMTTextWidget(
                                title: "Shipping By Weight",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_10),
                              Row(
                                children: [
                                  TMTTextWidget(
                                    title: "Free shipping",
                                    style: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_15,
                                      color: AppColor.neutral_600,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  const Spacer(),
                                  Transform.scale(
                                    scale: 0.7,
                                    child: CupertinoSwitch(
                                        activeColor: Colors.green,
                                        thumbColor: Colors.white,
                                        trackColor: Colors.grey,
                                        value: controller.isFreeShipping,
                                        onChanged: (value) => controller
                                            .enableFreeShipping(value)),
                                  ),
                                ],
                              ),
                              VerticalSpacing(HeightDimension.h_5),
                              TMTTextWidget(
                                title: "Minimum amount for free shipping",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_14,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_8),
                              Padding(
                                padding: const EdgeInsets.only(right: 6),
                                child: TextFormField(
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_14,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  inputFormatters: [DoubleTextInputFormatter()],
                                  enabled: controller.isFreeShipping,
                                  cursorColor: Colors.grey,
                                  textInputAction: TextInputAction.done,
                                  keyboardType: const TextInputType.numberWithOptions(signed: true, decimal: true),
                                  onChanged: (v){
                                    setState(() {
                                      _manageShippingController.data?.freeShippingMinimumCost = int.tryParse(v);
                                    });
                                  },
                                  decoration: InputDecoration(
                                    contentPadding: EdgeInsets.only(left: WidthDimension.w_20),
                                    focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30.0),
                                        borderSide: const BorderSide(
                                            color: Colors.black54,
                                            width: 0.7
                                        )
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30.0),
                                        borderSide: const BorderSide(
                                            color: Colors.black54,
                                            width: 0.7
                                        )
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30.0),
                                      borderSide: BorderSide.none,
                                    ),
                                    fillColor: controller.isFreeShipping ? Colors.transparent : AppColor.lightGrey,
                                    filled: !controller.isFreeShipping,
                                    floatingLabelBehavior: FloatingLabelBehavior.never,
                                    labelText: _manageShippingController.data?.freeShippingMinimumCost?.toStringAsFixed(2) ?? "",
                                    labelStyle: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_8),
                              Row(
                                children: [
                                  TMTTextWidget(
                                    title: "Enable Local Pickup & Add Cost",
                                    style: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_15,
                                      color: AppColor.neutral_600,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  const Spacer(),
                                  Transform.scale(
                                    scale: 0.7,
                                    child: CupertinoSwitch(
                                        activeColor: Colors.green,
                                        thumbColor: Colors.white,
                                        trackColor: Colors.grey,
                                        value: controller.isLocalShipping,
                                        onChanged: (value) => controller
                                            .enableLocalPickupShipping(value)),
                                  ),
                                ],
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 6),
                                child: TextFormField(
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_14,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  inputFormatters: [DoubleTextInputFormatter()],
                                  enabled: controller.isLocalShipping,
                                  cursorColor: Colors.grey,
                                  textInputAction: TextInputAction.done,
                                  keyboardType: const TextInputType.numberWithOptions(
                                    decimal: true,
                                    signed: true,
                                  ),
                                  onChanged: (v){
                                    setState(() {
                                      _manageShippingController.data?.pickupFromStoreHandlingCharges = int.tryParse(v);
                                    });
                                  },
                                  decoration: InputDecoration(
                                    contentPadding: EdgeInsets.only(left: WidthDimension.w_20),
                                    focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30.0),
                                        borderSide: const BorderSide(
                                            color: Colors.black54,
                                            width: 0.7
                                        )
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30.0),
                                        borderSide: const BorderSide(
                                            color: Colors.black54,
                                            width: 0.7
                                        )
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30.0),
                                      borderSide: BorderSide.none,
                                    ),
                                      fillColor: controller.isLocalShipping ? Colors.transparent : AppColor.lightGrey,
                                      filled: !controller.isLocalShipping,
                                    floatingLabelBehavior: FloatingLabelBehavior.never,
                                    labelText:  _manageShippingController.data?.pickupFromStoreHandlingCharges?.toStringAsFixed(2) ?? "",
                                    labelStyle: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_20),
                              ExpansionTileCard(
                                expandedColor: Colors.white,
                                contentPadding: EdgeInsets.zero,
                                borderRadius: BorderRadius.zero,
                                elevation: 0,
                                initiallyExpanded: true,
                                shadowColor: Colors.transparent,
                                trailing: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.black87, size: 28),
                                animateTrailing: true,
                                title: TMTTextWidget(
                                  title:
                                  "Country & Weight Wise Shipping\n Calculation",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                baseColor: Colors.white,
                                children: <Widget>[
                                  ListView.builder(
                                      padding: EdgeInsets.zero,
                                      itemCount: _manageShippingController.shippingMethods.length,
                                      shrinkWrap: true,
                                      physics: const NeverScrollableScrollPhysics(),
                                      itemBuilder: (context, index) {
                                        var shipping = _manageShippingController.shippingMethods[index];
                                        return Stack(
                                          children: [
                                            Container(
                                              padding: EdgeInsets.only(
                                                  bottom: HeightDimension.h_10),
                                              margin: EdgeInsets.only(
                                                  top: HeightDimension.h_20),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                  BorderRadius.circular(10),
                                                  border: Border.all(
                                                      color: Colors.black54,
                                                      width: 0.7)),
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 15, right: 15, top: 25),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    TMTTextWidget(
                                                      title: "Country",
                                                      style: TMTFontStyles.textTeen(
                                                        fontSize: TMTFontSize.sp_13,
                                                        color: AppColor.neutral_800,
                                                        fontWeight: FontWeight.w500,
                                                      ),
                                                    ),
                                                    VerticalSpacing(HeightDimension.h_5),
                                                    Padding(
                                                      padding: EdgeInsets.only(top: HeightDimension.h_8, bottom: HeightDimension.h_4),
                                                      child: ButtonTheme(
                                                        alignedDropdown: true,
                                                        child: DropdownButtonFormField(
                                                          menuMaxHeight: MediaQuery.of(context).size.height / 2.5,
                                                          hint: TMTTextWidget(title: (shipping.country?.isNotEmpty ?? false) ? shipping.country! : 'Country', style: TMTFontStyles.text(color: AppColor.neutral_700, fontSize: TMTFontSize.sp_13, fontWeight: FontWeight.w500),),
                                                          value: null,
                                                          items: _countryList.map((country) {
                                                            return DropdownMenuItem<String>(
                                                              value: country.name ?? "",
                                                              child: TMTTextWidget(title: country.name ?? "", maxLines: 1, style: TMTFontStyles.text(color: AppColor.neutral_800, fontSize: TMTFontSize.sp_13, fontWeight: FontWeight.w500),),
                                                            );
                                                          }).toList(),
                                                          onChanged: (value) {
                                                            setState(() {
                                                              _manageShippingController.shippingMethods[index].country = value;
                                                            });
                                                            },
                                                          decoration: InputDecoration(
                                                              contentPadding: EdgeInsets.only(right: WidthDimension.w_4, top: HeightDimension.h_12, bottom: HeightDimension.h_12),
                                                              focusedErrorBorder:  CustomOutlineInputBorder(
                                                                  borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25)),
                                                              errorBorder:  CustomOutlineInputBorder(
                                                                  borderSide:  const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25)),
                                                              enabledBorder: CustomOutlineInputBorder(
                                                                  borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25)),
                                                              floatingLabelBehavior: FloatingLabelBehavior.auto,
                                                              focusedBorder: CustomOutlineInputBorder(
                                                                  borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25)),
                                                              border: CustomOutlineInputBorder(
                                                                borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25),
                                                              ),
                                                              labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    VerticalSpacing(HeightDimension.h_10),
                                                    TMTTextWidget(
                                                      title: "Country Default cost",
                                                      style: TMTFontStyles.textTeen(
                                                        fontSize: TMTFontSize.sp_13,
                                                        color: AppColor.neutral_800,
                                                        fontWeight: FontWeight.w500,
                                                      ),
                                                    ),
                                                    VerticalSpacing(HeightDimension.h_5),
                                                    TextFormField(
                                                      style: TMTFontStyles.text(
                                                        fontSize: TMTFontSize.sp_14,
                                                        color: AppColor.textColor,
                                                        fontWeight: FontWeight.w500,
                                                      ),
                                                      inputFormatters: [DoubleTextInputFormatter()],
                                                      textInputAction: TextInputAction.done,
                                                      keyboardType: const TextInputType.numberWithOptions(
                                                        decimal: true,
                                                        signed: true,
                                                      ),
                                                      onChanged: (v){
                                                        setState(() {
                                                          _manageShippingController.shippingMethods[index].defaultPrice = int.tryParse(v);
                                                        });
                                                      },
                                                      cursorColor: Colors.grey,
                                                      decoration: InputDecoration(
                                                        contentPadding: EdgeInsets.only(left: WidthDimension.w_20),
                                                        focusedBorder: OutlineInputBorder(
                                                            borderRadius: BorderRadius.circular(30.0),
                                                            borderSide: const BorderSide(
                                                                color: Colors.black54,
                                                                width: 0.7
                                                            )
                                                        ),
                                                        enabledBorder: OutlineInputBorder(
                                                            borderRadius: BorderRadius.circular(30.0),
                                                            borderSide: const BorderSide(
                                                                color: Colors.black54,
                                                                width: 0.7
                                                            )
                                                        ),
                                                        border: OutlineInputBorder(
                                                          borderRadius: BorderRadius.circular(30.0),
                                                          borderSide: BorderSide.none,
                                                        ),
                                                          labelText: shipping.defaultPrice?.toStringAsFixed(2) ?? "",
                                                        labelStyle: TMTFontStyles.text(
                                                          fontSize: TMTFontSize.sp_14,
                                                          color: AppColor.textColor,
                                                          fontWeight: FontWeight.w500,
                                                        ),
                                                        floatingLabelBehavior: FloatingLabelBehavior.never,
                                                      ),
                                                    ),
                                                    VerticalSpacing(HeightDimension.h_10),
                                                    VerticalSpacing(HeightDimension.h_10),
                                                    (shipping.rules?.isEmpty ?? true) ? const SizedBox.shrink() :
                                                    ListView.builder(
                                                        padding: EdgeInsets.zero,
                                                        shrinkWrap: true,
                                                        physics: const NeverScrollableScrollPhysics(),
                                                        itemCount: shipping.rules?.length ?? 0,
                                                        itemBuilder: (context, i) {
                                                          var rule = shipping.rules?[i];
                                                          return Column(
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              VerticalSpacing(HeightDimension.h_15),
                                                              const Divider(
                                                                height: 1,
                                                                thickness: 1,
                                                                color: Colors.black38,
                                                              ),
                                                              VerticalSpacing(HeightDimension.h_20),
                                                              Row(
                                                                children: [
                                                                  TMTTextWidget(
                                                                    title: "Weight-Cost Rule",
                                                                    style: TMTFontStyles.textTeen(
                                                                      fontSize: TMTFontSize.sp_13,
                                                                      color: AppColor.neutral_800,
                                                                      fontWeight: FontWeight.w500,
                                                                    ),
                                                                  ),
                                                                  const Spacer(),
                                                                  Visibility(
                                                                    visible: shipping.rules?.length != 1,
                                                                    replacement: Container(),
                                                                    child: GestureDetector(
                                                                        onTap: () {
                                                                          setState(() {
                                                                            shipping.rules?.removeAt(i);
                                                                          });
                                                                        },
                                                                        child: const Icon(Icons.delete, color: Colors.grey, size: 20)),
                                                                  ),
                                                                ],
                                                              ),
                                                              VerticalSpacing(HeightDimension.h_15),
                                                              TMTTextWidget(
                                                                title: "Weight Rule",
                                                                style: TMTFontStyles.textTeen(
                                                                  fontSize: TMTFontSize.sp_13,
                                                                  color: AppColor.neutral_800,
                                                                  fontWeight: FontWeight.w500,
                                                                ),
                                                              ),
                                                              VerticalSpacing(HeightDimension.h_5),
                                                              Padding(
                                                                padding: EdgeInsets.only(top: HeightDimension.h_8, bottom: HeightDimension.h_4),
                                                                child: ButtonTheme(
                                                                  alignedDropdown: true,
                                                                  child: DropdownButtonFormField(
                                                                    menuMaxHeight: MediaQuery.of(context).size.height / 2.5,
                                                                    hint: TMTTextWidget(title: (rule?.ruleType?.isNotEmpty ?? false) ? rule!.ruleType! == "MORE_THAN" ? "More Than" : "Up To" : 'Rule Type', style: TMTFontStyles.text(color: AppColor.neutral_700, fontSize: TMTFontSize.sp_13, fontWeight: FontWeight.w500),),
                                                                    value: null,
                                                                    items: ["Up to", "More than"].map((country) {
                                                                      return DropdownMenuItem<String>(
                                                                        value: country,
                                                                        child: TMTTextWidget(title: country, maxLines: 1, style: TMTFontStyles.text(color: AppColor.neutral_800, fontSize: TMTFontSize.sp_13, fontWeight: FontWeight.w500),),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged: (value) {
                                                                      setState(() {
                                                                        _manageShippingController.shippingMethods[index].rules?[i].ruleType = value == "More than" ? "MORE_THAN" : "UPTO";
                                                                      });
                                                                    },
                                                                    decoration: InputDecoration(
                                                                        contentPadding: EdgeInsets.only(right: WidthDimension.w_4, top: HeightDimension.h_12, bottom: HeightDimension.h_12),
                                                                        focusedErrorBorder:  CustomOutlineInputBorder(
                                                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25)),
                                                                        errorBorder:  CustomOutlineInputBorder(
                                                                            borderSide:  const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25)),
                                                                        enabledBorder: CustomOutlineInputBorder(
                                                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25)),
                                                                        floatingLabelBehavior: FloatingLabelBehavior.auto,
                                                                        focusedBorder: CustomOutlineInputBorder(
                                                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25)),
                                                                        border: CustomOutlineInputBorder(
                                                                          borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_25),
                                                                        ),
                                                                        labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              VerticalSpacing(HeightDimension.h_10),
                                                              TMTTextWidget(
                                                                title: "Weight (KG)",
                                                                style: TMTFontStyles.textTeen(
                                                                  fontSize: TMTFontSize.sp_13,
                                                                  color: AppColor.neutral_800,
                                                                  fontWeight: FontWeight.w500,
                                                                ),
                                                              ),
                                                              VerticalSpacing(HeightDimension.h_5),
                                                              TextFormField(
                                                                style: TMTFontStyles.text(
                                                                  fontSize: TMTFontSize.sp_14,
                                                                  color: AppColor.textColor,
                                                                  fontWeight: FontWeight.w500,
                                                                ),
                                                                inputFormatters: [DoubleTextInputFormatter()],
                                                                textInputAction: TextInputAction.done,
                                                                keyboardType: const TextInputType.numberWithOptions(signed: true, decimal: true),
                                                                onChanged: (v){
                                                                  setState(() {
                                                                    _manageShippingController.shippingMethods[index].rules?[i].weightOnRule = int.parse(v);
                                                                  });
                                                                },
                                                                cursorColor: Colors.grey,
                                                                decoration: InputDecoration(
                                                                  contentPadding: EdgeInsets.only(left: WidthDimension.w_20),
                                                                  focusedBorder: OutlineInputBorder(
                                                                      borderRadius: BorderRadius.circular(30.0),
                                                                      borderSide: const BorderSide(
                                                                          color: Colors.black54,
                                                                          width: 0.7
                                                                      )
                                                                  ),
                                                                  enabledBorder: OutlineInputBorder(
                                                                      borderRadius: BorderRadius.circular(30.0),
                                                                      borderSide: const BorderSide(
                                                                          color: Colors.black54,
                                                                          width: 0.7
                                                                      )
                                                                  ),
                                                                  border: OutlineInputBorder(
                                                                    borderRadius: BorderRadius.circular(30.0),
                                                                    borderSide: BorderSide.none,
                                                                  ),
                                                                  labelText: rule?.weightOnRule?.toStringAsFixed(2) ?? "",
                                                                  floatingLabelBehavior: FloatingLabelBehavior.never,
                                                                  labelStyle: TMTFontStyles.text(
                                                                    fontSize: TMTFontSize.sp_14,
                                                                    color: AppColor.textColor,
                                                                    fontWeight: FontWeight.w500,
                                                                  ),
                                                                ),
                                                              ),
                                                              VerticalSpacing(HeightDimension.h_10),
                                                              TMTTextWidget(
                                                                title: "Cost (£)",
                                                                style: TMTFontStyles.textTeen(
                                                                  fontSize: TMTFontSize.sp_13,
                                                                  color: AppColor.neutral_800,
                                                                  fontWeight: FontWeight.w500,
                                                                ),
                                                              ),
                                                              VerticalSpacing(HeightDimension.h_5),
                                                              TextFormField(
                                                                style: TMTFontStyles.text(
                                                                  fontSize: TMTFontSize.sp_14,
                                                                  color: AppColor.textColor,
                                                                  fontWeight: FontWeight.w500,
                                                                ),
                                                                inputFormatters: [DoubleTextInputFormatter()],
                                                                textInputAction: TextInputAction.done,
                                                                keyboardType: const TextInputType.numberWithOptions(
                                                                  decimal: true,
                                                                  signed: true,
                                                                ),
                                                                onChanged: (v){
                                                                  setState(() {
                                                                    _manageShippingController.shippingMethods[index].rules?[i].costOnRule = int.tryParse(v);
                                                                  });
                                                                },
                                                                cursorColor: Colors.grey,
                                                                decoration: InputDecoration(
                                                                  contentPadding: EdgeInsets.only(left: WidthDimension.w_20),
                                                                  focusedBorder: OutlineInputBorder(
                                                                      borderRadius: BorderRadius.circular(30.0),
                                                                      borderSide: const BorderSide(
                                                                          color: Colors.black54,
                                                                          width: 0.7
                                                                      )
                                                                  ),
                                                                  enabledBorder: OutlineInputBorder(
                                                                      borderRadius: BorderRadius.circular(30.0),
                                                                      borderSide: const BorderSide(
                                                                          color: Colors.black54,
                                                                          width: 0.7
                                                                      )
                                                                  ),
                                                                  border: OutlineInputBorder(
                                                                    borderRadius: BorderRadius.circular(30.0),
                                                                    borderSide: BorderSide.none,
                                                                  ),
                                                                    floatingLabelBehavior: FloatingLabelBehavior.never,
                                                                  labelText: rule?.costOnRule?.toStringAsFixed(2) ?? "",
                                                                  labelStyle: TMTFontStyles.text(
                                                                    fontSize: TMTFontSize.sp_14,
                                                                    color: AppColor.textColor,
                                                                    fontWeight: FontWeight.w500,
                                                                  ),
                                                                ),
                                                              ),
                                                              VerticalSpacing(HeightDimension.h_10),
                                                            ],
                                                          );
                                                        }),
                                                    Align(
                                                        alignment: Alignment.centerRight,
                                                        child: GestureDetector(
                                                            onTap: () {
                                                              setState(() {
                                                                _manageShippingController.shippingMethods[index].rules?.add(Rule(
                                                                ));
                                                               });
                                                            },
                                                            child: const Icon(Icons.add_circle_outlined))),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Visibility(
                                              visible: _manageShippingController.shippingMethods.length != 1,
                                              child: Positioned(
                                                  right: 10,
                                                  top: 35,
                                                  child: GestureDetector(
                                                      onTap: () {
                                                        setState(() {
                                                          _manageShippingController.shippingMethods.removeAt(index);
                                                        });
                                                      },
                                                      child: const Icon(
                                                          Icons.delete_forever,
                                                          color: Colors.grey,
                                                          size: 25))),
                                            )
                                          ],
                                        );
                                      }),
                                  VerticalSpacing(HeightDimension.h_8),
                                  Align(
                                      alignment: Alignment.centerRight,
                                      child: Padding(
                                        padding: const EdgeInsets.only(right: 10),
                                        child: GestureDetector(
                                            onTap: addShippingData,
                                            child: const Icon(
                                                Icons.add_circle_outlined)),
                                      )),
                                ],
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                            ],
                          ),
                        ),
                      ),
                    )
                  ]);
            }));
  }

  /// Method use for add shipping.
  void addShippingData() {
    setState(() {
      _manageShippingController.shippingMethods.add(ShippingMethod(
        rules: [],
        defaultPrice: 0,
        country: "",
      ));
    });
  }

  /// Action button.
  Widget addShippingButton() {
    return GestureDetector(
      onTap: () {
        _manageShippingController.updateShippingDetails(context, (){
          Get.back();
        }, TMTLocalStorage.getSellerId().toString());
      },
      child: Container(
        height: HeightDimension.h_45,
        width: WidthDimension.w_190,
        margin: EdgeInsets.symmetric(horizontal: HeightDimension.h_15, vertical: HeightDimension.h_10),
        padding: EdgeInsets.only(
            top: HeightDimension.h_12,
            bottom: HeightDimension.h_12),
        decoration: const BoxDecoration(
            color: AppColor.primaryBG,
            borderRadius: BorderRadius.all(
                Radius.circular(TMTRadius.r_30))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TMTTextWidget(
              title: "ADD SHIPPING",
              style: TMTFontStyles.textTeen(
                fontSize: TMTFontSize.sp_18,
                color: AppColor.neutral_100,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
