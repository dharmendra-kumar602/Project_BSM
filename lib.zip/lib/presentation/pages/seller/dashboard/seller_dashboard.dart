import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/model/user_chat.dart';
import 'package:take_my_tack/data/model/response/get_seller_orders_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/dashboard/seller_dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/order/seller_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_notification/tmt_notification_bell.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'dart:io' show Platform, exit;

class SellerDashboard extends StatefulWidget {
  const SellerDashboard({super.key});

  @override
  State<StatefulWidget> createState() => _SellerDashboardState();
}

class _SellerDashboardState extends State<SellerDashboard> {

  final SellerDashboardController _sellerDashboardController =
  Get.put(SellerDashboardController());

  final SellerOrderController _orderController =
  Get.put(SellerOrderController());

  List<SellerOrderData> sellerOrderList = [];

  int count = 0;

  @override
  void initState() {
    _callApis();
    FirebaseFirestore.instance
        .collection(FirestoreConstants.pathMessageCollection).get().then((value) async {
      if (value.docs.isNotEmpty) {
        await Future.delayed(const Duration(milliseconds: 200));
        List<UserChat> sortedResult = [];
        value.docs.forEach((element) {
          if (element.get("groupChatId").toString().contains("-SELLER_${TMTUtilities.getUserIDFromToken()}")) {
            sortedResult.add(UserChat.fromDocument(element));
          }
        });
        setState(() {
          if (sortedResult.isNotEmpty) {
            count = sortedResult.length;
          }
        });
      }
    }).whenComplete((){
    }).onError((error, stackTrace){
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SellerDashboardController>(
        id: GetControllerBuilders.sellerDashboardController,
        init: _sellerDashboardController,
        builder: (controller) {
        return WillPopScope(
          onWillPop: (){
            showDialog(context: context, builder: (c){
              return AlertDialog(
                contentPadding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_20, right: WidthDimension.w_20, bottom: HeightDimension.h_20),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_10))),
                content: TMTTextWidget(title: "Are you sure you want to exit?", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_16, fontWeight: FontWeight.w700, color: AppColor.neutral_800),),
                actions: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(AppColor.green),
                        ),
                        child: TMTTextWidget(title: 'Cancel' , style: TMTFontStyles.text(color: AppColor.neutral_100),),
                        onPressed: () {
                          Navigator.of(context).pop(false); // Return false when cancelled
                        },
                      ),
                      HorizontalSpacing(WidthDimension.w_8),
                      ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(AppColor.primaryBG),
                        ),
                        child: TMTTextWidget(title: 'Exit', style: TMTFontStyles.text(color: AppColor.neutral_100),),
                        onPressed: () {
                          if (Platform.isAndroid) {
                            SystemNavigator.pop();
                          } else if (Platform.isIOS) {
                            exit(0);
                          }
                        },
                      ),
                      HorizontalSpacing(WidthDimension.w_10),
                    ],
                  ),
                ],
                actionsPadding: EdgeInsets.only(bottom: HeightDimension.h_10),
              );
            });
            return Future.value(false);
          },
          child: Scaffold(
            backgroundColor: AppColor.neutral_100,
            body: Column(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height/9.3,
                  decoration: BoxDecoration(boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      spreadRadius: 2,
                      blurRadius: 3,
                      offset: const Offset(0, 3), // changes position of shadow
                    ),
                  ], color: AppColor.neutral_100),
                  child: Padding(
                    padding: EdgeInsets.only(bottom: HeightDimension.h_10, top: HeightDimension.h_30),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_20),
                          TMTRoundedCornersContainer(
                            borderColor: AppColor.primaryBG,
                            bgColor: AppColor.primaryBG.withOpacity(0.2),
                            padding: EdgeInsets.only(
                                top: HeightDimension.h_2,
                                bottom: HeightDimension.h_2,
                                left: WidthDimension.w_10,
                                right: WidthDimension.w_10),
                            child: TMTTextWidget(
                              title: (TMTUtilities.getUserNameFromToken().isNotEmpty) ? (TMTUtilities.getUserNameFromToken())[0].toUpperCase() : "",
                              style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_15,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                          TMTTextWidget(
                            title: TMTUtilities.getUserNameFromToken(),
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_15,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                          const Spacer(),
                          HorizontalSpacing(WidthDimension.w_10),
                          GestureDetector(
                            onTap: () async {
                              await Get.toNamed(AppRoutes.notificationScreen,
                                  arguments: "SELLER");
                            },
                            child: TMTNotificationBell(isBuyer: false),
                          ),
                          HorizontalSpacing(WidthDimension.w_6),
                          GestureDetector(
                            onTap: () {
                              Get.offAllNamed(AppRoutes.dashBoardScreen);
                            },
                            child: Container(
                              height: HeightDimension.h_32,
                              child: Image.asset(
                                TMTImages.icBuy,
                              ),
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_20),
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 2,
                                blurRadius: 1,
                                offset: const Offset(2, 0), // changes position of shadow
                              ),
                            ],
                            borderRadius: BorderRadius.circular(TMTRadius.r_20),
                            color: AppColor.neutral_100,
                          ),
                          margin: EdgeInsets.only(
                              left: WidthDimension.w_15,
                              right: WidthDimension.w_15,
                              top: HeightDimension.h_15,
                              bottom: HeightDimension.h_15),
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20,
                              right: WidthDimension.w_20,
                              top: HeightDimension.h_15,
                              bottom: HeightDimension.h_15),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    children: [
                                      TMTTextWidget(
                                          title: _sellerDashboardController.data?.totalOrders.toString() ?? "",
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_25,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          )),
                                      VerticalSpacing(HeightDimension.h_4),
                                      TMTTextWidget(
                                          title: "Total Orders",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_18,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          )),
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      TMTTextWidget(
                                          title: _sellerDashboardController.data?.pendingOrderCount.toString() ?? "",
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_25,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          )),
                                      VerticalSpacing(HeightDimension.h_4),
                                      TMTTextWidget(
                                          title: "Pending Orders",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_18,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          )),
                                    ],
                                  ),
                                ],
                              ),
                              VerticalSpacing(HeightDimension.h_10),
                              Container(
                                height: 1,
                                width: double.infinity,
                                color: AppColor.dividerColor,
                              ),
                              VerticalSpacing(HeightDimension.h_10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(right: WidthDimension.w_10),
                                    child: Column(
                                      children: [
                                        TMTTextWidget(
                                            title: _sellerDashboardController.data?.productsCount.toString() ?? "",
                                            style: TMTFontStyles.textTeen(
                                              fontSize: TMTFontSize.sp_25,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w700,
                                            )),
                                        VerticalSpacing(HeightDimension.h_4),
                                        TMTTextWidget(
                                            title: "Total Products",
                                            style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_18,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w400,
                                            )),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(right: WidthDimension.w_30),
                                    child: Column(
                                      children: [
                                        TMTTextWidget(
                                            title: count.toString(),
                                            style: TMTFontStyles.textTeen(
                                              fontSize: TMTFontSize.sp_25,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w700,
                                            )),
                                        VerticalSpacing(HeightDimension.h_4),
                                        TMTTextWidget(
                                            title: "Enquires",
                                            style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_18,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w400,
                                            )),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_10),
                        Row(
                          children: [
                            HorizontalSpacing(WidthDimension.w_10),
                            Expanded(
                              child: GestureDetector(
                                onTap: (){
                                  Get.offNamed(AppRoutes.sellerOrderListingScreen);
                                },
                                child: Container(
                                  height: HeightDimension.h_110,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.2),
                                        spreadRadius: 1,
                                        blurRadius: 1,
                                        offset: const Offset(2, 0), // changes position of shadow
                                      ),
                                    ],
                                    borderRadius: BorderRadius.circular(TMTRadius.r_25),
                                    color: AppColor.neutral_100,
                                  ),
                                  margin: EdgeInsets.only(left: WidthDimension.w_4, right: WidthDimension.w_4),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      VerticalSpacing(HeightDimension.h_5),
                                      TMTRoundedCornersContainer(
                                        borderRadius: BorderRadius.circular(40),
                                        bgColor: AppColor.neutral_100,
                                        padding: const EdgeInsets.all(4.0),
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(TMTRadius.r_10), // Image border
                                          child: SizedBox(
                                            height: HeightDimension.h_55,
                                            width: HeightDimension.h_55,
                                            child: Image.asset(TMTImages.btnOrders, fit: BoxFit.contain),
                                          ),
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                      TMTTextWidget(
                                        title: "Orders",
                                        style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: GestureDetector(
                                onTap: (){
                                  Get.toNamed(AppRoutes.sellerProductListScreen);
                                },
                                child: Container(
                                  height: HeightDimension.h_110,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.2),
                                        spreadRadius: 1,
                                        blurRadius: 1,
                                        offset: const Offset(2, 0), // changes position of shadow
                                      ),
                                    ],
                                    borderRadius: BorderRadius.circular(TMTRadius.r_25),
                                    color: AppColor.neutral_100,
                                  ),
                                  margin: EdgeInsets.only(left: WidthDimension.w_4, right: WidthDimension.w_4),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      VerticalSpacing(HeightDimension.h_5),
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(TMTRadius.r_10), // Image border
                                        child: SizedBox(
                                          height: HeightDimension.h_55,
                                          width: HeightDimension.h_55,
                                          child: Image.asset(TMTImages.btnProducts, fit: BoxFit.contain),
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                      TMTTextWidget(
                                        title: "Products",
                                        style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: GestureDetector(
                                onTap: (){
                                  Get.toNamed(AppRoutes.enquiryListingScreenPage, arguments: false);
                                },
                                child: Container(
                                  height: HeightDimension.h_110,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.2),
                                        spreadRadius: 1,
                                        blurRadius: 1,
                                        offset: const Offset(2, 0), // changes position of shadow
                                      ),
                                    ],
                                    borderRadius: BorderRadius.circular(TMTRadius.r_25),
                                    color: AppColor.neutral_100,
                                  ),
                                  margin: EdgeInsets.only(left: WidthDimension.w_4, right: WidthDimension.w_4),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      VerticalSpacing(HeightDimension.h_5),
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(TMTRadius.r_10), // Image border
                                        child: SizedBox(
                                          height: HeightDimension.h_55,
                                          width: HeightDimension.h_55,
                                          child: Image.asset(TMTImages.btnEnquires, fit: BoxFit.contain),
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                      TMTTextWidget(
                                        title: "Enquire",
                                        style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_10),
                        Row(
                          children: [
                            HorizontalSpacing(WidthDimension.w_10),
                            Expanded(
                              child: GestureDetector(
                                onTap: (){
                                  Get.toNamed(AppRoutes.storageMediaStatsScreen);
                                },
                                child: Container(
                                  height: HeightDimension.h_110,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.2),
                                        spreadRadius: 1,
                                        blurRadius: 1,
                                        offset: const Offset(2, 0), // changes position of shadow
                                      ),
                                    ],
                                    borderRadius: BorderRadius.circular(TMTRadius.r_25),
                                    color: AppColor.neutral_100,
                                  ),
                                  margin: EdgeInsets.only(left: WidthDimension.w_4, right: WidthDimension.w_4),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      VerticalSpacing(HeightDimension.h_5),
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(TMTRadius.r_10), // Image border
                                        child: SizedBox(
                                          height: HeightDimension.h_55,
                                          width: HeightDimension.h_55,
                                          child: Image.asset(TMTImages.btnStorageStats, fit: BoxFit.contain),
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                      TMTTextWidget(
                                        textAlign: TextAlign.center,
                                        title: "Storage \nStats",
                                        style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: GestureDetector(
                                onTap: (){
                                  Get.toNamed(AppRoutes.sellerSupportTicketsScreen, arguments: true);
                                },
                                child: Container(
                                  height: HeightDimension.h_110,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.2),
                                        spreadRadius: 1,
                                        blurRadius: 1,
                                        offset: const Offset(2, 0), // changes position of shadow
                                      ),
                                    ],
                                    borderRadius: BorderRadius.circular(TMTRadius.r_25),
                                    color: AppColor.neutral_100,
                                  ),
                                  margin: EdgeInsets.only(left: WidthDimension.w_4, right: WidthDimension.w_4),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      VerticalSpacing(HeightDimension.h_5),
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(TMTRadius.r_10), // Image border
                                        child: SizedBox(
                                          height: HeightDimension.h_55,
                                          width: HeightDimension.h_55,
                                          child: Image.asset(TMTImages.btnSupport, fit: BoxFit.contain),
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                      TMTTextWidget(
                                        title: "Support",
                                        style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                height: HeightDimension.h_110,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_20),
                        Visibility(
                          visible: sellerOrderList.isNotEmpty,
                          child: Padding(
                            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                            child: TMTTextWidget(
                              textAlign: TextAlign.center,
                              title: "New orders",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_10),
                        ListView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          itemBuilder: (context, index) {
                            var data = sellerOrderList[index];
                            return GestureDetector(
                              onTap: () async {
                                await Get.toNamed(AppRoutes.sellerOrderDetailsScreen, arguments: data)?.then((value){
                                  _callApis();
                                });
                              },
                              child: Container(
                                decoration: const BoxDecoration(
                                  color: AppColor.lightGrey,
                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                ),
                                margin: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_4, bottom: HeightDimension.h_4),
                                padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        TMTTextWidget(
                                          title: "#${data.id.toString()}",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_16,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        TMTRoundedCornersContainer(
                                          padding: EdgeInsets.only(left: WidthDimension.w_8, right: WidthDimension.w_8, top: HeightDimension.h_4, bottom: HeightDimension.h_4),
                                          bgColor: const Color(0xFF336DE9).withOpacity(0.2),
                                          child: TMTTextWidget(
                                            title: data.status ?? "",
                                            style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_10,
                                              color: const Color(0xFF336DE9),
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    TMTTextWidget(
                                      title: data.orderedItems?.first.productName ?? "",
                                      style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    VerticalSpacing(HeightDimension.h_8),
                                    Row(
                                      children: [
                                        TMTTextWidget(
                                          title: "£${data.orderedItems?.first.salePrice?.toStringAsFixed(2) ?? ""}",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_16,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_6),
                                        TMTRoundedCornersContainer(
                                          height: HeightDimension.h_5,
                                          width: HeightDimension.h_5,
                                          bgColor: AppColor.neutral_800,
                                        ),
                                        HorizontalSpacing(WidthDimension.w_6),
                                        TMTTextWidget(
                                          title: "${timeago.format(data.updatedAt ?? DateTime.now(), locale: 'en_short', clock: DateTime.now())}",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            );
                          },
                          itemCount: sellerOrderList.length,
                        ),
                        VerticalSpacing(HeightDimension.h_20),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            bottomNavigationBar: CommonSellerBottomNavigationBar(
                currentSelectedItem: 0, onTap: (index) async {
                  if (index == 4) {
                    Get.offNamed(AppRoutes.sellerProfileScreen);
                  } else if (index == 1) {
                    Get.offNamed(AppRoutes.sellerOrderListingScreen);
                  } else if (index == 2) {
                    Get.offNamed(AppRoutes.sellerProductListScreen);
                  } else if (index == 3) {
                    Get.offNamed(AppRoutes.sellerSupportTicketsScreen);
                  }
            }),
          ),
        );
      }
    );
  }

  /// Convert date time to local format
  String _getTimeAgo(DateTime? createdAt) {
    final now = DateTime.now();
    final difference = now.difference(createdAt ?? DateTime.now());

    if (difference.inSeconds < 60) {
      return '${difference.inSeconds} seconds ago';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes} minutes ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} hours ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      final weeks = difference.inDays ~/ 7;
      return '$weeks weeks ago';
    }
  }

  /// call apis
  void _callApis() {
    _sellerDashboardController.getSellerDashboard(context);
    _orderController.getSellerOrders(context, (v){
      setState(() {
        sellerOrderList = v ?? [];
      });
    }, "Pending");
  }
}