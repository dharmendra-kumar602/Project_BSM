import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/authentication/seller_register_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_checkbox.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/tmt_webview.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class SellerPlanDetailsScreen extends StatefulWidget {
  const SellerPlanDetailsScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SellerPlanDetailsScreenState();
}

class _SellerPlanDetailsScreenState extends State<SellerPlanDetailsScreen> {
  final RegisterToSellController _registerToSellController =
  Get.put(RegisterToSellController());

  @override
  void initState() {
    _registerToSellController.getSellerPlanById(context, "1");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(SizeConfig.safeBlockVertical * 9),
          child: Container(
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 3,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ], color: AppColor.neutral_100),
            child: Column(
              children: [
                VerticalSpacing(SizeConfig.safeBlockVertical * 7),
                Row(
                  children: [
                    InkWell(
                      onTap: (){
                        Get.back();
                      },
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_20),
                          SizedBox(
                            width: WidthDimension.w_18,
                            height: HeightDimension.h_15,
                            child: Image.asset(
                              TMTImages.icBack,
                              color: AppColor.neutral_800,
                              fit: BoxFit.contain,
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_6),
                        ],
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(
                      title: "Sellers Plan Detail",
                      style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_20),
                  ],
                ),
              ],
            ),
          )),
      body: GetBuilder<RegisterToSellController>(
          id: GetControllerBuilders.sellerPlanDetailScreenController,
          init: _registerToSellController,
          builder: (controller) {
            return SingleChildScrollView(
              child: TMTRoundedCornersContainer(
                borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(TMTRadius.r_40),
                    topRight: Radius.circular(TMTRadius.r_40)),
                bgColor: Colors.transparent,
                width: double.infinity,
                child: SingleChildScrollView(
                  physics: const NeverScrollableScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        child: (_registerToSellController.planData?.image != null) ? TMTCachedImage.networkImage(_registerToSellController.planData?.image ?? "", fit: BoxFit.fitWidth): Image.asset(TMTImages.sellerPonyPlanDetail, fit: BoxFit.fitWidth),
                      ),
                      VerticalSpacing(HeightDimension.h_20),
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TMTTextWidget(
                              title: _registerToSellController.planData?.title ?? "",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_20,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_10),
                            TMTTextWidget(
                              maxLines: 50,
                              title: _registerToSellController.planData?.description ?? "",
                              style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_14,
                                color: AppColor.textColor,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_55),
                      Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_20),
                          Row(
                            children: [
                              TMTCustomCheckbox(
                                isChecked: _registerToSellController.agreeToTermsSellerPlan,
                                onChange: (value) {
                                  _registerToSellController.agreeToTermsSellerPlan = value;
                                  _registerToSellController.update([GetControllerBuilders.sellerPlanDetailScreenController]);
                                },
                                backgroundColor: AppColor.neutral_100,
                                borderColor: AppColor.neutral_800,
                                icon: Icons.check,
                                iconColor: AppColor.neutral_800,
                                size: 18,
                                iconSize: 14,
                              ),
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: MediaQuery.of(context).size.width - WidthDimension.w_70,
                                child: Text.rich(
                                    TextSpan(
                                      style: TMTFontStyles.text(
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                          fontSize: TMTFontSize.sp_12
                                      ),
                                      text: 'I agree to the ',
                                      children: [
                                        TextSpan(
                                          text: 'terms of service',
                                          style: TMTFontStyles.text(
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w600,
                                              textDecoration: TextDecoration.underline,
                                              fontSize: TMTFontSize.sp_12
                                          ),
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {
                                              _launchURL(
                                                  "https://tacktalk.co.uk/terms-conditions-%f0%9f%a4%9f/");
                                            },
                                        ),
                                        const TextSpan(
                                          text: '  and  ',
                                        ),
                                        TextSpan(
                                          text: 'privacy policy',
                                          style: TMTFontStyles.textTeen(
                                              color: AppColor.neutral_700,
                                              fontWeight: FontWeight.w600,
                                              textDecoration: TextDecoration.underline,
                                              fontSize: TMTFontSize.sp_12
                                          ),
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {
                                              _launchURL(
                                                  "https://tacktalk.co.uk/privacy-policy");
                                            },
                                        ),
                                      ],
                                    )),
                              )
                            ],
                          ),
                          HorizontalSpacing(WidthDimension.w_20),
                        ],
                      ),
                      VerticalSpacing(HeightDimension.h_10),
                      Padding(
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_15,
                            right: WidthDimension.w_15),
                        child: TMTTextButton(
                          onTap: (){
                            TMTUtilities.closeKeyboard(context);
                            if (!_registerToSellController.agreeToTermsSellerPlan) {
                              TMTToast.showErrorToast(context, "Please agree to our terms and conditions.", title: "Alert");
                              return;
                            }
                            _registerToSellController.subscribeToPlan(context, 1, TMTUtilities.getSellerStoreIdFromToken(TMTLocalStorage.getString(GetXStorageConstants.jwtToken)));
                          },
                          buttonTitle: "CONTINUE",
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                    ],
                  ),
                ),
              ),
            );
          }),
    );
  }

  /// For launching url
  _launchURL(String url) async {
    Navigator.push(context, MaterialPageRoute(builder: (c){
      return TMTWebView(url: url);
    }));
  }
}
