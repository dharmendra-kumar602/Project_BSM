import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/post_register-seller_request.dart';
import 'package:take_my_tack/data/model/request/post_resend_registration_seller_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_resend_signup_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_subscribe_to_seller_request.dart';
import 'package:take_my_tack/data/model/request/post_validate_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_validate_seller_otp_request.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_by_id_response.dart';
import 'package:take_my_tack/data/repository_implementation/auth_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class RegisterToSellController extends GetxController {
  final TextEditingController sellerNameController = TextEditingController();
  final TextEditingController sellerEmailAddressController = TextEditingController();
  final TextEditingController contactNumberController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController sellerCityController = TextEditingController();
  final TextEditingController sellerStateController = TextEditingController();
  final TextEditingController postCodeController = TextEditingController();
  final TextEditingController countryController = TextEditingController();
  final TextEditingController addressLineController = TextEditingController();
  final TextEditingController addressLine2Controller = TextEditingController();

  final FocusNode sellerNameNode = FocusNode();
  final FocusNode sellerEmailAddressNode = FocusNode();
  final FocusNode contactNumberNode = FocusNode();
  final FocusNode descriptionNode = FocusNode();
  final FocusNode sellerCityNode = FocusNode();
  final FocusNode sellerStateNode = FocusNode();
  final FocusNode postCodeNode = FocusNode();
  final FocusNode countryNode = FocusNode();
  final FocusNode addressLineNode = FocusNode();
  final FocusNode addressLine2Node = FocusNode();

  bool agreeToTerms = false;
  bool agreeToTermsSellerPlan = false;
  bool _imNotRobot = false;

  bool get imNotRobotStatus => _imNotRobot;

  AuthRepositoryImpl repositoryImpl = AuthRepositoryImpl();

  String? dateOfBirth;
  String? city;
  String? state;
  String? postCode;
  String? country;
  String selectedCountryDropdown = "";

  PlanData? planData;

  /*
   Method use to change captcha selected status.
   Parameter- bool value.
   Return -> No return type.
  */
  void changeCaptchaStatus(bool value) {
    _imNotRobot = value;
    update([GetControllerBuilders.registerToSellController]);
  }

  ///Method use for strong password
  static bool isPassword(String value) {
    return RegExp(
            r'(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&+=#*-.:;<>{}\/^_~,]{6,20}$')
        .hasMatch(value);
  }

  /*
   Method use to register seller.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void postRegisterUser(BuildContext context) {
    var request = PostRegisterSellerRequest(storeName: sellerNameController.text, email: sellerEmailAddressController.text, addressLine1: addressLineController.text, addressLine2: addressLine2Controller.text, city: sellerCityController.text, storeImage: "png", country: selectedCountryDropdown, postCode: postCodeController.text, contact: contactNumberController.text, about: descriptionController.text, dob: dateOfBirth ?? "", county: sellerStateController.text);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.registerSeller(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
               showDialog(context: context, builder: (context){
                                return Material(
                                  color: AppColor.transparent,
                                  child: Center(
                                    child: TMTRoundedCornersContainer(
                                      height: HeightDimension.h_215,
                                      width: HeightDimension.h_250,
                                      bgColor: AppColor.neutral_100,
                                      padding: const EdgeInsets.all(TMTDimension.padding_15),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          TMTTextWidget(title: "Check your email for verification code", style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_16,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w600,
                                          ), textAlign: TextAlign.center,),
                                          VerticalSpacing(HeightDimension.h_35),
                                          GestureDetector(
                                            onTap: (){
                                              Navigator.pop(context);
                                              Get.offNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: right.store?.id);
                                            },
                                            child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "CONTINUE", textStyle: TMTFontStyles.textTeen(
                                              fontSize: TMTFontSize.sp_18,
                                              color: AppColor.neutral_100,
                                              fontWeight: FontWeight.w700,
                                            ),)),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              });
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to verify otp.
   Parameter- BuildContext context, String email, String otp.
   Return -> No Return type.
  */
  void postVerifyOtp(BuildContext context, int storeId, String otp) {
    var request = PostValidateSellerOtpRequest(requestHeader: DioUtils.getRequestHeaderModel(), storeId: storeId, otp: otp, otpType: 3);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.postVerifyOTP(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              showDialog(
                  barrierDismissible: false,
                  context: context,
                  builder: (c) {
                    return Material(
                      color: Colors.transparent,
                      child: TMTBackButton(
                        onWillPop: (){
                          return Future.value(false);
                        },
                        child: Center(
                          child: SizedBox(
                            width: WidthDimension.w_240,
                            child: Stack(
                              children: [
                                TMTRoundedCornersContainer(
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(TMTRadius.r_15)),
                                  margin:
                                  EdgeInsets.only(top: HeightDimension.h_40),
                                  bgColor: AppColor.neutral_100,
                                  padding: const EdgeInsets.all(20),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      VerticalSpacing(HeightDimension.h_25),
                                      TMTTextWidget(
                                        title: "Verified",
                                        style: TMTFontStyles.text(
                                            color: AppColor.green,
                                            fontWeight: FontWeight.w600,
                                            fontSize: TMTFontSize.sp_16),
                                      ),
                                      VerticalSpacing(HeightDimension.h_10),
                                      TMTTextWidget(
                                          textAlign: TextAlign.center,
                                          title:
                                          "Your account has been verified successfully!",
                                          style: TMTFontStyles.text(
                                              fontWeight: FontWeight.w600,
                                              fontSize: TMTFontSize.sp_16)),
                                      VerticalSpacing(HeightDimension.h_20),
                                      Padding(
                                        padding: EdgeInsets.only(
                                            left: WidthDimension.w_40,
                                            right: WidthDimension.w_40),
                                        child: InkWell(
                                          onTap: () {
                                            getUpdatedToken(context, (){
                                              Navigator.pop(c);
                                              Get.offNamed(
                                                  AppRoutes.sellerPlanDetailsScreen);
                                            });
                                          },
                                          child: TMTTextButton(
                                            buttonTitle: "DONE",
                                            borderRadius: BorderRadius.circular(
                                              TMTRadius.r_35,
                                            ),
                                          ),
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_10),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    TMTRoundedCornersContainer(
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey.withOpacity(0.5),
                                          spreadRadius: 5,
                                          blurRadius: 7,
                                          offset: const Offset(
                                              0, 3), // changes position of shadow
                                        ),
                                      ],
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(50)),
                                      bgColor: AppColor.neutral_100,
                                      padding: const EdgeInsets.all(25),
                                      child: SizedBox(
                                        height: HeightDimension.h_30,
                                        width: HeightDimension.h_30,
                                        child: Image.asset(TMTImages.icTickGreen),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  });
            } else {
              TMTToast.showErrorToast(
                  context, right.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      } else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to resend otp request.
   Parameter- BuildContext context, String email, Function() callback
   Return -> No Return type.
  */
  void resendOtp(BuildContext context, String storeId, Function() callback) {
    var request = PostResendSellerRegistrationOtpRequest(
      requestHeader: DioUtils.getRequestHeaderModel(),
      storeId: storeId,
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.resendSellerOTP(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              TMTToast.showSuccessToast(context, right.message);
              callback.call();
            } else {
              TMTToast.showErrorToast(
                  context, right.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      } else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get all seller plans.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getAllSellerPlans(BuildContext context) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.getAllSellersPlan();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
            update([GetControllerBuilders.sellerPlanDetailScreenController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get seller plan by id.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getSellerPlanById(BuildContext context, String planId) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.getSellerPlanById(planId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              planData = right.data;
              update([GetControllerBuilders.sellerPlanDetailScreenController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to subscribe to a seller plan.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void subscribeToPlan(BuildContext context, int planId, String sellerStoreId) {
    var request = PostSubscribeToSellerPlanRequest(requestHeader: DioUtils.getRequestHeaderModel(), planId: planId, sellerStoreId: sellerStoreId != "null" ? sellerStoreId : "");
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.postSubscribeToPlan(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              showDialog(context: context, builder: (context){
                              return Material(
                                color: Colors.transparent,
                                child: Center(
                                  child: TMTRoundedCornersContainer(
                                    height: HeightDimension.h_215,
                                    width: HeightDimension.h_250,
                                    bgColor: AppColor.neutral_100,
                                    padding: const EdgeInsets.all(TMTDimension.padding_15),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        TMTTextWidget(title: "A seller account request is sent to the Admin.", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_16,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w600,
                                        ), textAlign: TextAlign.center,),
                                        VerticalSpacing(HeightDimension.h_35),
                                        GestureDetector(
                                          onTap: (){
                                            Navigator.pop(context);
                                            Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
                                          },
                                          child: SizedBox(width: WidthDimension.w_140,child: TMTTextButton(buttonTitle: "CONTINUE", textStyle: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_18,
                                            color: AppColor.neutral_100,
                                            fontWeight: FontWeight.w700,
                                          ),)),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            });
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get updated token.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getUpdatedToken(BuildContext context, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.getUpdateToken();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.token.jwtToken.isNotEmpty) {
              TMTLocalStorage.clear();
              TMTLocalStorage.save(
                  GetXStorageConstants.jwtToken, right.token.jwtToken);
              TMTLocalStorage.save(GetXStorageConstants.loggedInTime,
                  DateTime.now().millisecondsSinceEpoch);
              TMTLocalStorage.save(GetXStorageConstants.login, true);
              TMTLocalStorage.save(
                  GetXStorageConstants.rememberMe, true);
              TMTLocalStorage.save(GetXStorageConstants.userType,
                  TMTUtilities.getUserRoleFromToken());

                callback.call();

            } else {
              TMTToast.showErrorToast(context, right.responseHeader.message ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}
