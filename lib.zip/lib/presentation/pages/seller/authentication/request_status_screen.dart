import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/authentication/seller_register_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class RequestStatusScreen extends StatefulWidget {
  const RequestStatusScreen({super.key});

  @override
  State<StatefulWidget> createState() => _RequestStatusScreenState();
}

class _RequestStatusScreenState extends State<RequestStatusScreen> {
  final RegisterToSellController _registerToSellController =
  Get.put(RegisterToSellController());
  final _formKey = GlobalKey<FormState>();
  final platform = const MethodChannel(TMTConstant.captchaMethodChannel);
  String verifyResult = "";

  final isAwaiting = Get.arguments ?? true;

  String? selectedGender;

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        _registerToSellController.getUpdatedToken(context, (){
          Get.offAllNamed(AppRoutes.dashBoardScreen);
        });
        return Future.value(false);
      },
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: PreferredSize(
            preferredSize: Size.fromHeight(SizeConfig.safeBlockVertical * 9),
            child: Container(
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 2,
                  blurRadius: 3,
                  offset: const Offset(0, 3), // changes position of shadow
                ),
              ], color: AppColor.neutral_100),
              child: Column(
                children: [
                  VerticalSpacing(SizeConfig.safeBlockVertical * 7),
                  Row(
                    children: [
                      InkWell(
                        onTap: (){
                          _registerToSellController.getUpdatedToken(context, (){
                            Get.offAllNamed(AppRoutes.dashBoardScreen);
                          });
                        },
                        child: Row(
                          children: [
                            HorizontalSpacing(WidthDimension.w_20),
                            SizedBox(
                              width: WidthDimension.w_18,
                              height: HeightDimension.h_15,
                              child: Image.asset(
                                TMTImages.icBack,
                                color: AppColor.neutral_800,
                                fit: BoxFit.contain,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_6),
                          ],
                        ),
                      ),
                      HorizontalSpacing(WidthDimension.w_6),
                      TMTTextWidget(
                        title: isAwaiting ? "Request awaited" : "Request declined",
                        style: TMTFontStyles.textTeen(
                          fontSize: TMTFontSize.sp_18,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      HorizontalSpacing(WidthDimension.w_20),
                    ],
                  ),
                ],
              ),
            )),
        body: GetBuilder<RegisterToSellController>(
            id: GetControllerBuilders.registerToSellController,
            init: _registerToSellController,
            builder: (controller) {
              return Column(
                children: [
                  const Spacer(),
                  Column(
                    children: [
                      SizedBox(
                        height: HeightDimension.h_75,
                        width: HeightDimension.h_75,
                        child: Image.asset(isAwaiting ? TMTImages.icRequestAwait : TMTImages.icRequestCancel),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      TMTTextWidget(title: isAwaiting ? "Waiting" : "Declined", style: TMTFontStyles.text(
                        fontSize: 20,
                        color: isAwaiting ? AppColor.textColor : AppColor.primaryBG,
                        fontWeight: FontWeight.w700,
                      ),),
                      VerticalSpacing(HeightDimension.h_10),
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                        child: isAwaiting ? TMTTextWidget(
                          textAlign: TextAlign.center,
                          title: "Your seller account request is in progress. You will receive an email on the outcome. Click button below to go back to the home screen", style: TMTFontStyles.text(
                          fontSize: 20,
                          color: AppColor.textColor,
                          fontWeight: FontWeight.w500,
                        ), maxLines: 50,) : TMTTextWidget(
                          textAlign: TextAlign.center,
                          title: "Your seller account request is declined. Click SUPPORT to find out why.", style: TMTFontStyles.text(
                          fontSize: 20,
                          color: AppColor.textColor,
                          fontWeight: FontWeight.w500,
                        ), maxLines: 50,),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Padding(
                    padding: EdgeInsets.only(
                        left: WidthDimension.w_15,
                        right: WidthDimension.w_15),
                    child: TMTTextButton(
                      onTap: (){
                        TMTUtilities.closeKeyboard(context);
                        _registerToSellController.getUpdatedToken(context, (){
                          Get.offAllNamed(AppRoutes.dashBoardScreen);
                        });
                      },
                      buttonTitle: "HOME",
                    ),
                  ),
                  VerticalSpacing(HeightDimension.h_15),
                ],
              );
            }),
      ),
    );
  }

  /// Initialize and show captcha
  Future showCaptcha() async {
    try {
      ///Here we call Native code
      final bool result =
      await platform.invokeMethod(
          TMTConstant.captchaId);
      if (result) {
        _registerToSellController.changeCaptchaStatus(true);
      } else {
        _registerToSellController.changeCaptchaStatus(false);
      }
    } on PlatformException catch (e) {
      e.printError();
      _registerToSellController.changeCaptchaStatus(false);
    }
  }

  /// Show loader for 1 second as buffer while waiting for captcha to initialize
  Future showLoader() async {
    const Loading().start(context);
    await Future.delayed(const Duration(seconds: 2));
    Loading.stop();
  }
}
