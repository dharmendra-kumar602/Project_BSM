import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/pages/seller/authentication/seller_register_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_otp_text_field.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class SellerConfirmationOTPScreen extends StatefulWidget {
  const SellerConfirmationOTPScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SellerConfirmationOTPScreenState();
}

class _SellerConfirmationOTPScreenState extends State<SellerConfirmationOTPScreen> {

  int storeId = Get.arguments ?? "";

  final RegisterToSellController _registerToSellController =
  Get.put(RegisterToSellController());

  int _start = 30;
  Timer? _timer;
  String otp = "";

  void startTimer() {
    const oneSec = Duration(seconds: 1);
    _timer = Timer.periodic(
      oneSec,
          (Timer timer) {
        if (_start == 0) {
          setState(() {
            timer.cancel();
          });
        } else {
          setState(() {
            _start--;
          });
        }
      },
    );
  }

  @override
  void initState() {
    startTimer();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RegisterToSellController>(
        id: GetControllerBuilders.sellerOTPScreenController,
        init: _registerToSellController,
        builder: (controller) {
        return Scaffold(
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: (){
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              Container(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    VerticalSpacing(HeightDimension.h_20),
                    Padding(
                      padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                      child: TMTTextWidget(
                        title: "Please Enter \nVerification Code sent to \n ${TMTUtilities.getUserEmailFromToken()}",
                        style: TMTFontStyles.textTeen(
                            fontWeight: FontWeight.w700,
                            fontSize: TMTFontSize.sp_20,
                            color: AppColor.neutral_800), textAlign: TextAlign.center,
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_40),
                    TMTOtpTextField(
                      margin: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6),
                      textStyle: TMTFontStyles.text(fontWeight: FontWeight.w700, fontSize: TMTFontSize.sp_20, color: AppColor.neutral_800),
                      numberOfFields: 4,
                      showFieldAsBox: true,
                      onCodeChanged: (String code) {
                        setState(() {
                          otp = code;
                        });
                      },
                      //runs when every textfield is filled
                      onSubmit: (String verificationCode){
                        setState(() {
                          otp = verificationCode;
                        });
                      },
                    ),
                    VerticalSpacing(HeightDimension.h_40),
                    Column(
                      children: [
                        TMTTextWidget(title: _start == 0 ? "" : "Resend code in $_start", style: TMTFontStyles.text(fontWeight: FontWeight.w500, color: AppColor.textColor, fontSize: TMTFontSize.sp_14)),
                        VerticalSpacing(HeightDimension.h_2),
                        TMTTextWidget(title: "I don't receive a code!" , style: TMTFontStyles.text(fontWeight: FontWeight.w600, color: AppColor.textColor, fontSize: TMTFontSize.sp_14)),
                        VerticalSpacing(HeightDimension.h_4),
                        GestureDetector(onTap : (){
                          if (_start == 0) {
                            TMTUtilities.closeKeyboard(context);
                            _registerToSellController.resendOtp(context, storeId.toString(), (){
                              setState(() {
                                _start = 30;
                                startTimer();
                              });
                            });
                          }
                        }, child: TMTTextWidget(title: "Resend Code", style: TMTFontStyles.text(textDecoration: TextDecoration.underline, fontWeight: FontWeight.w600, color: _start == 0 ? AppColor.neutral_800 : AppColor.neutral_500, fontSize: TMTFontSize.sp_14),)),
                      ],
                    ),
                    VerticalSpacing(HeightDimension.h_30),
                  ],
                ),
              ),
            ],
          ),
          bottomNavigationBar: InkWell(
            onTap: () {
              TMTUtilities.closeKeyboard(context);
              if (otp.length == 4) {
                _registerToSellController.postVerifyOtp(context, storeId, otp);
              }
            },
            child: Container(
              margin: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, bottom: HeightDimension.h_20),
              padding: EdgeInsets.only(
                  top: HeightDimension.h_12,
                  bottom: HeightDimension.h_12,
                  left: WidthDimension.w_18,
                  right: WidthDimension.w_18),
              decoration: BoxDecoration(
                  color: otp.length == 4 ? AppColor.primaryBG : Colors.grey,
                  border: Border.all(color: otp.length == 4 ? AppColor.primaryBG : Colors.grey, width: 1),
                  borderRadius: const BorderRadius.all(
                      Radius.circular(TMTRadius.r_30))),
              height: HeightDimension.h_50,
              width: double.infinity,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TMTTextWidget(
                    title: "CONFIRM",
                    style: TMTFontStyles.textTeen(
                      fontSize: TMTFontSize.sp_18,
                      color: AppColor.neutral_100,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }
    );
  }
}