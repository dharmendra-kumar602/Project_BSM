import 'dart:async';
import 'dart:convert';
import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:take_my_tack/data/model/response/get_countries_list_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/authentication/seller_register_screen_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_checkbox.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/tmt_webview.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';
import 'dart:io' as _pf;

class RegisterToSellScreen extends StatefulWidget {
  const RegisterToSellScreen({super.key});

  @override
  State<StatefulWidget> createState() => _RegisterToSellScreenState();
}

class _RegisterToSellScreenState extends State<RegisterToSellScreen> {
  final RegisterToSellController _registerToSellController =
  Get.put(RegisterToSellController());
  final _formKey = GlobalKey<FormState>();
  final platform = const MethodChannel(TMTConstant.captchaMethodChannel);
  String verifyResult = "";

  final args = Get.arguments ?? AppRoutes.homeScreen;

  String? selectedGender;
  bool isKeyboardVisible = false;

  List<Country> _countryList = [];

  @override
  void initState() {
    super.initState();
    _loadCountryList();
    KeyboardVisibilityController().onChange.listen((bool visible) {
      setState(() {
        isKeyboardVisible = visible;
      });
    });
  }

  Future<void> _loadCountryList() async {
    Get.find<DashboardController>().getCountriesList(context, (countries) {
      setState(() {
        setState(() {
          _countryList = countries ?? [];
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          Padding(
            padding: EdgeInsets.only(top: MediaQuery.of(context).size.height/9.3),
            child: GetBuilder<RegisterToSellController>(
                id: GetControllerBuilders.registerToSellController,
                init: _registerToSellController,
                builder: (controller) {
                  return SingleChildScrollView(
                    child: Container(
                      color: AppColor.neutral_100,
                      width: double.infinity,
                      child: SingleChildScrollView(
                        physics: const NeverScrollableScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            VerticalSpacing(HeightDimension.h_20),
                            Padding(
                              padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                              child: TMTTextWidget(
                                title: "Seller Registration Form",
                                style: TMTFontStyles.textTeen(
                                    fontWeight: FontWeight.w700,
                                    fontSize: TMTFontSize.sp_20,
                                    color: AppColor.neutral_800),
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_20),
                            Form(
                              key: _formKey,
                              child: Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_10,
                                    right: WidthDimension.w_10),
                                child: Column(
                                  children: [
                                    TMTTextField(
                                        hintText: "Seller Name",
                                        controller: _registerToSellController
                                            .sellerNameController,
                                        focusNode:
                                        _registerToSellController.sellerNameNode,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        validator: Validator.sellerNameValidate,
                                        onFieldSubmitted: (v) {
                                          _registerToSellController.sellerEmailAddressNode.requestFocus();
                                        }
                                    ),
                                    VerticalSpacing(HeightDimension.h_8),
                                    TMTTextField(
                                        hintText: "Seller Email address",
                                        controller: _registerToSellController
                                            .sellerEmailAddressController,
                                        focusNode:
                                        _registerToSellController.sellerEmailAddressNode,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        validator: Validator.emailValidate,
                                        onFieldSubmitted: (v) {
                                          TMTUtilities.closeKeyboard(context);
                                        }
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    GestureDetector(
                                      onTap: () async {
                                        FocusScope.of(context).unfocus();
                                        final values = await showCalendarDatePicker2Dialog(
                                          context: context,
                                          config: CalendarDatePicker2WithActionButtonsConfig(
                                            firstDate: DateTime(1900),
                                            lastDate: DateTime.now().subtract(const Duration(days: 365*16)),
                                          ),
                                          dialogSize: const Size(325, 400),
                                          borderRadius: BorderRadius.circular(15),
                                          dialogBackgroundColor: Colors.white,
                                        );
                                        if (values != null) {
                                          setState(() {
                                            _registerToSellController.dateOfBirth = DateFormat('dd MMMM yyyy').format(values.first!);
                                          });
                                        }
                                      },
                                      child: Padding(
                                        padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6),
                                        child: Row(
                                          children: [
                                            Expanded(
                                              child: TMTRoundedCornersContainer(
                                                height: HeightDimension.h_45,
                                                borderRadius: const BorderRadius.all(Radius.circular(15)),
                                                padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_2),
                                                borderColor: const Color(0xFF595959),
                                                borderWidth: 0.5,
                                                child: Row(
                                                  children: [
                                                    HorizontalSpacing(WidthDimension.w_10),
                                                    TMTTextWidget(title: _registerToSellController.dateOfBirth ?? "Date Of Birth", style: _registerToSellController.dateOfBirth == null ? TMTFontStyles.text(
                                                      fontSize: TMTFontSize.sp_12,
                                                      color: AppColor.textColor,
                                                    ) : TMTFontStyles.text(
                                                      fontSize: TMTFontSize.sp_14,
                                                      color: AppColor.neutral_800,
                                                    ),),
                                                    HorizontalSpacing(WidthDimension.w_10),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    Padding(
                                      padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      child: Row(
                                        children: [
                                          TMTTextWidget(title: "Note: The minimum age required to sell is 16.", style: TMTFontStyles.text(),),
                                        ],
                                      ),
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),

                                    TMTTextField(
                                        contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 10),
                                        hintText: "Address Line",
                                        controller: _registerToSellController
                                            .addressLineController,
                                        focusNode:
                                        _registerToSellController.addressLineNode,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        validator: Validator.addressLineValidate,
                                        onFieldSubmitted: (v) {
                                          _registerToSellController.addressLine2Node.requestFocus();
                                        }
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    TMTTextField(
                                        contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 10),
                                        hintText: "Address Line 2",
                                        controller: _registerToSellController
                                            .addressLine2Controller,
                                        focusNode:
                                        _registerToSellController.addressLine2Node,
                                        isRequired: false,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        onFieldSubmitted: (v) {
                                          _registerToSellController.contactNumberNode.requestFocus();
                                        }
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Flexible(
                                          flex: 1,
                                          child: TMTTextField(
                                              hintText: "City",
                                              controller: _registerToSellController
                                                  .sellerCityController,
                                              focusNode:
                                              _registerToSellController.sellerCityNode,
                                              onChanged: (v){
                                                setState(() {

                                                });
                                              },
                                              validator: Validator.cityValidate,
                                              onFieldSubmitted: (v) {
                                                _registerToSellController.sellerStateNode.requestFocus();
                                              }
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_6),
                                        Flexible(
                                          flex: 1,
                                          child: TMTTextField(
                                              hintText: "County",
                                              controller: _registerToSellController
                                                  .sellerStateController,
                                              focusNode:
                                              _registerToSellController.sellerStateNode,
                                              onChanged: (v){
                                                setState(() {

                                                });
                                              },
                                              validator: Validator.countyValidate,
                                              onFieldSubmitted: (v) {
                                                _registerToSellController.postCodeNode.requestFocus();
                                              }
                                          ),
                                        ),
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_5),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Flexible(
                                          flex: 1,
                                          child: TMTTextField(
                                              hintText: "Post Code",
                                              controller: _registerToSellController
                                                  .postCodeController,
                                              focusNode:
                                              _registerToSellController.postCodeNode,
                                              onChanged: (v){
                                                setState(() {

                                                });
                                              },
                                              keyboardType: TextInputType.streetAddress,
                                              validator: Validator.postCodeValidate,
                                              onFieldSubmitted: (v) {
                                                _registerToSellController.countryNode.requestFocus();
                                              }
                                          ),
                                        ),
                                        Flexible(
                                          flex: 1,
                                          child: Container(
                                            padding: EdgeInsets.only(left: WidthDimension.w_4),
                                            child: DropdownButtonFormField(
                                              padding: EdgeInsets.only(top: HeightDimension.h_5, bottom: HeightDimension.h_5, left: WidthDimension.w_6, right: WidthDimension.w_2),
                                              hint: const TMTTextWidget(title: 'Country'),
                                              value: null,
                                              items: _countryList.map((country) {
                                                return DropdownMenuItem<String>(
                                                  value: country.name ?? "",
                                                  child: TMTTextWidget(title: country.name ?? "", maxLines: 1),
                                                );
                                              }).toList(),
                                              onChanged: (value) {
                                                _registerToSellController.selectedCountryDropdown = value ?? "";
                                                _registerToSellController.update([GetControllerBuilders.loginPageController]);
                                              },
                                              isExpanded: true,
                                              decoration: InputDecoration(
                                                contentPadding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_12, bottom: HeightDimension.h_12),
                                                  focusedErrorBorder:  CustomOutlineInputBorder(
                                                      borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                                  errorBorder:  CustomOutlineInputBorder(
                                                      borderSide:  const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                                  enabledBorder: CustomOutlineInputBorder(
                                                      borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                                  floatingLabelBehavior: FloatingLabelBehavior.auto,
                                                  focusedBorder: CustomOutlineInputBorder(
                                                      borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                                  border: CustomOutlineInputBorder(
                                                    borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
                                                  ),
                                                  labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                              ),
                                            ),
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_4),
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_5),
                                    TMTTextField(
                                        onTap: () {
                                          setState(() {
                                            isKeyboardVisible = true;
                                          });
                                        },
                                        contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 10),
                                        hintText: "Contact Number",
                                        controller: _registerToSellController
                                            .contactNumberController,
                                        focusNode:
                                        _registerToSellController.contactNumberNode,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        inputFormatters: [
                                          FilteringTextInputFormatter.deny(RegExp(r'\s'))
                                        ],
                                        keyboardType: const TextInputType.numberWithOptions(
                                          decimal: true,
                                          signed: true,
                                        ),
                                        validator: Validator.contactNumberValidate,
                                        onFieldSubmitted: (v) {
                                          _registerToSellController.descriptionNode.requestFocus();
                                        }
                                    ),

                                    VerticalSpacing(HeightDimension.h_10),
                                    Row(
                                      children: [
                                        HorizontalSpacing(WidthDimension.w_10),
                                        TMTTextWidget(title: "About Me", style: TMTFontStyles.textTeen(
                                          fontSize: TMTFontSize.sp_16,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w700,
                                        ),),
                                        HorizontalSpacing(WidthDimension.w_10),
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    Padding(
                                      padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6),
                                      child: TMTTextNoHintField(
                                        onTap: () {
                                          setState(() {
                                            isKeyboardVisible = true;
                                          });
                                        },
                                        maxLength: 200,
                                          maxLines: 5,
                                          controller: _registerToSellController
                                              .descriptionController,
                                          focusNode:
                                          _registerToSellController.descriptionNode,
                                          onChanged: (v){
                                            setState(() {

                                            });
                                          },
                                          validator: Validator.descriptionValidate,
                                          onFieldSubmitted: (v) {
                                            TMTUtilities.closeKeyboard(context);
                                          },
                                      ),
                                    ),
                                    VerticalSpacing(HeightDimension.h_8),
                                  ],
                                ),
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_5),
                            Row(
                              children: [
                                HorizontalSpacing(WidthDimension.w_20),
                                Row(
                                  children: [
                                    TMTCustomCheckbox(
                                      isChecked: _registerToSellController.agreeToTerms,
                                      onChange: (value) {
                                        _registerToSellController.agreeToTerms = value;
                                        _registerToSellController.update([GetControllerBuilders.loginPageController]);
                                      },
                                      backgroundColor: AppColor.neutral_100,
                                      borderColor: AppColor.neutral_800,
                                      icon: Icons.check,
                                      iconColor: AppColor.neutral_800,
                                      size: 18,
                                      iconSize: 14,
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width - WidthDimension.w_70,
                                      child: Text.rich(
                                          TextSpan(
                                            style: TMTFontStyles.text(
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w500,
                                                fontSize: TMTFontSize.sp_12
                                            ),
                                            text: 'I agree to the ',
                                            children: [
                                              TextSpan(
                                                text: 'terms of service',
                                                style: TMTFontStyles.text(
                                                    color: AppColor.textColor,
                                                    fontWeight: FontWeight.w600,
                                                    textDecoration: TextDecoration.underline,
                                                    fontSize: TMTFontSize.sp_12
                                                ),
                                                recognizer: TapGestureRecognizer()
                                                  ..onTap = () {
                                                    _launchURL(
                                                        "https://tacktalk.co.uk/terms-conditions-%f0%9f%a4%9f/");
                                                  },
                                              ),
                                              const TextSpan(
                                                text: '  and  ',
                                              ),
                                              TextSpan(
                                                text: 'privacy policy',
                                                style: TMTFontStyles.textTeen(
                                                    color: AppColor.neutral_700,
                                                    fontWeight: FontWeight.w600,
                                                    textDecoration: TextDecoration.underline,
                                                    fontSize: TMTFontSize.sp_12
                                                ),
                                                recognizer: TapGestureRecognizer()
                                                  ..onTap = () {
                                                    _launchURL(
                                                        "https://tacktalk.co.uk/privacy-policy/");
                                                  },
                                              ),
                                            ],
                                          )),
                                    )
                                  ],
                                ),
                                HorizontalSpacing(WidthDimension.w_20),
                              ],
                            ),
                            VerticalSpacing(HeightDimension.h_20),
                            Visibility(
                              visible: false,
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: TMTRoundedCornersContainer(
                                  margin: EdgeInsets.only(left: WidthDimension.w_20),
                                  borderRadius: const BorderRadius.all(Radius.circular(0)),
                                  padding: const EdgeInsets.all(10.0),
                                  borderColor: AppColor.neutral_800,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      GestureDetector(
                                        onTap: () async {
                                          /// Don't open captcha in IOS for now, just enable the checkbox on click (We'll fix it later)
                                          if (_pf.Platform.isIOS) {
                                            _registerToSellController.changeCaptchaStatus(true);
                                            return;
                                          }
                                          if (_registerToSellController.imNotRobotStatus) {
                                            _registerToSellController.changeCaptchaStatus(false);
                                          } else {
                                            /// Run both task in parallel
                                            Future.wait([showLoader(), showCaptcha()]).then((_) {});
                                          }
                                        },
                                        child: AnimatedContainer(
                                            height: 17,
                                            width: 17,
                                            duration: const Duration(milliseconds: 500),
                                            curve: Curves.fastLinearToSlowEaseIn,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(3),
                                                color: _registerToSellController.imNotRobotStatus
                                                    ? AppColor.neutral_100
                                                    : Colors.transparent,
                                                border: Border.all(color: AppColor.neutral_800, width: 1.5)),
                                            child: _registerToSellController.imNotRobotStatus
                                                ? const Icon(
                                              Icons.check,
                                              color: AppColor.neutral_800,
                                              size: 13,
                                            )
                                                : null),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_6),
                                      TMTTextWidget(title: "I'm not a robot", style: TMTFontStyles.text(
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                          fontSize: TMTFontSize.sp_12
                                      ),),
                                      HorizontalSpacing(WidthDimension.w_10),
                                      SizedBox(
                                        height: HeightDimension.h_25,
                                        width: HeightDimension.h_25,
                                        child: Image.asset(TMTImages.icCaptcha),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_15),
                            Padding(
                              padding: EdgeInsets.only(
                                  left: WidthDimension.w_15,
                                  right: WidthDimension.w_15),
                              child: TMTTextButton(
                                onTap: (){
                                  TMTUtilities.closeKeyboard(context);
                                  if (_formKey.currentState!.validate()) {
                                    if (_registerToSellController.agreeToTerms && (_registerToSellController.dateOfBirth?.isNotEmpty ?? false) && (_registerToSellController.selectedCountryDropdown.isNotEmpty)) {
                                     _registerToSellController.postRegisterUser(context);
                                    } else {
                                      if ((_registerToSellController.dateOfBirth?.isEmpty ?? true)) {
                                        TMTToast.showErrorToast(context, "Please select date of birth.", title: "Alert");
                                      } else if (_registerToSellController.selectedCountryDropdown.isEmpty) {
                                        TMTToast.showErrorToast(context, "Please select country.", title: "Alert");
                                      } else if (!_registerToSellController.agreeToTerms) {
                                        TMTToast.showErrorToast(context, "Please agree to our terms and conditions.", title: "Alert");
                                      }
                                    }
                                  }
                                },
                                buttonTitle: "REGISTER",
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_20),
                            Visibility(
                              visible: isKeyboardVisible,
                              child: SizedBox(height: HeightDimension.h_80),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
          ),
          Container(
            height: MediaQuery.of(context).size.height/9.3,
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 3,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ], color: AppColor.neutral_100),
            child: Padding(
              padding: EdgeInsets.only(bottom: HeightDimension.h_8, top: HeightDimension.h_30),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Row(
                  children: [
                    InkWell(
                      onTap: (){
                        Get.back();
                      },
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_20),
                          SizedBox(
                            width: WidthDimension.w_18,
                            height: HeightDimension.h_15,
                            child: Image.asset(
                              TMTImages.icBack,
                              color: AppColor.neutral_800,
                              fit: BoxFit.contain,
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_6),
                        ],
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(
                      title: "Register To Sell",
                      style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// For launching url
  _launchURL(String url) async {
    Navigator.push(context, MaterialPageRoute(builder: (c){
      return TMTWebView(url: url);
    }));
  }

  /// Initialize and show captcha
  Future showCaptcha() async {
    try {
      ///Here we call Native code
      final bool result =
      await platform.invokeMethod(
          TMTConstant.captchaId);
      if (result) {
        _registerToSellController.changeCaptchaStatus(true);
      } else {
        _registerToSellController.changeCaptchaStatus(false);
      }
    } on PlatformException catch (e) {
      e.printError();
      _registerToSellController.changeCaptchaStatus(false);
    }
  }

  /// Show loader for 1 second as buffer while waiting for captcha to initialize
  Future showLoader() async {
    const Loading().start(context);
    await Future.delayed(const Duration(seconds: 2));
    Loading.stop();
  }
}
