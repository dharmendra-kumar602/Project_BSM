import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart' as sSize;
import 'package:intl/intl.dart';
import 'package:take_my_tack/data/model/response/get_seller_details_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_order_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_orders_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/order/seller_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_popup/src/custom_pop_up_menu.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';
import 'package:url_launcher/url_launcher.dart';

class SellerOrderDetailsScreen extends StatefulWidget {
  const SellerOrderDetailsScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SellerOrderDetailsScreenState();
}

class _SellerOrderDetailsScreenState extends State<SellerOrderDetailsScreen> {

  final SellerOrderController _sellerOrderController =
  Get.find<SellerOrderController>();

  TextEditingController cancelOrderController = TextEditingController();

  SellerOrderData orderData = Get.arguments;

  @override
  void initState() {
    _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SellerOrderController>(
        id: GetControllerBuilders.sellerOrderDetailsScreenController,
        init: _sellerOrderController,
        builder: (controller) {
        return Scaffold(
          backgroundColor: AppColor.neutral_100,
          appBar: PreferredSize(
              preferredSize:
              sSize.Size.fromHeight(SizeConfig.safeBlockVertical * 9),
              child: Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset:
                    const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Column(
                  children: [
                    VerticalSpacing(SizeConfig.safeBlockVertical * 7),
                    Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_20),
                              SizedBox(
                                width: WidthDimension.w_18,
                                height: HeightDimension.h_15,
                                child: Image.asset(
                                  TMTImages.icBack,
                                  color: AppColor.neutral_800,
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_6),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_6),
                        Expanded(
                          child: TMTTextWidget(
                            maxLines: 1,
                            title: "Order Detail",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                    VerticalSpacing(HeightDimension.h_8),
                  ],
                ),
              )),
          body: SingleChildScrollView(
            child: Column(
              children: [
                VerticalSpacing(HeightDimension.h_20),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: "Order ID", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_15,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w500,
                      ),),
                      TMTTextWidget(title: "#${_sellerOrderController.data?.id ?? "0"}", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_15,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w500,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_10),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: "Order Date", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_15,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w500,
                      ),),
                      TMTTextWidget(title: DateFormat('dd/MM/yyyy').format(_sellerOrderController.data?.updatedAt ?? DateTime.now()), style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_15,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w500,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_10),
                ListView.builder(
                  itemCount: _sellerOrderController.data?.orderedItems?.length ?? 0,
                  shrinkWrap: true,
                  scrollDirection: Axis.vertical,
                  padding: EdgeInsets.zero,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    var element = _sellerOrderController.data?.orderedItems?[index];
                    return Padding(
                      padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TMTTextWidget(title: element?.productName ?? "", style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),),
                                VerticalSpacing(HeightDimension.h_10),
                                TMTTextWidget(title: "Qty: ${element?.quantity ?? ""}", style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_13,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w500,
                                ),),
                                VerticalSpacing(HeightDimension.h_10),
                                Row(
                                  children: [
                                    TMTTextWidget(title: "Size: ${_getSize(element)}", style: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_13,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.w500,
                                    ),),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    Row(
                                      children: [
                                        TMTTextWidget(title: "Color: ", style: TMTFontStyles.textTeen(
                                          fontSize: TMTFontSize.sp_13,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ),),
                                        _getColor(element?.productVariation?.productAttributeMappings)
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              SizedBox(
                                height: HeightDimension.h_90,
                                width: HeightDimension.h_90,
                                child: TMTCachedImage.networkImage(element?.productImage ?? "", fit: BoxFit.cover),
                              ),
                              VerticalSpacing(HeightDimension.h_10),
                              TMTTextWidget(title: "£${element?.salePrice?.toStringAsFixed(2) ?? 0}", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_16,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w600,
                              ),),
                            ],
                          ),
                        ],
                      ),
                    );
                  }
                ),
                VerticalSpacing(HeightDimension.h_10),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: "Order Summary", style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w700,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_8),
                Container(
                  height: 1.5,
                  width: double.infinity,
                  color: AppColor.lightGrey,
                ),
                VerticalSpacing(HeightDimension.h_8),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TMTTextWidget(title: "Order Amount:", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                          TMTTextWidget(title: "£${orderData.orderAmount?.toStringAsFixed(2) ?? ""}", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                        ],
                      ),
                      VerticalSpacing(HeightDimension.h_5),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TMTTextWidget(title: "VAT:", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                          TMTTextWidget(title: "£${orderData.vat?.toStringAsFixed(2) ?? ""}", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                        ],
                      ),
                      VerticalSpacing(HeightDimension.h_5),
                      orderData.shippingMethod != "PICKUP" ? Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TMTTextWidget(title: "Shipping Charges", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                          TMTTextWidget(title: "£${orderData.shippingCharges?.toStringAsFixed(2) ?? 0}", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                        ],
                      ) : Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TMTTextWidget(title: "Pickup Charges", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                          TMTTextWidget(title: "£${orderData.pickupCharges?.toStringAsFixed(2)}", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                        ],
                      ),
                      VerticalSpacing(HeightDimension.h_5),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TMTTextWidget(title: "Total:", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w500,
                          ),),
                          TMTTextWidget(title: "£${orderData.totalAmount?.toStringAsFixed(2) ?? ""}", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w500,
                          ),),
                        ],
                      ),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_8),
                Container(
                  height: 1.5,
                  width: double.infinity,
                  color: AppColor.lightGrey,
                ),
                VerticalSpacing(HeightDimension.h_15),
                (orderData.orderPaymentMappings?.isEmpty ?? true) ? _getStatusWidget(_sellerOrderController.data?.status ?? "", _sellerOrderController.data) : orderData.orderPaymentMappings?.first.paymentStatus == "PENDING" ?
                Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_15,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w500,
                          ),),
                          Row(
                            children: [
                              TMTRoundedCornersContainer(
                                height: HeightDimension.h_5,
                                width: HeightDimension.h_5,
                                bgColor: AppColor.primary,
                              ),
                              HorizontalSpacing(WidthDimension.w_6),
                              TMTTextWidget(title: "Payment Pending", style: TMTFontStyles.textHarbinger(
                                fontSize: TMTFontSize.sp_15,
                                color: AppColor.primary,
                                fontWeight: FontWeight.w400,
                              ),),
                            ],
                          ),
                        ],
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_15),
                  ],
                ) :
                _getStatusWidget(_sellerOrderController.data?.status ?? "", _sellerOrderController.data),
                Container(
                  height: 1.5,
                  width: double.infinity,
                  color: AppColor.lightGrey,
                ),
                VerticalSpacing(HeightDimension.h_15),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: "Payment Detail", style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w700,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_8),
                Container(
                  height: 1.5,
                  width: double.infinity,
                  color: AppColor.lightGrey,
                ),
                VerticalSpacing(HeightDimension.h_15),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: "Order total", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_15,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w500,
                      ),),
                      TMTTextWidget(title: "£${orderData.totalAmount?.toStringAsFixed(2) ?? ""} (${_sellerOrderController.data?.orderedItems?.length ?? 0} Item)", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_15,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w500,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_5),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: "Payment method", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_15,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w500,
                      ),),
                      TMTTextWidget(title: "Online", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_15,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w500,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_15),
                Container(
                  height: 1.5,
                  width: double.infinity,
                  color: AppColor.lightGrey,
                ),
                VerticalSpacing(HeightDimension.h_15),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: "Buyer Details", style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w700,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_8),
                Container(
                  height: 1.5,
                  width: double.infinity,
                  color: AppColor.lightGrey,
                ),
                VerticalSpacing(HeightDimension.h_15),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: _sellerOrderController.data?.user?.firstName ?? "", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_16,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w500,
                      ),),
                      GestureDetector(
                        onTap: (){
                          SellerData args = SellerData(storeId: 0, name: _sellerOrderController.data?.user?.firstName ?? "", userId: _sellerOrderController.data?.userId ?? 0, description: "", profilePicture: "", isBuyer: false, productId: _sellerOrderController.data?.orderedItems?.first.id.toString() ?? "", productName: _sellerOrderController.data?.orderedItems?.first.productName.toString() ?? "", productImage: _sellerOrderController.data?.orderedItems?.first.productImage.toString() ?? "", productPrice: _sellerOrderController.data?.orderedItems?.first.salePrice.toString() ?? "");
                          Get.toNamed(AppRoutes.enquiryChatPage, arguments: args);
                        },
                        child: TMTTextWidget(title: "Ask a question", style: TMTFontStyles.textHarbinger(
                          fontSize: TMTFontSize.sp_13,
                          color: AppColor.primary,
                          fontWeight: FontWeight.w400,
                        ),),
                      ),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_5),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: _sellerOrderController.data?.deliveryAddress?.address1 ?? "", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_13,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w500,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_5),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title:  "${_sellerOrderController.data?.deliveryAddress?.city ?? ""}, ${_sellerOrderController.data?.deliveryAddress?.state ?? ""}", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_13,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w500,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_5),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title:  "${_sellerOrderController.data?.deliveryAddress?.postCode ?? ""}, ${_sellerOrderController.data?.deliveryAddress?.country ?? ""}", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_13,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w500,
                      ),),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_5),
                Padding(
                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                  child: Row(
                    children: [
                      TMTTextWidget(title: "Email: ", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_13,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w500,
                      ),),
                      GestureDetector(
                        onTap: () async {
                          final Uri params = Uri(
                            scheme: 'mailto',
                            path: _sellerOrderController.data?.user?.email ?? "",
                            query: 'subject=Take My Tack', //add subject and body here
                          );

                          var url = params.toString();
                          await launchUrl(Uri.parse(url));
                        },
                        child: TMTTextWidget(title: _sellerOrderController.data?.user?.email ?? "", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_13,
                          color: AppColor.primary,
                          fontWeight: FontWeight.w500,
                          textDecoration: TextDecoration.underline
                        ),),
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: _sellerOrderController.data?.user?.contact != null,
                  child: Column(
                    children: [
                      VerticalSpacing(HeightDimension.h_5),
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            TMTTextWidget(title: "Mobile Number: ${_sellerOrderController.data?.user?.contact ?? ""}", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_13,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w500,
                            ),),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                VerticalSpacing(HeightDimension.h_20),
              ],
            ),
          ),
        );
      }
    );
  }

  /// popup for rejection cause
  void _showRejectionPopup(BuildContext context) {
    showDialog(
        barrierDismissible: false,
        context: context, builder: (context){
      return WillPopScope(
        onWillPop: () { return Future.value(false); },
        child: StatefulBuilder(
          builder: (c, setState) {
            return Material(
              color: AppColor.transparent,
              child: Center(
                child: TMTRoundedCornersContainer(
                  height: HeightDimension.h_260,
                  width: double.infinity,
                  margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                  bgColor: AppColor.neutral_100,
                  padding: const EdgeInsets.all(TMTDimension.padding_20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TMTTextWidget(title: "Please enter your reason for rejection", style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_15,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w700,
                      ), textAlign: TextAlign.center,),
                      VerticalSpacing(HeightDimension.h_10),
                      const Spacer(),
                      TextFormField(
                        maxLines: 5,
                        controller: cancelOrderController,
                        onChanged: (v){
                          setState(() {

                          });
                        },
                        validator: Validator.descriptionValidate,
                        onFieldSubmitted: (v) {
                          TMTUtilities.closeKeyboard(context);
                        },
                        textInputAction: TextInputAction.done,
                        keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                            focusedErrorBorder:  CustomOutlineInputBorder(
                                borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                            errorBorder:  CustomOutlineInputBorder(
                                borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                            enabledBorder: CustomOutlineInputBorder(
                                borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                            floatingLabelBehavior: FloatingLabelBehavior.auto,
                            focusedBorder: CustomOutlineInputBorder(
                                borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                            contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 10),
                            border: CustomOutlineInputBorder(
                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10),
                            ),
                            errorMaxLines: 3,
                            filled: false,
                            hintText: "",
                            hintStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500),
                            labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_10),
                      const Spacer(),
                      SizedBox(
                        height: HeightDimension.h_37,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Expanded(
                              child: TMTTextButton(
                                border: Border.all(color: AppColor.neutral_800),
                                color: AppColor.neutral_100,
                                textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_800, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                                onTap: () {
                                  TMTUtilities.closeKeyboard(context);
                                  Navigator.pop(context);
                                }, buttonTitle: 'CANCEL',
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_8),
                            Expanded(
                              child: TMTTextButton(
                                onTap: () {
                                  TMTUtilities.closeKeyboard(context);
                                  if (cancelOrderController.text.isEmpty) {
                                    TMTToast.showErrorToast(context, "Please enter reason for cancellation.", title: "Alert");
                                    return;
                                  }
                                  if (cancelOrderController.text.length >= 200) {
                                    TMTToast.showErrorToast(context, "Reason should not be more than 200 words..", title: "Alert");
                                    return;
                                  }
                                  Navigator.pop(context);
                                  _sellerOrderController.postRejectOrder(context, (){
                                    _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
                                  }, orderData.id.toString(), cancelOrderController.text);
                                }, buttonTitle: 'SUBMIT',
                                textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      );
    });
  }

  /// get color widget
  Widget _getColor(List<ProductAttributeMapping>? productAttributeMappings) {
    try {
      if (productAttributeMappings?.map((e) => e.attribute?.attributeName == "Color").toList().isNotEmpty ?? false) {
        String color = productAttributeMappings?.firstWhere((element) => element.attribute?.attributeName == "Color").value ?? "";
        return TMTRoundedCornersContainer(
          bgColor: color == "Blue" ? Colors.blue : color == "Red" ? Colors.red : color == "Green" ? Colors.green : Colors.black,
          height: HeightDimension.h_14,
          width: HeightDimension.h_14,
        );
      } else {
        return const SizedBox.shrink();
      }
    } catch (e) {
      return const SizedBox.shrink();
    }
  }

  /// get status widget
  _getStatusWidget(String? shippingMethod, SellerOrderDetails? data) {
    if (data?.shippingMethod == "PICKUP") {
      return shippingMethod == "PENDING" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.primary,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "Pending", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.primary,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
          Container(
            height: 1.5,
            width: double.infinity,
            color: AppColor.lightGrey,
          ),
          VerticalSpacing(HeightDimension.h_15),
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "New order request", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    GestureDetector(
                      onTap: (){
                        _sellerOrderController.postAcceptOrder(context, (){
                          _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
                        }, orderData.id.toString());
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.green,
                        child: TMTTextWidget(title: "Accept", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    GestureDetector(
                      onTap: (){
                        _showRejectionPopup(context);
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.primary,
                        child: TMTTextWidget(title: "Reject", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "PROCESSING" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.green,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "Confirmed", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.green,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
          Container(
            height: 1.5,
            width: double.infinity,
            color: AppColor.lightGrey,
          ),
          VerticalSpacing(HeightDimension.h_15),
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Mark order as", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    GestureDetector(
                      onTap: (){
                        _sellerOrderController.postUpdateOrderStatus(context, (){
                          _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
                        }, orderData.id.toString(), "COMPLETE");
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.primary,
                        child: TMTTextWidget(title: "Complete", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      (shippingMethod == "COMPLETE" || shippingMethod == "DELIVERED") ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.green,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "Completed", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.green,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "REJECTED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.primary,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "REJECTED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.primary,
                      fontWeight: FontWeight.w400,
                    ),),
                    HorizontalSpacing(WidthDimension.w_6),
                    CustomPopupMenu(
                      menuBuilder: () => TMTRoundedCornersContainer(
                        borderRadius: BorderRadius.zero,
                        margin: EdgeInsets.only(left: WidthDimension.w_100),
                        width: WidthDimension.w_190,
                        bgColor: AppColor.neutral_100,
                        borderColor: AppColor.arrowColor,
                        child: Column(
                          children: [
                            Container(
                              width: double.infinity,
                              color: AppColor.arrowColor,
                              padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                              child: TMTTextWidget(title: _getReason(data), style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_100,
                                fontWeight: FontWeight.w500,
                              ),),
                            ),
                          ],
                        ),
                      ),
                      barrierColor: Colors.transparent,
                      pressType: PressType.singleClick,
                      arrowColor: AppColor.arrowColor,
                      position: PreferredPosition.top,
                      child: SizedBox(
                        height: HeightDimension.h_15,
                        width: HeightDimension.h_15,
                        child: Image.asset(TMTImages.icInfo),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "CANCELLED" ?
      (isDateWithinLast7Days(data?.orderedItemStatuses?.last.updatedAt ?? DateTime.now()) && orderData.orderPaymentMappings?.first.paymentStatus == "SUCCEEDED") ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.green,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "Refund Approved", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.green,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.primary,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "CANCELLED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.primary,
                      fontWeight: FontWeight.w400,
                    ),),
                    HorizontalSpacing(WidthDimension.w_6),
                    CustomPopupMenu(
                      menuBuilder: () => TMTRoundedCornersContainer(
                        borderRadius: BorderRadius.zero,
                        margin: EdgeInsets.only(left: WidthDimension.w_100),
                        width: WidthDimension.w_190,
                        bgColor: AppColor.neutral_100,
                        borderColor: AppColor.arrowColor,
                        child: Column(
                          children: [
                            Container(
                              width: double.infinity,
                              color: AppColor.arrowColor,
                              padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                              child: TMTTextWidget(title: _getReason(data), style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_100,
                                fontWeight: FontWeight.w500,
                              ),),
                            ),
                          ],
                        ),
                      ),
                      barrierColor: Colors.transparent,
                      pressType: PressType.singleClick,
                      arrowColor: AppColor.arrowColor,
                      position: PreferredPosition.top,
                      child: SizedBox(
                        height: HeightDimension.h_15,
                        width: HeightDimension.h_15,
                        child: Image.asset(TMTImages.icInfo),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      const SizedBox.shrink();
    } else {
      return shippingMethod == "PENDING" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.primary,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "Pending", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.primary,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
          Container(
            height: 1.5,
            width: double.infinity,
            color: AppColor.lightGrey,
          ),
          VerticalSpacing(HeightDimension.h_15),
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "New order request", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    GestureDetector(
                      onTap: (){
                        _sellerOrderController.postAcceptOrder(context, (){
                          _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
                        }, orderData.id.toString());
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.green,
                        child: TMTTextWidget(title: "Accept", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    GestureDetector(
                      onTap: (){
                        _showRejectionPopup(context);
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.primary,
                        child: TMTTextWidget(title: "Reject", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "PROCESSING" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.green,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "Confirmed", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.green,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
          Container(
            height: 1.5,
            width: double.infinity,
            color: AppColor.lightGrey,
          ),
          VerticalSpacing(HeightDimension.h_15),
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Mark order as", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    GestureDetector(
                      onTap: (){
                        _sellerOrderController.postUpdateOrderStatus(context, (){
                          _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
                        }, orderData.id.toString(), "SHIPPED");
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.primary,
                        child: TMTTextWidget(title: "Shipped", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "SHIPPED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.green,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "Shipped", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.green,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
          Container(
            height: 1.5,
            width: double.infinity,
            color: AppColor.lightGrey,
          ),
          VerticalSpacing(HeightDimension.h_15),
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Mark item as", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    GestureDetector(
                      onTap: (){
                        _sellerOrderController.postUpdateOrderStatus(context, (){
                          _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
                        }, orderData.id.toString(), "DELIVERED");
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.primary,
                        child: TMTTextWidget(title: "Delivered", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "DELIVERED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.green,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "DELIVERED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.green,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "REFUND_REQUESTED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: Colors.blue,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "REFUND REQUESTED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: Colors.blue,
                      fontWeight: FontWeight.w400,
                    ),),
                    HorizontalSpacing(WidthDimension.w_6),
                    CustomPopupMenu(
                      menuBuilder: () => TMTRoundedCornersContainer(
                        borderRadius: BorderRadius.zero,
                        margin: EdgeInsets.only(left: WidthDimension.w_100),
                        width: WidthDimension.w_190,
                        bgColor: AppColor.neutral_100,
                        borderColor: AppColor.arrowColor,
                        child: Column(
                          children: [
                            Container(
                              width: double.infinity,
                              color: AppColor.arrowColor,
                              padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                              child: TMTTextWidget(title: _getReason(data), style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_100,
                                fontWeight: FontWeight.w500,
                              ),),
                            ),
                          ],
                        ),
                      ),
                      barrierColor: Colors.transparent,
                      pressType: PressType.singleClick,
                      arrowColor: AppColor.arrowColor,
                      position: PreferredPosition.top,
                      child: SizedBox(
                        height: HeightDimension.h_15,
                        width: HeightDimension.h_15,
                        child: Image.asset(TMTImages.icInfo),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
          Container(
            height: 1.5,
            width: double.infinity,
            color: AppColor.lightGrey,
          ),
          VerticalSpacing(HeightDimension.h_15),
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Refund Request", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    GestureDetector(
                      onTap: (){
                        _sellerOrderController.postUpdateOrderStatus(context, (){
                          _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
                        }, orderData.id.toString(), "REFUND_REQ_APPROVED");
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.green,
                        child: TMTTextWidget(title: "Accept", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    GestureDetector(
                      onTap: (){
                        showDialog(
                            barrierDismissible: false,
                            context: context, builder: (context){
                          return WillPopScope(
                            onWillPop: () { return Future.value(false); },
                            child: StatefulBuilder(
                              builder: (c, setState) {
                                return Material(
                                  color: AppColor.transparent,
                                  child: Center(
                                    child: TMTRoundedCornersContainer(
                                      height: HeightDimension.h_260,
                                      width: double.infinity,
                                      margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      bgColor: AppColor.neutral_100,
                                      padding: const EdgeInsets.all(TMTDimension.padding_20),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          TMTTextWidget(title: "Please enter your reason for rejection", style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_15,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ), textAlign: TextAlign.center,),
                                          VerticalSpacing(HeightDimension.h_10),
                                          const Spacer(),
                                          TextFormField(
                                            maxLines: 5,
                                            controller: cancelOrderController,
                                            onChanged: (v){
                                              setState(() {

                                              });
                                            },
                                            validator: Validator.descriptionValidate,
                                            onFieldSubmitted: (v) {
                                              TMTUtilities.closeKeyboard(context);
                                            },
                                            textInputAction: TextInputAction.done,
                                            keyboardType: TextInputType.text,
                                            decoration: InputDecoration(
                                                focusedErrorBorder:  CustomOutlineInputBorder(
                                                    borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                                errorBorder:  CustomOutlineInputBorder(
                                                    borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                                enabledBorder: CustomOutlineInputBorder(
                                                    borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                                floatingLabelBehavior: FloatingLabelBehavior.auto,
                                                focusedBorder: CustomOutlineInputBorder(
                                                    borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                                contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 10),
                                                border: CustomOutlineInputBorder(
                                                  borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10),
                                                ),
                                                errorMaxLines: 3,
                                                filled: false,
                                                hintText: "",
                                                hintStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500),
                                                labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                            ),
                                          ),
                                          VerticalSpacing(HeightDimension.h_10),
                                          const Spacer(),
                                          SizedBox(
                                            height: HeightDimension.h_37,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.end,
                                              children: [
                                                Expanded(
                                                  child: TMTTextButton(
                                                    border: Border.all(color: AppColor.neutral_800),
                                                    color: AppColor.neutral_100,
                                                    textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_800, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                                                    onTap: () {
                                                      TMTUtilities.closeKeyboard(context);
                                                      Navigator.pop(context);
                                                    }, buttonTitle: 'CANCEL',
                                                  ),
                                                ),
                                                HorizontalSpacing(WidthDimension.w_8),
                                                Expanded(
                                                  child: TMTTextButton(
                                                    onTap: () {
                                                      TMTUtilities.closeKeyboard(context);
                                                      if (cancelOrderController.text.isEmpty) {
                                                        TMTToast.showErrorToast(context, "Please enter reason for cancellation.", title: "Alert");
                                                        return;
                                                      }
                                                      if (cancelOrderController.text.length >= 200) {
                                                        TMTToast.showErrorToast(context, "Reason should not be more than 200 words..", title: "Alert");
                                                        return;
                                                      }
                                                      Navigator.pop(context);
                                                      _sellerOrderController.postUpdateOrderStatus(context, (){
                                                        _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
                                                      }, orderData.id.toString(), "REFUND_REQ_APPROVED");
                                                      cancelOrderController.clear();
                                                    }, buttonTitle: 'SUBMIT',
                                                    textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          );
                        });
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.primary,
                        child: TMTTextWidget(title: "Reject", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "REFUND_REQ_APPROVED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.green,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "REFUND REQUEST APPROVED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.green,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
          Container(
            height: 1.5,
            width: double.infinity,
            color: AppColor.lightGrey,
          ),
          VerticalSpacing(HeightDimension.h_15),
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Mark item as", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    GestureDetector(
                      onTap: (){
                        _sellerOrderController.postUpdateOrderStatus(context, (){
                          _sellerOrderController.getSellerOrderDetails(context, (){}, orderData.id.toString());
                        }, orderData.id.toString(), "REFUND_PRODUCT_COLLECTED");
                      },
                      child: TMTRoundedCornersContainer(
                        padding: EdgeInsets.only(top: HeightDimension.h_4, bottom: HeightDimension.h_4, left: WidthDimension.w_10, right: WidthDimension.w_10),
                        bgColor: AppColor.primary,
                        child: TMTTextWidget(title: "Collected", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "REFUND_REQ_REJECTED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.primary,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "REFUND REQUEST REJECTED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.primary,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "REFUND_PRODUCT_COLLECTED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.green,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "REFUND PRODUCT COLLECTED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.green,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "REFUNDED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.green,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "REFUNDED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.green,
                      fontWeight: FontWeight.w400,
                    ),),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "REJECTED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.primary,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "REJECTED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.primary,
                      fontWeight: FontWeight.w400,
                    ),),
                    HorizontalSpacing(WidthDimension.w_6),
                    CustomPopupMenu(
                      menuBuilder: () => TMTRoundedCornersContainer(
                        borderRadius: BorderRadius.zero,
                        margin: EdgeInsets.only(left: WidthDimension.w_100),
                        width: WidthDimension.w_190,
                        bgColor: AppColor.neutral_100,
                        borderColor: AppColor.arrowColor,
                        child: Column(
                          children: [
                            Container(
                              width: double.infinity,
                              color: AppColor.arrowColor,
                              padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                              child: TMTTextWidget(title: _getReason(data), style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_100,
                                fontWeight: FontWeight.w500,
                              ),),
                            ),
                          ],
                        ),
                      ),
                      barrierColor: Colors.transparent,
                      pressType: PressType.singleClick,
                      arrowColor: AppColor.arrowColor,
                      position: PreferredPosition.top,
                      child: SizedBox(
                        height: HeightDimension.h_15,
                        width: HeightDimension.h_15,
                        child: Image.asset(TMTImages.icInfo),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      shippingMethod == "CANCELLED" ?
      Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TMTTextWidget(title: "Status", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_15,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                Row(
                  children: [
                    TMTRoundedCornersContainer(
                      height: HeightDimension.h_5,
                      width: HeightDimension.h_5,
                      bgColor: AppColor.primary,
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    TMTTextWidget(title: "CANCELLED", style: TMTFontStyles.textHarbinger(
                      fontSize: TMTFontSize.sp_15,
                      color: AppColor.primary,
                      fontWeight: FontWeight.w400,
                    ),),
                    HorizontalSpacing(WidthDimension.w_6),
                    CustomPopupMenu(
                      menuBuilder: () => TMTRoundedCornersContainer(
                        borderRadius: BorderRadius.zero,
                        margin: EdgeInsets.only(left: WidthDimension.w_100),
                        width: WidthDimension.w_190,
                        bgColor: AppColor.neutral_100,
                        borderColor: AppColor.arrowColor,
                        child: Column(
                          children: [
                            Container(
                              width: double.infinity,
                              color: AppColor.arrowColor,
                              padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                              child: TMTTextWidget(title: _getReason(data), style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_100,
                                fontWeight: FontWeight.w500,
                              ),),
                            ),
                          ],
                        ),
                      ),
                      barrierColor: Colors.transparent,
                      pressType: PressType.singleClick,
                      arrowColor: AppColor.arrowColor,
                      position: PreferredPosition.top,
                      child: SizedBox(
                        height: HeightDimension.h_15,
                        width: HeightDimension.h_15,
                        child: Image.asset(TMTImages.icInfo),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
        ],
      ) :
      const SizedBox.shrink();
    }
  }

  /// get size
  String _getSize(element) {
    try {
      return element?.productVariation?.productAttributeMappings?.firstWhere((e) => e.attribute?.attributeName == "Size").value ?? "";
    } catch (e) {
      return "M";
    }
  }

  /// get reason for rejection
  String _getReason(SellerOrderDetails? data) {
    try {
      if (data?.orderedItemStatuses?.isNotEmpty ?? false) {
        String v = data?.orderedItemStatuses?.last.otherReasonText ?? "";
        if (v.isEmpty) {
          return data?.orderedItemStatuses?.last.reason?.text ?? "";
        } else {
          return v;
        }
      } else {
        return "";
      }
    } catch (e) {
      return "";
    }
  }

  /// check if given date is within 7 days
  bool isDateWithinLast7Days(DateTime inputDate) {
    // Get the current date
    DateTime currentDate = DateTime.now();

    // Calculate the date 7 days ago from the current date
    DateTime sevenDaysAgo = currentDate.subtract(const Duration(days: 7));

    // Check if the input date is greater than or equal to seven days ago
    // and less than or equal to the current date
    return inputDate.isAfter(sevenDaysAgo) && inputDate.isBefore(currentDate);
  }
}