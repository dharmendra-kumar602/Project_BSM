
import 'package:app_settings/app_settings.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:page_view_dot_indicator/page_view_dot_indicator.dart';
import 'package:take_my_tack/data/model/response/get_buyer_orders_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/seller/dashboard/seller_dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/order/seller_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_notification/tmt_notification_bell.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class SellerOrderListingScreen extends StatefulWidget {
  const SellerOrderListingScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SellerOrderListingScreenState();
}

class _SellerOrderListingScreenState extends State<SellerOrderListingScreen> {

  final CarouselController carouselController = CarouselController();

  final SellerOrderController _orderController = Get.put(SellerOrderController());

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(
      context: context,
      widget: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TMTRoundedCornersContainer(
            padding: EdgeInsets.only(
                left: WidthDimension.w_20,
                right: WidthDimension.w_20,
                top: HeightDimension.h_20,
                bottom: HeightDimension.h_20),
            bgColor: AppColor.neutral_100,
            borderRadius: BorderRadius.circular(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text(
                    'No Connection',
                    style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_16,
                      fontWeight: FontWeight.w700,
                      color: AppColor.neutral_800,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text(
                    'Please check your internet connectivity',
                    style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_14,
                      fontWeight: FontWeight.w600,
                      color: AppColor.textColor,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    AppSettings.openAppSettings(type: AppSettingsType.wifi);
                  },
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                    child: Text(
                      'Okay',
                      style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_16,
                        fontWeight: FontWeight.w700,
                        color: AppColor.neutral_700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      callback: () {
        _orderController.getSellerOrders(context, (v) {}, "");
      },
    );
    super.initState();
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SellerOrderController>(
        id: GetControllerBuilders.sellerOrderListingScreenController,
        init: _orderController,
        builder: (controller) {
          return WillPopScope(
            onWillPop: (){
              Get.offNamed(AppRoutes.sellerDashboard);
              return Future.value(false);
            },
            child: Scaffold(
              backgroundColor: AppColor.lightGrey,
              body: Column(
                children: [
                  Container(
                    height: MediaQuery.of(context).size.height / 9.3,
                    decoration: const BoxDecoration(color: AppColor.neutral_100),
                    child: Padding(
                      padding: EdgeInsets.only(
                          bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Row(
                          children: [
                            InkWell(
                              onTap: () {
                                Get.offNamed(AppRoutes.sellerDashboard);
                              },
                              child: Row(
                                children: [
                                  HorizontalSpacing(WidthDimension.w_10),
                                  Container(
                                    width: WidthDimension.w_40,
                                    height: HeightDimension.h_30,
                                    child: Center(
                                      child: Image.asset(
                                        TMTImages.icBack,
                                        color: AppColor.neutral_800,
                                        fit: BoxFit.contain,
                                        scale: 3.4,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            TMTTextWidget(
                              title: "Orders",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const Spacer(),
                            HorizontalSpacing(WidthDimension.w_10),
                            GestureDetector(
                              onTap: () async {
                                await Get.toNamed(AppRoutes.notificationScreen,
                                    arguments: "SELLER");
                              },
                              child: TMTNotificationBell(isBuyer: false),
                            ),
                            HorizontalSpacing(WidthDimension.w_20),
                          ],
                        ),
                      ),
                    ),
                  ),
                  VerticalSpacing(HeightDimension.h_15),
                  Container(
                    margin: EdgeInsets.only(
                        left: WidthDimension.w_20, right: WidthDimension.w_20),
                    child: Row(
                      children: [
                        Expanded(
                          child: TMTRoundedCornersContainer(
                            borderColor: AppColor.neutral_800,
                            borderWidth: 0.5,
                            height: HeightDimension.h_35,
                            bgColor: AppColor.neutral_100,
                            borderRadius: const BorderRadius.all(
                                Radius.circular(TMTRadius.r_35)),
                            padding: EdgeInsets.only(
                                left: WidthDimension.w_15,
                                right: WidthDimension.w_15),
                            child: Row(
                              children: [
                                SizedBox(
                                  height: HeightDimension.h_18,
                                  width: HeightDimension.h_18,
                                  child: Image.asset(
                                    TMTImages.icSearch,
                                    color: AppColor.textColor,
                                  ),
                                ),
                                HorizontalSpacing(WidthDimension.w_10),
                                Expanded(
                                    child: TextField(
                                  onChanged: (v) {
                                    setState(() {});
                                  },
                                  decoration: InputDecoration.collapsed(
                                      hintText: "Search",
                                      hintStyle: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w500,
                                      )),
                                  controller:
                                      _orderController.searchTextController,
                                )),
                                HorizontalSpacing(WidthDimension.w_10),
                                GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      _orderController.searchTextController
                                          .clear();
                                    });
                                    TMTUtilities.closeKeyboard(context);
                                  },
                                  child: SizedBox(
                                    height: HeightDimension.h_12,
                                    width: HeightDimension.h_12,
                                    child: Image.asset(
                                      TMTImages.icErrorToastCancel,
                                      color: AppColor.neutral_800,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  VerticalSpacing(HeightDimension.h_15),
                  SizedBox(
                    width: double.infinity,
                    height: HeightDimension.h_30,
                    child: ListView.builder(
                      padding: EdgeInsets.only(
                          left: WidthDimension.w_15, right: WidthDimension.w_15),
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            _orderController.selectedSortFilter = index;
                            _orderController.getSellerOrders(context, (v) {}, "");
                          },
                          child: TMTRoundedCornersContainer(
                            width: WidthDimension.w_90,
                            margin: EdgeInsets.only(
                                left: WidthDimension.w_4,
                                right: WidthDimension.w_4),
                            padding: EdgeInsets.only(
                                top: HeightDimension.h_4,
                                bottom: HeightDimension.h_4),
                            bgColor: AppColor.neutral_100,
                            borderColor:
                                index == _orderController.selectedSortFilter
                                    ? AppColor.primary
                                    : AppColor.neutral_500,
                            borderWidth: 1.5,
                            child: Center(
                                child: TMTTextWidget(
                              title: _orderController.filters[index] ?? "",
                              style: TMTFontStyles.text(
                                  color:
                                      index == _orderController.selectedSortFilter
                                          ? AppColor.primary
                                          : AppColor.textColor),
                            )),
                          ),
                        );
                      },
                      itemCount: _orderController.filters.length,
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                    ),
                  ),
                  VerticalSpacing(HeightDimension.h_10),
                  Expanded(
                    child: Stack(
                      children: [
                        SingleChildScrollView(
                          child: Column(
                            children: [
                              ListView.builder(
                                itemBuilder: (BuildContext c, int index) {
                                  var e =
                                      _orderController.getFilteredOrders()[index];
                                  return GestureDetector(
                                    onTap: () async {
                                      await Get.toNamed(AppRoutes.sellerOrderDetailsScreen, arguments: e)?.then((value) {
                                        _orderController.getSellerOrders(context, (v) {}, "");
                                      });
                                    },
                                    child: TMTRoundedCornersContainer(
                                      borderRadius: BorderRadius.circular(10),
                                      margin: EdgeInsets.only(
                                          bottom: HeightDimension.h_4,
                                          top: HeightDimension.h_4,
                                          left: WidthDimension.w_20,
                                          right: WidthDimension.w_20),
                                      width: double.infinity,
                                      bgColor: AppColor.neutral_100,
                                      padding: EdgeInsets.only(
                                          top: HeightDimension.h_8,
                                          bottom: HeightDimension.h_8,
                                          left: WidthDimension.w_10,
                                          right: WidthDimension.w_10),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            width: WidthDimension.w_70,
                                            height: HeightDimension.h_70,
                                            child: TMTCachedImage.networkImage(e.orderedItems?.first.productImage ?? "", fit: BoxFit.cover),
                                          ),
                                          HorizontalSpacing(WidthDimension.w_15),
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  TMTTextWidget(
                                                    title: "#${e.id}",
                                                    style: TMTFontStyles.text(
                                                      fontSize: TMTFontSize.sp_12,
                                                      color: AppColor.textColor,
                                                      fontWeight: FontWeight.w400,
                                                    ),
                                                  ),
                                                  HorizontalSpacing(WidthDimension.w_6),
                                                  TMTRoundedCornersContainer(
                                                    height: HeightDimension.h_4,
                                                    width: HeightDimension.h_4,
                                                    bgColor: AppColor.textColor,
                                                  ),
                                                  HorizontalSpacing(WidthDimension.w_6),
                                                  TMTTextWidget(
                                                    title: _getTimeAgo(e.createdAt),
                                                    style: TMTFontStyles.text(
                                                      fontSize: TMTFontSize.sp_12,
                                                      color: AppColor.textColor,
                                                      fontWeight: FontWeight.w400,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              VerticalSpacing(HeightDimension.h_4),
                                              TMTTextWidget(
                                                title: "£${e.totalAmount?.toStringAsFixed(2)}",
                                                style: TMTFontStyles.text(
                                                  fontSize: TMTFontSize.sp_16,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                              VerticalSpacing(HeightDimension.h_4),
                                              Row(
                                                children: [
                                                  TMTRoundedCornersContainer(
                                                    padding: EdgeInsets.only(
                                                        top: HeightDimension.h_4,
                                                        bottom: HeightDimension.h_4,
                                                        left: WidthDimension.w_6,
                                                        right: WidthDimension.w_6),
                                                    bgColor: _getStatusColor(e.status),
                                                    child: TMTTextWidget(
                                                      title: _getStatus(e.status),
                                                      style: TMTFontStyles.text(
                                                        fontSize: TMTFontSize.sp_10,
                                                        color: _getStatusColorTextColor(e.status),
                                                        fontWeight: FontWeight.w400,
                                                      ),
                                                    ),
                                                  ),
                                                  HorizontalSpacing(WidthDimension.w_10),
                                                  TMTRoundedCornersContainer(
                                                    padding: EdgeInsets.only(
                                                        top: HeightDimension.h_4,
                                                        bottom: HeightDimension.h_4,
                                                        left: WidthDimension.w_6,
                                                        right: WidthDimension.w_6),
                                                    bgColor: AppColor.lightGrey,
                                                    child: TMTTextWidget(
                                                      title: e.user?.firstName ?? "",
                                                      style: TMTFontStyles.text(
                                                        fontSize: TMTFontSize.sp_10,
                                                        color: AppColor.textColor,
                                                        fontWeight: FontWeight.w400,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                                shrinkWrap: true,
                                scrollDirection: Axis.vertical,
                                physics: const NeverScrollableScrollPhysics(),
                                padding: EdgeInsets.zero,
                                itemCount:
                                    _orderController.getFilteredOrders().length,
                              ),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: _orderController.getFilteredOrders().isEmpty,
                          child: const Center(
                            child: TMTTextWidget(title: "No order found."),
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
              bottomNavigationBar: CommonSellerBottomNavigationBar(
                  currentSelectedItem: 1,
                  onTap: (index) async {
                    if (index == 4) {
                      Get.offNamed(AppRoutes.sellerProfileScreen);
                    } else if (index == 0) {
                      Get.offNamed(AppRoutes.sellerDashboard);
                    } else if (index == 2) {
                      Get.offNamed(AppRoutes.sellerProductListScreen);
                    } else if (index == 3) {
                      Get.offNamed(AppRoutes.sellerSupportTicketsScreen);
                    }
                  }),
            ),
          );
        });
  }

  /// Convert date time to local format
  String _getTimeAgo(DateTime? createdAt) {
    final now = DateTime.now();
    final difference = now.difference(createdAt ?? DateTime.now());

    if (difference.inSeconds < 60) {
      return '${difference.inSeconds} seconds ago';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes} minutes ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} hours ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      final weeks = difference.inDays ~/ 7;
      return '$weeks weeks ago';
    }
  }

  /// get status
  String _getStatus(status) {
    if (status == "PROCESSING") {
      return "PROCESSING";
    } else if (status == "COMPLETE") {
      return "COMPLETE";
    } else if (status == "DELIVERED") {
      return "DELIVERED";
    } else if (status == "SHIPPED") {
      return "SHIPPED";
    } else if (status == "REFUND_REQUESTED") {
      return "REFUND REQUESTED";
    } else if (status == "REFUND_REQ_APPROVED") {
      return "REFUND APPROVED";
    } else if (status == "REFUND_REQ_REJECTED") {
      return "REFUND REJECTED";
    } else if (status == "REFUND_PRODUCT_COLLECTED") {
      return "REFUND PRODUCT COLLECTED";
    } else if (status == "REFUNDED") {
      return "REFUNDED";
    } else if (status == "REJECTED") {
      return "REJECTED";
    } else if (status == "CANCELLED") {
      return "CANCELLED";
    } else if (status == "APPROVED") {
      return "APPROVED";
    } else {
      return "PENDING";
    }
  }

  Color _getStatusColor(status) {
    if (status == "PROCESSING") {
      return AppColor.lightGrey;
    } else if (status == "COMPLETE") {
      return AppColor.green;
    } else if (status == "DELIVERED") {
      return AppColor.green;
    } else if (status == "SHIPPED") {
      return AppColor.lightGrey;
    } else if (status == "REFUND_REQUESTED") {
      return AppColor.lightGrey;
    } else if (status == "REFUND_REQ_APPROVED") {
      return AppColor.green;
    } else if (status == "REFUND_REQ_REJECTED") {
      return AppColor.primary;
    } else if (status == "REFUND_PRODUCT_COLLECTED") {
      return AppColor.green;
    } else if (status == "REFUNDED") {
      return AppColor.green;
    } else if (status == "REJECTED") {
      return AppColor.primary;
    } else if (status == "CANCELLED") {
      return AppColor.primary;
    } else if (status == "APPROVED") {
      return AppColor.green;
    } else {
      return AppColor.lightGrey;
    }
  }

  Color _getStatusColorTextColor(status) {
    if (status == "PROCESSING") {
      return AppColor.textColor;
    } else if (status == "COMPLETE") {
      return AppColor.neutral_100;
    } else if (status == "DELIVERED") {
      return AppColor.neutral_100;
    } else if (status == "SHIPPED") {
      return AppColor.textColor;
    } else if (status == "REFUND_REQUESTED") {
      return AppColor.textColor;
    } else if (status == "REFUND_REQ_APPROVED") {
      return AppColor.neutral_100;
    } else if (status == "REFUND_REQ_REJECTED") {
      return AppColor.neutral_100;
    } else if (status == "REFUND_PRODUCT_COLLECTED") {
      return AppColor.neutral_100;
    } else if (status == "REFUNDED") {
      return AppColor.neutral_100;
    } else if (status == "REJECTED") {
      return AppColor.neutral_100;
    } else if (status == "CANCELLED") {
      return AppColor.neutral_100;
    } else if (status == "APPROVED") {
      return AppColor.neutral_100;
    } else {
      return AppColor.textColor;
    }
  }
}
