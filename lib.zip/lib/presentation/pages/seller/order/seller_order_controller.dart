import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/processing_time_model.dart';
import 'package:take_my_tack/data/model/request/get_all_categories_request.dart';
import 'package:take_my_tack/data/model/request/get_products_by_sellerid_request.dart';
import 'package:take_my_tack/data/model/request/post_add_new_product_request.dart';
import 'package:take_my_tack/data/model/request/post_update_product_request.dart';
import 'package:take_my_tack/data/model/response/get_default_attributes_response.dart';
import 'package:take_my_tack/data/model/response/get_product_by_product_id_response.dart';
import 'package:take_my_tack/data/model/response/get_products_by_seller_id_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_order_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_orders_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_product_details_response.dart';
import 'package:take_my_tack/data/repository_implementation/dashboard_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/seller_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

import '../../../../data/model/response/get_all_categories_response.dart';

class SellerOrderController extends GetxController {

  final SellerRepositoryImpl _sellerRepositoryImpl = SellerRepositoryImpl();

  List<SellerOrderData> sellerOrderList = [];
  SellerOrderDetails? data;

  int selectedSortFilter = 0;
  List<String> filters = [
    "All",
    "Pending",
    "Shipped",
    "Approved",
    "Refunded",
    "Rejected",
    "Cancelled",
  ];

  var searchTextController = TextEditingController();

  /*
   Method use to get seller orders list.
   Parameter- BuildContext context, Function callback
   Return -> No Return type.
  */
  void getSellerOrders (BuildContext context, Function(List<SellerOrderData>? data) callback, String fromDashboard) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.getSellerOrders(status: selectedSortFilter == 0 ? fromDashboard : filters[selectedSortFilter] == "Approved" ? "Processing" : filters[selectedSortFilter]);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              sellerOrderList = right.data ?? [];
              update([GetControllerBuilders.sellerOrderListingScreenController]);
              callback.call(right.data);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get seller orders details.
   Parameter- BuildContext context, Function callback, int orderId
   Return -> No Return type.
  */
  void getSellerOrderDetails (BuildContext context, Function callback, String orderId) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        try {
          const Loading().start(context);
        } catch (e) {}

        try {
          var response = await _sellerRepositoryImpl.getSellerOrderDetails(orderId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              data = right.data;
              update([GetControllerBuilders.sellerOrderDetailsScreenController]);
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to accept order.
   Parameter- BuildContext context, Function callback, int orderId
   Return -> No Return type.
  */
  void postAcceptOrder (BuildContext context, Function callback, String orderId) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.acceptOrder(orderId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to reject order.
   Parameter- BuildContext context, Function callback, int orderId
   Return -> No Return type.
  */
  void postRejectOrder (BuildContext context, Function callback, String orderId, String reason) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.rejectOrder(orderId, reason);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update order status.
   Parameter- BuildContext context, Function callback, int orderId
   Return -> No Return type.
  */
  void postUpdateOrderStatus (BuildContext context, Function callback, String orderId, String status) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.orderStatusUpdate(orderId, status);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// filtered orders
  List<SellerOrderData> getFilteredOrders () {
    if (searchTextController.text.isNotEmpty) {
      return sellerOrderList.where((element) => element.user?.firstName?.toLowerCase().contains(searchTextController.text.toLowerCase())).toList();
    }
    return sellerOrderList;
  }
}