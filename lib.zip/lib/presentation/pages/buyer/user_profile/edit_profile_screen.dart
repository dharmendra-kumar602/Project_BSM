import 'dart:io';
import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/put_update_profile_picture_request.dart';
import 'package:take_my_tack/data/model/request/put_update_profile_request.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/tmt_media_picker.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<StatefulWidget> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  final _formKey = GlobalKey<FormState>();
  final TextEditingController mobileNumberTextController =
  TextEditingController();
  final FocusNode mobileNumberNode = FocusNode();
  final TextEditingController fullNameTextController =
  TextEditingController();
  final FocusNode fullNameNode = FocusNode();
  final TextEditingController emailTextController =
  TextEditingController();
  final FocusNode emailNode = FocusNode();
  final TextEditingController locationController =
  TextEditingController();
  final FocusNode locationNode = FocusNode();
  File? imageFile;

  bool isKeyboardVisible = false;

  @override
  void initState() {
    super.initState();
    if (_dashboardController.buyerData != null) {
      mobileNumberTextController.text = _dashboardController.buyerData?.contact ?? "";
      fullNameTextController.text = "${_dashboardController.buyerData?.firstName} ${_dashboardController.buyerData?.lastName}";
      emailTextController.text = _dashboardController.buyerData?.email ?? "";
    }
    KeyboardVisibilityController().onChange.listen((bool visible) {
      setState(() {
        isKeyboardVisible = visible;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height/9.3,
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 3,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ], color: AppColor.neutral_100),
            child: Padding(
              padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Row(
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_10),
                          SizedBox(
                            width: WidthDimension.w_40,
                            height: HeightDimension.h_30,
                            child: Center(
                              child: Image.asset(
                                TMTImages.icBack,
                                color: AppColor.neutral_800,
                                fit: BoxFit.contain,
                                scale: 3.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    TMTTextWidget(
                      title: "Profile",
                      style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  VerticalSpacing(HeightDimension.h_15),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        children: [
                          SizedBox(
                            height: HeightDimension.h_110,
                            width: HeightDimension.h_110,
                            child: (_dashboardController.buyerData?.profilePicture.isNotEmpty ?? false) ? ClipRRect(
                              borderRadius: BorderRadius.circular(100.0),
                              child: TMTCachedImage.networkImage(_dashboardController.buyerData!.profilePicture, fit: BoxFit.cover,),
                            ) : Image.asset(_dashboardController.buyerData?.gender == "MALE" ? TMTImages.icProfileMen : TMTImages.icProfileFemale),
                          ),
                          VerticalSpacing(HeightDimension.h_15),
                          GestureDetector(
                            onTap: (){
                              showDialog(
                                context: context,
                                builder: (c) => SimpleDialog(
                                  contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, top: HeightDimension.h_8),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  titlePadding: EdgeInsets.only(top: HeightDimension.h_10, left: WidthDimension.w_20, right: WidthDimension.w_20),
                                  title: const Text('Select Image'),
                                  children: <Widget>[
                                    SimpleDialogOption(
                                      onPressed: () async {
                                        Navigator.pop(context);
                                        XFile? pickedFile = await TMTMediaPicker(context).pickImageFromCamera(imageQuality: 40);
                                        if (pickedFile != null) {
                                          var v = await TMTUtilities.isFileBiggerThan1MB(pickedFile);
                                          if (v) {
                                            if (!mounted) return;
                                            TMTToast.showErrorToast(context, "Image size must be less than 2MB.");
                                            return;
                                          }
                                          imageFile = File(pickedFile.path);
                                          if(imageFile != null) {
                                            if (!mounted) return;
                                            const Loading().start(context);
                                            uploadFile();
                                          }
                                        }
                                      },
                                      child: const Text('Camera'),
                                    ),
                                    SimpleDialogOption(
                                      onPressed: () async {
                                        Navigator.pop(context);
                                        XFile? pickedFile = await TMTMediaPicker(context).pickImageFromGallery(imageQuality: 40);
                                        if (pickedFile != null) {
                                          var v = await TMTUtilities.isFileBiggerThan1MB(pickedFile);
                                          if (v) {
                                            if (!mounted) return;
                                            TMTToast.showErrorToast(context, "Image size must be less than 2MB.");
                                            return;
                                          }
                                          imageFile = File(pickedFile.path);
                                          if (imageFile != null) {
                                            if (!mounted) return;
                                            const Loading().start(context);
                                            uploadFile();
                                          }
                                        }
                                      },
                                      child: const Text('Gallery'),
                                    ),
                                  ],
                                ),
                              );
                            },
                            child: TMTRoundedCornersContainer(
                              width: HeightDimension.h_95,
                              height: HeightDimension.h_25,
                              bgColor: AppColor.neutral_100,
                              borderColor: AppColor.textColor,
                              child: Center(
                                child: TMTTextWidget(title: "Edit profile", style: TMTFontStyles.text(),),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  VerticalSpacing(HeightDimension.h_25),
                  Padding(
                    padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                    child: TMTTextWidget(title: "Contact Details", style: TMTFontStyles.textTeen(
                      fontSize: TMTFontSize.sp_16,
                      color: AppColor.neutral_800,
                      fontWeight: FontWeight.w700,
                    ),),
                  ),
                  VerticalSpacing(HeightDimension.h_15),
                  Form(
                    key: _formKey,
                    child: Padding(
                      padding: EdgeInsets.only(
                          left: WidthDimension.w_10,
                          right: WidthDimension.w_10),
                      child: Column(
                        children: [
                          TMTTextField(
                              hintText: "Full name",
                              controller: fullNameTextController,
                              textInputAction: TextInputAction.done,
                              focusNode:
                              fullNameNode,
                              onChanged: (v){
                                setState(() {

                                });
                              },
                              onFieldSubmitted: (v) {
                                emailNode.requestFocus();
                              }
                          ),
                          VerticalSpacing(HeightDimension.h_8),
                          TMTTextField(
                            onTap: () {
                              setState(() {
                                isKeyboardVisible = true;
                              });
                            },
                            hintText: "Email",
                            textInputAction: TextInputAction.done,
                            controller: emailTextController,
                            focusNode: emailNode,
                            onChanged: (v){
                              setState(() {

                              });
                            },
                            inputFormatters: [
                              FilteringTextInputFormatter.deny(RegExp(r'\s'))
                            ],
                            validator: Validator.emailValidate,
                            keyboardType: TextInputType.emailAddress,
                            onFieldSubmitted: (v) {
                              locationNode.requestFocus();
                            },),
                          VerticalSpacing(HeightDimension.h_8),
                          TMTTextField(
                              hintText: "Mobile number",
                              controller: mobileNumberTextController,
                              textInputAction: TextInputAction.done,
                              focusNode:
                              mobileNumberNode,
                              onChanged: (v){
                                setState(() {

                                });
                              },
                              validator: Validator.mobileNumberValidate,
                              keyboardType: const TextInputType.numberWithOptions(
                                decimal: true,
                                signed: true,
                              ),
                              onFieldSubmitted: (v) {
                                fullNameNode.requestFocus();
                              }
                          ),
                        ],
                      ),
                    ),
                  ),
                  VerticalSpacing(HeightDimension.h_20),
                  InkWell(
                    onTap: () {
                      Get.toNamed(AppRoutes.changePasswordScreen);
                    },
                    child: Container(
                      margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                      padding: EdgeInsets.only(
                          top: HeightDimension.h_12,
                          bottom: HeightDimension.h_12,
                          left: WidthDimension.w_15,
                          right: WidthDimension.w_15),
                      decoration: BoxDecoration(
                          color: AppColor.neutral_100,
                          border: Border.all(color: const Color(0xFF595959), width: 0.5),
                          borderRadius: const BorderRadius.all(
                              Radius.circular(TMTRadius.r_10))),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TMTTextWidget(
                            title: "CHANGE PASSWORD",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  VerticalSpacing(HeightDimension.h_20),
                  Visibility(
                    visible: isKeyboardVisible,
                    child: SizedBox(height: HeightDimension.h_120),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.only(
            left: WidthDimension.w_15, right: WidthDimension.w_15),
        height: HeightDimension.h_90,
        decoration: BoxDecoration(boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 3,
            blurRadius: 5,
            offset: const Offset(0, 3), // changes position of shadow
          ),
        ], color: AppColor.neutral_100),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Expanded(
              child: InkWell(
                onTap: () {
                  var request = PutUpdateProfileRequest(requestHeader: DioUtils.getRequestHeaderModel());
                  if (mobileNumberTextController.text.isNotEmpty) {
                    request.contact = mobileNumberTextController.text;
                  }
                  if (fullNameTextController.text.isNotEmpty) {
                    List<String> nameParts = fullNameTextController.text.split(" ");
                    String firstName = nameParts[0];
                    String lastName = nameParts.length > 1 ? nameParts[1] : "";
                    request.firstName = firstName;
                    request.lastName = lastName;
                  }
                  if (emailTextController.text.isNotEmpty) {
                    request.email = emailTextController.text;
                  }
                  _dashboardController.updateBuyerProfile(context, request, (){});
                },
                child: Container(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_12,
                      bottom: HeightDimension.h_12,
                      left: WidthDimension.w_18,
                      right: WidthDimension.w_18),
                  decoration: BoxDecoration(
                      color: AppColor.primaryBG,
                      border: Border.all(color: AppColor.primaryBG, width: 1),
                      borderRadius: const BorderRadius.all(
                          Radius.circular(TMTRadius.r_30))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TMTTextWidget(
                        title: "SAVE DETAILS",
                        style: TMTFontStyles.textTeen(
                          fontSize: TMTFontSize.sp_18,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// upload image
  void uploadFile() {
    _dashboardController.updateBuyerProfilePicture(context, PutUpdateProfilePictureRequest(profilePicture: imageFile!), (){
      setState(() {

      });
    });
  }
}
