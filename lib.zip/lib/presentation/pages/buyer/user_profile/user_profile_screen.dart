import 'dart:async';
import 'dart:ui';
import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/tmt_webview.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<StatefulWidget> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  final DashboardController _dashboardController =
      Get.put(DashboardController());

  String firstLetterOfName = "";
  String fullName = "";
  bool isSubscribedToNewsLetter = false;

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      if (TMTLocalStorage.getUserLoggedIn()) {
        _callApi();
      }
    },);
    super.initState();
  }

  /// call apis and update names
  _callApi () {
    _dashboardController.getBuyerProfile(context, (){
      setState(() {
        firstLetterOfName = (_dashboardController.buyerData?.firstName.isNotEmpty ?? false) ? (_dashboardController.buyerData?.firstName ?? TMTUtilities.getUserNameFromToken())[0].toUpperCase() : "";
        fullName = "${_dashboardController.buyerData?.firstName ?? ""} ${_dashboardController.buyerData?.lastName ?? ""}";
      });
    });
    _dashboardController.getNewsLetterStatus(context, callBack: (v){
      setState(() {
        isSubscribedToNewsLetter = v == 1;
      });
    });
   }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            _dashboardController.changeSelectedPage(
                                pageIndex: AppRoutesIdentifiers.homeScreen,
                                navBarItemIndex: AppRoutesIdentifiers.homeScreen);
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: "Profile",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(
                        left: WidthDimension.w_20,
                        right: WidthDimension.w_20,
                        top: HeightDimension.h_20,
                        bottom: HeightDimension.h_20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              height: HeightDimension.h_30,
                              width: HeightDimension.h_30,
                              child: (_dashboardController.buyerData?.profilePicture.isNotEmpty ?? false) ? ClipRRect(
                                borderRadius: BorderRadius.circular(100.0),
                                child: TMTCachedImage.networkImage(_dashboardController.buyerData!.profilePicture, fit: BoxFit.cover,),
                              ) : TMTRoundedCornersContainer(
                                height: HeightDimension.h_30,
                                width: HeightDimension.h_30,
                                bgColor: const Color(0xFFBDBDBD),
                                child: Center(
                                    child: TMTTextWidget(
                                      title: firstLetterOfName,
                                      style: TMTFontStyles.text(
                                          color: AppColor.neutral_800,
                                          fontSize: TMTFontSize.sp_15,
                                          fontWeight: FontWeight.w700),
                                    )),
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_8),
                            SizedBox(
                              width: WidthDimension.w_180,
                              child: TMTTextWidget(
                                title: fullName,
                                style: TMTFontStyles.textTeen(
                                    color: AppColor.neutral_800,
                                    fontSize: TMTFontSize.sp_18,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            const Spacer(),
                            InkWell(
                              onTap: () async {
                                await Get.toNamed(AppRoutes.editProfileScreen);
                                _callApi();
                              },
                              child: Row(
                                children: [
                                  SizedBox(
                                    height: HeightDimension.h_15,
                                    width: HeightDimension.h_15,
                                    child: Image.asset(TMTImages.icEdit),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_8),
                                  TMTTextWidget(
                                    title: "EDIT",
                                    style: TMTFontStyles.textHarbinger(
                                        color: AppColor.primaryBG,
                                        fontSize: TMTFontSize.sp_16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Row(
                          children: [
                            Expanded(
                              child: InkWell(
                                onTap: (){
                                  _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.myOrdersScreen, navBarItemIndex: AppRoutesIdentifiers.userProfileScreen);
                                },
                                child: TMTRoundedCornersContainer(
                                  padding: EdgeInsets.only(
                                      left: WidthDimension.w_15,
                                      right: WidthDimension.w_15,
                                      top: HeightDimension.h_10,
                                      bottom: HeightDimension.h_10),
                                  bgColor: AppColor.neutral_100,
                                  borderColor: AppColor.neutral_500,
                                  borderRadius: BorderRadius.circular(TMTRadius.r_12),
                                  borderWidth: 0.8,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        width: WidthDimension.w_15,
                                        height: HeightDimension.h_15,
                                        child: Image.asset(
                                          TMTImages.icOrders,
                                          color: AppColor.neutral_800,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_8),
                                      TMTTextWidget(
                                        title: "Orders",
                                        style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_16,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_10),
                                      const Spacer(),
                                      SizedBox(
                                        width: HeightDimension.h_10,
                                        height: HeightDimension.h_10,
                                        child: Image.asset(
                                          TMTImages.icNext,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            Expanded(
                              child: InkWell(
                                onTap: () async {
                                  await Get.toNamed(AppRoutes.wishListScreen, arguments: false);
                                  setState(() {

                                  });
                                },
                                child: TMTRoundedCornersContainer(
                                  padding: EdgeInsets.only(
                                      left: WidthDimension.w_15,
                                      right: WidthDimension.w_15,
                                      top: HeightDimension.h_10,
                                      bottom: HeightDimension.h_10),
                                  bgColor: AppColor.neutral_100,
                                  borderColor: AppColor.neutral_500,
                                  borderRadius: BorderRadius.circular(TMTRadius.r_12),
                                  borderWidth: 0.8,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        width: WidthDimension.w_18,
                                        height: HeightDimension.h_18,
                                        child: Image.asset(
                                          TMTImages.icHeart,
                                          color: AppColor.neutral_800,
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_8),
                                      TMTTextWidget(
                                        title: "Wishlist",
                                        style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_16,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_10),
                                      const Spacer(),
                                      SizedBox(
                                        width: HeightDimension.h_10,
                                        height: HeightDimension.h_10,
                                        child: Image.asset(
                                          TMTImages.icNext,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        InkWell(
                          onTap: (){
                            Get.toNamed(AppRoutes.addressListingScreen);
                          },
                          child: Container(
                            child: Column(
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: 0.8,
                                  color: AppColor.neutral_400,
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                                Row(
                                  children: [
                                    SizedBox(
                                      width: WidthDimension.w_18,
                                      height: HeightDimension.h_18,
                                      child: Image.asset(
                                        TMTImages.icManageDeliveryAddress,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    TMTTextWidget(
                                      title: "Manage Delivery Address",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_16,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    const Spacer(),
                                    SizedBox(
                                      width: WidthDimension.w_10,
                                      height: HeightDimension.h_10,
                                      child: Image.asset(
                                        TMTImages.icNext,
                                      ),
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                              ],
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            Get.toNamed(AppRoutes.enquiryListingScreenPage);
                          },
                          child: Container(
                            child: Column(
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: 0.8,
                                  color: AppColor.neutral_400,
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                                Row(
                                  children: [
                                    SizedBox(
                                      width: WidthDimension.w_18,
                                      height: HeightDimension.h_18,
                                      child: Image.asset(
                                        TMTImages.icManageEnquires,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    TMTTextWidget(
                                      title: "Enquiries",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_16,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    const Spacer(),
                                    SizedBox(
                                      width: WidthDimension.w_10,
                                      height: HeightDimension.h_10,
                                      child: Image.asset(
                                        TMTImages.icNext,
                                      ),
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                              ],
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.supportTicketScreen, navBarItemIndex: AppRoutesIdentifiers.userProfileScreen);
                          },
                          child: Container(
                            child: Column(
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: 0.8,
                                  color: AppColor.neutral_400,
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                                Row(
                                  children: [
                                    SizedBox(
                                      width: WidthDimension.w_18,
                                      height: HeightDimension.h_18,
                                      child: Image.asset(
                                        TMTImages.icSupportTicket,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    TMTTextWidget(
                                      title: "Support Ticket",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_16,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    const Spacer(),
                                    SizedBox(
                                      width: WidthDimension.w_10,
                                      height: HeightDimension.h_10,
                                      child: Image.asset(
                                        TMTImages.icNext,
                                      ),
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                              ],
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _showSwitchProfileDialog();
                            },
                          child: Container(
                            child: Column(
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: 0.8,
                                  color: AppColor.neutral_400,
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                                Row(
                                  children: [
                                    SizedBox(
                                      width: WidthDimension.w_18,
                                      height: HeightDimension.h_18,
                                      child: Image.asset(
                                        TMTImages.icManageSellerAccount,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    TMTTextWidget(
                                      title: TMTLocalStorage.getString(GetXStorageConstants.userType) == "SELLER" ? TMTLocalStorage.getSellerStatus() == "COMPLETED" ? "Manage Seller Account" : "Register to Sell" : "Register to Sell",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_16,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_4),
                                    SizedBox(
                                      width: WidthDimension.w_18,
                                      height: HeightDimension.h_18,
                                      child: Image.asset(
                                        TMTImages.icVerifiedTick,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    const Spacer(),
                                    SizedBox(
                                      width: WidthDimension.w_10,
                                      height: HeightDimension.h_10,
                                      child: Image.asset(
                                        TMTImages.icNext,
                                      ),
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                              ],
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _launchURL(
                                "https://tacktalk.co.uk");
                          },
                          child: Container(
                            child: Column(
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: 0.8,
                                  color: AppColor.neutral_400,
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                                Row(
                                  children: [
                                    SizedBox(
                                      width: WidthDimension.w_18,
                                      height: HeightDimension.h_18,
                                      child: Image.asset(
                                        TMTImages.icWriteBlog,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    TMTTextWidget(
                                      title: "Contribute to the Blog",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_16,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    const Spacer(),
                                    SizedBox(
                                      width: WidthDimension.w_10,
                                      height: HeightDimension.h_10,
                                      child: Image.asset(
                                        TMTImages.icNext,
                                      ),
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                              ],
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _dashboardController.updateNewsLetterStatus(context, isSubscribedToNewsLetter, callBack: (){
                              if (TMTLocalStorage.getUserLoggedIn()) {
                                _callApi();
                              }
                            });
                          },
                          child: Container(
                            child: Column(
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: 0.8,
                                  color: AppColor.neutral_400,
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(top: HeightDimension.h_5),
                                      height: HeightDimension.h_15,
                                      child: Image.asset(
                                        isSubscribedToNewsLetter ? TMTImages.icUnsub : TMTImages.icSub,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    TMTTextWidget(
                                      title: isSubscribedToNewsLetter ? "Unsubscribe News Letter" : "Subscribe News Letter",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_16,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    const Spacer(),
                                    SizedBox(
                                      width: WidthDimension.w_10,
                                      height: HeightDimension.h_10,
                                      child: Image.asset(
                                        TMTImages.icNext,
                                      ),
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_15),
                                Container(
                                  width: double.infinity,
                                  height: 0.8,
                                  color: AppColor.neutral_400,
                                ),
                              ],
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        TMTTextWidget(
                          title: "About",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_16,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_20),
                        Column(
                          children: [
                            GestureDetector(
                              onTap: (){
                                _launchURL(
                                    "https://tacktalk.co.uk/terms-conditions-%f0%9f%a4%9f/");
                              },
                              child: TMTRoundedCornersContainer(
                                width: double.infinity,
                                borderRadius: const BorderRadius.only(),
                                bgColor: AppColor.neutral_100,
                                borderColor: AppColor.dividerColor,
                                borderWidth: 0.8,
                                padding: const EdgeInsets.all(15),
                                child: TMTTextWidget(
                                  title: "Terms & Conditions",
                                  style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w500,
                                      textDecoration: TextDecoration.underline),
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: (){
                                _launchURL(
                                    "https://tacktalk.co.uk/privacy-policy");
                              },
                              child: TMTRoundedCornersContainer(
                                width: double.infinity,
                                borderRadius: const BorderRadius.only(
                                    bottomLeft: Radius.circular(TMTRadius.r_10),
                                    bottomRight: Radius.circular(TMTRadius.r_10)),
                                bgColor: AppColor.neutral_100,
                                borderColor: AppColor.dividerColor,
                                borderWidth: 0.8,
                                padding: const EdgeInsets.all(15),
                                child: TMTTextWidget(
                                  title: "Privacy Policy",
                                  style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w500,
                                      textDecoration: TextDecoration.underline),
                                ),
                              ),
                            ),
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_25),
                        GestureDetector(
                          onTap: (){
                            _showLogoutConfirmationDialog(context);
                          },
                          child: TMTRoundedCornersContainer(
                            bgColor: AppColor.neutral_100,
                            borderColor: AppColor.neutral_800,
                            borderWidth: 1,
                            borderRadius: BorderRadius.circular(TMTRadius.r_30),
                            width: double.infinity,
                            padding: const EdgeInsets.all(15),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: WidthDimension.w_18,
                                  height: HeightDimension.h_18,
                                  child: Image.asset(
                                    TMTImages.icLogout,
                                  ),
                                ),
                                HorizontalSpacing(WidthDimension.w_10),
                                TMTTextWidget(
                                  title: "LOGOUT",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_16,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w600,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        GestureDetector(
                          onTap: (){
                            _dashboardController.showDeleteConfirmationDialog(context);
                          },
                          child: TMTRoundedCornersContainer(
                            bgColor: AppColor.primaryBG,
                            borderColor: AppColor.neutral_100,
                            borderWidth: 1,
                            borderRadius: BorderRadius.circular(TMTRadius.r_30),
                            width: double.infinity,
                            padding: const EdgeInsets.all(15),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                TMTTextWidget(
                                  title: "DELETE ACCOUNT",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_16,
                                    color: AppColor.neutral_100,
                                    fontWeight: FontWeight.w600,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_20),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          Visibility(
            visible: !TMTLocalStorage.getUserLoggedIn(),
            child: Material(
              color: Colors.transparent,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                child: Container(
                  decoration: BoxDecoration(color: AppColor.neutral_800.withOpacity(0.5)),
                  width: double.infinity,
                  height: double.infinity,
                  child: Center(
                    child: TMTRoundedCornersContainer(
                      width: WidthDimension.w_286,
                      height: HeightDimension.h_140,
                      bgColor: AppColor.neutral_100,
                      borderRadius:
                          const BorderRadius.all(Radius.circular(TMTRadius.r_15)),
                      padding: const EdgeInsets.only(top: TMTDimension.padding_20, left: TMTDimension.padding_20, right: TMTDimension.padding_20),
                      child: Column(
                        children: [
                          TMTTextWidget(
                            title: "Please login to continue.",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.primaryBG,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          VerticalSpacing(HeightDimension.h_15),
                          InkWell(
                            onTap: (){
                              Get.offAndToNamed(AppRoutes.loginScreen, arguments: AppRoutes.homeScreen);
                            },
                              child: Container(height: HeightDimension.h_40, margin: EdgeInsets.only(left: HeightDimension.h_20, right: HeightDimension.h_20),child: const TMTTextButton(buttonTitle: "Login"),)),
                          VerticalSpacing(HeightDimension.h_10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TMTTextWidget(
                                title: "New customer?",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_12,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_4),
                              GestureDetector(
                                onTap: (){
                                  Get.offAndToNamed(AppRoutes.signUpScreen);
                                },
                                child: TMTTextWidget(
                                  title: "Start here.",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_12,
                                    color: AppColor.primaryBG,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// show confirmation dialog for logout
  void _showLogoutConfirmationDialog(BuildContext context) {
    showDialog(context: context, builder: (c){
      return AlertDialog(
        contentPadding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_20, right: WidthDimension.w_20, bottom: HeightDimension.h_20),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_10))),
        content: TMTTextWidget(title: "Are you sure you want to logout?", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_16, fontWeight: FontWeight.w700, color: AppColor.neutral_800),),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.green),
                ),
                child: TMTTextWidget(title: 'Cancel' , style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.of(context).pop(false); // Return false when cancelled
                },
              ),
             HorizontalSpacing(WidthDimension.w_8),
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.primaryBG),
                ),
                child: TMTTextWidget(title: 'Logout', style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  _dashboardController.postLogoutUser(context);
                },
              ),
              HorizontalSpacing(WidthDimension.w_10),
            ],
          ),
        ],
        actionsPadding: EdgeInsets.only(bottom: HeightDimension.h_10),
      );
    });
  }

  /// For launching url
  _launchURL(String url) async {
    Navigator.push(context, MaterialPageRoute(builder: (c){
      return TMTWebView(url: url);
    }));
  }

  void _showSwitchProfileDialog() {
    showDialog(context: context, builder: (c){
      return AlertDialog(
        contentPadding: EdgeInsets.all(20),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_10))),
        content: TMTTextWidget(title: "Are you sure you want to switch to your seller profile?", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w700, color: AppColor.textColor), textAlign: TextAlign.center,),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.green),
                ),
                child: TMTTextWidget(title: 'Cancel' , style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.of(context).pop(false); // Return false when cancelled
                },
              ),
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.primaryBG),
                ),
                child: TMTTextWidget(title: 'Switch', style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  if (TMTUtilities.getUserRoleFromToken() == "SELLER") {
                    _dashboardController.getSellerRegisterStatus(context, (){
                      if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
                        Get.toNamed(AppRoutes.sellerDashboard);
                      } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
                        Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
                      } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
                        Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
                      } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
                        _dashboardController.getUpdatedToken(context, (){
                          Get.toNamed(
                              AppRoutes.sellerPlanDetailsScreen);
                        });
                      } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
                        _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), (){
                          Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
                        });
                      } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
                        TMTUtilities.showUserDisabledDialog(context);
                      } else {
                        Get.toNamed(AppRoutes.sellerDashboard);
                      }
                    });
                  }
                  else {
                    if (!TMTLocalStorage.getUserLoggedIn()) {
                      Get.offAndToNamed(AppRoutes.loginScreen,
                          arguments: AppRoutes.homeScreen);
                    } else {
                      _dashboardController.getSellerRegisterStatus(context, (){
                        if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
                          _dashboardController.getUpdatedToken(context, (){
                            Get.toNamed(AppRoutes.sellerDashboard);
                          });
                        } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
                          Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
                        } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
                          Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
                        } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
                          _dashboardController.getUpdatedToken(context, (){
                            Get.toNamed(
                                AppRoutes.sellerPlanDetailsScreen);
                          });
                        } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
                          _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), (){
                            Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
                          });
                        } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
                          TMTUtilities.showUserDisabledDialog(context);
                        } else {
                          Get.toNamed(AppRoutes.registerToSellScreen);
                        }
                      });
                    }
                  }
                },
              ),
            ],
          ),
        ],
        actionsPadding: EdgeInsets.only(bottom: HeightDimension.h_10),
      );
    });
  }
}
