import 'dart:ui';
import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/model/cart_models.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/request/post_create_payment_intent_request.dart';
import 'package:take_my_tack/data/model/response/get_cart_response.dart';
import 'package:take_my_tack/data/model/response/post_create_order_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/address/address_screens_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/cart/cart_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_popup/src/custom_pop_up_menu.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<StatefulWidget> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final List<String> qtItems = [
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
  ];

  String? address;

  final CartController _cartController =
  Get.put(CartController());

  final DashboardController _dashboardController =
  Get.put(DashboardController());

  final AddressScreenController _addressScreenController =
  Get.put(AddressScreenController());

  var cameFromDashBoard = Get.arguments ?? true;

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      _callApi();
    },);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CartController>(
        id: GetControllerBuilders.cartScreenController,
        init: _cartController,
        builder: (controller) {
        return Scaffold(
          backgroundColor: AppColor.lightGrey,
          body: Stack(
            children: [
              Column(
                children: [
                  Container(
                    height: MediaQuery.of(context).size.height/9.3,
                    decoration: BoxDecoration(boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 3,
                        offset: const Offset(1, 3), // changes position of shadow
                      ),
                    ], color: AppColor.neutral_100),
                    child: Padding(
                      padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Row(
                          children: [
                            InkWell(
                              onTap: () {
                                try {
                                  if (!cameFromDashBoard) {
                                    Get.back();
                                    return;
                                  }
                                } catch (e) {
                                  Get.back();
                                }
                                _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.homeScreen, navBarItemIndex: AppRoutesIdentifiers.homeScreen);
                              },
                              child: Row(
                                children: [
                                  HorizontalSpacing(WidthDimension.w_10),
                                  Container(
                                    width: WidthDimension.w_40,
                                    height: HeightDimension.h_30,
                                    child: Center(
                                      child: Image.asset(
                                        TMTImages.icBack,
                                        color: AppColor.neutral_800,
                                        fit: BoxFit.contain,
                                        scale: 3.4,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            TMTTextWidget(
                              title: "Cart",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            const Spacer(),
                            GestureDetector(
                              onTap: () async {
                                await Get.toNamed(AppRoutes.wishListScreen, arguments: false);
                                setState(() {
                                  _cartController.getBuyerCart(context);
                                });
                              },
                              child: Stack(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(top: HeightDimension.h_5, right: HeightDimension.h_5),
                                    padding: const EdgeInsets.all(6.0),
                                    decoration: const BoxDecoration(
                                        image: DecorationImage(
                                            image: AssetImage(TMTImages.icRoundWhiteBG))),
                                    child: Stack(
                                      children: [
                                        SizedBox(
                                          height: HeightDimension.h_20,
                                          width: HeightDimension.h_20,
                                          child: Image.asset(
                                            TMTImages.icHeart,
                                            color: AppColor.neutral_800,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Visibility(
                                    visible: TMTLocalStorage.getWishlistItems().isNotEmpty,
                                    child: Positioned(
                                      top: 7,
                                      right: 7,
                                      child: TMTRoundedCornersContainer(
                                          bgColor: AppColor.primaryBG,
                                          padding: EdgeInsets.only(left: 5, right: 5, top: 2, bottom: 2),
                                          child: TMTTextWidget(title: TMTLocalStorage.getWishlistItems().length.toString() ?? "", style: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontSize: 10),)),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_20),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          VerticalSpacing(5),
                          Container(
                            decoration:
                                BoxDecoration(color: AppColor.neutral_100, boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 2,
                                blurRadius: 3,
                                offset: const Offset(0, 2), // changes position of shadow
                              ),
                            ]),
                            padding: EdgeInsets.only(
                                left: WidthDimension.w_20,
                                right: WidthDimension.w_20,
                                top: HeightDimension.h_5,
                                bottom: HeightDimension.h_5),
                            height: HeightDimension.h_40,
                            width: double.infinity,
                            child: Row(
                              children: [
                                SizedBox(
                                  height: HeightDimension.h_18,
                                  width: WidthDimension.w_13,
                                  child: Image.asset(TMTImages.icMapMarker),
                                ),
                                HorizontalSpacing(WidthDimension.w_10),
                                Expanded(
                                  child: TMTTextWidget(
                                    maxLines: 1,
                                    title: address == null ? "Add address" : "Deliver to: $address",
                                    style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                                HorizontalSpacing(WidthDimension.w_10),
                                GestureDetector(
                                  onTap: () async {
                                    if (!TMTLocalStorage.getUserLoggedIn()) {
                                      _showLoginPrompt(context);
                                      return;
                                    }
                                    await Get.toNamed(AppRoutes.addressListingScreen);
                                    if (!mounted) return;
                                    _cartController.getAddress(context, callback: () async {
                                      await Future.delayed(const Duration(milliseconds: 500));
                                      setState(() {
                                        if ( _cartController.defaultAddress?.firstName != null && _cartController.defaultAddress?.postCode != null) {
                                          address = "${_cartController.defaultAddress?.firstName}, ${_cartController.defaultAddress?.postCode}";
                                        } else {
                                          address = null;
                                        }
                                      });
                                    });
                                  },
                                  child: TMTTextWidget(
                                    title: address == null ? "Add" : "Change",
                                    style: TMTFontStyles.textHarbinger(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.primaryBG,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          ListView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              if (_cartController.cartData?.sellers[index].sellerStore.isPickupFromStoreEnabled == 1) {
                                _cartController.cartData?.sellers[index].sellerStore.deliveryItems = [
                                  'PICKUP',
                                  'DELIVERY',
                                ];
                              } else {
                                _cartController.cartData?.sellers[index].sellerStore.deliveryItems = [
                                  'DELIVERY',
                                ];
                              }
                              return Container(
                                margin: EdgeInsets.only(bottom: HeightDimension.h_8, top: HeightDimension.h_5),
                                width: double.infinity,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20,
                                    right: WidthDimension.w_20,
                                    top: HeightDimension.h_10,
                                    bottom: HeightDimension.h_10),
                                decoration: const BoxDecoration(
                                  color: AppColor.neutral_100,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        TMTTextWidget(
                                          title: _cartController.cartData?.sellers[index].name ?? "",
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                        const Spacer(),
                                        Visibility(
                                          visible: _cartController.cartData?.sellers[index].pickupOrDelivery == "PICKUP",
                                          child: GestureDetector(
                                            onTap: (){
                                              showDialog(context: context, builder: (context){
                                                return _pickupPopup(context, _cartController.cartData?.sellers[index].sellerStore);
                                              });
                                            },
                                            child: TMTTextWidget(title: "Pickup", style: TMTFontStyles.textHarbinger(
                                              fontSize: TMTFontSize.sp_14,
                                              color: AppColor.primaryBG,
                                              fontWeight: FontWeight.w400,
                                            ),),
                                          ),
                                        ),
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_8),
                                    ListView.builder(
                                      shrinkWrap: true,
                                      scrollDirection: Axis.vertical,
                                      padding: EdgeInsets.zero,
                                      physics: const NeverScrollableScrollPhysics(),
                                      itemBuilder: (context, productIndex) {
                                        return GestureDetector(
                                          onTap: (){
                                            Get.toNamed(AppRoutes.productDetailScreen, arguments: [_cartController.cartData?.sellers[index].products[productIndex].id, _cartController.cartData?.sellers[index].products[productIndex].productVariation.id]);
                                          },
                                          child: Container(
                                            margin: EdgeInsets.only(top: HeightDimension.h_8, bottom: HeightDimension.h_8),
                                            child: Stack(
                                              children: [
                                                Row(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Stack(
                                                      children: [
                                                        ClipRRect(
                                                          borderRadius: BorderRadius.circular(12),
                                                          // Image border
                                                          child: SizedBox(
                                                            height: HeightDimension.h_70,
                                                            width: HeightDimension.h_70,
                                                            child: Image.network((_cartController.cartData?.sellers[index].products[productIndex].productVariation.productImages.isNotEmpty ?? false) ? _cartController.cartData?.sellers[index].products[productIndex].productVariation.productImages.first ?? "" : "",
                                                                fit: BoxFit.cover),
                                                          ),
                                                        ),
                                                        Visibility(
                                                          visible: true,
                                                          child: Positioned(
                                                            top: HeightDimension.h_5,
                                                            left: WidthDimension.w_2,
                                                            child: _cartController.cartData?.sellers[index].pickupOrDelivery == "PICKUP" ? SizedBox(width: WidthDimension.w_38, height: HeightDimension.h_14,child: Image.asset( TMTImages.icPickup),) : _cartController.cartData?.sellers[index].sellerStore.isFreeShippingEnabled == 1 ? SizedBox(width: WidthDimension.w_50, height: HeightDimension.h_14,child: Image.asset( TMTImages.icFreeDelivery),) : SizedBox.shrink(),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    HorizontalSpacing(WidthDimension.w_15),
                                                    Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        SizedBox(
                                                          width: SizeConfig.safeBlockHorizontal * 55,
                                                          child: TMTTextWidget(
                                                            maxLines: 2,
                                                            title: _cartController.cartData?.sellers[index].products[productIndex].title ?? "",
                                                            style: TMTFontStyles.text(
                                                              fontSize: TMTFontSize.sp_13,
                                                              color: AppColor.neutral_800,
                                                              fontWeight: FontWeight.w500,
                                                            ),
                                                          ),
                                                        ),
                                                        VerticalSpacing(HeightDimension.h_2),
                                                        SizedBox(
                                                          width: SizeConfig.safeBlockHorizontal * 55,
                                                          child: TMTTextWidget(
                                                            maxLines: 2,
                                                            title: _cartController.cartData?.sellers[index].products[productIndex].description ?? "",
                                                            style: TMTFontStyles.text(
                                                              fontSize: TMTFontSize.sp_11,
                                                              color: AppColor.textColor,
                                                              fontWeight: FontWeight.w400,
                                                            ),
                                                          ),
                                                        ),
                                                        VerticalSpacing(HeightDimension.h_8),
                                                        Row(
                                                          children: [
                                                            TMTTextWidget(
                                                              title: _cartController.getItemsPrice(index, productIndex),
                                                              style: TMTFontStyles.text(
                                                                fontSize: TMTFontSize.sp_16,
                                                                color: AppColor.neutral_800,
                                                                fontWeight: FontWeight.w600,
                                                              ),
                                                            ),
                                                            HorizontalSpacing(WidthDimension.w_10),
                                                            GestureDetector(
                                                              onTap: (){},
                                                              child: Container(
                                                                height: 25,
                                                                width: 70,
                                                                decoration: BoxDecoration(
                                                                    borderRadius: const BorderRadius.all(Radius.circular(6)),
                                                                    border: Border.all(color: const Color(0xFFD9D9D9), width: 0.7)
                                                                ),
                                                                child: Center(child: Text("Qty: 1", style: TMTFontStyles.text(),)),
                                                              ),
                                                            ),
                                                           /* TMTRoundedCornersContainer(
                                                              padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_2),
                                                              borderColor: const Color(0xFFD9D9D9),
                                                              child: PopupMenuButton<String>(
                                                                shape: RoundedRectangleBorder(
                                                                  borderRadius: BorderRadius.circular(12),
                                                                ),
                                                                offset: const Offset(0, 20),
                                                                constraints: BoxConstraints(
                                                                  minWidth: WidthDimension.w_90,
                                                                  maxWidth: WidthDimension.w_120,
                                                                  minHeight: HeightDimension.h_50,
                                                                  maxHeight: double.infinity
                                                                ),
                                                                itemBuilder: (context) {
                                                                  return qtItems.map((str) {
                                                                    return PopupMenuItem(
                                                                      value: str,
                                                                      child: Text(str),
                                                                    );
                                                                  }).toList();
                                                                },
                                                                child: Row(
                                                                  mainAxisSize: MainAxisSize.min,
                                                                  children: <Widget>[
                                                                    Text("Qty: ${_cartController.cartData?.sellers[index].products[productIndex].quantity}", style: TMTFontStyles.text(),),
                                                                    const Icon(Icons.arrow_drop_down, color: AppColor.neutral_800,),
                                                                  ],
                                                                ),
                                                                onSelected: (v) {
                                                                  setState(() {
                                                                    _cartController.cartData?.sellers[index].products[productIndex].quantity = int.parse(v);
                                                                    if (!TMTLocalStorage.getUserLoggedIn()) {
                                                                      TMTLocalStorage.updateCart(CartModel(productId: _cartController.cartData!.sellers[index].products[productIndex].id, productVariationId: _cartController.cartData!.sellers[index].products[productIndex].productVariation.id, quantity: _cartController.cartData!.sellers[index].products[productIndex].quantity));
                                                                      _cartController.getBuyerCart(context);
                                                                    } else {
                                                                      _cartController.updateCartQuantity(context, _cartController.cartData!.sellers[index].products[productIndex].cartItemId.toString(), v, _cartController.cartData!.sellers[index].products[productIndex].productVariation.id);
                                                                    }
                                                                    });
                                                                },
                                                              ),
                                                            ),*/ /// todo disabling qt dropdown for now
                                                            HorizontalSpacing(WidthDimension.w_10),
                                                            GestureDetector(
                                                              onTap: (){},
                                                              child: Container(
                                                                height: 25,
                                                                width: 70,
                                                                decoration: BoxDecoration(
                                                                    borderRadius: const BorderRadius.all(Radius.circular(6)),
                                                                    border: Border.all(color: const Color(0xFFD9D9D9), width: 0.7)
                                                                ),
                                                                child: Center(child: Text("Size: ${_cartController.cartData?.sellers[index].products[productIndex].selectedSize == null ? "M" : _cartController.cartData?.sellers[index].products[productIndex].selectedSize}", style: TMTFontStyles.text(),)),
                                                              ),
                                                            ),
                                                           /* TMTRoundedCornersContainer(
                                                              padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_2),
                                                              borderColor: const Color(0xFFD9D9D9),
                                                              child: PopupMenuButton<String>(
                                                                itemBuilder: (context) {
                                                                  return _cartController.cartData!.sellers[index].products[productIndex].sizes.map((str) {
                                                                    return PopupMenuItem(
                                                                      value: str.attributes.size,
                                                                      child: Text(str.attributes.size),
                                                                    );
                                                                  }).toList();
                                                                },
                                                                child: Row(
                                                                  mainAxisSize: MainAxisSize.min,
                                                                  children: <Widget>[
                                                                    Text("Size: ${_cartController.cartData?.sellers[index].products[productIndex].selectedSize}", style: TMTFontStyles.text(),),
                                                                    const Icon(Icons.arrow_drop_down, color: AppColor.neutral_800,),
                                                                  ],
                                                                ),
                                                                onSelected: (v) {
                                                                  setState(() {
                                                                    _cartController.cartData?.sellers[index].products[productIndex].selectedSize = v;
                                                                    if (!TMTLocalStorage.getUserLoggedIn()) {
                                                                      TMTLocalStorage.updateCart(CartModel(productId: _cartController.cartData?.sellers[index].products[productIndex].id ?? 0, productVariationId: _cartController.cartData?.sellers[index].products[productIndex].productVariation.id ?? 0, quantity: _cartController.cartData?.sellers[index].products[productIndex].quantity ?? 0));
                                                                      _cartController.getBuyerCart(context);
                                                                    } else {
                                                                      _cartController.updateCartSize(context, cartItemId: _cartController.cartData?.sellers[index].products[productIndex].cartItemId.toString() ?? "", productId: _cartController.cartData?.sellers[index].products[productIndex].id.toString() ?? "", size: v, variationId: _cartController.cartData?.sellers[index].products[productIndex].productVariation.id ?? 0);
                                                                    }
                                                                  });
                                                                },
                                                              ),
                                                            ),*/

                                                          ],
                                                        )
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                                Positioned(
                                                  top: 0,
                                                  right: 0,
                                                  child: InkWell(
                                                    onTap: (){
                                                      if (TMTLocalStorage.getUserLoggedIn()) {
                                                        TMTLocalStorage.removeFromCart(CartModel(productId: _cartController.cartData!.sellers[index].products[productIndex].id, productVariationId: _cartController.cartData!.sellers[index].products[productIndex].productVariation.id, quantity: 1));
                                                        _cartController.removeFromCart(context, _cartController.cartData!.sellers[index].products[productIndex].cartItemId, (){
                                                          setState(() {
                                                            if (TMTLocalStorage.getCartItems().isEmpty) {
                                                              _cartController.cartData = null;
                                                            } else {
                                                              _cartController.getBuyerCart(context);
                                                            }
                                                          });
                                                        });
                                                      } else {
                                                        TMTLocalStorage.removeFromCart(CartModel(productId: _cartController.cartData!.sellers[index].products[productIndex].id, productVariationId: _cartController.cartData!.sellers[index].products[productIndex].productVariation.id, quantity: 1));
                                                        setState(() {
                                                          if (TMTLocalStorage.getCartItems().isEmpty) {
                                                            _cartController.cartData = null;
                                                          } else {
                                                            _cartController.getBuyerCart(context);
                                                          }
                                                        });
                                                      }
                                                    },
                                                    child: SizedBox(
                                                      height: HeightDimension.h_20,
                                                      width: HeightDimension.h_20,
                                                      child: Container(
                                                        padding: const EdgeInsets.all(5),
                                                        child: Image.asset(TMTImages.icErrorToastCancel, color: AppColor.neutral_800,),
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                      itemCount: _cartController.cartData?.sellers[index].products.length ?? 0,
                                    ),
                                    VerticalSpacing(HeightDimension.h_15),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: TMTRoundedCornersContainer(
                                            borderColor: const Color(0xFFD9D9D9),
                                            borderRadius: const BorderRadius.all(Radius.circular(12)),
                                            padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_2, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                                            bgColor: Colors.white,
                                            child: InkWell(
                                              onTap: () {
                                                showDialog(
                                                  context: context,
                                                  builder: (context) => SimpleDialog(
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.circular(12),
                                                    ),
                                                    title: Text("Select Delivery Option", style: TMTFontStyles.text(
                                                      fontSize: TMTFontSize.sp_16,
                                                      color: AppColor.neutral_800,
                                                      fontWeight: FontWeight.w500,
                                                    ),),
                                                    children: _cartController.cartData?.sellers[index].sellerStore.deliveryItems.map((str) {
                                                      return SimpleDialogOption(
                                                        onPressed: () {
                                                          Navigator.pop(context, str);
                                                        },
                                                        child: Padding(
                                                          padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                                          child: TMTRoundedCornersContainer(
                                                            bgColor: _cartController.cartData?.sellers[index].pickupOrDelivery == str ? AppColor.primaryBG.withOpacity(0.2) : AppColor.neutral_100,
                                                            borderColor: _cartController.cartData?.sellers[index].pickupOrDelivery == str ? AppColor.primaryBG : AppColor.neutral_800,
                                                            padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, bottom: HeightDimension.h_8, top: HeightDimension.h_8),
                                                            child: Row(
                                                              children: [
                                                                HorizontalSpacing(WidthDimension.w_10),
                                                                TMTTextWidget(title: str.capitalizeFirst.toString(), style: TMTFontStyles.text(
                                                                  fontSize: TMTFontSize.sp_12,
                                                                  color: AppColor.neutral_800,
                                                                  fontWeight: FontWeight.w500,)),
                                                                HorizontalSpacing(WidthDimension.w_10),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      );
                                                    }).toList(),
                                                  ),
                                                ).then((value) {
                                                  if (value != null) {
                                                    setState(() {
                                                      _cartController.cartData?.sellers[index].pickupOrDelivery = value;
                                                      List<int> cartItemIds = [];
                                                      _cartController.cartData?.sellers[index].products.forEach((element) {
                                                        cartItemIds.add(element.cartItemId);
                                                      });
                                                      _cartController.updateDeliveryOption(context, cartItemIds, value);
                                                      _cartController.cartData?.sellers[index].products.forEach((element) {
                                                        if ((TMTLocalStorage.getCartItems().where((e) => e.productId == element.id && e.productVariationId == element.productVariation.id).isNotEmpty)) {
                                                          TMTLocalStorage.updateCart(CartModel(productId: element.id, productVariationId: element.productVariation.id, quantity: element.quantity));
                                                        }
                                                      });
                                                    });
                                                  }
                                                });
                                              },
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: <Widget>[
                                                  HorizontalSpacing(WidthDimension.w_6),
                                                  Text((_cartController.cartData?.sellers[index].pickupOrDelivery.isNotEmpty ?? false) ? _cartController.cartData!.sellers[index].pickupOrDelivery.capitalizeFirst.toString() : "Pickup", style: TMTFontStyles.text()),
                                                  const Spacer(),
                                                  const Icon(Icons.keyboard_arrow_down, color: AppColor.borderColor,),
                                                  HorizontalSpacing(WidthDimension.w_6),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        CustomPopupMenu(
                                          menuBuilder: () => TMTRoundedCornersContainer(
                                            borderRadius: BorderRadius.zero,
                                            margin: EdgeInsets.only(left: WidthDimension.w_100),
                                            width: WidthDimension.w_190,
                                            bgColor: AppColor.neutral_100,
                                            borderColor: AppColor.arrowColor,
                                            child: Column(
                                              children: [
                                                Container(
                                                  width: double.infinity,
                                                  color: AppColor.arrowColor,
                                                  padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                  child: TMTTextWidget(title: _getCharges(index), style: TMTFontStyles.text(
                                                    fontSize: TMTFontSize.sp_12,
                                                    color: AppColor.neutral_100,
                                                    fontWeight: FontWeight.w500,
                                                  ),),
                                                ),
                                              ],
                                            ),
                                          ),
                                          barrierColor: Colors.transparent,
                                          pressType: PressType.singleClick,
                                          arrowColor: AppColor.arrowColor,
                                          position: PreferredPosition.top,
                                          child: SizedBox(
                                            height: HeightDimension.h_15,
                                            width: HeightDimension.h_15,
                                            child: Image.asset(TMTImages.icInfo),
                                          ),
                                        )
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_5),
                                  ],
                                ),
                              );
                            },
                            itemCount: _cartController.cartData?.sellers.length ?? 0,
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            padding: EdgeInsets.only(top: HeightDimension.h_10),
                          ),
                          Visibility(
                            visible: _cartController.cartData?.sellers.isNotEmpty ?? false,
                            child: Column(
                              children: [
                                VerticalSpacing(HeightDimension.h_10),
                                Container(
                                  width: double.infinity,
                                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_10, bottom: HeightDimension.h_10),
                                  color: AppColor.neutral_100,
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          TMTTextWidget(title: "Price Details", style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ),),
                                          HorizontalSpacing(WidthDimension.w_10),
                                          const Spacer(),
                                          Row(
                                            children: [
                                              TMTTextWidget(title: _cartController.getTotalItemsCount().toString(), style: TMTFontStyles.textTeen(
                                                fontSize: TMTFontSize.sp_14,
                                                color: AppColor.primaryBG,
                                                fontWeight: FontWeight.w700,
                                              ),),
                                              HorizontalSpacing(WidthDimension.w_4),
                                              TMTTextWidget(title: _cartController.getTotalItemsCount() <= 1 ? "Item" : "Items", style: TMTFontStyles.textTeen(
                                                fontSize: TMTFontSize.sp_14,
                                                color: AppColor.neutral_800,
                                                fontWeight: FontWeight.w700,
                                              ),),
                                            ],
                                          ),
                                        ],
                                      ),
                                      VerticalSpacing(HeightDimension.h_10),
                                      Container(
                                        width: double.infinity,
                                        height: 1,
                                        color: AppColor.lightGrey,
                                      ),
                                      VerticalSpacing(HeightDimension.h_10),
                                      Row(
                                        children: [
                                          TMTTextWidget(title: "Item Price", style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),),
                                          HorizontalSpacing(WidthDimension.w_10),
                                          const Spacer(),
                                          TMTTextWidget(title: "£${_cartController.getItemPrices().toStringAsFixed(2)}", style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),),
                                        ],
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                      Row(
                                        children: [
                                          TMTTextWidget(title: "VAT(${_cartController.cartData?.tax}%)", style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),),
                                          HorizontalSpacing(WidthDimension.w_10),
                                          const Spacer(),
                                          TMTTextWidget(title: _cartController.getTotalTax(), style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),),
                                        ],
                                      ),
                                      VerticalSpacing(HeightDimension.h_5),
                                      Row(
                                        children: [
                                          Row(
                                            children: [
                                              TMTTextWidget(title: "Shipping Charges", style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_12,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w400,
                                              ),),
                                              HorizontalSpacing(WidthDimension.w_6),
                                              CustomPopupMenu(
                                                menuBuilder: () => TMTRoundedCornersContainer(
                                                  borderRadius: BorderRadius.zero,
                                                  margin: EdgeInsets.only(left: WidthDimension.w_100),
                                                  width: WidthDimension.w_190,
                                                  height: ((_cartController.cartData?.sellers.length ?? 0) < 2 && (_cartController.cartData?.sellers.first.products.length ?? 0) <= 2) ? HeightDimension.h_100 : HeightDimension.h_130,
                                                  bgColor: AppColor.neutral_100,
                                                  borderColor: AppColor.arrowColor,
                                                  child: Column(
                                                    children: [
                                                      Container(
                                                        width: double.infinity,
                                                        color: AppColor.arrowColor,
                                                        padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                        child: TMTTextWidget(title: "Shipping Calculations", style: TMTFontStyles.text(
                                                          fontSize: TMTFontSize.sp_12,
                                                          color: AppColor.neutral_100,
                                                          fontWeight: FontWeight.w500,
                                                        ),),
                                                      ),
                                                      VerticalSpacing(HeightDimension.h_5),
                                                      Expanded(
                                                        child: SingleChildScrollView(
                                                          child: Column(
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              ListView.builder(
                                                                padding: EdgeInsets.zero,
                                                                itemBuilder: (context, index){
                                                                  return Container(
                                                                    padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                                                                    color: AppColor.neutral_100,
                                                                    child: Column(
                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                      children: [
                                                                        Column(
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            Row(
                                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                              children: [
                                                                                TMTTextWidget(title: _cartController.cartData?.sellers[index].name ?? "", style: TMTFontStyles.text(
                                                                                  fontSize: TMTFontSize.sp_8,
                                                                                  color: AppColor.textColor,
                                                                                  fontWeight: FontWeight.w600,
                                                                                ),),
                                                                                TMTTextWidget(title: "£${_cartController.getProductHandlingPrice(index).toStringAsFixed(2)}", style: TMTFontStyles.text(
                                                                                  fontSize: TMTFontSize.sp_8,
                                                                                  color: AppColor.textColor,
                                                                                  fontWeight: FontWeight.w600,
                                                                                ),),
                                                                              ],
                                                                            ),
                                                                            VerticalSpacing(HeightDimension.h_5),
                                                                            ListView.builder(
                                                                              padding: EdgeInsets.zero,
                                                                              itemBuilder: (c,i){

                                                                                double subCost = 0;
                                                                                _cartController.cartData?.sellers[index].products.forEach((element) {
                                                                                  subCost = subCost + element.productVariation.salePrice;
                                                                                });

                                                                                return Column(
                                                                                  children: [
                                                                                    Row(
                                                                                      children: [
                                                                                        SizedBox(
                                                                                          width: WidthDimension.w_120,
                                                                                          child: TMTTextWidget(
                                                                                            maxLines: 3,
                                                                                            title: _cartController.cartData?.sellers[index].products[i].title ?? "", style: TMTFontStyles.text(
                                                                                            fontSize: TMTFontSize.sp_8,
                                                                                            color: AppColor.textColor,
                                                                                            fontWeight: FontWeight.w500,
                                                                                          ),),
                                                                                        ),
                                                                                        const Spacer(),
                                                                                        HorizontalSpacing(WidthDimension.w_10),
                                                                                        TMTTextWidget(title: _cartController.cartData?.sellers[index].pickupOrDelivery ?? "PICKUP", style: TMTFontStyles.text(
                                                                                          fontSize: TMTFontSize.sp_8,
                                                                                          color: AppColor.textColor,
                                                                                          fontWeight: FontWeight.w500,
                                                                                        ),)
                                                                                      ],
                                                                                    ),
                                                                                  ],
                                                                                );
                                                                              }, itemCount: _cartController.cartData?.sellers[index].products.length ?? 0, scrollDirection: Axis.vertical, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),)
                                                                          ],
                                                                        ),
                                                                        VerticalSpacing(HeightDimension.h_5),
                                                                      ],
                                                                    ),
                                                                  );
                                                                }, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), scrollDirection: Axis.vertical, itemCount: _cartController.cartData?.sellers.length ?? 0,),
                                                            ],
                                                          ),
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                ),
                                                barrierColor: Colors.transparent,
                                                pressType: PressType.singleClick,
                                                arrowColor: AppColor.arrowColor,
                                                position: PreferredPosition.bottom,
                                                child: SizedBox(
                                                  height: HeightDimension.h_15,
                                                  width: HeightDimension.h_15,
                                                  child: Image.asset(TMTImages.icInfo),
                                                ),
                                              )
                                            ],
                                          ),
                                          HorizontalSpacing(WidthDimension.w_10),
                                          const Spacer(),
                                          TMTTextWidget(title: "£${_cartController.getProductHandlingSumPrice().toStringAsFixed(2)}", style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),),
                                        ],
                                      ),
                                      VerticalSpacing(HeightDimension.h_20),
                                      Container(
                                        width: double.infinity,
                                        height: 1,
                                        color: AppColor.lightGrey,
                                      ),
                                      VerticalSpacing(HeightDimension.h_10),
                                      Row(
                                        children: [
                                          TMTTextWidget(title: "Total Amount", style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ),),
                                          HorizontalSpacing(WidthDimension.w_10),
                                          const Spacer(),
                                          TMTTextWidget(title: _cartController.getTotalSumAmount(), style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.primaryBG,
                                            fontWeight: FontWeight.w700,
                                          ),),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          VerticalSpacing(HeightDimension.h_10),
                        ],
                      ),
                    ),
                  ),
                  Visibility(
                    visible: _cartController.cartData?.sellers.isNotEmpty ?? false,
                    child: Container(
                      padding: EdgeInsets.only(
                          left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.3),
                          spreadRadius: 3,
                          blurRadius: 5,
                          offset: const Offset(0, 3), // changes position of shadow
                        ),
                      ], color: AppColor.neutral_100),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () async {
                                if (TMTLocalStorage.getUserLoggedIn()) {
                                  if (_cartController.addressData.isEmpty) {
                                    TMTToast.showErrorToast(context, "Please add address to continue", title: "Alert");
                                    return;
                                  }
                                  _cartController.postCreateOrder(context, (data) {
                                    TMTLocalStorage.clearCart();
                                    _startPayment(data);
                                  });
                                } else {
                                  _showLoginPrompt(context);
                                }
                              },
                              child: Container(
                                padding: EdgeInsets.only(
                                    top: HeightDimension.h_12,
                                    bottom: HeightDimension.h_12,
                                    left: WidthDimension.w_18,
                                    right: WidthDimension.w_18),
                                decoration: BoxDecoration(
                                    color: AppColor.primaryBG,
                                    border: Border.all(color: AppColor.primaryBG, width: 1),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(TMTRadius.r_30))),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    TMTTextWidget(
                                      title: "CHECKOUT",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_18,
                                        color: AppColor.neutral_100,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
              Visibility(
                visible: (_cartController.cartData?.sellers.isEmpty ?? true),
                child: Center(
                  child: Padding(
                    padding: EdgeInsets.only(left: WidthDimension.w_40, right: WidthDimension.w_40),
                    child: TMTTextWidget(
                      maxLines: 6,
                      textAlign: TextAlign.center,
                      title: "Your cart is feeling light and ready for new adventures! Start exploring our amazing collection and fill it up with products.",
                      style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_12,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
          bottomNavigationBar: cameFromDashBoard == false ? CommonBottomNavigationBar(
              currentSelectedItem: 3, onTap: (index) {
            Get.offAllNamed(AppRoutes.dashBoardScreen, arguments: index);
          }) : SizedBox.shrink(),
        );
      }
    );
  }

  /// show login prompt
  void _showLoginPrompt(BuildContext context) {
    showDialog(context: context, builder: (context) {
      return Material(
        color: Colors.transparent,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
          child: Container(
            decoration: BoxDecoration(color: AppColor.neutral_800.withOpacity(0.5)),
            width: double.infinity,
            height: double.infinity,
            child: Center(
              child: TMTRoundedCornersContainer(
                width: WidthDimension.w_286,
                height: HeightDimension.h_140,
                bgColor: AppColor.neutral_100,
                borderRadius:
                const BorderRadius.all(Radius.circular(TMTRadius.r_15)),
                padding: const EdgeInsets.only(top: TMTDimension.padding_20, left: TMTDimension.padding_20, right: TMTDimension.padding_20),
                child: Column(
                  children: [
                    TMTTextWidget(
                      title: "Please login to continue.",
                      style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.primaryBG,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_15),
                    InkWell(
                        onTap: (){
                          Get.offAndToNamed(AppRoutes.loginScreen, arguments: AppRoutes.homeScreen);
                        },
                        child: Container(height: HeightDimension.h_40, margin: EdgeInsets.only(left: HeightDimension.h_20, right: HeightDimension.h_20),child: const TMTTextButton(buttonTitle: "Login"),)),
                    VerticalSpacing(HeightDimension.h_10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TMTTextWidget(
                          title: "New customer?",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_12,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_4),
                        GestureDetector(
                          onTap: (){
                            Get.offAndToNamed(AppRoutes.signUpScreen);
                          },
                          child: TMTTextWidget(
                            title: "Start here.",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_12,
                              color: AppColor.primaryBG,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    });
  }

  /// Return popup with pickup address details
  Widget _pickupPopup(BuildContext context, SellerStore? sellerStore) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: TMTRoundedCornersContainer(
          width: WidthDimension.w_286,
          height: HeightDimension.h_122,
          bgColor: AppColor.neutral_100,
          borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_15)),
          padding: const EdgeInsets.all(TMTDimension.padding_20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TMTTextWidget(title: "Seller Pickup address", style: TMTFontStyles.textTeen(
                fontSize: TMTFontSize.sp_18,
                color: AppColor.primaryBG,
                fontWeight: FontWeight.w700,
              ),),
              VerticalSpacing(HeightDimension.h_20),
              TMTTextWidget(title: "${sellerStore?.addressLine1 ?? ""}, ${sellerStore?.city ?? ""}, ${sellerStore?.country ?? ""}, ${sellerStore?.postCode ?? ""}", style: TMTFontStyles.text(
                fontSize: TMTFontSize.sp_12,
                color: AppColor.textColor,
                fontWeight: FontWeight.w400,
              ), textAlign: TextAlign.center,),
            ],
          ),
        ),
      ),
    );
  }

  /// start payment process
  void _startPayment(CreatedOrder? orderData) {
    try {
      _cartController.postCreateCustomer(context, (customerId) {
        if (customerId?.isNotEmpty ?? false) {
          _cartController.getCards(context, (cards) async {
            if (cards != null) {
              if (cards.data.isNotEmpty) {
                await Get.toNamed(AppRoutes.cardsCheckoutScreen, arguments: orderData!.id)?.then((value){
                  _cartController.getBuyerCart(context);
                });
              } else {
                _cartController.postCreatePaymentIntent(context, (data) async {
                  _cartController.paymentUsingCard(data : data, context: context);
                }, PostCreatePaymentIntentRequest(
                    amount: _cartController.getGrandTotal().toInt(),
                    paymentMethod: ["cards"],
                    shipping: PRShipping(address: PRAddress(
                        line1: _cartController.defaultAddress?.address1 ?? "",
                        line2: _cartController.defaultAddress?.address1 ?? "",
                        postalCode: _cartController.defaultAddress?.postCode ??
                            "",
                        city: _cartController.defaultAddress?.city ?? "",
                        state: _cartController.defaultAddress?.state ?? "",
                        country: _cartController.defaultAddress?.country ??
                            "")), orderId: orderData!.id.toString()));
              }
            }
            else {
              _cartController.postCreatePaymentIntent(context, (data) async {
                _cartController.paymentUsingCard(data : data, context: context);
              }, PostCreatePaymentIntentRequest(
                  amount: _cartController.getGrandTotal().toInt(),
                  paymentMethod: ["cards"],
                  shipping: PRShipping(address: PRAddress(
                      line1: _cartController.defaultAddress?.address1 ?? "",
                      line2: _cartController.defaultAddress?.address1 ?? "",
                      postalCode: _cartController.defaultAddress?.postCode ??
                          "",
                      city: _cartController.defaultAddress?.city ?? "",
                      state: _cartController.defaultAddress?.state ?? "",
                      country: _cartController.defaultAddress?.country ??
                          "")), orderId: orderData!.id.toString()));
            }
          });
        }
        else {
          _cartController.postCreatePaymentIntent(context, (data) async {
            _cartController.paymentUsingCard(data : data, context: context);
          }, PostCreatePaymentIntentRequest(
              amount: _cartController.getGrandTotal().toInt(),
              paymentMethod: ["cards"],
              shipping: PRShipping(address: PRAddress(
                  line1: _cartController.defaultAddress?.address1 ?? "",
                  line2: _cartController.defaultAddress?.address1 ?? "",
                  postalCode: _cartController.defaultAddress?.postCode ??
                      "",
                  city: _cartController.defaultAddress?.city ?? "",
                  state: _cartController.defaultAddress?.state ?? "",
                  country: _cartController.defaultAddress?.country ??
                      "")), orderId: orderData!.id.toString()));
        }
      });
    } catch (e) {
      print(e.toString());
    }
  }

  void _callApi() {
    _cartController.getBuyerCart(context);
    if (TMTLocalStorage.getUserLoggedIn()) {
      _addressScreenController.getAddress(context);
      _cartController.getAddress(context, callback: () async {
        await Future.delayed(const Duration(milliseconds: 500));
        setState(() {
          if ( _cartController.defaultAddress?.firstName != null && _cartController.defaultAddress?.postCode != null) {
            address = "${_cartController.defaultAddress?.firstName}, ${_cartController.defaultAddress?.postCode}";
          }
        });
      });
    }
  }

  /// get pickup / delivery charges
  String _getCharges(int index) {
    try {
      if (_cartController.cartData!.sellers[index].pickupOrDelivery.capitalizeFirst.toString().contains("Pickup")) {
        return "Pickup charges (per item): £${_cartController.cartData?.sellers[index].sellerStore.pickupFromStoreHandlingCharges.toInt().toStringAsFixed(2) ?? 0}";
      } else {
        int subCost = _cartController.cartData?.cartFinalData[index].subCost ?? 0;
        var cost = (_cartController.cartData?.sellers[index].sellerStore.isFreeShippingEnabled == 1 &&  subCost > (_cartController.cartData?.sellers[index].sellerStore.freeShippingMinimumCost ?? 0)) ? 0 : (_cartController.cartData?.cartFinalData[index].totalWeightShippingCost ?? 0);
        if (cost == 0) {
          return "Your cart value is eligible for free shipping. Delivery charges: ${0.00}";
        } else {
          return "Delivery charges £${cost.toStringAsFixed(2)}";
        }
      }
    } catch (e) {
      return "Charges £0.00";
    }
  }
}