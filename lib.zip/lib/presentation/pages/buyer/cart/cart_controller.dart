import 'package:dartz/dartz.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/cart_models.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/post_add_to_cart_request.dart';
import 'package:take_my_tack/data/model/request/post_create_order_request.dart';
import 'package:take_my_tack/data/model/request/post_create_payment_intent_request.dart';
import 'package:take_my_tack/data/model/request/post_make_payment_request.dart';
import 'package:take_my_tack/data/model/request/put_change_cart_quantity_request.dart';
import 'package:take_my_tack/data/model/request/put_update_cart_delivery_type_request.dart';
import 'package:take_my_tack/data/model/response/get_cards_response.dart';
import 'package:take_my_tack/data/model/response/get_cart_response.dart';
import 'package:take_my_tack/data/model/response/get_delivery_address_response.dart';
import 'package:take_my_tack/data/model/response/post_create_order_response.dart';
import 'package:take_my_tack/data/model/response/post_create_payment_intent_response.dart';
import 'package:take_my_tack/data/model/response/post_payment_off_session_response.dart';
import 'package:take_my_tack/data/repository_implementation/dashboard_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/payment_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/product_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/loading_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';
import 'package:stripe_platform_interface/src/models/payment_methods.dart' as billingMethod;

class CartController extends GetxController {

  ProductRepositoryImpl productRepositoryImpl = ProductRepositoryImpl();
  PaymentRepositoryImpl paymentRepositoryImpl = PaymentRepositoryImpl();

  CartData? cartData;

  List<SizeClass> sizes = [];

  final DashboardRepositoryImpl _dashboardRepositoryImpl = DashboardRepositoryImpl();

  List<AddressData> addressData = [];
  AddressData? defaultAddress;

  CardFieldInputDetails? card;
  bool? saveCard = true;

  List<CardResponseData> cardsData = [];
  CreatedOrder? orderData;

  /*
   Method use to get Products By Category Id.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getBuyerCart (BuildContext context) {
    var params = PostAddBulkToCartRequest(requestHeader: DioUtils.getRequestHeaderModel(), items: TMTLocalStorage.getCartItems().map((e) => CartItem(productId: e.productId, productVariationId: e.productVariationId, quantity: e.quantity)).toList());

    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        try {
          const Loading().start(context);
        } catch (e) {}
        try {
          bool isLocalDataEmpty = TMTLocalStorage.getCartItems().isEmpty;
          if (isLocalDataEmpty) {
            if (TMTLocalStorage.getUserLoggedIn()) {
              _callCartApi(context);
            }
          } else {
            Either<Failure, GetCartProductsResponse> response = await productRepositoryImpl.getBulkCart(params);
            response.fold((left) {
              if (left is ServerFailure) {
                /// show exception
                TMTToast.showErrorToast(context, left.message ?? '');
              }
            }, (right) {
              if (right.responseHeader.error == null) {
                cartData = right.data;
                cartData?.sellers.forEach((sellerElement) {
                  for (var productElement in sellerElement.products) {
                    sizes = productElement.sizes;
                    productElement.selectedSize = "M";
                  }
                });
                TMTLocalStorage.clearCart();
                cartData?.sellers.forEach((sellerElement) {
                  for (var sellerProduct in sellerElement.products) {
                    TMTLocalStorage.addToCart(CartModel(productId: sellerProduct.id, productVariationId: sellerProduct.productVariation.id, quantity: sellerProduct.quantity));
                  }
                });
                update([GetControllerBuilders.cartScreenController]);
              }
              else {
                if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                  TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                  TMTLocalStorage.clear();
                  Get.offAllNamed(AppRoutes.dashBoardScreen);
                } else {
                  TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
                }
              }
            });
          }

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to remove Product from Cart.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void removeFromCart (BuildContext context, int cartItemId, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.removeFromCart(cartItemId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              callback.call();
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update cart products size.
   Parameter- BuildContext context, String cartItemId, String productId, String size, int variationId.
   Return -> No Return type.
  */
  void updateCartSize (BuildContext context, {required String cartItemId, required String productId, required String size, required int variationId}) {

    var params = PutChangeCartQuantityRequest(requestHeader: DioUtils.getRequestHeaderModel(), variationId: variationId);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.putUpdateCartSize(params, cartItemId, productId, size);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              getBuyerCart(context);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token") {

              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update cart products quantity.
   Parameter- BuildContext context, String cartItemId, String quantity, int variationId.
   Return -> No Return type.
  */
  void updateCartQuantity (BuildContext context, String cartItemId, String quantity, int variationId) {

    var params = PutChangeCartQuantityRequest(requestHeader: DioUtils.getRequestHeaderModel(), variationId: variationId);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.putUpdateCartQuantity(params, cartItemId, quantity);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              TMTLocalStorage.clearCart();
              getBuyerCart(context);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token") {
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update cart delivery option.
   Parameter- BuildContext context, String cartItemId, String option.
   Return -> No Return type.
  */
  void updateDeliveryOption (BuildContext context, List<int> cartItemIds, String option) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.putUpdateCartDeliveryOption(PutUpdateDeliveryTypeRequest(requestHeader: DioUtils.getRequestHeaderModel(), pickupOrDelivery: option, cartItemIds: cartItemIds));
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              TMTLocalStorage.clearCart();
              getBuyerCart(context);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token") {
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// call get cart api
  void _callCartApi(BuildContext context) async {
    Either<Failure, GetCartProductsResponse> response = await productRepositoryImpl.getCart();
    response.fold((left) {
      if (left is ServerFailure) {
        /// show exception
        TMTToast.showErrorToast(context, left.message ?? '');
      }
    }, (right) {
      if (right.responseHeader.error == null) {
        if (right.data.sellers.isNotEmpty) {
          cartData = right.data;
          cartData?.sellers.forEach((sellerElement) {
            for (var productElement in sellerElement.products) {
              sizes = productElement.sizes;
              if (productElement.sizes.isNotEmpty){
                productElement.selectedSize = productElement.sizes.first.attributes.size;
              }
            }
          });
          cartData?.sellers.forEach((sellerElement) {
            for (var sellerProduct in sellerElement.products) {
              TMTLocalStorage.addToCart(CartModel(productId: sellerProduct.id, productVariationId: sellerProduct.productVariation.id, quantity: sellerProduct.quantity));
            }
          });
        } else {
          cartData = null;
        }
        update([GetControllerBuilders.cartScreenController]);
      }
      else {
        if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
          TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
          TMTLocalStorage.clear();
          Get.offAllNamed(AppRoutes.dashBoardScreen);
        } else {
          TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
        }
      }
    });
  }

  /*
   Method use to get address.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getAddress (BuildContext context, {Function? callback}) {
    if (!TMTLocalStorage.getUserLoggedIn()) {
      return;
    }
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _dashboardRepositoryImpl.getDeliveryAddress();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              addressData = right.data ?? [];
              defaultAddress = right.data?.firstWhereOrNull((element) => element.isDefault == 1);
              callback?.call();
              update([GetControllerBuilders.cartAddressCheckoutScreenController]);
            }
            else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to create order.
   Parameter- BuildContext context, Function callback.
   Return -> No Return type.
  */
  void postCreateOrder (BuildContext context, Function(CreatedOrder? data) callback) {
    var params = PostCreateOrderRequest(cartId: cartData?.cartId ?? 0, deliveryAddressId: defaultAddress!.id);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.postCreateOrder(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              orderData = right.createdOrder;
              callback.call(right.createdOrder);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// get total items count
  int getTotalItemsCount() {
    int count = 0;
    cartData?.sellers.forEach((element) {
      for (var element in element.products) {
        count = count + element.quantity;
      }
    });
    return count;
  }

  /// get total sum price of items
  double getItemPrices() {
    double subCostPrice = 0;
    cartData?.cartFinalData.forEach((element) {
      subCostPrice = subCostPrice + element.subCost;
    });
    return subCostPrice;
  }

  /// get total sum price of items
  int getItemCost() {
    int subCostPrice = 0;
    cartData?.cartFinalData.forEach((element) {
      subCostPrice = subCostPrice + (element.subCost as int);
    });
    return subCostPrice;
  }

  /// get product handling price charges
  double getProductHandlingPrice(int index) {
    try {
      /// calculate sub cost of products
      int subCost = cartData?.cartFinalData[index].subCost ?? 0;

      var charges = 0;
      if (cartData?.sellers[index].pickupOrDelivery == "PICKUP") {
        charges = ((cartData?.cartFinalData[index].pickupFromStoreHandlingCharges ?? 0));
      }
      else {
        charges = (cartData?.sellers[index].sellerStore.isFreeShippingEnabled == 1 &&  subCost > (cartData?.sellers[index].sellerStore.freeShippingMinimumCost ?? 0)) ? 0 : (cartData?.cartFinalData[index].totalWeightShippingCost ?? 0);
      }
      return charges.toDouble();
    } catch (error) {
      return 0;
    }
  }

  double getProductHandlingSumPrice () {
    try {
      double subCost = 0;
      for (int i=0; i<(cartData?.sellers.length ?? 0); i++) {
        subCost = subCost + getProductHandlingPrice(i);
      }
      return subCost;
    } catch (error) {
      return 0;
    }
  }

  /// get total tax
  String getTotalTax() {
    var grossTax = calculatePercentage(getItemPrices().toDouble(), cartData?.tax.toDouble() ?? 0);
    var sum = grossTax;
    return "£${sum.toStringAsFixed(2)}";
  }

  /// get percentage of given value
  double calculatePercentage(double value, double percentage) {
    double result = (value * percentage) / 100;
    return result;
  }

  /// get total payable amount
  String getTotalSumAmount() {
    var grossTax = calculatePercentage(getItemPrices().toDouble(), cartData?.tax.toDouble() ?? 0);
    var priceWithoutShipping = getItemPrices() + grossTax;
    var sum = priceWithoutShipping + getProductHandlingSumPrice();
    return "£${sum.toStringAsFixed(2)}";
  }

  /// get item sales amount by quantity
  String getItemsPrice(int index, int productIndex) {
    try {
      int totalPriceOfItem = 0;
      for (int i = 0; i < (cartData?.sellers[index].products[productIndex].quantity ?? 0); i++) {
        totalPriceOfItem = (cartData?.sellers[index].products[productIndex].productVariation.salePrice ?? 0) * (cartData?.sellers[index].products[productIndex].quantity ?? 0);
      }
      return "£${totalPriceOfItem.toStringAsFixed(2)}";
    } catch (error) {
      return "";
    }
  }

  /// get total cart cost without tax
  double _getTotalCartCostWOTax() {
    List<double> prices = [];
    double totalWithoutTax = 0;
    for(int i = 0; i< (cartData?.sellers.length ?? 0); i++) {

      if (cartData?.sellers[i].pickupOrDelivery == "PICKUP") {
        double sum = getItemCost().toDouble() + (cartData?.sellers[i].sellerStore.pickupFromStoreHandlingCharges ?? 0);
        prices.add(sum);
      } else {
        double sum = (cartData?.sellers[i].sellerStore.isFreeShippingEnabled == 1 && getItemCost().toDouble() > (cartData?.sellers[i].sellerStore.freeShippingMinimumCost ?? 0)) ? getItemCost().toDouble() : getItemCost().toDouble() + (cartData?.sellers[i].sellerStore.freeShippingMinimumCost ?? 0);
        prices.add(sum);
      }
      totalWithoutTax += prices[i];
    }

    return totalWithoutTax;
  }

  /// get grand total cost
  double getGrandTotal() {
    List<double> prices = [];
    double totalWithoutTax = 0;
    for(int i = 0; i< (cartData?.sellers.length ?? 0); i++) {

      if (cartData?.sellers[i].pickupOrDelivery == "PICKUP") {
        double sum = getItemCost().toDouble() + (cartData?.sellers[i].sellerStore.pickupFromStoreHandlingCharges ?? 0);
        prices.add(sum);
      } else {
        double sum = (cartData?.sellers[i].sellerStore.isFreeShippingEnabled == 1 &&  getItemCost().toDouble() > (cartData?.sellers[i].sellerStore.freeShippingMinimumCost ?? 0)) ? getItemCost().toDouble() : getItemCost().toDouble() + (cartData?.sellers[i].sellerStore.freeShippingMinimumCost ?? 0);
        prices.add(sum);
      }
      totalWithoutTax += prices[i];
    }

    var grossTax = calculatePercentage(totalWithoutTax, cartData?.tax.toDouble() ?? 0);
    var sum = totalWithoutTax + grossTax;
    return sum;
  }

  /// get tax in percentage
  int _getTaxInPercentage() {
    return cartData?.tax ?? 0;
  }

  /*
   Method use to create customer.
   Parameter- BuildContext context, Function callback.
   Return -> No Return type.
  */
  void postCreateCustomer (BuildContext context, Function(String? customerId) callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await paymentRepositoryImpl.postCreateCustomer();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              callback.call(right.customerId);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to create payment intent.
   Parameter- BuildContext context, Function callback.
   Return -> No Return type.
  */
  void postCreatePaymentIntent (BuildContext context, Function (PIData? data) callback, PostCreatePaymentIntentRequest request) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        try {
          const Loading().start(context);
        } catch (e) {}
        try {
          var response = await paymentRepositoryImpl.postCreatePaymentIntent(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              callback.call(right.data);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                callback.call(right.data);
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get cards.
   Parameter- BuildContext context, Function callback.
   Return -> No Return type.
  */
  void getCards (BuildContext context, Function(OrderDetails? data) callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await paymentRepositoryImpl.getCards();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              cardsData = right.orderDetails?.data ?? [];
              callback.call(right.orderDetails);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                callback.call(right.orderDetails);
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// handle payment
  Future<void> _handlePayPress(PIData data, BuildContext context) async {
    if (card == null) {
      return;
    }
    var paymentIntent;
    try {
      paymentIntent = await Stripe.instance.confirmPayment(
        paymentIntentClientSecret: data.clientSecret,
        data: const PaymentMethodParams.card(
          paymentMethodData: PaymentMethodData(
            billingDetails: billingMethod.BillingDetails(),
          ),
        ),
        options: PaymentMethodOptions(
          setupFutureUsage:
          saveCard == true ? PaymentIntentsFutureUsage.OffSession : null,
        ),
      );
      if (kDebugMode) {
        print(paymentIntent);
      }
      if (paymentIntent.status == PaymentIntentsStatus.Succeeded) {
        if (!context.mounted) return;
        TMTToast.showSuccessToast(context, "Payment successful, Seller would be shipping your order in 2-3 business days");
      } else {
        if (!context.mounted) return;
        TMTToast.showErrorToast(context, paymentIntent.toString());
      }
      Navigator.pop(context);
      Get.offNamed(AppRoutes.confirmOrderScreen, arguments: orderData!.id);
    } catch (e) {
      Get.offNamed(AppRoutes.confirmOrderScreen, arguments: orderData!.id);
      if (e is StripeException) {
        TMTToast.showErrorToast(context, e.error.message ?? e.toString());
      } else {
        TMTToast.showErrorToast(context, e.toString());
      }
      if (kDebugMode) {
        print("Error : ${e.toString()}");
      }
    }
    return;
  }

  /// make payment using card
  Future<void> paymentUsingCard({PIData? data, required BuildContext context}) async {
    /// Stripe payment
    Stripe.publishableKey = "pk_test_51NPfpzSCzdOYRdbbDTCvvwFC1Exjx58UMUmOcHtKtUy85iamihgoj2kkKidqYB5PrYKS93I3nrjWBDxbNloFWHLh00qwEgFafB";
    await Stripe.instance.applySettings();
    if (!context.mounted) return;
    if (data != null) {
      showDialog(
          barrierDismissible: false,
          context: context, builder: (context) {
        return StatefulBuilder(
            builder: (c, setState) {
              return Material(
                color: Colors.white,
                child: TMTBackButton(
                  onWillPop: () {
                    return Future.value(false);
                  },
                  child: Container(
                    padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                    child: Column(
                      children: [
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: (){
                                Navigator.pop(c);
                                TMTToast.showErrorToast(context, "Do not worry, we have placed your order. You can try paying again", title: "Payment Failed");
                                Get.offNamed(AppRoutes.confirmOrderScreen, arguments: orderData!.id);
                              },
                              child: SizedBox(
                                height: HeightDimension.h_20,
                                width: HeightDimension.h_20,
                                child: Image.asset(TMTImages.icBack, color: AppColor.neutral_800,),
                              ),
                            ),
                            TMTTextWidget(title: "ADD CARD DETAILS", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_18, fontWeight: FontWeight.w700, color: AppColor.neutral_700),),
                            SizedBox(
                              height: HeightDimension.h_20,
                              width: HeightDimension.h_20,
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        CardField(
                          enablePostalCode: true,
                          countryCode: 'GB',
                          postalCodeHintText: 'Enter the UK postal code',
                          onCardChanged: (c) {
                            setState(() {
                              card = c;
                            });
                          },
                        ),
                        const SizedBox(height: 20),
                        CheckboxListTile(
                          activeColor: AppColor.primary,
                          controlAffinity: ListTileControlAffinity.leading,
                          value: saveCard,
                          onChanged: (value) {
                            setState(() {
                              saveCard = value;
                            });
                          },
                          title: const Text('Save card during payment'),
                        ),
                        LoadingButton(
                          onPressed: card?.complete == true
                              ? () async {
                            await _handlePayPress(data, c);
                          }
                              : null,
                          text: 'Pay',
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              );
            }
        );
      });
    }
  }

  /*
   Method use to get cards.
   Parameter- BuildContext context, Function callback.
   Return -> No Return type.
  */
  void makePaymentOffSession (BuildContext context, CardResponseData cardsData, Function(POSData? data) callback, String orderId) {
    var params = PostMakePaymentOffSessionRequest(amount: _getTotalAmount(orderData!).toInt(), paymentMethodId: cardsData.id, shipping: PORShipping(address: POAddress(line1: defaultAddress!.address1, line2: defaultAddress!.address2, postalCode: defaultAddress!.postCode, city: defaultAddress!.city, state: defaultAddress!.state, country: defaultAddress!.country)), orderId: orderId);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await paymentRepositoryImpl.postPaymentOffSession(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              callback.call(right.data);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// get total amount (with tax)
  double _getTotalAmount(CreatedOrder createdOrder) {
    return createdOrder.cartSubCost! + (createdOrder.cartSubCost! * (createdOrder.taxInPercentage! / 100));
  }
}