import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/post_resend_signup_otp_request.dart';
import 'package:take_my_tack/data/model/request/post_validate_otp_request.dart';
import 'package:take_my_tack/data/repository_implementation/auth_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class VerifyOTPController extends GetxController {
  AuthRepositoryImpl repositoryImpl = AuthRepositoryImpl();

  /*
   Method use to verify otp.
   Parameter- BuildContext context, String email.
   Return -> No Return type.
  */
  void postVerifyOtp(BuildContext context, String email, String otp) {
    var request = PostValidateOtpRequest(
        requestHeader: DioUtils.getRequestHeaderModel(),
        email: email.toLowerCase(),
        otp: otp,
      otpType: 2
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.validateOTP(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              showDialog(
                barrierDismissible: false,
                  context: context,
                  builder: (context) {
                    return Material(
                      color: Colors.transparent,
                      child: TMTBackButton(
                        onWillPop: (){
                          return Future.value(false);
                        },
                        child: Center(
                          child: SizedBox(
                            width: WidthDimension.w_240,
                            child: Stack(
                              children: [
                                TMTRoundedCornersContainer(
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(TMTRadius.r_15)),
                                  margin:
                                      EdgeInsets.only(top: HeightDimension.h_40),
                                  bgColor: AppColor.neutral_100,
                                  padding: const EdgeInsets.all(20),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      VerticalSpacing(HeightDimension.h_25),
                                      TMTTextWidget(
                                        title: "Verified",
                                        style: TMTFontStyles.text(
                                            color: AppColor.green,
                                            fontWeight: FontWeight.w600,
                                            fontSize: TMTFontSize.sp_16),
                                      ),
                                      VerticalSpacing(HeightDimension.h_10),
                                      TMTTextWidget(
                                          textAlign: TextAlign.center,
                                          title:
                                              "Your account has been verified successfully!",
                                          style: TMTFontStyles.text(
                                              fontWeight: FontWeight.w600,
                                              fontSize: TMTFontSize.sp_16)),
                                      VerticalSpacing(HeightDimension.h_20),
                                      Padding(
                                        padding: EdgeInsets.only(
                                            left: WidthDimension.w_40,
                                            right: WidthDimension.w_40),
                                        child: InkWell(
                                          onTap: () {
                                            Get.offAllNamed(
                                                AppRoutes.loginScreen);
                                          },
                                          child: TMTTextButton(
                                            buttonTitle: "DONE",
                                            borderRadius: BorderRadius.circular(
                                              TMTRadius.r_35,
                                            ),
                                          ),
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_10),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    TMTRoundedCornersContainer(
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey.withOpacity(0.5),
                                          spreadRadius: 5,
                                          blurRadius: 7,
                                          offset: const Offset(
                                              0, 3), // changes position of shadow
                                        ),
                                      ],
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(50)),
                                      bgColor: AppColor.neutral_100,
                                      padding: const EdgeInsets.all(25),
                                      child: SizedBox(
                                        height: HeightDimension.h_30,
                                        width: HeightDimension.h_30,
                                        child: Image.asset(TMTImages.icTickGreen),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  });
            } else {
              TMTToast.showErrorToast(
                  context, right.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      } else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to resend otp request.
   Parameter- BuildContext context, String email.
   Return -> No Return type.
  */
  void resendOtp(BuildContext context, String email, Function() callback) {
    var request = PostResendSignupOtpRequest(
      requestHeader: DioUtils.getRequestHeaderModel(),
      email: email.toLowerCase(),
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.resendSignUpOTP(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              TMTToast.showSuccessToast(context, right.message);
              callback.call();
            } else {
              TMTToast.showErrorToast(
                  context, right.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      } else {
        /// No internet connection dialog
      }
    });
  }
}
