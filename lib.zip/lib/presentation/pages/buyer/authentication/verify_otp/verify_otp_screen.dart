import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/verify_otp/verify_otp_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_otp_text_field.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';

import '../../../../resources/images.dart';

class VerifyOTPScreen extends StatefulWidget {
  const VerifyOTPScreen({super.key});

  @override
  State<StatefulWidget> createState() => _VerifyOTPState();
}

class _VerifyOTPState extends State<VerifyOTPScreen> {
  final VerifyOTPController _verifyOTPController =
      Get.put(VerifyOTPController());

  final args = Get.arguments;

  int _start = 30;
  Timer? _timer;
  String otp = "";

  void startTimer() {
    const oneSec = Duration(seconds: 1);
    _timer = Timer.periodic(
      oneSec,
          (Timer timer) {
        if (_start == 0) {
          setState(() {
            timer.cancel();
          });
        } else {
          setState(() {
            _start--;
          });
        }
      },
    );
  }

  @override
  void initState() {
    startTimer();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return TMTBackButton(
      route: AppRoutes.loginScreen,
      child: Material(
        color: AppColor.primary,
        child: GetBuilder<VerifyOTPController>(
            id: GetControllerBuilders.verifyOTPController,
            init: _verifyOTPController,
            builder: (controller) {
              return CustomScrollView(
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                slivers: [
                  SliverAppBar(
                    floating: false,
                    pinned: false,
                    backgroundColor: AppColor.primary,
                    expandedHeight: HeightDimension.h_190,
                    flexibleSpace: FlexibleSpaceBar(
                      background: Container(
                        color: AppColor.primary,
                        child: Column(
                          children: [
                            VerticalSpacing(HeightDimension.h_40),
                            VerticalSpacing(HeightDimension.h_40),
                            TMTTextWidget(
                              title: "Verify Account",
                              style: TMTFontStyles.textTeen(
                                  color: AppColor.neutral_100,
                                  fontSize: TMTFontSize.sp_28,
                                  fontWeight: FontWeight.w600),
                            ),
                            VerticalSpacing(HeightDimension.h_5),
                            Padding(
                              padding: EdgeInsets.only(left: WidthDimension.w_40, right: WidthDimension.w_40),
                              child: TMTTextWidget(
                                textAlign: TextAlign.center,
                                title: "Enter verification code sent to $args",
                                style: TMTFontStyles.text(
                                    color: AppColor.neutral_100,
                                    fontSize: TMTFontSize.sp_18,
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_20),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: Container(
                      color: AppColor.neutral_100,
                      child: Stack(
                        children: [
                          Container(
                            color: AppColor.primary,
                            child: TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(TMTRadius.r_35),
                                  topRight: Radius.circular(TMTRadius.r_35)),
                              bgColor: AppColor.neutral_100,
                              borderColor: AppColor.neutral_100,
                              borderWidth: 0,
                              width: double.infinity,
                              child: SingleChildScrollView(
                                physics: const NeverScrollableScrollPhysics(),
                                child: Column(
                                  children: [
                                    VerticalSpacing(HeightDimension.h_30),
                                    TMTTextWidget(
                                      title: "Enter OTP",
                                      style: TMTFontStyles.textTeen(
                                          fontWeight: FontWeight.w700,
                                          fontSize: TMTFontSize.sp_24,
                                          color: AppColor.neutral_800),
                                    ),
                                    VerticalSpacing(HeightDimension.h_25),
                                    TMTOtpTextField(
                                      margin: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6),
                                      textStyle: TMTFontStyles.text(fontWeight: FontWeight.w700, fontSize: TMTFontSize.sp_20, color: AppColor.neutral_800),
                                      numberOfFields: 4,
                                      showFieldAsBox: true,
                                      onCodeChanged: (String code) {
                                        setState(() {
                                          otp = code;
                                        });
                                      },
                                      //runs when every textfield is filled
                                      onSubmit: (String verificationCode){
                                        setState(() {
                                          otp = verificationCode;
                                        });
                                      }, // end onSubmit
                                    ),
                                    VerticalSpacing(HeightDimension.h_30),
                                    Column(
                                      children: [
                                        TMTTextWidget(title: _start == 0 ? "" : "Resend code in $_start", style: TMTFontStyles.text(fontWeight: FontWeight.w500, color: AppColor.textColor, fontSize: TMTFontSize.sp_14)),
                                        VerticalSpacing(HeightDimension.h_2),
                                        TMTTextWidget(title: "I don't receive a code!" , style: TMTFontStyles.text(fontWeight: FontWeight.w600, color: AppColor.textColor, fontSize: TMTFontSize.sp_14)),
                                        VerticalSpacing(HeightDimension.h_4),
                                        GestureDetector(onTap : (){
                                          if (_start == 0) {
                                            TMTUtilities.closeKeyboard(context);
                                            _verifyOTPController.resendOtp(context, args, (){
                                              setState(() {
                                                _start = 30;
                                                startTimer();
                                              });
                                            });
                                          }
                                        }, child: TMTTextWidget(title: "Resend Code", style: TMTFontStyles.text(textDecoration: TextDecoration.underline, fontWeight: FontWeight.w600, color: _start == 0 ? AppColor.neutral_800 : AppColor.neutral_500, fontSize: TMTFontSize.sp_14),)),
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_30),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: HeightDimension.h_20,
                            left: WidthDimension.w_15,
                            right: WidthDimension.w_15,
                            child: TMTTextButton(
                              onTap: (){
                                TMTUtilities.closeKeyboard(context);
                                _verifyOTPController.postVerifyOtp(context, args, otp);
                              },
                              buttonTitle: "CONFIRM",
                              isDisable: otp.length != 4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              );
            }),
      ),
    );
  }
}