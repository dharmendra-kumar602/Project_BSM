import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/post_register_request.dart';
import 'package:take_my_tack/data/repository_implementation/auth_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/text_based_captcha/hb_check_code.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class SignUpPageController extends GetxController {
  final TextEditingController firstNameTextController = TextEditingController();
  final TextEditingController lastNameTextController = TextEditingController();
  final TextEditingController emailAddressTextController =
      TextEditingController();
  final TextEditingController passwordTextController = TextEditingController();
  final TextEditingController captchaTextEditingController =  TextEditingController();
  final TextEditingController confirmPasswordTextController =
      TextEditingController();
  final FocusNode firstNameNode = FocusNode();
  final FocusNode lastNameNode = FocusNode();
  final FocusNode emailNode = FocusNode();
  final FocusNode passwordNode = FocusNode();
  final FocusNode confirmPasswordNode = FocusNode();
  bool passwordVisible = true;
  bool confirmPasswordVisible = true;
  bool agreeToTerms = false;
  bool _imNotRobot = false;
  /// Properties for Captcha.
  String textBasedCaptchaCode = '';
  Map textCaptchaDrawData = {};
  double textCaptchaDrawWidth = 0.0;
  bool get imNotRobotStatus => _imNotRobot;

  AuthRepositoryImpl repositoryImpl = AuthRepositoryImpl();

  String? selectedGender;

  /*
   Method use to change captcha selected status.
   Parameter- bool value.
   Return -> No return type.
  */
  void changeCaptchaStatus(bool value) {
    _imNotRobot = value;
    update([GetControllerBuilders.signUpPageController]);
  }

  /*
   Method use to change password secure status.
   Parameter- No Parameter.
   Return -> No return type.
  */
  void changePasswordVisibility() {
    passwordVisible = !passwordVisible;
    update([GetControllerBuilders.signUpPageController]);
  }

  /*
   Method use to change confirm password secure status.
   Parameter- No Parameter.
   Return -> No return type.
  */
  void changeConfirmPasswordVisibility() {
    confirmPasswordVisible = !confirmPasswordVisible;
    update([GetControllerBuilders.signUpPageController]);
  }

  /*
   Method use to get button enable status.
   Parameter- No Parameter.
   Return -> bool.
  */
  bool isRegisterButtonEnabled() {
    if (firstNameTextController.text.isNotEmpty &&
        lastNameTextController.text.isNotEmpty &&
        emailAddressTextController.text.isNotEmpty &&
        passwordTextController.text.isNotEmpty &&
        confirmPasswordTextController.text.isNotEmpty) {
      if (agreeToTerms && _imNotRobot) {
        return true;
      } else {
        return false;
      }
    }
    return false;
  }

  /// Method used to reset text captcha.
  resetTextCaptcha() {
    textBasedCaptchaCode = TextBasedCaptchaUtils.getRandomText();
    textCaptchaDrawData =
        TextBasedCaptchaUtils.getRandomData(textBasedCaptchaCode);
    textCaptchaDrawWidth = TextBasedCaptchaUtils.getTextSize(
            "8" * textBasedCaptchaCode.length,
            TextStyle(fontWeight: FontWeight.values[8], fontSize: 25))
        .width;
    update([GetControllerBuilders.signUpPageController]);
  }

  ///Method use for strong password
  static bool isPassword(String value) {
    return RegExp(
            r'(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&+=#*-.:;<>{}\/^_~,]{6,20}$')
        .hasMatch(value);
  }

  /*
   Method use to register user.
   Parameter- No Parameter.
   Return -> No Return type.
  */
  void postRegisterUser(BuildContext context) {
    var request = PostRegisterRequest(
        requestHeader: DioUtils.getRequestHeaderModel(),
        email: emailAddressTextController.text.toLowerCase(),
        password: passwordTextController.text,
        firstName: firstNameTextController.text,
        lastName: lastNameTextController.text,
        termOfServicesConsent: agreeToTerms,
      role: TMTConstant.roleBuyer, gender: selectedGender!
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.register(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              Get.offNamed(AppRoutes.verifyOTPScreen, arguments: emailAddressTextController.text);
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}
