import 'dart:async';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/signup/signup_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_checkbox.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/tmt_app_icons.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/tmt_webview.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/text_based_captcha/hb_check_code.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';
import 'dart:io' as _pf;

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final SignUpPageController _signUpPageController =
      Get.put(SignUpPageController());
  final _formKey = GlobalKey<FormState>();
  final platform = const MethodChannel(TMTConstant.captchaMethodChannel);
  String verifyResult = "";
  bool isKeyboardVisible = false;
  final args = Get.arguments ?? AppRoutes.homeScreen;
  String? selectedGender;

  @override
  void initState() {
    super.initState();
    _signUpPageController.resetTextCaptcha();
    KeyboardVisibilityController().onChange.listen((bool visible) {
      setState(() {
        isKeyboardVisible = visible;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.primary,
      resizeToAvoidBottomInset: true,
      body: TMTBackButton(
        route: AppRoutes.loginScreen,
        child: GetBuilder<SignUpPageController>(
            id: GetControllerBuilders.signUpPageController,
            init: _signUpPageController,
            builder: (controller) {
              return CustomScrollView(
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                slivers: [
                  SliverAppBar(
                    floating: false,
                    pinned: false,
                    backgroundColor: AppColor.primary,
                    expandedHeight: HeightDimension.h_180,
                    flexibleSpace: FlexibleSpaceBar(
                      background: Container(
                        color: AppColor.primary,
                        child: Column(
                          children: [
                            VerticalSpacing(HeightDimension.h_40),
                            Visibility(
                              visible: ModalRoute.of(context)?.canPop == false,
                              child: InkWell(
                                onTap: () {
                                  Get.offNamed(args == AppRoutes.homeScreen
                                      ? AppRoutes.dashBoardScreen
                                      : AppRoutes.cartScreen, arguments: false);
                                },
                                child: Row(
                                  children: [
                                    HorizontalSpacing(WidthDimension.w_20),
                                    SizedBox(
                                      height: HeightDimension.h_15,
                                      width: WidthDimension.w_15,
                                      child: Image.asset(
                                        TMTImages.icBack,
                                        color: AppColor.neutral_100,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_20),
                                  ],
                                ),
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_40),
                            TMTTextWidget(
                              title: "Welcome",
                              style: TMTFontStyles.textTeen(
                                  color: AppColor.neutral_100,
                                  fontSize: TMTFontSize.sp_28,
                                  fontWeight: FontWeight.w600),
                            ),
                            VerticalSpacing(HeightDimension.h_5),
                            TMTTextWidget(
                              title: "Sign up to buy & sell",
                              style: TMTFontStyles.text(
                                  color: AppColor.neutral_100,
                                  fontSize: TMTFontSize.sp_18,
                                  fontWeight: FontWeight.w500),
                            ),
                            VerticalSpacing(HeightDimension.h_20),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: Container(
                      color: AppColor.primary,
                      child: TMTRoundedCornersContainer(
                        borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(TMTRadius.r_40),
                            topRight: Radius.circular(TMTRadius.r_40)),
                        bgColor: AppColor.neutral_100,
                        width: double.infinity,
                        child: SingleChildScrollView(
                          physics: const NeverScrollableScrollPhysics(),
                          child: Column(
                            children: [
                              VerticalSpacing(HeightDimension.h_20),
                              TMTTextWidget(
                                title: "Sign Up",
                                style: TMTFontStyles.textTeen(
                                    fontWeight: FontWeight.w700,
                                    fontSize: TMTFontSize.sp_24,
                                    color: AppColor.neutral_800),
                              ),
                              VerticalSpacing(HeightDimension.h_20),
                              Form(
                                key: _formKey,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                      left: WidthDimension.w_10,
                                      right: WidthDimension.w_10),
                                  child: Column(
                                    children: [
                                      TMTTextField(
                                        hintText: "First Name",
                                        controller: _signUpPageController
                                            .firstNameTextController,
                                        focusNode:
                                        _signUpPageController.firstNameNode,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        validator: Validator.firstNameValidate,
                                          onFieldSubmitted: (v) {
                                            _signUpPageController.lastNameNode.requestFocus();
                                          }
                                      ),
                                      VerticalSpacing(HeightDimension.h_8),
                                      TMTTextField(
                                        hintText: "Last Name",
                                        controller: _signUpPageController
                                            .lastNameTextController,
                                        focusNode:
                                        _signUpPageController.lastNameNode,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        validator: Validator.lastNameValidate,
                                          onFieldSubmitted: (v) {
                                            _signUpPageController.emailNode.requestFocus();
                                          }
                                      ),
                                      VerticalSpacing(HeightDimension.h_10),
                                      GestureDetector(
                                        onTap: (){
                                          showDialog(context: context, builder: (context){
                                            return StatefulBuilder(
                                                builder: (context, setState) {
                                                return AlertDialog(
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius.circular(12.0),
                                                  ),
                                                  title: TMTTextWidget(title: 'Select Gender', style: TMTFontStyles.text(
                                                    fontSize: TMTFontSize.sp_16,
                                                    color: AppColor.neutral_800,
                                                    fontWeight: FontWeight.w500,
                                                  ),),
                                                  content: Column(
                                                    mainAxisSize: MainAxisSize.min,
                                                    children: [
                                                      GestureDetector(
                                                        onTap: (){
                                                          setState(() {
                                                            selectedGender = "Male";
                                                            Navigator.pop(context);
                                                            FocusScope.of(context).unfocus();
                                                            _signUpPageController.selectedGender = selectedGender;
                                                            _signUpPageController.update([GetControllerBuilders.signUpPageController]);
                                                          });
                                                        },
                                                        child: TMTRoundedCornersContainer(
                                                          bgColor: selectedGender == "Male" ? AppColor.primaryBG.withOpacity(0.2) :  AppColor.neutral_100,
                                                          borderColor: selectedGender == "Male" ? AppColor.primaryBG : AppColor.neutral_800,
                                                          padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, bottom: HeightDimension.h_8, top: HeightDimension.h_8),
                                                          child: Row(
                                                            children: [
                                                              HorizontalSpacing(WidthDimension.w_10),
                                                            TMTTextWidget(title: 'Male', style: TMTFontStyles.text(
                                                            fontSize: TMTFontSize.sp_12,
                                                            color: AppColor.neutral_800,
                                                            fontWeight: FontWeight.w500,)),
                                                              HorizontalSpacing(WidthDimension.w_10),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      VerticalSpacing(HeightDimension.h_10),
                                                      GestureDetector(
                                                        onTap: (){
                                                          setState(() {
                                                            selectedGender = "Female";
                                                            Navigator.pop(context);
                                                            FocusScope.of(context).unfocus();
                                                            _signUpPageController.selectedGender = selectedGender;
                                                            _signUpPageController.update([GetControllerBuilders.signUpPageController]);
                                                          });
                                                        },
                                                        child: TMTRoundedCornersContainer(
                                                          bgColor: selectedGender == "Female" ? AppColor.primaryBG.withOpacity(0.2) :  AppColor.neutral_100,
                                                          borderColor: selectedGender == "Female" ? AppColor.primaryBG : AppColor.neutral_800,
                                                          padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, bottom: HeightDimension.h_8, top: HeightDimension.h_8),
                                                          child: Row(
                                                            children: [
                                                              HorizontalSpacing(WidthDimension.w_10),
                                                              TMTTextWidget(title: 'Female', style: TMTFontStyles.text(
                                                                fontSize: TMTFontSize.sp_12,
                                                                color: AppColor.neutral_800,
                                                                fontWeight: FontWeight.w500,)),
                                                              HorizontalSpacing(WidthDimension.w_10),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      VerticalSpacing(HeightDimension.h_10),
                                                      GestureDetector(
                                                        onTap: (){
                                                          setState(() {
                                                            selectedGender = "Other";
                                                            Navigator.pop(context);
                                                            FocusScope.of(context).unfocus();
                                                            _signUpPageController.selectedGender = selectedGender;
                                                            _signUpPageController.update([GetControllerBuilders.signUpPageController]);
                                                          });
                                                        },
                                                        child: TMTRoundedCornersContainer(
                                                          bgColor: selectedGender == "Other" ? AppColor.primaryBG.withOpacity(0.2) :  AppColor.neutral_100,
                                                          borderColor: selectedGender == "Other" ? AppColor.primaryBG : AppColor.neutral_800,
                                                          padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, bottom: HeightDimension.h_8, top: HeightDimension.h_8),
                                                          child: Row(
                                                            children: [
                                                              HorizontalSpacing(WidthDimension.w_10),
                                                              TMTTextWidget(title: 'Other', style: TMTFontStyles.text(
                                                                fontSize: TMTFontSize.sp_12,
                                                                color: AppColor.neutral_800,
                                                                fontWeight: FontWeight.w500,)),
                                                              HorizontalSpacing(WidthDimension.w_10),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }
                                            );
                                          });
                                        },
                                        child: Padding(
                                          padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: TMTRoundedCornersContainer(
                                                  height: HeightDimension.h_45,
                                                  borderRadius: const BorderRadius.all(Radius.circular(15)),
                                                  padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_2),
                                                  borderColor: const Color(0xFF595959),
                                                  borderWidth: 0.5,
                                                  child: Row(
                                                    children: [
                                                      HorizontalSpacing(WidthDimension.w_10),
                                                      TMTTextWidget(title: _signUpPageController.selectedGender ?? "Select Gender", style: _signUpPageController.selectedGender == null ? TMTFontStyles.text(
                                                        fontSize: TMTFontSize.sp_12,
                                                        color: AppColor.textColor,
                                                      ) : TMTFontStyles.text(
                                                        fontSize: TMTFontSize.sp_14,
                                                        color: AppColor.neutral_800,
                                                      ),),
                                                      HorizontalSpacing(WidthDimension.w_10),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_10),
                                      TMTTextField(
                                        contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 10),
                                        hintText: "Email Address",
                                        controller: _signUpPageController
                                            .emailAddressTextController,
                                        focusNode:
                                        _signUpPageController.emailNode,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        inputFormatters: [
                                          FilteringTextInputFormatter.deny(RegExp(r'\s'))
                                        ],
                                        validator: Validator.emailValidate,
                                          onFieldSubmitted: (v) {
                                            _signUpPageController.passwordNode.requestFocus();
                                          }
                                      ),
                                      VerticalSpacing(HeightDimension.h_8),
                                      TMTTextField(
                                        onTap: () {
                                          setState(() {
                                            isKeyboardVisible = true;
                                          });
                                        },
                                        isSecure: _signUpPageController.passwordVisible,
                                        hintText: "Password",
                                        controller: _signUpPageController
                                            .passwordTextController,
                                        focusNode: _signUpPageController
                                            .passwordNode,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        suffixIcon: InkWell(
                                            onTap: () {
                                              _signUpPageController
                                                  .changePasswordVisibility();
                                            },
                                            child: Icon(
                                              _signUpPageController.passwordVisible ? MyFlutterApp.icEyeCloseGrey : MyFlutterApp.icEyeOpen,
                                              size: 15,
                                            )),
                                        inputFormatters: [
                                          FilteringTextInputFormatter.deny(RegExp(r'\s'))
                                        ],
                                        validator: Validator.passwordValidate,
                                        keyboardType: TextInputType.text,
                                        onFieldSubmitted: (v) {
                                          _signUpPageController
                                              .confirmPasswordNode.requestFocus();
                                        },),
                                      VerticalSpacing(HeightDimension.h_8),
                                      TMTTextField(
                                        onTap: () {
                                          setState(() {
                                            isKeyboardVisible = true;
                                          });
                                        },
                                        isSecure: _signUpPageController.confirmPasswordVisible,
                                        hintText: "Confirm Password",
                                        controller: _signUpPageController
                                            .confirmPasswordTextController,
                                        focusNode: _signUpPageController
                                            .confirmPasswordNode,
                                        onChanged: (v){
                                          setState(() {

                                          });
                                        },
                                        suffixIcon: InkWell(
                                            onTap: () {
                                              _signUpPageController
                                                  .changeConfirmPasswordVisibility();
                                            },
                                            child: Icon(
                                              _signUpPageController.confirmPasswordVisible ? MyFlutterApp.icEyeCloseGrey : MyFlutterApp.icEyeOpen,
                                              size: 15,
                                            )),
                                        inputFormatters: [
                                          FilteringTextInputFormatter.deny(RegExp(r'\s'))
                                        ],
                                        validator: Validator.confirmPasswordValidator(_signUpPageController.passwordTextController.text, _signUpPageController.confirmPasswordTextController.text),
                                        keyboardType: TextInputType.text,
                                        onFieldSubmitted: (v) {
                                          TMTUtilities.closeKeyboard(context);
                                        },),
                                    ],
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Row(
                                children: [
                                  HorizontalSpacing(WidthDimension.w_20),
                                  Row(
                                    children: [
                                      TMTCustomCheckbox(
                                        isChecked: _signUpPageController.agreeToTerms,
                                        onChange: (value) {
                                          _signUpPageController.agreeToTerms = value;
                                          _signUpPageController.update([GetControllerBuilders.loginPageController]);
                                        },
                                        backgroundColor: AppColor.neutral_100,
                                        borderColor: AppColor.neutral_800,
                                        icon: Icons.check,
                                        iconColor: AppColor.neutral_800,
                                        size: 18,
                                        iconSize: 14,
                                      ),
                                      HorizontalSpacing(WidthDimension.w_10),
                                      SizedBox(
                                        width: MediaQuery.of(context).size.width - WidthDimension.w_70,
                                        child: Text.rich(
                                            TextSpan(
                                              style: TMTFontStyles.text(
                                                  color: AppColor.textColor,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: TMTFontSize.sp_12
                                              ),
                                              text: 'I agree to the ',
                                              children: [
                                                TextSpan(
                                                  text: 'terms of service',
                                                  style: TMTFontStyles.text(
                                                      color: AppColor.textColor,
                                                      fontWeight: FontWeight.w600,
                                                      textDecoration: TextDecoration.underline,
                                                      fontSize: TMTFontSize.sp_12
                                                  ),
                                                  recognizer: TapGestureRecognizer()
                                                    ..onTap = () {
                                                      _launchURL(
                                                          "https://tacktalk.co.uk/terms-conditions-%f0%9f%a4%9f/");
                                                    },
                                                ),
                                                const TextSpan(
                                                  text: '  and  ',
                                                ),
                                                TextSpan(
                                                  text: 'privacy policy',
                                                  style: TMTFontStyles.text(
                                                      color: AppColor.neutral_700,
                                                      fontWeight: FontWeight.w600,
                                                      textDecoration: TextDecoration.underline,
                                                      fontSize: TMTFontSize.sp_12
                                                  ),
                                                  recognizer: TapGestureRecognizer()
                                                    ..onTap = () {
                                                      _launchURL(
                                                          "https://tacktalk.co.uk/privacy-policy/");
                                                    },
                                                ),
                                              ],
                                            )),
                                      )
                                    ],
                                  ),
                                  HorizontalSpacing(WidthDimension.w_20),
                                ],
                              ),
                              VerticalSpacing(HeightDimension.h_20),
                              Visibility(
                                visible: _pf.Platform.isAndroid,
                                replacement: _buildTextBasedCaptcha(),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: TMTRoundedCornersContainer(
                                    margin: EdgeInsets.only(left: WidthDimension.w_20),
                                    borderRadius: const BorderRadius.all(Radius.circular(0)),
                                    padding: const EdgeInsets.all(10.0),
                                    borderColor: AppColor.neutral_800,
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        GestureDetector(
                                          onTap: () async {
                                            if (_signUpPageController
                                                .imNotRobotStatus) {
                                              _signUpPageController
                                                  .changeCaptchaStatus(false);
                                            } else {
                                              /// Run both task in parallel
                                              Future.wait([showLoader(), showCaptcha()]).then((_) {});
                                            }
                                          },
                                          child: AnimatedContainer(
                                              height: 17,
                                              width: 17,
                                              duration: const Duration(milliseconds: 500),
                                              curve: Curves.fastLinearToSlowEaseIn,
                                              decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(3),
                                                  color: _signUpPageController.imNotRobotStatus
                                                      ? AppColor.neutral_100
                                                      : Colors.transparent,
                                                  border: Border.all(color: AppColor.neutral_800, width: 1.5)),
                                              child: _signUpPageController.imNotRobotStatus
                                                  ? const Icon(
                                                Icons.check,
                                                color: AppColor.neutral_800,
                                                size: 13,
                                              )
                                                  : null),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_6),
                                        TMTTextWidget(title: "I'm not a robot", style: TMTFontStyles.text(
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                            fontSize: TMTFontSize.sp_12
                                        ),),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        SizedBox(
                                          height: HeightDimension.h_25,
                                          width: HeightDimension.h_25,
                                          child: Image.asset(TMTImages.icCaptcha),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_40),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15,
                                    right: WidthDimension.w_15),
                                child: TMTTextButton(
                                  onTap: () {
                                    if (_formKey.currentState!.validate()) {
                                      if (_signUpPageController.agreeToTerms && _signUpPageController.imNotRobotStatus && (_signUpPageController.selectedGender?.isNotEmpty ?? false)) {
                                          _signUpPageController
                                              .postRegisterUser(context);
                                      } else {
                                        if ((_signUpPageController.selectedGender?.isEmpty ?? true)) {
                                          TMTToast.showErrorToast(context, "Please select gender.", title: "Alert");
                                        } else if (!_signUpPageController.agreeToTerms) {
                                          TMTToast.showErrorToast(context, "Please agree to our terms and conditions.", title: "Alert");
                                        } else {
                                          TMTToast.showErrorToast(context, _pf.Platform.isIOS ? "Please enter captcha first." : "Please verify captcha first.", title: "Alert");
                                        }
                                      }
                                    }
                                    TMTUtilities.closeKeyboard(context);
                                  },
                                  buttonTitle: "REGISTER",
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_20),
                              Text.rich(
                                  TextSpan(
                                    style: TMTFontStyles.text(
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w500,
                                      fontSize: TMTFontSize.sp_14
                                    ),
                                    text: 'Already have an account? ',
                                    children: [
                                      TextSpan(
                                        text: 'Sign in',
                                        style: TMTFontStyles.text(
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w500,
                                            fontSize: TMTFontSize.sp_14,
                                            textDecoration: TextDecoration.underline,
                                        ),
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = () {
                                          if (Navigator.canPop(context)) {
                                            Get.back();
                                          } else {
                                            Get.offNamed(AppRoutes.loginScreen, arguments: args);
                                          }
                                          },
                                      ),
                                    ],
                                  )),
                              VerticalSpacing(HeightDimension.h_20),
                              Visibility(
                                visible: isKeyboardVisible,
                                child: SizedBox(height: HeightDimension.h_80),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              );
            }),
      ),
    );
  }

  /// Method used to build captcha widget for ios.
  Widget _buildTextBasedCaptcha() {
    return Container(
      width: ScreenUtil().screenWidth, padding: EdgeInsets.only(
          left: WidthDimension.w_20, right: WidthDimension.w_20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: TMTRoundedCornersContainer(
              padding: EdgeInsets.only(
                left: WidthDimension.w_12,
                right: WidthDimension.w_12,
                top: HeightDimension.h_5,
                bottom: HeightDimension.h_5,
              ),
              borderColor: AppColor.neutral_400,
              borderRadius: BorderRadius.circular(TMTRadius.r_15),
              child: TextBasedCaptcha(
                captchaDrawData: _signUpPageController.textCaptchaDrawData,
                maxDataWidth: _signUpPageController.textCaptchaDrawWidth,
              ),
            ),
          ),
          HorizontalSpacing(WidthDimension.w_10),
          Container(
            alignment: Alignment.center,
            width: HeightDimension.h_18,
            height: HeightDimension.h_45,
            child: InkWell(
                onTap: () {
                  _signUpPageController.resetTextCaptcha();
                },
                child: const Icon(Icons.refresh)),
          ),
          HorizontalSpacing(WidthDimension.w_10),
          Expanded(
            child: TMTTextField(
              padding: EdgeInsets.only(
                left: WidthDimension.w_12,
                right: WidthDimension.w_12,
                top: HeightDimension.h_4,
                bottom: HeightDimension.h_4,
              ),
              controller: _signUpPageController.captchaTextEditingController,
              validator: Validator.validateCaptchaText(
                  _signUpPageController.textBasedCaptchaCode),
              keyboardType: TextInputType.text,
              onChanged: (value) {
               if ( _signUpPageController.textBasedCaptchaCode == value) {
                 _signUpPageController.changeCaptchaStatus(true);
               } else {
                 _signUpPageController.changeCaptchaStatus(false);
               }
              },
              onFieldSubmitted: (v) {
                TMTUtilities.closeKeyboard(context);
              },
            ),
          )
        ],
      ),
    );
  }

  /// For launching url
  _launchURL(String url) async {
    Navigator.push(context, MaterialPageRoute(builder: (c){
      return TMTWebView(url: url);
    }));
  }

  /// Initialize and show captcha
  Future showCaptcha() async {
    try {
      ///Here we call Native code
      final bool result =
          await platform.invokeMethod(
          TMTConstant.captchaId);
      if (result) {
        _signUpPageController.changeCaptchaStatus(true);
      } else {
        _signUpPageController.changeCaptchaStatus(false);
      }
    } on PlatformException catch (e) {
      e.printError();
      _signUpPageController.changeCaptchaStatus(false);
    }
  }

  /// Show loader for 1 second as buffer while waiting for captcha to initialize
  Future showLoader() async {
    const Loading().start(context);
    await Future.delayed(const Duration(seconds: 2));
    Loading.stop();
  }
}
