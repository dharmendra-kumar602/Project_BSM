import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/forgot_password/forgot_password_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<StatefulWidget> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final ForgotPasswordPageController _forgotPasswordPageController =
      Get.put(ForgotPasswordPageController());
  final _formKey = GlobalKey<FormState>();

  final args = Get.arguments;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.primary,
      resizeToAvoidBottomInset: true,
      body: TMTBackButton(
        route: AppRoutes.loginScreen,
        child: GetBuilder<ForgotPasswordPageController>(
            id: GetControllerBuilders.forgotPasswordPageController,
            init: _forgotPasswordPageController,
            builder: (controller) {
              return CustomScrollView(
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                slivers: [
                  SliverAppBar(
                    floating: false,
                    pinned: false,
                    backgroundColor: AppColor.primary,
                    expandedHeight: HeightDimension.h_200,
                    flexibleSpace: FlexibleSpaceBar(
                      background: Container(
                        color: AppColor.primary,
                        child: Column(
                          children: [
                            VerticalSpacing(HeightDimension.h_40),
                            VerticalSpacing(HeightDimension.h_40),
                            TMTTextWidget(
                              title: "Forgot Password?",
                              style: TMTFontStyles.textTeen(
                                  color: AppColor.neutral_100,
                                  fontSize: TMTFontSize.sp_28,
                                  fontWeight: FontWeight.w600),
                            ),
                            VerticalSpacing(HeightDimension.h_5),
                            Padding(
                              padding: EdgeInsets.only(left: WidthDimension.w_30, right: WidthDimension.w_30),
                              child: TMTTextWidget(
                                textAlign: TextAlign.center,
                                title: "Enter your email for the verification process. We will send a 4 digits code to your email.",
                                style: TMTFontStyles.text(
                                    color: AppColor.neutral_100,
                                    fontSize: TMTFontSize.sp_16,
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: Container(
                      color: AppColor.primary,
                      child: Stack(
                        children: [
                          Container(
                            color: AppColor.primary,
                            child: TMTRoundedCornersContainer(
                              height: double.infinity,
                              borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(TMTRadius.r_40),
                                  topRight: Radius.circular(TMTRadius.r_40)),
                              bgColor: AppColor.neutral_100,
                              width: double.infinity,
                              borderWidth: 2,
                              child: SingleChildScrollView(
                                physics: const NeverScrollableScrollPhysics(),
                                child: Column(
                                  children: [
                                    VerticalSpacing(HeightDimension.h_25),
                                    TMTTextWidget(
                                      title: "Enter Email",
                                      style: TMTFontStyles.textTeen(
                                          fontWeight: FontWeight.w700,
                                          fontSize: TMTFontSize.sp_24,
                                          color: AppColor.neutral_800),
                                    ),
                                    VerticalSpacing(HeightDimension.h_25),
                                    Form(
                                      key: _formKey,
                                      child: Padding(
                                        padding: EdgeInsets.only(
                                            left: WidthDimension.w_15,
                                            right: WidthDimension.w_15),
                                        child: Column(
                                          children: [
                                            TMTTextField(
                                              hintText: "Email Address",
                                              controller: _forgotPasswordPageController
                                                  .emailTextController,
                                              onChanged: (v){
                                                setState(() {

                                                });
                                              },
                                              inputFormatters: [
                                                FilteringTextInputFormatter.deny(RegExp(r'\s'))
                                              ],
                                              validator: Validator.emailValidate,
                                              onFieldSubmitted: (value){
                                                TMTUtilities.closeKeyboard(context);
                                              },
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    VerticalSpacing(HeightDimension.h_25),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: HeightDimension.h_20,
                            left: WidthDimension.w_15,
                            right: WidthDimension.w_15,
                            child: TMTTextButton(
                              onTap: (){
                                if (_formKey.currentState!.validate()) {
                                  _forgotPasswordPageController
                                      .postForgotPassword(context);
                                }
                                TMTUtilities.closeKeyboard(context);
                              },
                              buttonTitle: "CONTINUE",
                              isDisable: _forgotPasswordPageController.emailTextController.text.isEmpty,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              );
            }),
      ),
    );
  }
}