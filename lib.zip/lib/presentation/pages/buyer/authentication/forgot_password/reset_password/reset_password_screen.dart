import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/forgot_password/reset_password/reset_password_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_app_icons.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';

class ResetPasswordScreen extends StatefulWidget {
  const ResetPasswordScreen({super.key});

  @override
  State<StatefulWidget> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final ResetPasswordController _resetPasswordController =
      Get.put(ResetPasswordController());
  final _formKey = GlobalKey<FormState>();

  final args = Get.arguments;

  @override
  Widget build(BuildContext context) {
    return TMTBackButton(
      route: AppRoutes.verifyForgotOTPScreen,
      child: Material(
        color: AppColor.primary,
        child: GetBuilder<ResetPasswordController>(
            id: GetControllerBuilders.resetPasswordController,
            init: _resetPasswordController,
            builder: (controller) {
              return CustomScrollView(
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                slivers: [
                  SliverAppBar(
                    floating: false,
                    pinned: false,
                    backgroundColor: AppColor.primary,
                    expandedHeight: HeightDimension.h_200,
                    flexibleSpace: FlexibleSpaceBar(
                      background: Container(
                        color: AppColor.primary,
                        child: Column(
                          children: [
                            VerticalSpacing(HeightDimension.h_40),
                            VerticalSpacing(HeightDimension.h_40),
                            TMTTextWidget(
                              title: "Reset Password",
                              style: TMTFontStyles.textTeen(
                                  color: AppColor.neutral_100,
                                  fontSize: TMTFontSize.sp_28,
                                  fontWeight: FontWeight.w600),
                            ),
                            VerticalSpacing(HeightDimension.h_5),
                            Padding(
                              padding: EdgeInsets.only(left: WidthDimension.w_25, right: WidthDimension.w_25),
                              child: TMTTextWidget(
                                textAlign: TextAlign.center,
                                title: "Set the new password for your account so you can log in and access all the features.",
                                style: TMTFontStyles.text(
                                    color: AppColor.neutral_100,
                                    fontSize: TMTFontSize.sp_16,
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: Container(
                      color: AppColor.neutral_100,
                      child: Stack(
                        children: [
                          Container(
                            color: AppColor.primary,
                            child: TMTRoundedCornersContainer(
                              borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(TMTRadius.r_40),
                                  topRight: Radius.circular(TMTRadius.r_40)),
                              bgColor: AppColor.neutral_100,
                              width: double.infinity,
                              borderWidth: 0,
                              borderColor: AppColor.neutral_100,
                              child: SingleChildScrollView(
                                physics: const NeverScrollableScrollPhysics(),
                                child: Column(
                                  children: [
                                    VerticalSpacing(HeightDimension.h_25),
                                    TMTTextWidget(
                                      title: "Enter New Password",
                                      style: TMTFontStyles.textTeen(
                                          fontWeight: FontWeight.w700,
                                          fontSize: TMTFontSize.sp_24,
                                          color: AppColor.neutral_800),
                                    ),
                                    VerticalSpacing(HeightDimension.h_25),
                                    Form(
                                      key: _formKey,
                                      child: Padding(
                                        padding: EdgeInsets.only(
                                            left: WidthDimension.w_10,
                                            right: WidthDimension.w_10),
                                        child: Column(
                                          children: [
                                            TMTTextField(
                                              isSecure: _resetPasswordController.confirmPasswordVisible,
                                              hintText: "Enter new password",
                                              controller: _resetPasswordController
                                                  .passwordTextController,
                                              focusNode:
                                              _resetPasswordController.passwordFocusNode,
                                              onChanged: (v){
                                                setState(() {

                                                });
                                              },
                                              suffixIcon: InkWell(
                                                  onTap: () {
                                                    _resetPasswordController
                                                        .changeConfirmPasswordVisibility();
                                                  },
                                                  child: Icon(
                                                    _resetPasswordController.confirmPasswordVisible ? MyFlutterApp.icEyeCloseGrey : MyFlutterApp.icEyeOpen,
                                                    size: 15,
                                                  )),
                                              inputFormatters: [
                                                FilteringTextInputFormatter.deny(RegExp(r'\s'))
                                              ],
                                              validator: Validator.passwordValidate,
                                            ),
                                            VerticalSpacing(HeightDimension.h_8),
                                            TMTTextField(
                                              isSecure: _resetPasswordController.passwordVisible,
                                              hintText: "Confirm password",
                                              controller: _resetPasswordController
                                                  .confirmPasswordTextController,
                                              focusNode: _resetPasswordController
                                                  .confirmPasswordFocusNode,
                                              onChanged: (v){
                                                setState(() {

                                                });
                                              },
                                              suffixIcon: InkWell(
                                                  onTap: () {
                                                    _resetPasswordController
                                                        .changePasswordVisibility();
                                                  },
                                                  child: Icon(
                                                    _resetPasswordController.passwordVisible ? MyFlutterApp.icEyeCloseGrey : MyFlutterApp.icEyeOpen,
                                                    size: 15,
                                                  )),
                                              inputFormatters: [
                                                FilteringTextInputFormatter.deny(RegExp(r'\s'))
                                              ],
                                              validator: Validator.confirmPasswordValidator(_resetPasswordController.passwordTextController.text, _resetPasswordController.confirmPasswordTextController.text),
                                              keyboardType: TextInputType.text,
                                              onFieldSubmitted: (v) {
                                                TMTUtilities.closeKeyboard(context);
                                              },),
                                          ],
                                        ),
                                      ),
                                    ),
                                    VerticalSpacing(HeightDimension.h_20),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: HeightDimension.h_20,
                            left: WidthDimension.w_15,
                            right: WidthDimension.w_15,
                            child: TMTTextButton(
                              onTap: (){
                                if (_formKey.currentState!.validate()) {
                                  _resetPasswordController
                                      .postResetPassword(context, args);
                                }
                                TMTUtilities.closeKeyboard(context);
                              },
                              buttonTitle: "SUBMIT",
                              isDisable: !_resetPasswordController.isButtonEnabled(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              );
            }),
      ),
    );
  }
}