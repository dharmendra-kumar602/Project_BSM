import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/post_forgot_password_request.dart';
import 'package:take_my_tack/data/repository_implementation/auth_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class ForgotPasswordPageController extends GetxController {
  final TextEditingController emailTextController = TextEditingController();

  AuthRepositoryImpl repositoryImpl = AuthRepositoryImpl();

  /*
   Method use to call forgot password api.
   Parameter- No Parameter.
   Return -> No Return type.
  */
  void postForgotPassword(BuildContext context) {
    var request = PostForgotPasswordRequest(
        requestHeader: DioUtils.getRequestHeaderModel(),
        email: emailTextController.text.toLowerCase(),
       );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await repositoryImpl.forgotPasswordOtp(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              Get.offNamed(AppRoutes.verifyForgotOTPScreen, arguments: emailTextController.text);
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}