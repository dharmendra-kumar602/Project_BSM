import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/post_login_request.dart';
import 'package:take_my_tack/data/repository_implementation/auth_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class LoginPageController extends GetxController {
  final TextEditingController emailTextController = TextEditingController();
  final TextEditingController passwordTextController = TextEditingController();
  final FocusNode emailFocusNode = FocusNode();
  final FocusNode passwordFocusNode = FocusNode();
  bool rememberMe = false;
  bool passwordVisible = true;
  String loggingStatus = '';
  AuthRepositoryImpl repositoryImpl = AuthRepositoryImpl();

  /*
   Method use to change password secure status.
   Parameter- No Parameter.
   Return -> No return type.
  */
  void changePasswordVisibility() {
    passwordVisible = !passwordVisible;
    update([GetControllerBuilders.loginPageController]);
  }

  /*
   Method use to get button enable status.
   Parameter- No Parameter.
   Return -> bool.
  */
  bool isSignInButtonEnabled () {
    if (emailTextController.text.isNotEmpty && passwordTextController.text.isNotEmpty) {
      return true;
    } else {
      return false;
    }
  }

  /*
   Method use to login user.
   Parameter- No Parameter.
   Return -> No Return type.
  */
  void postLoginUser (BuildContext context) {
    var request = PostLoginRequest(
        requestHeader: DioUtils.getRequestHeaderModel(),
        email: emailTextController.text.toLowerCase(),
        password: passwordTextController.text);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
       try {
         var response = await repositoryImpl.login(request);
         response.fold((left) {
           if (left is ServerFailure) {
             /// show exception
             TMTToast.showErrorToast(context, left.message ?? '');
           }
         }, (right) {
             if(right.responseHeader?.status == "SUCCESS") {
              loggingStatus = right.verificationStatus ?? '';
              if (loggingStatus == 'UN_VERIFIED') {
                return Get.offNamed(AppRoutes.verifyOTPScreen,
                    arguments: emailTextController.text);
              }
              if (right.token!.isNotEmpty) {
                TMTLocalStorage.save(
                    GetXStorageConstants.jwtToken, right.token);
                TMTLocalStorage.save(GetXStorageConstants.loggedInTime,
                    DateTime.now().millisecondsSinceEpoch);
                TMTLocalStorage.save(GetXStorageConstants.login, true);
                TMTLocalStorage.save(
                    GetXStorageConstants.rememberMe, rememberMe);
                TMTLocalStorage.save(
                    GetXStorageConstants.userEmail, emailTextController.text);
                TMTLocalStorage.save(GetXStorageConstants.userType,
                    TMTUtilities.getUserRoleFromToken());
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(
                    context, right.responseHeader?.error?.messages.first ?? "");
              }
            } else {
               TMTToast.showErrorToast(
                   context, right.responseHeader?.error?.messages.first ?? "");
             }
          });

       } catch (error) {
         TMTToast.showErrorToast(context, error.toString());
         if (kDebugMode) {
           print(error);
         }
       } finally {
         Loading.stop();
       }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}