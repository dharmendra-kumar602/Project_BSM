import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/login/login_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_app_icons.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<StatefulWidget> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final LoginPageController _loginPageController =
      Get.put(LoginPageController());
  final _formKey = GlobalKey<FormState>();

  final String args = Get.arguments ?? "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.primary,
      resizeToAvoidBottomInset: true,
      body: GetBuilder<LoginPageController>(
          id: GetControllerBuilders.loginPageController,
          init: _loginPageController,
          builder: (controller) {
            return TMTBackButton(
              route: AppRoutes.dashBoardScreen,
              child: CustomScrollView(
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                slivers: [
                  SliverAppBar(
                    floating: false,
                    pinned: false,
                    backgroundColor: AppColor.primary,
                    expandedHeight: HeightDimension.h_180,
                    flexibleSpace: FlexibleSpaceBar(
                      background: Container(
                        color: AppColor.primary,
                        child: Column(
                          children: [
                            VerticalSpacing(HeightDimension.h_40),
                            Visibility(
                              visible: ModalRoute.of(context)?.canPop == false,
                              child: InkWell(
                                onTap: () {
                                  Get.offAllNamed(AppRoutes.dashBoardScreen);
                                },
                                child: Row(
                                  children: [
                                    HorizontalSpacing(WidthDimension.w_20),
                                    SizedBox(
                                      height: HeightDimension.h_15,
                                      width: WidthDimension.w_15,
                                      child: Image.asset(
                                        TMTImages.icBack,
                                        color: AppColor.neutral_100,
                                      ),
                                    ),
                                    HorizontalSpacing(WidthDimension.w_20),
                                  ],
                                ),
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_40),
                            TMTTextWidget(
                              title: "Welcome Back",
                              style: TMTFontStyles.textTeen(
                                  color: AppColor.neutral_100,
                                  fontSize: TMTFontSize.sp_28,
                                  fontWeight: FontWeight.w600),
                            ),
                            VerticalSpacing(HeightDimension.h_5),
                            TMTTextWidget(
                              title: "Sign in to buy & sell",
                              style: TMTFontStyles.text(
                                  color: AppColor.neutral_100,
                                  fontSize: TMTFontSize.sp_18,
                                  fontWeight: FontWeight.w500),
                            ),
                            VerticalSpacing(HeightDimension.h_20),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: Container(
                      color: AppColor.primary,
                      child: TMTRoundedCornersContainer(
                        borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(TMTRadius.r_40),
                            topRight: Radius.circular(TMTRadius.r_40)),
                        bgColor: AppColor.neutral_100,
                        width: double.infinity,
                        child: SingleChildScrollView(
                          physics: const NeverScrollableScrollPhysics(),
                          child: Column(
                            children: [
                              VerticalSpacing(HeightDimension.h_20),
                              TMTTextWidget(
                                title: "Sign In",
                                style: TMTFontStyles.textTeen(
                                    fontWeight: FontWeight.w700,
                                    fontSize: TMTFontSize.sp_24,
                                    color: AppColor.neutral_800),
                              ),
                              VerticalSpacing(HeightDimension.h_20),
                              Form(
                                key: _formKey,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                      left: WidthDimension.w_10,
                                      right: WidthDimension.w_10),
                                  child: Column(
                                    children: [
                                      TMTTextField(
                                        hintText: "Email Address",
                                        controller: _loginPageController
                                            .emailTextController,
                                        focusNode:
                                            _loginPageController.emailFocusNode,
                                        onChanged: (v) {
                                          setState(() {});
                                        },
                                        inputFormatters: [
                                          FilteringTextInputFormatter.deny(
                                              RegExp(r'\s'))
                                        ],
                                        keyboardType: TextInputType.emailAddress,
                                        validator: Validator.emailValidate,
                                      ),
                                      VerticalSpacing(HeightDimension.h_8),
                                      TMTTextField(
                                        isSecure: _loginPageController
                                            .passwordVisible,
                                        hintText: "Password",
                                        controller: _loginPageController
                                            .passwordTextController,
                                        focusNode: _loginPageController
                                            .passwordFocusNode,
                                        onChanged: (v) {
                                          setState(() {});
                                        },
                                        suffixIcon: InkWell(
                                            onTap: () {
                                              _loginPageController
                                                  .changePasswordVisibility();
                                            },
                                            child: Icon(
                                              _loginPageController
                                                      .passwordVisible
                                                  ? MyFlutterApp.icEyeCloseGrey
                                                  : MyFlutterApp.icEyeOpen,
                                              size: 15,
                                            )),
                                        inputFormatters: [
                                          FilteringTextInputFormatter.deny(
                                              RegExp(r'\s'))
                                        ],
                                        validator:
                                            Validator.loginPasswordValidate,
                                        keyboardType: TextInputType.text,
                                        onFieldSubmitted: (v) {
                                          TMTUtilities.closeKeyboard(context);
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Row(
                                children: [
                                  HorizontalSpacing(WidthDimension.w_20),
                                  InkWell(
                                    onTap: (){
                                      _loginPageController.rememberMe =
                                      !_loginPageController.rememberMe;
                                      _loginPageController.update([
                                        GetControllerBuilders.loginPageController
                                      ]);
                                     },
                                    child: Row(
                                      children: [
                                        AnimatedContainer(
                                            height: 17,
                                            width: 17,
                                            duration: const Duration(milliseconds: 500),
                                            curve: Curves.fastLinearToSlowEaseIn,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(3),
                                                color: _loginPageController.rememberMe
                                                    ? AppColor.neutral_100
                                                    : Colors.transparent,
                                                border: Border.all(color: AppColor.neutral_800, width: 1.5)),
                                            child: _loginPageController.rememberMe
                                                ? const Icon(
                                              Icons.check,
                                              color: AppColor.neutral_800,
                                              size: 12,
                                            )
                                                : null),
                                        HorizontalSpacing(WidthDimension.w_6),
                                        TMTTextWidget(
                                          title: "Remember me",
                                          style: TMTFontStyles.text(
                                              fontWeight: FontWeight.w500,
                                              color: AppColor.textColor,
                                              fontSize: TMTFontSize.sp_13),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Spacer(),
                                  GestureDetector(
                                      onTap: () {
                                        Get.toNamed(
                                            AppRoutes.forgotPasswordScreen,
                                            arguments: args);
                                      },
                                      child: TMTTextWidget(
                                        title: "Forgot Password?",
                                        style: TMTFontStyles.text(
                                            fontWeight: FontWeight.w500,
                                            color: AppColor.textColor,
                                            fontSize: TMTFontSize.sp_13),
                                      )),
                                  HorizontalSpacing(WidthDimension.w_20),
                                ],
                              ),
                              VerticalSpacing(
                                  SizeConfig.safeBlockVertical * 24),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15,
                                    right: WidthDimension.w_15),
                                child: TMTTextButton(
                                  onTap: () {
                                    if (_formKey.currentState!.validate()) {
                                      _loginPageController.postLoginUser(context);
                                    }
                                    TMTUtilities.closeKeyboard(context);
                                  },
                                  buttonTitle: "SIGN IN",
                                  textStyle: TMTFontStyles.textTeen(
                                      color: !_loginPageController
                                              .isSignInButtonEnabled()
                                          ? AppColor.white
                                          : Colors.white,
                                      fontSize: TMTFontSize.sp_18,
                                      fontWeight: FontWeight.w700),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Text.rich(TextSpan(
                                style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_14,
                                    fontWeight: FontWeight.w500,
                                    color: AppColor.textColor),
                                text: 'Need an account? ',
                                children: [
                                  TextSpan(
                                    text: 'Sign Up',
                                    style: TMTFontStyles.text(
                                        color: AppColor.neutral_800,
                                        fontSize: TMTFontSize.sp_14,
                                        fontWeight: FontWeight.w500,
                                        textDecoration:
                                            TextDecoration.underline),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        Get.toNamed(AppRoutes.signUpScreen,
                                            arguments: args);
                                      },
                                  ),
                                ],
                              )),
                              VerticalSpacing(HeightDimension.h_10),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            );
          }),
    );
  }
}
