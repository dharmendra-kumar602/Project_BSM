import 'dart:async';
import 'package:app_settings/app_settings.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/response/get_all_categories_response.dart';
import 'package:take_my_tack/data/model/response/get_buyer_dashboard_response.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/home/homepage_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/product_detail/product_detail_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_notification/tmt_notification_bell.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<StatefulWidget> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final HomePageController _homePageController = Get.put(HomePageController());

  final CategoryController _categoryController = Get.find<CategoryController>();
  final DashboardController _dashboardController = Get.find<DashboardController>();

  final CarouselController _carouselController = CarouselController();
  List<WishlistModel> recentViewedProducts = [];

  int _start = 30;
  Timer? _timer;
  String otp = "";
  bool isSubscribedToNewsLetter = false;

  void startTimer() {
    const oneSec = Duration(seconds: 1);
    _timer = Timer.periodic(
      oneSec,
          (Timer timer) {
        if (_start == 0) {
          setState(() {
            timer.cancel();
          });
        } else {
          setState(() {
            _start--;
          });
        }
      },
    );
  }

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      _dashboardController.putUpdateFcmToken(context);
      _callApis();
    },);
    super.initState();
  }

  /// Call api's
  _callApis () {
    _homePageController.getBuyerDashboardContent(context);
    if(TMTLocalStorage.getString(GetXStorageConstants.jwtToken).isNotEmpty) {
      _dashboardController.getSellerRegisterStatus(context, (){});
      _dashboardController.getNewsLetterStatus(context, callBack: (v){
        setState(() {
          isSubscribedToNewsLetter = v == 1;
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    recentViewedProducts = TMTLocalStorage.getRecentlyViewedItems();
    recentViewedProducts.forEach((element) {
      element.isLiked = (TMTLocalStorage.getWishlistItems().firstWhereOrNull((e) => element.variationId == e.variationId) != null);
    });

    return GetBuilder<HomePageController>(
        id: GetControllerBuilders.homePageController,
        init: _homePageController,
        builder: (controller) {
          return Scaffold(
            body: Column(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height/9.3,
                  decoration: BoxDecoration(
                    color: AppColor.neutral_100,
                    boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      spreadRadius: 2,
                      blurRadius: 3,
                      offset: const Offset(0, 3), // changes position of shadow
                    ),
                  ]),
                  child: Padding(
                    padding: EdgeInsets.only(bottom: HeightDimension.h_8, top: HeightDimension.h_30),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_20),
                          SizedBox(
                            width: WidthDimension.w_55,
                            height: HeightDimension.h_40,
                            child: Image.asset(
                              TMTImages.icAppBarLogo,
                              fit: BoxFit.contain,
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_8),
                          SizedBox(
                            width: WidthDimension.w_100,
                            child: Image.asset(
                              TMTImages.icAppBarName,
                              fit: BoxFit.cover,
                            ),
                          ),
                          const Spacer(),
                          GestureDetector(
                            onTap: () async {
                              await Get.toNamed(AppRoutes.searchScreen);
                              _callApis();
                            },
                            child: SizedBox(
                              height: HeightDimension.h_19,
                              width: HeightDimension.h_19,
                              child: Image.asset(TMTImages.icSearch),
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                          GestureDetector(
                            onTap: () async {
                              await Get.toNamed(AppRoutes.notificationScreen);
                            },
                            child: TMTNotificationBell(isBuyer: true,),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                          GestureDetector(
                            onTap: () {
                             _checkUserStatus();
                            },
                            child: SizedBox(
                              height: HeightDimension.h_22,
                              width: HeightDimension.h_48,
                              child: Image.asset(TMTImages.icSell),
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_20),
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          constraints: BoxConstraints(maxHeight: SizeConfig.safeBlockVertical * 13.5, minHeight: SizeConfig.safeBlockVertical * 12),
                          width: double.infinity,
                          child: ListView.builder(
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: () async {
                                  _categoryController.selectedGrandChildCategory = null;
                                  _categoryController.selectedChildCategory = null;
                                  _categoryController.updateSelectCategory(CategoryObj(
                                      id: _homePageController.allChildCats[index].id ?? 0,
                                      name: _homePageController
                                          .allChildCats[index].name ?? "",
                                      iconName: _homePageController
                                          .allChildCats[index].iconName ?? "",
                                      imageName: _homePageController
                                          .allChildCats[index].imageName ?? "",
                                      sub: [], products: 0));
                                  await Get.toNamed(AppRoutes.categoryListingScreen,
                                      arguments: [_homePageController
                                          .allChildCats[index].name]);
                                  setState(() {
                                    _callApis();
                                  });
                                },
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    TMTRoundedCornersContainer(
                                      padding: const EdgeInsets.all(5),
                                      bgColor: AppColor.neutral_200,
                                      height: SizeConfig.safeBlockVertical * 8,
                                      child: TMTCachedImage.networkImage(_homePageController
                                          .allChildCats[index].iconName ?? ""),
                                    ),
                                    VerticalSpacing(HeightDimension.h_2),
                                    Container(
                                      constraints: BoxConstraints(minWidth: SizeConfig.safeBlockHorizontal * 24, maxWidth: SizeConfig.safeBlockHorizontal * 30),
                                      padding: EdgeInsets.only(
                                          left: WidthDimension.w_4,
                                          right: WidthDimension.w_4),
                                      child: TMTTextWidget(
                                        textAlign: TextAlign.center,
                                        maxLines: 2,
                                        title: _homePageController.allChildCats[index].name ?? "",
                                        style: TMTFontStyles.textTeen(
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                            fontSize: TMTFontSize.sp_13),
                                      ),
                                    )
                                  ],
                                ),
                              );
                            },
                            itemCount: _homePageController.allChildCats.length,
                            padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            scrollDirection: Axis.horizontal,
                          ),
                        ),
                        const VerticalSpacing(5),
                        Stack(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                  color: AppColor.neutral_100,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.3),
                                      spreadRadius: 3,
                                      blurRadius: 7,
                                      offset: const Offset(
                                          0, 3), // changes position of shadow
                                    ),
                                  ]
                              ),
                              child: CarouselSlider(
                                items: getBannersWidgetList(1, _homePageController.bannersTop),
                                carouselController: _carouselController,
                                options: CarouselOptions(
                                    autoPlayAnimationDuration:
                                        const Duration(milliseconds: 1000),
                                    autoPlay: true,
                                    height: HeightDimension.h_180,
                                    viewportFraction: 1.0,
                                    enlargeCenterPage: false,
                                    onPageChanged: (index, reason) {
                                      _homePageController.isCurrentIndex = index;
                                      _homePageController.update(
                                          [GetControllerBuilders.homePageController]);
                                    }),
                              ),
                            ),
                            Positioned(
                              bottom: HeightDimension.h_25,
                              left: 0,
                              right: 0,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: _homePageController.bannersTop
                                    .asMap()
                                    .entries
                                    .map((entry) {
                                  return Container(
                                    width: 14.0,
                                    height: 2.0,
                                    margin: const EdgeInsets.only(right: 2, left: 2),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color:
                                                _homePageController.isCurrentIndex ==
                                                        entry.key
                                                    ? AppColor.primary
                                                    : AppColor
                                                        .sliderIndicatorDisabledColor,
                                            width: 0.5),
                                        borderRadius: const BorderRadius.all(
                                            Radius.circular(TMTRadius.r_20)),
                                        color: _homePageController.isCurrentIndex ==
                                                entry.key
                                            ? AppColor.primary
                                            : AppColor.sliderIndicatorDisabledColor),
                                  );
                                }).toList(),
                              ),
                            ),
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_12),
                        Visibility(
                          visible: getJustAddedProductsByLimit().isNotEmpty,
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  HorizontalSpacing(WidthDimension.w_15),
                                  TMTTextWidget(
                                    title: "JUST ADDED",
                                    style: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_16,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const Spacer(),
                                  GestureDetector(
                                    onTap: () async {
                                      await Get.toNamed(AppRoutes.justAddedProductsListingScreen);
                                      setState(() {
                                        _callApis();
                                      });
                                    },
                                    child: SizedBox(
                                      height: HeightDimension.h_20,
                                      width: HeightDimension.h_40,
                                      child: Padding(
                                        padding: const EdgeInsets.only(right: 2),
                                        child: Align(alignment: Alignment.centerRight, child: Image.asset(TMTImages.icGroupNext, scale: 3.5,)),
                                      ),
                                    ),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_15),
                                ],
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              GridView.builder(
                                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: MediaQuery.of(context).size.width / (MediaQuery.of(context).size.height / 1.57)),
                                shrinkWrap: true,
                                padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: getJustAddedProductsByLimit().length,
                                itemBuilder: (BuildContext context, int index){
                                  var e = getJustAddedProductsByLimit()[index];
                                 return InkWell(
                                    onTap: () async {
                                      await Get.toNamed(AppRoutes.productDetailScreen, arguments: [e.id, e.productVariations.first.id]);
                                      setState(() {
                                        _callApis();
                                      });
                                    },
                                    child: Center(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Stack(
                                            children: [
                                              SizedBox(
                                                height: SizeConfig.safeBlockVertical * 14,
                                                width: WidthDimension.w_100,
                                                child: TMTCachedImage.networkImage(
                                                  (e.productVariations.isNotEmpty &&
                                                      e.productVariations.first
                                                          .productImages.isNotEmpty)
                                                      ? e.productVariations.first
                                                      .productImages.first.imageName
                                                      : "",
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                              Positioned(
                                                top: HeightDimension.h_8,
                                                right: HeightDimension.h_8,
                                                child: GestureDetector(
                                                  onTap: (){
                                                    _dashboardController.addToWishList(
                                                        context,
                                                        wishlistModel : WishlistModel(productId: e.id, variationId: e.productVariations.first.id,
                                                            variation: Variation(id: e.productVariations.first.id, salePrice: e.productVariations.first.salePrice, maxRetailPrice: e.productVariations.first.maxRetailPrice, weightInPound: 0, productImages: e.productVariations.first.productImages.map((element) =>
                                                                WishlistProductImage(imageName: element.imageName)).toList(), product: WishlistProduct(id: e.id, title: e.title, description: e.description, sellerStore: WishlistSellerStore(id: 0)))), (isAdded){
                                                      setState(() {
                                                        e.isLiked = isAdded;
                                                        _callApis();
                                                      });
                                                    });
                                                  },
                                                  child: SizedBox(
                                                    height: HeightDimension.h_20,
                                                    width: HeightDimension.h_20,
                                                    child: Image.asset((e.isLiked ?? false) ? TMTImages.icLikeEnabled : TMTImages.icLike),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          VerticalSpacing(HeightDimension.h_4),
                                          SizedBox(
                                            width: WidthDimension.w_100,
                                            child: TMTTextWidget(
                                              maxLines: 1,
                                              title: e.title,
                                              style: TMTFontStyles.textTeen(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: TMTFontSize.sp_12,
                                                  color: AppColor.neutral_800),
                                            ),
                                          ),
                                          VerticalSpacing(HeightDimension.h_4),
                                          TMTTextWidget(
                                              title: e.productVariations.isNotEmpty
                                                  ? "£${e.productVariations.first.salePrice.toStringAsFixed(2)}"
                                                  : "£",
                                              style: TMTFontStyles.textTeen(
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: TMTFontSize.sp_12,
                                                  color: AppColor.neutral_800)),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        Stack(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: AppColor.neutral_100,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.3),
                                    spreadRadius: 3,
                                    blurRadius: 7,
                                    offset: const Offset(
                                        0, 3), // changes position of shadow
                                  ),
                                ]
                              ),
                              width: double.infinity,
                              height: HeightDimension.h_180,
                              child: Image.asset(
                                TMTImages.banner2,
                                fit: BoxFit.contain,
                              ),
                            ),
                            Positioned(
                              bottom: 10,
                              right: 50,
                              child: SizedBox(
                                height: HeightDimension.h_45,
                                  width: WidthDimension.w_100,
                                  child: Center(child: TMTRoundedCornersContainer(
                                     boxShadow: [
                                       BoxShadow(
                                         color: Colors.grey.withOpacity(0.1),
                                         spreadRadius: 3,
                                         blurRadius: 5,
                                         offset: const Offset(
                                             0, 3), // changes position of shadow
                                       ),
                                     ],
                                      child: TMTTextButton(buttonTitle: " View Seller", textStyle: TMTFontStyles.text(color: AppColor.neutral_100, fontWeight: FontWeight.w700, fontSize: 12), onTap: (){
                                        /// view all seller list
                                        _dashboardController.getTopSellerData(context, (data) {
                                          if (data != null) {
                                            Get.put(ProductDetailController());
                                            Get.toNamed(AppRoutes.productSellerDetailScreen, arguments: data.storeId ?? 0);
                                          }
                                        });
                                      },)))),
                            ),
                          ],
                        ),
                        if (recentViewedProducts.isEmpty) VerticalSpacing(HeightDimension.h_5) else Container(
                          width: double.infinity,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage(TMTImages.phPink),
                                  fit: BoxFit.cover)),
                          child: Stack(
                            children: [
                              TMTRoundedCornersContainer(
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(TMTRadius.r_15)),
                                width: double.infinity,
                                margin: EdgeInsets.only(
                                    top: HeightDimension.h_10,
                                    bottom: HeightDimension.h_10,
                                    left: WidthDimension.w_20,
                                    right: WidthDimension.w_20),
                                bgColor: AppColor.neutral_100,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20,
                                    top: HeightDimension.h_10,
                                    bottom: HeightDimension.h_10,
                                    right: WidthDimension.w_10),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.3),
                                    spreadRadius: 5,
                                    blurRadius: 7,
                                    offset: const Offset(
                                        0, 3), // changes position of shadow
                                  ),
                                ],
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    VerticalSpacing(HeightDimension.h_10),
                                    TMTTextWidget(
                                      title: "RECENTLY VIEWED",
                                      style: TMTFontStyles.textTeen(
                                          fontWeight: FontWeight.w700,
                                          fontSize: TMTFontSize.sp_16,
                                          color: AppColor.neutral_800),
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    SizedBox(
                                      width: double.infinity,
                                      height: HeightDimension.h_100,
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    Visibility(
                                      visible: false,
                                      child: TMTTextWidget(
                                        title: "SEE MORE",
                                        style: TMTFontStyles.textHarbinger(
                                            fontWeight: FontWeight.w400,
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(top: HeightDimension.h_65),
                                width: double.infinity,
                                height: HeightDimension.h_100,
                                child: ListView.builder(
                                  itemBuilder: (context, index) {
                                    return GestureDetector(
                                      onTap: () async {
                                        await Get.toNamed(AppRoutes.productDetailScreen,
                                            arguments: [recentViewedProducts[index].productId, recentViewedProducts[index].variation?.id ?? -1]);
                                        setState(() {
                                          _callApis();
                                        });
                                      },
                                      child: Stack(
                                        children: [
                                          Container(
                                            margin: EdgeInsets.only(
                                                left: WidthDimension.w_4,
                                                right: WidthDimension.w_4),
                                            height: HeightDimension.h_90,
                                            width: WidthDimension.w_120,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(8.0),
                                              child: TMTCachedImage.networkImage(
                                                (recentViewedProducts[index].variation?.productImages.isNotEmpty ?? false) ? recentViewedProducts[index].variation?.productImages.first.imageName ?? "" : "",
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            top: HeightDimension.h_8,
                                            right: HeightDimension.h_8,
                                            child: GestureDetector(
                                              onTap: (){
                                                _dashboardController.addToWishList(context, wishlistModel : recentViewedProducts[index], (isAdded){
                                                  setState(() {
                                                    recentViewedProducts[index].isLiked = isAdded;
                                                    _callApis();
                                                  });
                                                });
                                              },
                                              child: SizedBox(
                                                  height: HeightDimension.h_25,
                                                  width: HeightDimension.h_25,
                                                  child: Image.asset(recentViewedProducts[index].isLiked ? TMTImages.icLikeEnabled : TMTImages.icLike)),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                  itemCount: recentViewedProducts.length,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.horizontal,
                                  padding: EdgeInsets.only(left: WidthDimension.w_30, right: WidthDimension.w_30),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: double.infinity,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage(TMTImages.phGrey),
                                  fit: BoxFit.cover)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              VerticalSpacing(HeightDimension.h_15),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15,
                                    right: WidthDimension.w_15),
                                child: TMTTextWidget(
                                  title: "FEATURED CATEGORIES",
                                  style: TMTFontStyles.textTeen(
                                      fontWeight: FontWeight.w700,
                                      fontSize: TMTFontSize.sp_16,
                                      color: AppColor.neutral_800),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              SizedBox(
                                width: double.infinity,
                                height: HeightDimension.h_160,
                                child: ListView.builder(
                                  itemBuilder: (context, index) {
                                    return GestureDetector(
                                      onTap: () async {
                                        _categoryController.updateSelectCategory(
                                            CategoryObj(
                                                id: _homePageController
                                                    .isFeatured[index].id ?? 0,
                                                name: _homePageController
                                                    .isFeatured[index].title ?? "",
                                                iconName: _homePageController
                                                    .isFeatured[index].iconName ?? "",
                                                imageName: _homePageController
                                                    .isFeatured[index].imageName ?? "",
                                                sub: [], products: 0));
                                        await Get.toNamed(AppRoutes.categoryListingScreen,
                                            arguments: [_homePageController
                                                .isFeatured[index].title]);
                                        setState(() {
                                          _callApis();
                                        });
                                      },
                                      child: Stack(
                                        children: [
                                          Container(
                                            margin: EdgeInsets.only(
                                                left: WidthDimension.w_4,
                                                right: WidthDimension.w_4),
                                            height: HeightDimension.h_160,
                                            width: WidthDimension.w_160,
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    width: double.infinity,
                                                    height: double.infinity,
                                                    child: TMTCachedImage.networkImage(
                                                      (_homePageController.isFeatured[index]
                                                          .imageName?.isEmpty ?? true)
                                                          ? ""
                                                          : _homePageController
                                                              .isFeatured[index]
                                                              .imageName ?? "",
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                  Container(
                                                    height: double.infinity,
                                                    width: double.infinity,
                                                    decoration: BoxDecoration(
                                                      gradient: LinearGradient(
                                                        colors: [
                                                          Colors.black.withOpacity(0.2),
                                                          Colors.transparent,
                                                          Colors.transparent,
                                                          Colors.black.withOpacity(0.8)
                                                        ],
                                                        begin: Alignment.topCenter,
                                                        end: Alignment.bottomCenter,
                                                        stops: [0, 0, 0.6, 1],
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            bottom: HeightDimension.h_5,
                                            left: HeightDimension.h_8,
                                            right: HeightDimension.h_8,
                                            child: TMTRoundedCornersContainer(
                                              borderRadius: const BorderRadius.all(
                                                  Radius.circular(TMTRadius.r_10)),
                                              bgColor: AppColor.neutral_100,
                                              padding: const EdgeInsets.all(4.0),
                                              child: SingleChildScrollView(
                                                child: Padding(
                                                  padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6, top: HeightDimension.h_2),
                                                  child: Column(
                                                    mainAxisSize: MainAxisSize.min,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      TMTTextWidget(
                                                        maxLines: 2,
                                                        title: _homePageController
                                                            .isFeatured[index].title ?? "",
                                                        style: TMTFontStyles.textTeen(
                                                          fontSize: 15,
                                                          color: AppColor.neutral_800,
                                                          fontWeight: FontWeight.w700,
                                                        ),
                                                        textAlign: TextAlign.start,
                                                      ),
                                                      VerticalSpacing(
                                                          HeightDimension.h_4),
                                                      TMTTextWidget(
                                                        maxLines: 2,
                                                        title: _homePageController.isFeatured[index].description ?? "",
                                                        style: TMTFontStyles.textTeen(
                                                          fontSize: 11,
                                                          color: AppColor.neutral_800,
                                                          fontWeight: FontWeight.w400,
                                                        ),
                                                        textAlign: TextAlign.center,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                  itemCount: _homePageController.isFeatured.length,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.horizontal,
                                  padding: EdgeInsets.only(left: WidthDimension.w_15),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                           _checkUserStatus();
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: AppColor.neutral_100,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.3),
                                    spreadRadius: 3,
                                    blurRadius: 7,
                                    offset: const Offset(
                                        0, 3), // changes position of shadow
                                  ),
                                ]
                            ),
                            width: double.infinity,
                            height: HeightDimension.h_180,
                            child: Image.asset(
                              TMTImages.banner4,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Row(
                          children: [
                            HorizontalSpacing(WidthDimension.w_15),
                            TMTTextWidget(
                              title: "EXPLORE MORE PRODUCTS",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_16,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_15),
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_10),
                        SizedBox(
                          width: MediaQuery.of(context).size.width,
                          height: HeightDimension.h_30,
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                HorizontalSpacing(WidthDimension.w_10),
                                GestureDetector(
                                  onTap: () {
                                    _homePageController.selectedExploreCategory = -1;
                                    _homePageController.getProductsByCategoryId(context,
                                        0);
                                  },
                                  child: TMTRoundedCornersContainer(
                                    margin: EdgeInsets.only(
                                        left: WidthDimension.w_4,
                                        right: WidthDimension.w_4),
                                    padding: EdgeInsets.only(
                                        left: WidthDimension.w_18,
                                        right: WidthDimension.w_18,
                                        top: HeightDimension.h_4,
                                        bottom: HeightDimension.h_4),
                                    bgColor: AppColor.neutral_100,
                                    borderColor: -1 ==
                                        _homePageController.selectedExploreCategory
                                        ? AppColor.primary
                                        : AppColor.neutral_500,
                                    borderWidth: 1.5,
                                    child: Center(
                                        child: TMTTextWidget(
                                          title:
                                          "All",
                                          style: TMTFontStyles.text(
                                              color: -1 ==
                                                  _homePageController
                                                      .selectedExploreCategory
                                                  ? AppColor.primary
                                                  : AppColor.textColor),
                                        )),
                                  ),
                                ),
                                ListView.builder(
                                  physics: const NeverScrollableScrollPhysics(),
                                  padding: EdgeInsets.zero,
                                  itemBuilder: (context, index) {
                                    return GestureDetector(
                                      onTap: () {
                                        _homePageController.selectedExploreCategory = index;
                                        _homePageController.getProductsByCategoryId(context,
                                            _homePageController.allChildCats[index].id ?? 0);
                                      },
                                      child: TMTRoundedCornersContainer(
                                        margin: EdgeInsets.only(
                                            left: WidthDimension.w_4,
                                            right: WidthDimension.w_4),
                                        padding: EdgeInsets.only(
                                            left: WidthDimension.w_10,
                                            right: WidthDimension.w_10,
                                            top: HeightDimension.h_4,
                                            bottom: HeightDimension.h_4),
                                        bgColor: AppColor.neutral_100,
                                        borderColor: index ==
                                                _homePageController.selectedExploreCategory
                                            ? AppColor.primary
                                            : AppColor.neutral_500,
                                        borderWidth: 1.5,
                                        child: Center(
                                            child: TMTTextWidget(
                                          title:
                                              _homePageController.allChildCats[index].name ?? "",
                                          style: TMTFontStyles.text(
                                              color: index ==
                                                      _homePageController
                                                          .selectedExploreCategory
                                                  ? AppColor.primary
                                                  : AppColor.textColor),
                                        )),
                                      ),
                                    );
                                  },
                                  itemCount: _homePageController.allChildCats.length,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.horizontal,
                                ),
                              ],
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        _homePageController.exploreProductsDta.isEmpty
                            ? Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SizedBox(
                                    height: HeightDimension.h_10,
                                    width: double.infinity,
                                  ),
                                const TMTTextWidget(title: "No product found."),
                                SizedBox(
                                    height: HeightDimension.h_20,
                                    width: double.infinity,
                                  ),
                              ],
                            )
                            : Column(
                                children: [
                                  GridView.count(
                                    childAspectRatio: MediaQuery.of(context).size.width / (MediaQuery.of(context).size.height / 1.72),
                                    shrinkWrap: true,
                                    padding: EdgeInsets.only(
                                        left: WidthDimension.w_15,
                                        right: WidthDimension.w_15),
                                    physics: const NeverScrollableScrollPhysics(),
                                    crossAxisCount: 2,
                                    children: _homePageController.exploreProductsDta
                                        .map((e) {
                                      return InkWell(
                                        onTap: () async {
                                          await Get.toNamed(AppRoutes.productDetailScreen,
                                              arguments: [e.id, e.productVariations?.first.id ?? 0]);
                                          setState(() {
                                            _callApis();
                                          });
                                        },
                                        child: TMTRoundedCornersContainer(
                                          margin: EdgeInsets.only(
                                              bottom: HeightDimension.h_12,
                                              left: WidthDimension.w_4,
                                              right: WidthDimension.w_4),
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_10)),
                                          bgColor: AppColor.neutral_100,
                                          borderColor: AppColor.neutral_400,
                                          borderWidth: 1,
                                          child: SingleChildScrollView(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Stack(
                                                  children: [
                                                    ClipRRect(
                                                      borderRadius:
                                                          const BorderRadius.only(
                                                              topRight:
                                                                  Radius.circular(
                                                                      TMTRadius.r_10),
                                                              topLeft: Radius.circular(
                                                                  TMTRadius.r_10)),
                                                      child: SizedBox(
                                                        height: SizeConfig.safeBlockVertical * 15,
                                                        width: double.infinity,
                                                        child: TMTCachedImage.networkImage(
                                                          ((e.productVariations?.isNotEmpty ?? false) && (e.productVariations?.first.productImages?.isNotEmpty ?? false))
                                                              ? e.productVariations?.first.productImages?.first.imageName ?? ""
                                                              : "",
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      top: HeightDimension.h_8,
                                                      right: HeightDimension.h_8,
                                                      child: Row(
                                                        children: [
                                                          GestureDetector(
                                                            onTap: (){
                                                              Share.share("Check out this product https://sharetakemytack.page.link/productDetailScreen?id=${(e.productVariations?.isNotEmpty ?? false) ? e.productVariations?.first.id : 0}");
                                                             },
                                                            child: SizedBox(
                                                              height:
                                                                  HeightDimension.h_23,
                                                              width: HeightDimension.h_23,
                                                              child: Image.asset(
                                                                  TMTImages.icShare),
                                                            ),
                                                          ),
                                                          const HorizontalSpacing(
                                                              5),
                                                          GestureDetector(
                                                            onTap: (){
                                                              _dashboardController.addToWishList(context, wishlistModel: WishlistModel(productId: e.id ?? 0, variationId: e.productVariations?.first.id ?? 0, variation: Variation(id: e.id ?? 0, salePrice: e.productVariations?.first.salePrice ?? 0, maxRetailPrice: e.productVariations?.first.maxRetailPrice ?? 0, weightInPound: 0, productImages: e.productVariations?.first.productImages?.map((e) => WishlistProductImage(imageName: e.imageName ?? "")).toList() ?? [], product: WishlistProduct(id: e.id ?? 0, title: e.title ?? "", description: e.description ?? "", sellerStore: WishlistSellerStore(id: 0))),), (isAdded){
                                                                setState(() {
                                                                  e.isLiked = isAdded;
                                                                  _callApis();
                                                                });
                                                              });
                                                            },
                                                            child: SizedBox(
                                                              height:
                                                                  HeightDimension.h_23,
                                                              width: HeightDimension.h_23,
                                                              child: Image.asset(
                                                                  (e.isLiked ?? false) ? TMTImages.icLikeEnabled : TMTImages.icLike),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                VerticalSpacing(HeightDimension.h_4),
                                                Padding(
                                                  padding: EdgeInsets.only(
                                                      left: WidthDimension.w_8,
                                                      right: WidthDimension.w_8),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.start,
                                                    children: [
                                                      VerticalSpacing(
                                                          HeightDimension.h_4),
                                                      TMTTextWidget(
                                                        maxLines: 1,
                                                        title: e.title ?? "",
                                                        style: TMTFontStyles.text(
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 13.sp,
                                                            color:
                                                                AppColor.neutral_800),
                                                      ),
                                                      VerticalSpacing(
                                                          HeightDimension.h_2),
                                                      TMTTextWidget(
                                                        maxLines: 1,
                                                        title: e.description ?? "",
                                                        style: TMTFontStyles.textTeen(
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 12.sp,
                                                            color: AppColor.textColor),
                                                      ),
                                                      VerticalSpacing(
                                                          HeightDimension.h_2),
                                                      TMTTextWidget(
                                                          title: (e.productVariations?.isNotEmpty ?? false)
                                                              ? "£${e.productVariations?.first.salePrice?.toStringAsFixed(2) ?? ""}"
                                                              : "£",
                                                          style: TMTFontStyles.text(
                                                              fontWeight:
                                                                  FontWeight.w700,
                                                              fontSize:
                                                                  12.sp,
                                                              color: AppColor
                                                                  .neutral_800)),
                                                      VerticalSpacing(
                                                          HeightDimension.h_2),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                  ),
                                  VerticalSpacing(HeightDimension.h_10),
                                  Container(
                                    height: HeightDimension.h_45,
                                    padding: EdgeInsets.only(
                                        left: WidthDimension.w_15,
                                        right: WidthDimension.w_15),
                                    child: GestureDetector(
                                        onTap: () async {
                                          _categoryController.updateSelectCategory(CategoryObj(
                                              id: _homePageController
                                                  .selectedExploreCategory == -1 ? -1 : _homePageController
                                                  .allChildCats[_homePageController
                                                      .selectedExploreCategory]
                                                  .id ?? 0,
                                              name: _homePageController
                                                  .selectedExploreCategory == -1 ? "All" : _homePageController
                                                  .allChildCats[_homePageController
                                                      .selectedExploreCategory]
                                                  .name ?? "",
                                              iconName: _homePageController
                                                  .selectedExploreCategory == -1 ? "" :_homePageController
                                                  .allChildCats[_homePageController
                                                      .selectedExploreCategory]
                                                  .iconName ?? "",
                                              imageName: _homePageController
                                                  .selectedExploreCategory == -1 ? "" : _homePageController
                                                  .allChildCats[_homePageController
                                                      .selectedExploreCategory]
                                                  .imageName ?? "",
                                              sub: [], products: 0));
                                          await Get.toNamed(AppRoutes.categoryListingScreen,
                                              arguments: [_homePageController
                                                  .selectedExploreCategory == -1 ? "All" :_homePageController
                                                  .allChildCats[_homePageController
                                                      .selectedExploreCategory]
                                                  .name]);
                                          setState(() {
                                            _callApis();
                                          });
                                        },
                                        child: const TMTTextButton(
                                            buttonTitle: "VIEW MORE")),
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                ],
                              ),
                        Visibility(
                          visible: !isSubscribedToNewsLetter,
                          child: Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: AppColor.neutral_100,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.2),
                                  spreadRadius: 2,
                                  blurRadius: 3,
                                  offset:
                                      const Offset(0, 3), // changes position of shadow
                                ),
                              ],
                            ),
                            padding: EdgeInsets.only(
                                top: HeightDimension.h_10,
                                bottom: HeightDimension.h_10,
                                left: WidthDimension.w_15,
                                right: WidthDimension.w_15),
                            child: Column(
                              children: [
                                TMTTextWidget(
                                  title: "Subscribe to our newsletter",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_16,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                VerticalSpacing(HeightDimension.h_10),
                                Padding(
                                  padding: EdgeInsets.only(
                                      left: WidthDimension.w_10,
                                      right: WidthDimension.w_10),
                                  child: TMTTextWidget(
                                    title:
                                        "Stay connected: Subscribe to our newsletter for the latest updates!",
                                    style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_12,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.w500,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                VerticalSpacing(HeightDimension.h_10),
                                TMTTextButton(
                                  onTap: (){
                                    if (TMTLocalStorage.getUserLoggedIn()) {
                                      _dashboardController.updateNewsLetterStatus(context, isSubscribedToNewsLetter, callBack: (){
                                        _callApis();
                                      });
                                    } else {
                                      Get.offAndToNamed(AppRoutes.loginScreen,
                                          arguments: AppRoutes.homeScreen);
                                    }
                                  },
                                  buttonTitle: "SUBSCRIBE",
                                  width: WidthDimension.w_105,
                                  height: HeightDimension.h_35,
                                  textStyle: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_12,
                                    color: AppColor.neutral_100,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                VerticalSpacing(HeightDimension.h_5),
                              ],
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        });
  }

  /*
   Method use to get banners widgets list.
   Parameter- List<String> banners.
   Return -> List<Widget>.
  */
  List<Widget> getBannersWidgetList(int typeId, List<String> banners) {
    List<Widget> bannersList = [];
    for (int i=0; i<banners.length; i++) {
      var element = banners[i];
      bannersList.add(GestureDetector(
        onTap: () async {
          if (i == 0) {
            _checkUserStatus();
          } else if (i == 1) {
            /// view all seller list
            _dashboardController.getSellerList(context, (sellers) {
              if (sellers?.isNotEmpty ?? false) {
                Get.toNamed(AppRoutes.sellersListingScreen, arguments: sellers);
              }
            });
          } else if (i == 2) {
            /// view all brands list
            _dashboardController.getBrandList(context, (brands) {
              if (brands?.isNotEmpty ?? false) {
                Get.toNamed(AppRoutes.brandsListingScreen, arguments: brands?.where((element) => element.isTopBrand == 1).toList());
              }
            });
          } else {
            await Get.toNamed(AppRoutes.categoryListingScreen,
                arguments: ["Trending", true]);
            setState(() {
              _callApis();
            });
          }
        },
        child: SizedBox(
          width: double.infinity,
          height: HeightDimension.h_100,
          child: TMTCachedImage.networkImage(
            element,
            fit: BoxFit.fill,
          ),
        ),
      ));
    }
    return bannersList;
  }

  /*
   Method use to get first 10 products from just added list.
   Parameter- No parameters.
   Return -> List<IsFeatured>.
  */
  List<JustAdded> getJustAddedProductsByLimit() {
    if (_homePageController.justAdded.length > 10) {
      List<JustAdded> first20 = [];
      for (int i=0; i < 10; i++) {
        first20.add(_homePageController.justAdded[i]);
      }
      return first20;
    } else {
      return _homePageController.justAdded;
    }
 }

 /// Check user status
  void _checkUserStatus() {

    if (TMTUtilities.getUserRoleFromToken() == "SELLER") {
      _dashboardController.getSellerRegisterStatus(context, (){
        if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
          Get.toNamed(AppRoutes.sellerDashboard);
        } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
          Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
        } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
          Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
        } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
          _dashboardController.getUpdatedToken(context, (){
            Get.toNamed(
                AppRoutes.sellerPlanDetailsScreen);
          });
        } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
          _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), (){
            Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
          });
        } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
          TMTUtilities.showUserDisabledDialog(context);
        } else {
          Get.toNamed(AppRoutes.sellerDashboard);
        }
      });
    } else {
      if (!TMTLocalStorage.getUserLoggedIn()) {
        Get.offAndToNamed(AppRoutes.loginScreen,
            arguments: AppRoutes.homeScreen);
      } else {
        _dashboardController.getSellerRegisterStatus(context, (){
          if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
            _dashboardController.getUpdatedToken(context, (){
              Get.toNamed(AppRoutes.sellerDashboard);
            });
          } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
            Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
          } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
            Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
          } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
            _dashboardController.getUpdatedToken(context, (){
              Get.toNamed(
                  AppRoutes.sellerPlanDetailsScreen);
            });
          } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
            _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), (){
              Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
            });
          } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
            TMTUtilities.showUserDisabledDialog(context);
          } else {
            Get.toNamed(AppRoutes.registerToSellScreen);
          }
        });
      }
    }
  }
}
