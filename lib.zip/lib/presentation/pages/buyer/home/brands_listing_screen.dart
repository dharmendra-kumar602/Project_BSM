import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/response/get_brands_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_list_response.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class BrandsListingScreen extends StatefulWidget {
  const BrandsListingScreen({super.key});

  @override
  State<StatefulWidget> createState() => _BrandsListingScreenState();
}

class _BrandsListingScreenState extends State<BrandsListingScreen> {
  List<BrandData> brandsList = Get.arguments ?? [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height / 9.3,
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 3,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ], color: AppColor.neutral_100),
            child: Padding(
              padding: EdgeInsets.only(
                  bottom: HeightDimension.h_5, top: HeightDimension.h_25),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Row(
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_10),
                          SizedBox(
                            width: WidthDimension.w_40,
                            height: HeightDimension.h_30,
                            child: Center(
                              child: Image.asset(
                                TMTImages.icBack,
                                color: AppColor.neutral_800,
                                fit: BoxFit.contain,
                                scale: 3.4,
                              ),
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_2),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: WidthDimension.w_220,
                      child: TMTTextWidget(
                        maxLines: 1,
                        title: "Top Brands",
                        style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_18,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(WidthDimension.w_20),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: brandsList.isEmpty
                  ? Padding(
                      padding: EdgeInsets.only(
                          top: MediaQuery.of(context).size.height / 2.5),
                      child: Center(
                        child: TMTTextWidget(
                          title: "No data found.",
                          style: TMTFontStyles.textTeen(),
                        ),
                      ),
                    )
                  : ListView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      padding: EdgeInsets.only(
                          top: HeightDimension.h_20,
                          bottom: HeightDimension.h_20,
                          left: WidthDimension.w_15,
                          right: WidthDimension.w_15),
                      itemCount: brandsList.length,
                      itemBuilder: (BuildContext context, int index) {
                        var e = brandsList[index];
                        return InkWell(
                          onTap: () {
                            Get.toNamed(AppRoutes.productsByBrandIdScreen, arguments: e);
                          },
                          child: Container(
                            margin: EdgeInsets.only(
                                bottom: HeightDimension.h_8,
                                left: WidthDimension.w_4,
                                right: WidthDimension.w_4),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: 1,
                                  color: AppColor.lightGrey,
                                ),
                                VerticalSpacing(HeightDimension.h_10),
                                SizedBox(
                                    width: WidthDimension.w_250,
                                    child: TMTTextWidget(
                                      title: e.name ?? "",
                                      style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_14,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      maxLines: 2,
                                    )),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: CommonBottomNavigationBar(
          currentSelectedItem: 0,
          onTap: (index) {
            Get.offAllNamed(AppRoutes.dashBoardScreen, arguments: index);
          }),
    );
  }
}
