import 'package:carousel_slider/carousel_controller.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/request/get_buyer_dashboard_request.dart';
import 'package:take_my_tack/data/model/request/get_products_by_categoryId_request.dart';
import 'package:take_my_tack/data/model/response/get_buyer_dashboard_response.dart';
import 'package:take_my_tack/data/model/response/get_products_by_category_id_response.dart';
import 'package:take_my_tack/data/repository_implementation/dashboard_repository_impl.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';
import 'package:take_my_tack/data/model/response/get_buyer_dashboard_response.dart' as _banner;

class HomePageController extends GetxController {
  final CarouselController carouselController = CarouselController();
  var isCurrentIndex = 0;

  DashboardRepositoryImpl dashboardRepositoryImpl = DashboardRepositoryImpl();

  List<JustAdded> justAdded = [];
  List<AllChildCat> allChildCats = [];
  List<AllChildCat> isFeatured = [];
  List<_banner.Banner> allBanners = [];
  List<String> bannersTop = [];
  List<String> bannersMedium = [];
  List<String> bannersBottom = [];
  List<CategoryDatum> exploreProductsDta = [];

  int selectedExploreCategory = 0;

  /// Method use to change current index.
  changeCurrentIndexValue(int index) {
    isCurrentIndex = index;
    carouselController.animateToPage(index);
    update([GetControllerBuilders.dashboardController]);
  }

  /*
   Method use to get buyer dashboard content.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getBuyerDashboardContent (BuildContext context) {
    var request = GetBuyerDashboardRequest(limit: 10, offSet: 0
       );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getDashboardDetails(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              justAdded = right.data.justAdded;
              justAdded.forEach((element) {
                element.isLiked = (TMTLocalStorage.getWishlistItems().firstWhereOrNull((e) => element.productVariations.first.id == e.variationId) != null);
              });
              allChildCats = right.data.allChildCats;
              isFeatured = right.data.featuredCategories;
              allBanners = right.data.banners;
              bannersTop = right.data.banners.firstWhereOrNull((element) => element.typeId == 1)?.images ?? [];
              bannersMedium = right.data.banners.firstWhereOrNull((element) => element.typeId == 2)?.images ?? [];
              bannersBottom = right.data.banners.firstWhereOrNull((element) => element.typeId == 3)?.images ?? [];
              getProductsByCategoryId(context, selectedExploreCategory == -1 ? 0 : allChildCats[selectedExploreCategory].id ?? 0);
              update([GetControllerBuilders.homePageController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get Products by Category Id.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getProductsByCategoryId (BuildContext context, int id) {
    GetProductsByCategoryIdRequest request = GetProductsByCategoryIdRequest(pageSize: 10, pageNumber: 0, categoryId: id, sortId: "JUST_ADDED");

    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getProductsByCategoryId(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              exploreProductsDta = right.data ?? [];
              exploreProductsDta.forEach((element) {
                element.isLiked = (TMTLocalStorage.getWishlistItems().firstWhereOrNull((e) => element.productVariations?.map((e) => e.id).toList().contains(e.variationId) ?? false) != null);
              });
              update([GetControllerBuilders.homePageController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use for add product to Cart.
   Parameter- BuildContext context, int variationId, int productId.
   Return -> No Return type.
  */
  void addToWishList (BuildContext context, WishlistModel wishlistModel) {
    TMTLocalStorage.addToWishlist(wishlistModel);
    TMTToast.showSuccessToast(context, "Product added to Wishlist.");
    update([GetControllerBuilders.homePageController]);
    return;
  }
}