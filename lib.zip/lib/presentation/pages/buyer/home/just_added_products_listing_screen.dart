import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class JustAddedProductsListingScreen extends StatefulWidget {
  const JustAddedProductsListingScreen({super.key});

  @override
  State<StatefulWidget> createState() => _JustAddedProductsListingScreenState();
}

class _JustAddedProductsListingScreenState extends State<JustAddedProductsListingScreen> {

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  final CategoryController _categoryController =
  Get.find<CategoryController>();

  @override
  void initState() {
    _callApi();
    super.initState();
  }

  /// call api
  _callApi () {
    _categoryController.getJustAddedProducts(context);
  }

  @override
  Widget build(BuildContext context) {

    return GetBuilder<CategoryController>(
        id: GetControllerBuilders.categoryScreenController,
        init: _categoryController,
        builder: (controller) {
        return Scaffold(
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_2),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: WidthDimension.w_220,
                          child: TMTTextWidget(
                            maxLines: 1,
                            title: "Just Added",
                            style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () async {
                            await Get.toNamed(AppRoutes.wishListScreen, arguments: false);
                            setState(() {
                              _callApi();
                            });
                          },
                          child: Stack(
                            children: [
                              Container(
                                margin: EdgeInsets.only(top: HeightDimension.h_5, right: HeightDimension.h_5),
                                height: HeightDimension.h_20,
                                width: HeightDimension.h_20,
                                child: Image.asset(
                                  TMTImages.icHeart,
                                  color: AppColor.neutral_800,
                                ),
                              ),
                              Visibility(
                                visible: TMTLocalStorage.getWishlistItems().isNotEmpty,
                                child: Positioned(
                                  top: 0,
                                  right: 0,
                                  child: TMTRoundedCornersContainer(
                                      bgColor: AppColor.primaryBG,
                                      padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                      child: TMTTextWidget(title: TMTLocalStorage.getWishlistItems().length.toString() ?? "", style: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontSize: 10),)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_10),
                        GestureDetector(
                          onTap: () async {
                            await Get.toNamed(AppRoutes.cartScreen, arguments: false);
                            setState(() {
                              _callApi();
                            });
                          },
                          child: Stack(
                            children: [
                              Container(
                                margin: EdgeInsets.only(top: HeightDimension.h_5, right: HeightDimension.h_5),
                                height: HeightDimension.h_20,
                                width: HeightDimension.h_20,
                                child: Image.asset(TMTImages.icCart,
                                    color: AppColor.neutral_800),
                              ),
                              Visibility(
                                visible: TMTLocalStorage.getCartItems().isNotEmpty,
                                child: Positioned(
                                  top: 0,
                                  right: 0,
                                  child: TMTRoundedCornersContainer(
                                      bgColor: AppColor.primaryBG,
                                      padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                      child: TMTTextWidget(title: TMTLocalStorage.getCartItems().length.toString() ?? "", style: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontSize: 10),)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: _categoryController.allProducts.isEmpty ? Padding(
                    padding: EdgeInsets.only(top: MediaQuery.of(context).size.height/2.5),
                    child: Center(
                      child: TMTTextWidget(title: "No product.", style: TMTFontStyles.textTeen(),),
                    ),
                  ): GridView.builder(
                    physics: NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        childAspectRatio: MediaQuery.of(context).size.width / (MediaQuery.of(context).size.height / 1.76),
                        crossAxisCount: 2),
                    shrinkWrap: true,
                    padding: EdgeInsets.only(
                        top: HeightDimension.h_20,
                        bottom: HeightDimension.h_20,
                        left: WidthDimension.w_15,
                        right: WidthDimension.w_15),
                    itemCount: _categoryController.allProducts.length,
                    itemBuilder: (BuildContext context, int index){
                      var e = _categoryController.allProducts[index];

                      return InkWell(
                        onTap: () async {
                          await Get.toNamed(AppRoutes.productDetailScreen, arguments: [e.id, e.productVariations?.first.id]);
                          setState(() {
                            _callApi();
                          });
                        },
                        child: Container(
                          margin: EdgeInsets.only(
                              bottom: HeightDimension.h_8,
                              left: WidthDimension.w_4,
                              right: WidthDimension.w_4),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Stack(
                                children: [
                                  SizedBox(
                                    height: HeightDimension.h_115,
                                    width: double.infinity,
                                    child: TMTCachedImage.networkImage(
                                      (e.productVariations?.first.productImages?.isEmpty ?? true) ? "" : e.productVariations?.first.productImages?.first.imageName ?? "",
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  Visibility(
                                    visible: e.badge?.name?.isNotEmpty ?? false,
                                    child: Positioned(
                                      left: 0,
                                      top: HeightDimension.h_5,
                                      child: Stack(
                                        children: [
                                          SizedBox(
                                            height: HeightDimension.h_14,
                                            child: Image.asset(TMTImages.icBadgeBg),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(left: WidthDimension.w_10, top: 1),
                                            child: TMTTextWidget(title: e.badge?.title ?? "", style: TMTFontStyles.text(
                                              fontSize: 8,
                                              color: AppColor.neutral_100,
                                              fontWeight: FontWeight.w500,
                                            ), maxLines: 1,),
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              VerticalSpacing(HeightDimension.h_8),
                              Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_8, right: WidthDimension.w_8),
                                child: Stack(
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          width: WidthDimension.w_90,
                                          child: TMTTextWidget(
                                            maxLines: 1,
                                            title: e.title ?? "",
                                            style: TMTFontStyles.text(
                                                fontWeight: FontWeight.w500,
                                                fontSize: TMTFontSize.sp_12,
                                                color: AppColor.neutral_800),
                                          ),
                                        ),
                                        TMTTextWidget(
                                          maxLines: 1,
                                          title: e.description ?? "",
                                          style: TMTFontStyles.text(
                                              fontWeight: FontWeight.w400,
                                              fontSize: TMTFontSize.sp_10,
                                              color: AppColor.textColor),
                                        ),
                                        TMTTextWidget(
                                            title: "£${e.productVariations?.first.salePrice?.toStringAsFixed(2) ?? ""}",
                                            style: TMTFontStyles.text(
                                                fontWeight: FontWeight.w700,
                                                fontSize: TMTFontSize.sp_10,
                                                color: AppColor.neutral_800)),

                                      ],
                                    ),
                                    Positioned(
                                        top: 0,
                                        right: 0,
                                        child: Row(
                                          children: [
                                            GestureDetector(
                                              onTap: (){
                                                Share.share("Check out this product https://sharetakemytack.page.link/productDetailScreen?id=${(e.productVariations?.isNotEmpty ?? false) ? e.productVariations?.first.id : 0}");
                                              },
                                              child: SizedBox(
                                                height: HeightDimension.h_15,
                                                width: HeightDimension.h_15,
                                                child: Image.asset(TMTImages.icShareWB, color: AppColor.neutral_800,),
                                              ),
                                            ),
                                            HorizontalSpacing(WidthDimension.w_4),
                                            GestureDetector(
                                              onTap: (){
                                                _dashboardController.addToWishList(context, wishlistModel : WishlistModel(productId: e.id ?? 0, variationId: e.productVariations?.first.id ?? 0, variation: Variation(id: e.id ?? 0, salePrice: e.productVariations?.first.salePrice ?? 0, maxRetailPrice: e.productVariations?.first.maxRetailPrice ?? 0, weightInPound: 0, productImages: e.productVariations?.first.productImages?.map((e) => WishlistProductImage(imageName: e.imageName ?? "")).toList() ?? [], product: WishlistProduct(id: e.id ?? 0, title: e.title ?? "", description: e.description ?? "", sellerStore: WishlistSellerStore(id: 0)))), (isAdded){
                                                  setState(() {
                                                    e.isLiked = isAdded;
                                                  });
                                                });
                                              },
                                              child: SizedBox(
                                                height: HeightDimension.h_15,
                                                width: HeightDimension.h_15,
                                                child: Image.asset((e.isLiked ?? false) ? TMTImages.icHeartEnabled : TMTImages.icHeart),
                                              ),
                                            ),
                                          ],
                                        ))
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
          bottomNavigationBar: CommonBottomNavigationBar(
              currentSelectedItem: 0, onTap: (index) {
            Get.offAllNamed(AppRoutes.dashBoardScreen, arguments: index);
          }),
        );
      }
    );
  }

  /*
   Method use to get wishlist icon.
   Parameter- No parameters.
   Return -> Widget.
  */
  Widget _getWishlistCount() {
    return SizedBox(
      height: HeightDimension.h_20,
      width: HeightDimension.h_20,
      child: Image.asset(
        TMTImages.icHeart,
        color: AppColor.neutral_800,
      ),
    );
  }
}
