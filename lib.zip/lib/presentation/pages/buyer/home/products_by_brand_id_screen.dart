import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/model/request/post_apply_filters_request.dart';
import 'package:take_my_tack/data/model/response/get_brands_response.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/filters/products_filter_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/filters/sort_filter_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/home/homepage_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class ProductsByBrandIdScreen extends StatefulWidget {
  const ProductsByBrandIdScreen({super.key});

  @override
  State<StatefulWidget> createState() => _ProductsByBrandIdScreenState();
}

class _ProductsByBrandIdScreenState extends State<ProductsByBrandIdScreen> {
  BrandData? brandData = Get.arguments;

  final CategoryController _controller = Get.put(CategoryController());
  final DashboardController _dashboardController =
  Get.find<DashboardController>();
  ScrollController? scrollController;

  @override
  void initState() {
    if (brandData == null) {
      Navigator.pop(context);
      return;
    }

    scrollController = ScrollController()..addListener(_scrollListener);
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      _callApis();
    },);
    super.initState();
  }

  @override
  void dispose() {
    scrollController?.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    if ((scrollController?.position.extentAfter ?? 0) < 50) {
      if (_controller.totalCount > _controller.productsByCategories.length) {
        _controller.offset += _controller.limit;
        _controller.applyBrandsFilters(context, PostProductFiltersReruest(attributes: [], brands: _controller.selectedBrandsFilters ,pageSize: _controller.limit, pageNumber: _controller.offset, sortId: _controller.sortingFilters[_controller.selectedSorting], isTrending: false));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CategoryController>(
        id: GetControllerBuilders.productsByBrandIdScreenController,
        init: _controller,
        builder: (controller) {
        return Scaffold(
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height / 9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(
                      bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_2),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: WidthDimension.w_220,
                          child: TMTTextWidget(
                            maxLines: 1,
                            title: _controller.selectedBrandsFilters.length > 1 ? "Products" : brandData?.name ?? "Products",
                            style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const Spacer(),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: _controller.brandProductsData.isEmpty ? Padding(
                    padding: EdgeInsets.only(top: MediaQuery.of(context).size.height/2.3),
                    child: Center(
                      child: TMTTextWidget(title: "No product.", style: TMTFontStyles.textTeen(),),
                    ),
                  ): GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: MediaQuery.of(context).size.width / (MediaQuery.of(context).size.height / 1.75)),
                    shrinkWrap: true,
                    padding: EdgeInsets.only(top: HeightDimension.h_20, left: WidthDimension.w_12, right: WidthDimension.w_12),
                    itemCount: _controller.brandProductsData.length,
                    itemBuilder: (BuildContext context, int index){
                      var e = _controller.brandProductsData[index];
                      return InkWell(
                        onTap: () async {
                          await Get.toNamed(AppRoutes.productDetailScreen, arguments: [e.id, e.productVariations?.first.id ?? 0]);
                          setState(() { 
                            _controller.applyBrandsFilters(context, PostProductFiltersReruest(attributes: [], brands: _controller.selectedBrandsFilters ,pageSize: _controller.limit, pageNumber: _controller.offset, sortId: _controller.sortingFilters[_controller.selectedSorting], isTrending: false));
                          });
                        },
                        child: Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_4, right: WidthDimension.w_4),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Stack(
                                children: [
                                  SizedBox(
                                    height: HeightDimension.h_120,
                                    width: double.infinity,
                                    child: TMTCachedImage.networkImage(
                                      (e.productVariations?.first.productImages?.isEmpty ?? true) ? "" : e.productVariations?.first.productImages?.first.imageName ?? "",
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  Visibility(
                                    visible: e.badge?.name?.isNotEmpty ?? false,
                                    child: Positioned(
                                      left: 0,
                                      top: HeightDimension.h_5,
                                      child: Stack(
                                        children: [
                                          SizedBox(
                                            height: HeightDimension.h_10,
                                            child: Image.asset(TMTImages.icBadgeBg),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(left: WidthDimension.w_10, bottom: HeightDimension.h_2),
                                            child: TMTTextWidget(title: e.badge?.title ?? "", style: TMTFontStyles.text(
                                              fontSize: 8,
                                              color: AppColor.neutral_100,
                                              fontWeight: FontWeight.w500,
                                            ),),
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              VerticalSpacing(HeightDimension.h_8),
                              Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_8, right: WidthDimension.w_8),
                                child: Stack(
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          width: WidthDimension.w_90,
                                          child: TMTTextWidget(
                                            maxLines: 1,
                                            title: e.title ?? "",
                                            style: TMTFontStyles.text(
                                                fontWeight: FontWeight.w500,
                                                fontSize: TMTFontSize.sp_12,
                                                color: AppColor.neutral_800),
                                          ),
                                        ),
                                        TMTTextWidget(
                                          maxLines: 1,
                                          title: e.description ?? "",
                                          style: TMTFontStyles.text(
                                              fontWeight: FontWeight.w400,
                                              fontSize: TMTFontSize.sp_10,
                                              color: AppColor.textColor),
                                        ),
                                        TMTTextWidget(
                                            maxLines: 1,
                                            title: "£${e.productVariations?.first.salePrice?.toStringAsFixed(2) ?? ""}",
                                            style: TMTFontStyles.text(
                                                fontWeight: FontWeight.w700,
                                                fontSize: TMTFontSize.sp_10,
                                                color: AppColor.neutral_800)),
                                        VerticalSpacing(HeightDimension.h_8),
                                      ],
                                    ),
                                    Positioned(
                                        top: 0,
                                        right: 0,
                                        child: Row(
                                          children: [
                                            GestureDetector(
                                              onTap: (){
                                                Share.share("Check out this product https://sharetakemytack.page.link/productDetailScreen?id=${(e.productVariations?.isNotEmpty ?? false) ? e.productVariations?.first.id : 0}");
                                              },
                                              child: SizedBox(
                                                height: HeightDimension.h_15,
                                                width: HeightDimension.h_15,
                                                child: Image.asset(TMTImages.icShareWB, color: AppColor.neutral_800,),
                                              ),
                                            ),
                                            HorizontalSpacing(WidthDimension.w_4),
                                            GestureDetector(
                                              onTap: (){
                                                _dashboardController.addToWishList(context, wishlistModel : WishlistModel(productId: e.id ?? 0, variationId: e.productVariations?.first.id ?? 0, isLiked: true, variation: Variation(id: e.productVariations?.first.id ?? 0, salePrice: e.productVariations?.first.salePrice ?? 0, maxRetailPrice: e.productVariations?.first.maxRetailPrice ?? 0, weightInPound: 0, productImages: e.productVariations?.first.productImages?.map((e) => WishlistProductImage(imageName: e.imageName ?? "")).toList() ?? [], product: WishlistProduct(id: e.id ?? 0, title: e.title ?? "", description: e.description ?? "", sellerStore: WishlistSellerStore(id: 0)))), (isAdded){
                                                  setState(() {
                                                    e.isLiked = isAdded;
                                                  });
                                                });
                                              },
                                              child: SizedBox(
                                                height: HeightDimension.h_15,
                                                width: HeightDimension.h_15,
                                                child: Image.asset((e.isLiked ?? false) ? TMTImages.icHeartEnabled : TMTImages.icHeart),
                                              ),
                                            ),
                                          ],
                                        ))
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                    physics: const NeverScrollableScrollPhysics(),
                  ),
                ),
              ),
              Container(
                height: HeightDimension.h_48,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Stack(
                  children: [
                    Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: (){
                                showDialog(
                                    barrierColor: Colors.transparent,
                                    useSafeArea: false,
                                    context: context, builder: (context){return SafeArea(
                                    bottom: false,
                                    child: Dialog.fullscreen(
                                        backgroundColor: Colors.transparent,
                                        child: SortFilterScreen(isEmpty: _controller.brandProductsData.isEmpty, brandId: brandData?.id,)));});
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  SizedBox(
                                    height: HeightDimension.h_18,
                                    width: HeightDimension.h_18,
                                    child: Image.asset(TMTImages.icSettingSort),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_10),
                                  TMTTextWidget(title: "SORT", style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_12,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: InkWell(
                              onTap: (){
                                showDialog(
                                    barrierColor: Colors.transparent,
                                    useSafeArea: false,
                                    context: context, builder: (context){return SafeArea(
                                    bottom: false,
                                    child: Dialog.fullscreen(
                                        backgroundColor: Colors.transparent,
                                        child: ProductsFilterScreen(brandId: brandData?.id ?? 0,)));});
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  SizedBox(
                                    height: HeightDimension.h_18,
                                    width: HeightDimension.h_18,
                                    child: Image.asset(TMTImages.icSettingProduct),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_10),
                                  TMTTextWidget(title: "FILTER", style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_12,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                          width: 1,
                          height: double.infinity,
                          color: const Color(0XFFC1C1C1),
                        )
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
          bottomNavigationBar: CommonBottomNavigationBar(
              currentSelectedItem: 0,
              onTap: (index) {
                Get.offAllNamed(AppRoutes.dashBoardScreen, arguments: index);
              }),
        );
      }
    );
  }

  /// call apis
  void _callApis() { 
    _controller.applyBrandsFilters(context, PostProductFiltersReruest(attributes: [], brands: [brandData?.id ?? 0],pageSize: _controller.limit, pageNumber: _controller.offset, sortId: _controller.sortingFilters[_controller.selectedSorting], isTrending: false));
  }
}
