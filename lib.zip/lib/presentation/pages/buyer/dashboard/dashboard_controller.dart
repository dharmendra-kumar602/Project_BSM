import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/cart_models.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/post_add_to_cart_request.dart';
import 'package:take_my_tack/data/model/request/post_add_to_wishlist_request.dart';
import 'package:take_my_tack/data/model/request/post_resend_registration_seller_otp_request.dart';
import 'package:take_my_tack/data/model/request/put_update_fcm_token_request.dart';
import 'package:take_my_tack/data/model/request/put_update_password_request.dart';
import 'package:take_my_tack/data/model/request/put_update_profile_picture_request.dart';
import 'package:take_my_tack/data/model/request/put_update_profile_request.dart';
import 'package:take_my_tack/data/model/response/get_brands_response.dart';
import 'package:take_my_tack/data/model/response/get_buyer_profile_response.dart';
import 'package:take_my_tack/data/model/response/get_cart_response.dart';
import 'package:take_my_tack/data/model/response/get_countries_list_response.dart';
import 'package:take_my_tack/data/model/response/get_notifications_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_list_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_plan_status_response.dart';
import 'package:take_my_tack/data/model/response/get_top_seller_response.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/data/repository_implementation/auth_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/dashboard_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/product_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/seller_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

import '../../../../data/model/response/get_address_by_post_code_response.dart';

class DashboardController extends GetxController {

  int selectedNavItemIndex = AppRoutesIdentifiers.homeScreen;
  int selectedPageIndex = AppRoutesIdentifiers.homeScreen;

  ProductRepositoryImpl productRepositoryImpl = ProductRepositoryImpl();
  AuthRepositoryImpl authRepositoryImpl = AuthRepositoryImpl();
  DashboardRepositoryImpl dashboardRepositoryImpl = DashboardRepositoryImpl();
  final SellerRepositoryImpl _sellerRepositoryImpl = SellerRepositoryImpl();

  String isStatus = '';
  List<WishlistDatum> localList = [];
  List<WishlistDatum> serverList = [];
  List<WishlistDatum> finalList = [];
  BuyerData? buyerData;

  /*
   Method use to change selected page and selected navbar index.
   Parameter- int pageIndex.
   Return -> No return type.
  */
  void changeSelectedPage({required int pageIndex, required int navBarItemIndex}) {
    selectedPageIndex = pageIndex;
    selectedNavItemIndex = navBarItemIndex;
    update([GetControllerBuilders.dashboardController]);
  }

  /*
   Method use for add product to Cart.
   Parameter- BuildContext context, int variationId, int productId.
   Return -> No Return type.
  */
  void addToCart (BuildContext context, int variationId, int productId, CartData cartData, Function callback, int qt) {
    if (productId == 0) {
      callback.call();
      update([GetControllerBuilders.dashboardController]);
      return;
    }
    var request = PostAddToCartRequest(requestHeader: DioUtils.getRequestHeaderModel(), variationId: variationId, productId: productId);
    if (TMTLocalStorage.getUserLoggedIn()) {
      NetWorkUtility.isInternetAvailable().then((value) async {
        if (value) {
          const Loading().start(context);
          try {
            var response = await productRepositoryImpl.addToCart(request);
            response.fold((left) {
              if (left is ServerFailure) {
                /// show exception
                TMTToast.showErrorToast(context, left.message ?? '');
              }
            }, (right) {
              if (right.responseHeader.error == null) {
                TMTLocalStorage.addToCart(CartModel(productId: productId, productVariationId: variationId, quantity: qt));
                TMTToast.showSuccessToast(context, right.responseHeader.message);
                callback.call();
                update([GetControllerBuilders.dashboardController]);
              } else {
                if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                  TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                  TMTLocalStorage.clear();
                  Get.offAllNamed(AppRoutes.dashBoardScreen);
                } else {
                  TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
                }
              }
            });

          } catch (error) {
            TMTToast.showErrorToast(context, error.toString());
            if (kDebugMode) {
              print(error);
            }
          } finally {
            Loading.stop();
          }
        }
        else {
          /// No internet connection dialog
        }
      });
    }
    else {
      TMTLocalStorage.addToCart(CartModel(productId: productId, productVariationId: variationId, quantity: qt));
      TMTToast.showSuccessToast(context, "Product added in cart.");
      callback.call();
    }
  }

  /*
   Method use for add product to Wishlist.
   Parameter- BuildContext context, WishlistModel wishlistModel.
   Return -> No Return type.
  */
  void addToWishList (BuildContext context, Function (bool isAdded) callback, {required WishlistModel wishlistModel, bool showToast = true}) {

    PostAddToWishlistRequest request = PostAddToWishlistRequest(requestHeader: DioUtils.getRequestHeaderModel(), items: [Item(productId: wishlistModel.productId, variationId: wishlistModel.variationId)]);
    var v = TMTLocalStorage.getWishlistItems().firstWhereOrNull((element) => element.productId == wishlistModel.productId);
    if (v == null) {
      if (TMTLocalStorage.getUserLoggedIn()) {
        NetWorkUtility.isInternetAvailable().then((value) async {
          if (value) {
            const Loading().start(context);
            try {
              var response = await productRepositoryImpl.addToWishList(request);
              response.fold((left) {
                if (left is ServerFailure) {
                  /// show exception
                  TMTToast.showErrorToast(context, left.message ?? '');
                }
              }, (right) {
                if (right.responseHeader.error == null) {
                  if (showToast) {
                    TMTToast.showSuccessToast(context, "Product added to Wishlist.");
                  }
                  TMTLocalStorage.addToWishlist(WishlistModel(productId: wishlistModel.productId, variationId: wishlistModel.variationId, isLiked: true, variation: wishlistModel.variation));
                  TMTToast.showSuccessToast(context, "Product added to Wishlist.");
                  callback.call(true);
                  update([GetControllerBuilders.dashboardController]);
                } else {
                  if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                    TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                    TMTLocalStorage.clear();
                    Get.offAllNamed(AppRoutes.dashBoardScreen);
                  } else {
                    TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
                  }
                }
              });

            } catch (error) {
              TMTToast.showErrorToast(context, error.toString());
              if (kDebugMode) {
                print(error);
              }
            } finally {
              Loading.stop();
            }
          }
          else {
            /// No internet connection dialog
          }
        });
      } else {
        TMTLocalStorage.addToWishlist(WishlistModel(productId: wishlistModel.productId, variationId: wishlistModel.variationId, isLiked: true, variation: wishlistModel.variation));
        TMTToast.showSuccessToast(context, "Product added to Wishlist.");
        callback.call(true);
      }
    } else {
      if (TMTLocalStorage.getUserLoggedIn()) {
        NetWorkUtility.isInternetAvailable().then((value) async {
          if (value) {
            const Loading().start(context);
            try {
              var response = await productRepositoryImpl.removeFromWishList(wishlistModel.variationId.toString());
              response.fold((left) {
                if (left is ServerFailure) {
                  /// show exception
                  TMTToast.showErrorToast(context, left.message ?? '');
                }
              }, (right) {
                if (right.error == null) {
                  TMTLocalStorage.removeFromWishlist(WishlistModel(productId: wishlistModel.productId, variationId: wishlistModel.variationId, isLiked: true, variation: wishlistModel.variation));
                  callback.call(false);
                  TMTToast.showSuccessToast(context, right.message);
                } else {
                  if (right.error?.messages.first == "Invalid Access Token" || right.error?.messages.first == "Please Provide User Token or Cart Items.") {
                    TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                    TMTLocalStorage.clear();
                    Get.offAllNamed(AppRoutes.dashBoardScreen);
                  } else {
                    TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
                  }
                }
              });

            } catch (error) {
              TMTToast.showErrorToast(context, error.toString());
              if (kDebugMode) {
                print(error);
              }
            } finally {
              Loading.stop();
            }
          }
          else {
            /// No internet connection dialog
          }
        });
      } else {
        TMTLocalStorage.removeFromWishlist(WishlistModel(productId: wishlistModel.productId, variationId: wishlistModel.variationId, isLiked: true, variation: wishlistModel.variation));
        callback.call(false);
      }
    }
  }

  /*
   Method use for add bulk product to Wishlist.
   Parameter- BuildContext context, Function callback, List<Item> items.
   Return -> No Return type.
  */
  void addBulkToWishList (BuildContext context, Function callback, List<Item> items) {

    PostAddToWishlistRequest request = PostAddToWishlistRequest(requestHeader: DioUtils.getRequestHeaderModel(), items: items);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.addToWishList(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              callback.call(true);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get wishlist product.
   Parameter- BuildContext context
   Return -> No Return type.
  */
  void getWishList (BuildContext context, {Function()? callBack}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getWishList();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              serverList = right.data ?? [];
              callBack?.call();
              update([GetControllerBuilders.dashboardController]);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get news letter status.
   Parameter- BuildContext context
   Return -> No Return type.
  */
  void getNewsLetterStatus (BuildContext context, {Function(int? v)? callBack}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getNewsLetterStatus(TMTUtilities.getUserIDFromToken().toString());
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              callBack?.call(right.data);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update news letter status.
   Parameter- BuildContext context
   Return -> No Return type.
  */
  void updateNewsLetterStatus (BuildContext context, bool status, {Function()? callBack}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.postNewsLetterStatus(TMTUtilities.getUserIDFromToken().toString(), status);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              if (status) {
                TMTToast.showSuccessToast(context, "Unsubscribed to news letter.");
              } else {
                TMTToast.showSuccessToast(context, "Subscribed to news letter.");
              }
              callBack?.call();
            } else {
              if (right.error?.messages.first == "Invalid Access Token" || right.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get wishlist product from local database.
   Parameter- BuildContext context
   Return -> No Return type.
  */
  void getLocalWishlistData(BuildContext context) {
    localList = TMTLocalStorage.getWishlistItems().map((e) => WishlistDatum(createdAt: DateTime.now(), updatedAt: DateTime.now(), variation: Variation(id: e.variationId, salePrice: e.variation?.salePrice ?? 0, maxRetailPrice: e.variation?.maxRetailPrice ?? 0, weightInPound: e.variation?.weightInPound ?? 0, productImages: e.variation?.productImages ?? [], product: e.variation?.product ?? WishlistProduct(id: e.productId, title: "", description: "", sellerStore: WishlistSellerStore(id: 0))))).toList();
    localList.removeWhere((element) => element.variation.id == 0 && element.variation.product.id == 0);
  }

  /*
   Method use to remove wishlist product.
   Parameter- BuildContext context, String variationId.
   Return -> No Return type.
  */
  void removeFromWishList (BuildContext context, String variationId, int productId, Function callback) {
    if (!TMTLocalStorage.getUserLoggedIn()) {
      TMTLocalStorage.removeFromWishlist(WishlistModel(productId: productId, variationId: int.parse(variationId), variation: Variation(id: int.parse(variationId), salePrice: 0, maxRetailPrice: 0, weightInPound: 0, productImages: [], product: WishlistProduct(id: productId, title: "", description: "", sellerStore: WishlistSellerStore(id: 0)))));
      callback.call();
     return;
    }

    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.removeFromWishList(variationId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              TMTLocalStorage.removeFromWishlist(WishlistModel(productId: productId, variationId: int.parse(variationId), variation: Variation(id: int.parse(variationId), salePrice: 0, maxRetailPrice: 0, weightInPound: 0, productImages: [], product: WishlistProduct(id: productId, title: "", description: "", sellerStore: WishlistSellerStore(id: 0)))));
              callback.call();
              TMTToast.showSuccessToast(context, right.message);
            } else {
              if (right.error?.messages.first == "Invalid Access Token" || right.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }


  /// get seller registration status
  void getSellerRegisterStatus(BuildContext context, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await authRepositoryImpl.getSellerRegisterStatus();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.status == "SUCCESS") {
              isStatus = right.sellerState?.state ?? '';
              TMTLocalStorage.saveSellerId(right.sellerState?.storeId ?? 0);
              TMTLocalStorage.saveSellerStatus(isStatus);
              callback.call();
            } else {
              TMTLocalStorage.clear();
              Get.offAllNamed(AppRoutes.dashBoardScreen);
            }
          });
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// resend OTP by storeId
  void resendOtp(BuildContext context, String storeId, Function() callback) {
    var request = PostResendSellerRegistrationOtpRequest(
      requestHeader: DioUtils.getRequestHeaderModel(),
      storeId: storeId,
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await authRepositoryImpl.resendSellerOTP(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              TMTToast.showSuccessToast(context, right.message);
              callback.call();
            } else {
              TMTToast.showErrorToast(
                  context, right.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      } else {
        /// No internet connection dialog
      }
    });
  }

  /// Method used to get locally sav
  List<Item> _getLocalWishlistItems() {
    List<Item> localItems = [];
    TMTLocalStorage.getWishlistItems().forEach((element) {
      localItems.add(Item(productId: element.productId, variationId: element.variationId));
    });
    return localItems;
  }

  /*
   Method use to logout user.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void postLogoutUser (BuildContext context) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await authRepositoryImpl.logout();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              TMTLocalStorage.clear();
             Get.offAllNamed(AppRoutes.dashBoardScreen);
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// get buyer profile
  void getBuyerProfile(BuildContext context, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getBuyerUserProfile();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.status == "SUCCESS") {
              buyerData = right.data;
              callback.call();
              update();
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// update buyer profile
  void updateBuyerProfile(BuildContext context, PutUpdateProfileRequest request, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.updateBuyerProfile(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.status == "SUCCESS") {
              TMTToast.showSuccessToast(context, right.message ?? '');
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first.toString() ?? "");
            }
          });
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// get buyer profile picture
  void updateBuyerProfilePicture(BuildContext context, PutUpdateProfilePictureRequest request, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.updateBuyerProfilePicture(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.status == "SUCCESS") {
              TMTToast.showSuccessToast(context, right.message ?? '');
              getBuyerProfile(context, (){
                callback.call();
              });
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first.toString() ?? "");
            }
          });
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// get buyer profile
  void updateBuyerPassword(BuildContext context, UpdateBuyerPasswordRequest request, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.updateBuyerPasswordRequest(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.status == "SUCCESS") {
              TMTToast.showSuccessToast(context, right.message ?? '');
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first.toString() ?? "");
            }
          });
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// get buyer profile
  void updateSellerPassword(BuildContext context, UpdateBuyerPasswordRequest request, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.updateSellerPasswordRequest(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.status == "SUCCESS") {
              TMTToast.showSuccessToast(context, right.message ?? '');
              callback.call();
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first.toString() ?? "");
            }
          });
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update fcm token.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void putUpdateFcmToken (BuildContext context) {
    if (TMTLocalStorage.getFcm().isEmpty) {
      return;
    }
    if (TMTUtilities.getUserIDFromToken() == -1) {
      return;
    }
    var params = PutUpdateFcmTokenRequest(requestHeader: DioUtils.getRequestHeaderModel(), fcmToken: TMTLocalStorage.getFcm(), userId: TMTUtilities.getUserIDFromToken().toString());
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        try {
          var response = await dashboardRepositoryImpl.putUpdateFcmToken(params);
          response.fold((left) {
            if (left is ServerFailure) {
              print("FCM update error: ${left.message ?? ''}");
            }
          }, (right) {
            if (right.error == null) {
              print("FCM updated !!!");
            } else {
              print("FCM update error: ${right.error?.messages.first.toString() ?? ''}");
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get updated token.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getUpdatedToken(BuildContext context, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await authRepositoryImpl.getUpdateToken();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.token.jwtToken.isNotEmpty) {
              TMTLocalStorage.clear();
              TMTLocalStorage.save(
                  GetXStorageConstants.jwtToken, right.token.jwtToken);
              TMTLocalStorage.save(GetXStorageConstants.loggedInTime,
                  DateTime.now().millisecondsSinceEpoch);
              TMTLocalStorage.save(GetXStorageConstants.login, true);
              TMTLocalStorage.save(
                  GetXStorageConstants.rememberMe, true);
              TMTLocalStorage.save(GetXStorageConstants.userType,
                  TMTUtilities.getUserRoleFromToken());

              callback.call();

            } else {
              TMTToast.showErrorToast(context, right.responseHeader.message ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get countries list.
   Parameter- BuildContext context
   Return -> No Return type.
  */
  void getCountriesList (BuildContext context, Function(List<Country>? countries) callBack) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getCountriesList();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              callBack.call(right.countries);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get seller list.
   Parameter- BuildContext context
   Return -> No Return type.
  */
  void getSellerList (BuildContext context, Function(List<SellerData>? sellers) callBack) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getSellerList();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              callBack.call(right.data);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get seller list.
   Parameter- BuildContext context
   Return -> No Return type.
  */
  void getTopSellerData (BuildContext context, Function(TopSellerData? data) callBack) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getTopSellerList();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              callBack.call(right.data);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get brand list.
   Parameter- BuildContext context
   Return -> No Return type.
  */
  void getBrandList (BuildContext context, Function(List<BrandData>? brands) callBack) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getBrandList();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              callBack.call(right.data);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// get seller registration status
  void getSubscribedPlansStatus(BuildContext context, Function(PlanList? data) callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _sellerRepositoryImpl.getSubscribedPlansStatus();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) async {
            if (right.responseHeader?.status == "SUCCESS") {
              callback.call(right.planList);
            }
          });
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to delete user account.
   Parameter- BuildContext context, Function callBack
   Return -> No Return type.
  */
  void deleteUserAccount (BuildContext context, Function callBack) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.deleteAccount();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              TMTToast.showSuccessToast(context, right.message);
              callBack.call();
            } else {
              if (right.error?.messages.first == "Invalid Access Token" || right.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// show confirmation dialog for delete account
  void showDeleteConfirmationDialog(BuildContext context) {
    showDialog(context: context, builder: (c){
      return AlertDialog(
        contentPadding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_20, right: WidthDimension.w_20, bottom: HeightDimension.h_20),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_10))),
        content: TMTTextWidget(title: "Are you sure you want to delete your account?", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_16, fontWeight: FontWeight.w700, color: AppColor.neutral_800),),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.green),
                ),
                child: TMTTextWidget(title: 'Cancel' , style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.of(context).pop(false); // Return false when cancelled
                },
              ),
              HorizontalSpacing(WidthDimension.w_8),
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.primaryBG),
                ),
                child: TMTTextWidget(title: 'Delete', style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.pop(context);
                  deleteUserAccount(context, (){
                    TMTLocalStorage.clear();
                    selectedNavItemIndex = AppRoutesIdentifiers.homeScreen;
                    selectedPageIndex = AppRoutesIdentifiers.homeScreen;
                    Get.offAllNamed(AppRoutes.dashBoardScreen);
                  });
                },
              ),
              HorizontalSpacing(WidthDimension.w_10),
            ],
          ),
        ],
        actionsPadding: EdgeInsets.only(bottom: HeightDimension.h_10),
      );
    });
  }

  /*
   Method use to get address by post code.
   Parameter- BuildContext context, Function callBack
   Return -> No Return type.
  */
  void getCompleteAddressByPostCode (BuildContext context, Function (List<PostCodeAddress> data) callBack, String postCode) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getAddressByPostCode(postCode);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              callBack.call(right.data ?? []);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}