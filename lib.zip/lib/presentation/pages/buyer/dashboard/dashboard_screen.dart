import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/cart/cart_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/sub_category_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/home/home_page.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/my_orders_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/product_detail/product_detail_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/support_ticket/support_tickets_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/user_profile/user_profile_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/wishlist/wishlist_screen.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/utils/double_back_to_close_app.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';

class DashBoardScreen extends StatefulWidget {
  const DashBoardScreen({super.key});

  @override
  State<StatefulWidget> createState() => _DashBoardScreenState();
}

class _DashBoardScreenState extends State<DashBoardScreen> {

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  var cameFromSellerListing = Get.arguments ?? -1;

  @override
  void initState() {
    Get.put(CategoryController());
    _dashboardController.putUpdateFcmToken(context);

    try {
      if (cameFromSellerListing != -1) {
        _dashboardController.selectedPageIndex = cameFromSellerListing;
        _dashboardController.selectedNavItemIndex = cameFromSellerListing;
      }
    } catch (e) {
      _dashboardController.selectedPageIndex = 0;
      _dashboardController.selectedNavItemIndex = 0;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<DashboardController>(
        id: GetControllerBuilders.dashboardController,
        init: _dashboardController,
        builder: (controller) {
          return Scaffold(
            body: DoubleBackToCloseApp(snackBar: const SnackBar(
              content: Text('Tap back again to leave'),
            ),
                callBack: () {
                  if ((_dashboardController.selectedPageIndex ==
                      AppRoutesIdentifiers.subCategoryScreen &&
                      _dashboardController.selectedNavItemIndex ==
                          AppRoutesIdentifiers.categoryScreen)) {
                    _dashboardController.changeSelectedPage(
                        pageIndex: AppRoutesIdentifiers.categoryScreen,
                        navBarItemIndex: AppRoutesIdentifiers.categoryScreen);
                  } else if ((_dashboardController.selectedPageIndex ==
                      AppRoutesIdentifiers.supportTicketScreen &&
                      _dashboardController.selectedNavItemIndex ==
                          AppRoutesIdentifiers.userProfileScreen)) {
                    _dashboardController.changeSelectedPage(
                        pageIndex: AppRoutesIdentifiers.userProfileScreen,
                        navBarItemIndex: AppRoutesIdentifiers.userProfileScreen);
                  } else {
                    _dashboardController.changeSelectedPage(
                        pageIndex: AppRoutesIdentifiers.homeScreen,
                        navBarItemIndex: AppRoutesIdentifiers.homeScreen);
                  }
                },
                isAtHomeScreen: (_dashboardController.selectedNavItemIndex !=
                    AppRoutesIdentifiers.homeScreen),
                child: _getPage(_dashboardController.selectedPageIndex)),
            bottomNavigationBar: CommonBottomNavigationBar(
                currentSelectedItem: _dashboardController.selectedNavItemIndex,
                onTap: (index) {
                  _dashboardController.changeSelectedPage(
                      pageIndex: index, navBarItemIndex: index);
                }),
          );
        });
  }

  /// Get selected page by selectedPageIndex
  Widget _getPage(int selectedPageIndex) {
    switch (selectedPageIndex) {
      case AppRoutesIdentifiers.homeScreen:
        return const HomePage();
      case AppRoutesIdentifiers.categoryScreen:
        return const CategoryScreen();
      case AppRoutesIdentifiers.wishListScreen:
        return const WishListScreen();
      case AppRoutesIdentifiers.cartScreen:
        return const CartScreen();
      case AppRoutesIdentifiers.userProfileScreen:
        return const UserProfileScreen();
      case AppRoutesIdentifiers.subCategoryScreen:
        return const SubCategoryScreen();
      case AppRoutesIdentifiers.productDetailScreen:
        return const ProductDetailScreen();
      case AppRoutesIdentifiers.myOrdersScreen:
        return const MyOrdersScreen();
      case AppRoutesIdentifiers.supportTicketScreen:
        return const SupportTicketsScreen();
      default:
        return const HomePage();
    }
  }
}