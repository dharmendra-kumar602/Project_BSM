import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/firebase/firebase_chat_service.dart';
import 'package:take_my_tack/data/model/response/get_seller_details_response.dart';
import 'package:take_my_tack/presentation/pages/buyer/product_detail/product_detail_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/tmt_media_picker.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_fullscreen_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class EnquiryChatPage extends StatefulWidget {
  const EnquiryChatPage({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _EnquiryChatPageState();
}

class _EnquiryChatPageState extends State<EnquiryChatPage> {

  final TextEditingController _messageController = TextEditingController();

  SellerData? sellerData = Get.arguments;

  FirebaseFirestore firestore = FirebaseFirestore.instance;
  late String groupChatId;
  late DocumentReference documentReference;
  String? lastMessage;
  String? sentAt;
  File? imageFile;
  String? imageUrl;
  ScrollController listScrollController = ScrollController();

  @override
  void initState() {
    if (sellerData?.isBuyer ?? false) {
      groupChatId = 'BUYER_${TMTUtilities.getUserIDFromToken()}-SELLER_${sellerData?.userId}-PID${sellerData?.productId}';
    } else {
      groupChatId = 'BUYER_${sellerData?.userId}-SELLER_${TMTUtilities.getUserIDFromToken()}-PID${sellerData?.productId}';
    }
    getFcm();
    super.initState();
  }

  Future<void> getFcm() async {
    String? token = await FirebaseMessaging.instance.getToken();
    if (kDebugMode) {
      print("FCM token is $token");
    }
    updateChatUserFcmToken(token);

    FirebaseMessaging.instance.onTokenRefresh.listen((fcmToken) {
      updateChatUserFcmToken(fcmToken);
    }).onError((err) {
      // Error getting token.
    });
  }

  void updateChatUserFcmToken(String? token) {
    TMTLocalStorage.saveFcm(token!);
    FirebaseFirestore.instance
        .collection(FirestoreConstants.pathUserCollection)
        .doc(TMTUtilities.getUserIDFromToken().toString())
        .update({'pushToken': token});
  }

  @override
  void dispose() {
    listScrollController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  // Method to scroll the list to the bottom
  void _scrollToBottom() {
    if (listScrollController.hasClients) {
      listScrollController.animateTo(
        listScrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  // Call this method whenever there is a change in the list
  void _onListChanged() {
    // Delay scrolling to the bottom slightly to allow the list to update first
    Future.delayed(const Duration(milliseconds: 1), () {
      _scrollToBottom();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height/8,
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 1,
                blurRadius: 2,
                offset: const Offset(0, 3),
              ),
            ], color: Colors.white),
            child: Padding(
              padding: EdgeInsets.only(bottom: 0, top: HeightDimension.h_35),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(width: 8),
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Row(
                        children: [
                          SizedBox(
                            width: WidthDimension.w_40,
                            height: HeightDimension.h_30,
                            child: Center(
                              child: Image.asset(
                                TMTImages.icBack,
                                color: AppColor.neutral_800,
                                fit: BoxFit.contain,
                                scale: 3.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 4),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ClipOval(
                          child: SizedBox.fromSize(
                            size: const Size.fromRadius(18),
                            child: TMTCachedImage.networkImage(
                              sellerData?.profilePicture ?? "", fit: BoxFit.cover
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: WidthDimension.w_150,
                              child: TMTTextWidget(
                                title: sellerData?.name ?? "",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_14,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () {},
                      child: Theme(
                        data:  Theme.of(context).copyWith(
                          canvasColor: Colors.white,
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton(
                            padding: EdgeInsets.zero,
                            menuMaxHeight: HeightDimension.h_40,
                            icon: const Icon(Icons.more_vert, color: AppColor.neutral_800,),
                            items: <String>[
                              'Delete Chat',
                            ].map<DropdownMenuItem<String>>(
                                    (String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Center(child: TMTTextWidget(title: value, style: TMTFontStyles.text(fontSize: TMTFontSize.sp_12),)),
                                  );
                                }).toList(),
                            onChanged: (value) {
                              if (value == "Delete Chat") {
                                showDeleteAllChatDialog();
                              }
                            },
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              controller: listScrollController,
              child: GestureDetector(
                onTap: () {
                  FocusScope.of(context).unfocus();
                },
                child: StreamBuilder<QuerySnapshot>(
                  stream: firestore
                      .collection(FirestoreConstants.pathMessageCollection)
                      .doc(groupChatId)
                      .collection(groupChatId)
                      .orderBy(FirestoreConstants.timestamp, descending: true)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      final chat = snapshot.data!.docs
                          .map((doc) => ChatModel.fromSnapshot(doc))
                          .toList();

                      return ListView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        reverse: true,
                        itemCount: chat.length,
                        itemBuilder: (context, index) {
                          return chat[index].senderId != TMTUtilities.getUserIDFromToken().toString() ? Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              chat[index].messageType == "Text" ? Container(
                                constraints: BoxConstraints(maxWidth: WidthDimension.w_185),
                                padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_8, bottom: HeightDimension.h_8),
                                margin: EdgeInsets.only(bottom: HeightDimension.h_10),
                                decoration: const BoxDecoration(
                                    color: Color(0xFFFFEAEB),
                                    borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_20))
                                ),
                                child: TMTTextWidget(title: chat[index].message, style: TMTFontStyles.text(), maxLines: 20,),
                              ) :
                              Container(
                                margin: EdgeInsets.only(right: WidthDimension.w_10, bottom: HeightDimension.h_10),
                                child: OutlinedButton(
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => TMTFullScreenImage(
                                          tag: 'imgHero',
                                          img: chat[index].message,
                                        ),
                                      ),
                                    );
                                  },
                                  style: ButtonStyle(
                                      padding:
                                      MaterialStateProperty.all<EdgeInsets>(
                                          const EdgeInsets.all(0))),
                                  child: Material(
                                    borderRadius:
                                    const BorderRadius.all(Radius.circular(8)),
                                    clipBehavior: Clip.hardEdge,
                                    child: Hero(
                                      tag: "imgHero",
                                      child: SizedBox(
                                        height: 200,
                                        width: 200,
                                        child: TMTCachedImage.networkImage(
                                            chat[index].message, fit: BoxFit.cover
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ) : Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              chat[index].messageType == "Text" ? Container(
                                constraints: BoxConstraints(maxWidth: WidthDimension.w_185),
                                padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_8, bottom: HeightDimension.h_8),
                                margin: EdgeInsets.only(bottom: HeightDimension.h_10),
                                decoration: const BoxDecoration(
                                    color: Color(0xFFED2024),
                                    borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_25))
                                ),
                                child: TMTTextWidget(title: chat[index].message, style: TMTFontStyles.text(color: AppColor.neutral_100), maxLines: 20),
                              ) : Container(
                                margin: EdgeInsets.only(right: WidthDimension.w_10, bottom: HeightDimension.h_10),
                                child: OutlinedButton(
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => TMTFullScreenImage(
                                          tag: 'imgHero',
                                          img: chat[index].message,
                                        ),
                                      ),
                                    );
                                  },
                                  style: ButtonStyle(
                                      padding:
                                      MaterialStateProperty.all<EdgeInsets>(
                                          const EdgeInsets.all(0))),
                                  child: Material(
                                    borderRadius:
                                    const BorderRadius.all(Radius.circular(8)),
                                    clipBehavior: Clip.hardEdge,
                                    child: Hero(
                                      tag: "imgHero",
                                      child: SizedBox(
                                        height: 200,
                                        width: 200,
                                        child: TMTCachedImage.networkImage(
                                          chat[index].message, fit: BoxFit.cover
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          );
                        },
                        padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_10, bottom: HeightDimension.h_10),
                      );
                    } else if (snapshot.hasError) {
                      return Text('Error: ${snapshot.error}');
                    } else {
                      return const Center(child: CircularProgressIndicator());
                    }
                  },
                ),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(bottom: HeightDimension.h_15, top: HeightDimension.h_10,),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: (){
                    showDialog(
                      context: context,
                      builder: (c) => SimpleDialog(
                        contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, top: HeightDimension.h_8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        titlePadding: EdgeInsets.only(top: HeightDimension.h_10, left: WidthDimension.w_20, right: WidthDimension.w_20),
                        title: const Text('Select Image'),
                        children: <Widget>[
                          SimpleDialogOption(
                            onPressed: () async {
                              Navigator.pop(context);
                              XFile? pickedFile = await TMTMediaPicker(context).pickImageFromCamera(imageQuality: 40);
                              if (pickedFile != null) {
                                var v = await TMTUtilities.isFileBiggerThan1MB(pickedFile);
                                if (v) {
                                  if (!mounted) return;
                                  TMTToast.showErrorToast(context, "Image size must be less than 2MB.");
                                  return;
                                }
                                imageFile = File(pickedFile.path);
                                if(imageFile != null) {
                                  if (!mounted) return;
                                  const Loading().start(context);
                                  uploadFile();
                                }
                              }
                            },
                            child: const Text('Camera'),
                          ),
                          SimpleDialogOption(
                            onPressed: () async {
                              Navigator.pop(context);
                              XFile? pickedFile = await TMTMediaPicker(context).pickImageFromGallery(imageQuality: 40);
                              if (pickedFile != null) {
                                var v = await TMTUtilities.isFileBiggerThan1MB(pickedFile);
                                if (v) {
                                  if (!mounted) return;
                                  TMTToast.showErrorToast(context, "Image size must be less than 2MB.");
                                  return;
                                }
                                imageFile = File(pickedFile.path);
                                if (imageFile != null) {
                                  if (!mounted) return;
                                  const Loading().start(context);
                                  uploadFile();
                                }
                              }
                            },
                            child: const Text('Gallery'),
                          ),
                        ],
                      ),
                    );
                  },
                  child: Container(
                    margin: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_5),
                    height: HeightDimension.h_32,
                    width: HeightDimension.h_32,
                    child: Image.asset(TMTImages.icAddBlackBg, color: AppColor.textColor,),
                  ),
                ),
                Expanded(
                  child: TMTRoundedCornersContainer(
                    borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_30)),
                    margin: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_15),
                    bgColor: AppColor.neutral_100,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 3,
                        offset: const Offset(0, 3), // changes position of shadow
                      ),
                    ],
                    padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_10, bottom: HeightDimension.h_10),
                    child: Row(children: [
                      Expanded(child: TextField(style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14), decoration: const InputDecoration.collapsed(hintText: "Type a message"), maxLines: 4, minLines: 1, controller: _messageController, onSubmitted: (v){_sendMessage();}, onChanged: (v){
                        _onListChanged();
                      },)),
                      HorizontalSpacing(WidthDimension.w_8),
                      GestureDetector(
                        onTap: (){
                          _sendMessage();
                        },
                        child: SizedBox(
                          height: HeightDimension.h_18,
                          width: HeightDimension.h_18,
                          child: Image.asset(TMTImages.icSendRed),
                        ),
                      )
                    ],),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  ///Upload image on firebase storage
  Future uploadFile() async {
    String fileName = DateTime.now().millisecondsSinceEpoch.toString();
    UploadTask uploadTask = FirebaseChatService.uploadChatFile(imageFile!, fileName, groupChatId);
    try {
      TaskSnapshot snapshot = await uploadTask;
      imageUrl = await snapshot.ref.getDownloadURL();
        if (!mounted) return;
        Loading.stop();
      _onListChanged();
        _sendMessage(hasImage: true);
    } on FirebaseException catch (e) {
      if (!mounted) return;
      Loading.stop();
    }
  }

  /// send message
  void _sendMessage({bool hasImage = false}) {
    documentReference = firestore
        .collection(FirestoreConstants.pathMessageCollection)
        .doc(groupChatId)
        .collection(groupChatId)
        .doc(DateTime.now().millisecondsSinceEpoch.toString());

    var message = _messageController.text.toString();
    var messageType = hasImage ? "Image" : "Text";

    if (!hasImage) {
      if (message.isEmpty) {
        return;
      }
    }

    ChatModel chatModel;
    if (hasImage) {
      chatModel = ChatModel(senderId: TMTUtilities.getUserIDFromToken().toString(), receiverId: sellerData!.userId.toString(), timestamp: DateTime.now().millisecondsSinceEpoch.toString(), senderName: TMTUtilities.getUserNameFromToken(), message: imageUrl!, messageType: messageType, id: "PID${sellerData?.productId}", profilePicture: sellerData?.profilePicture ?? "", sender: (sellerData?.isBuyer ?? false) ? UserType.buyer : UserType.seller);
    } else {
      chatModel = ChatModel(senderId: TMTUtilities.getUserIDFromToken().toString(), receiverId: sellerData!.userId.toString(), timestamp: DateTime.now().millisecondsSinceEpoch.toString(), senderName: TMTUtilities.getUserNameFromToken(), message: message, messageType: messageType, id: "PID${sellerData?.productId}", profilePicture: sellerData?.profilePicture ?? "", sender: (sellerData?.isBuyer ?? false) ? UserType.buyer : UserType.seller);
    }
      firestore.runTransaction((transaction) async {
        transaction.set(
          documentReference,
          chatModel.toJson(),
        );
      }).onError((error, stackTrace) {
       print(error);
      }).whenComplete(() {
        setState(() {
          sentAt = DateTime.now().millisecondsSinceEpoch.toString();
          var m = message;
          if (imageUrl != null || m.contains("firebasestorage.googleapis")) {
            m = "Image";
          }
          _onListChanged();
          _saveUser(m);
          imageUrl = null;
        });
      });
      _messageController.clear();
  }

  void _saveUser(String message) {
    DocumentReference documentReference =  firestore
        .collection(FirestoreConstants.pathMessageCollection)
        .doc(groupChatId);

    documentReference.get().then((value){
      if(value.exists){
        firestore.runTransaction((transaction) async {
          transaction.update(
              documentReference,
              {
                FirestoreConstants.lastMessage: message,
                FirestoreConstants.sentAt:
                DateTime.now().millisecondsSinceEpoch.toString(),
              }
          );
        });
      } else {
        firestore.runTransaction((transaction) async {
          transaction.set(
              documentReference,
              {
                "senderName": TMTUtilities.getUserNameFromToken(),
                "receiverName": sellerData?.name ?? "",
                FirestoreConstants.photoUrl: "",
                FirestoreConstants.id: TMTUtilities.getUserIDFromToken(),
                'createdAt': DateTime.now().millisecondsSinceEpoch.toString(),
                FirestoreConstants.chattingWith: sellerData?.userId ?? 0,
                FirestoreConstants.lastMessage: message,
                FirestoreConstants.sentAt:
                DateTime.now().millisecondsSinceEpoch.toString(),
                "productId" : "${sellerData?.productId}",
                "productName" : "${sellerData?.productName}",
                "productPrice" : "${sellerData?.productPrice}",
                "productImage" : "${sellerData?.productImage}",
                "groupChatId" : groupChatId,
              }
          );
        });
      }
      _onListChanged();
    });
  }

  /// Delete single chat message
  void showDeleteAllChatDialog() {
    showDialog(context: context, builder: (c){
      return AlertDialog(
        contentPadding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_20, right: WidthDimension.w_20, bottom: HeightDimension.h_20),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_10))),
        content: TMTTextWidget(title: "Do you want to delete all chat?", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_16, fontWeight: FontWeight.w700, color: AppColor.neutral_800),),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.green),
                ),
                child: TMTTextWidget(title: 'Cancel' , style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.of(context).pop(false); // Return false when cancelled
                },
              ),
              HorizontalSpacing(WidthDimension.w_8),
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(AppColor.primaryBG),
                ),
                child: TMTTextWidget(title: 'Delete', style: TMTFontStyles.text(color: AppColor.neutral_100),),
                onPressed: () {
                  Navigator.of(context).pop(false);
                  FirebaseChatService.deleteChatById(groupChatId, (){
                    if (!mounted) return;
                    Navigator.pop(context, true);
                  });
                },
              ),
              HorizontalSpacing(WidthDimension.w_10),
            ],
          ),
        ],
        actionsPadding: EdgeInsets.only(bottom: HeightDimension.h_10),
      );
    });
  }
}

enum UserType {
  buyer,
  seller,
}

class ChatModel {
  final String senderId;
  final String receiverId;
  final String timestamp;
  final String senderName;
  final String message;
  final String messageType;
  final String id;
  final String profilePicture;
  final UserType sender;

  factory ChatModel.fromSnapshot(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ChatModel(
      senderId: data['senderId'], receiverId: data['receiverId'], timestamp: data['timestamp'], senderName: data['senderName'], message: data['message'], messageType: data['messageType'], id: doc.id, profilePicture: data['profilePicture'], sender: data['userType'] == UserType.buyer.toString() ? UserType.buyer : UserType.seller,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'senderId' : senderId,
      'receiverId' : receiverId,
      'timestamp' : timestamp,
      'senderName' : senderName,
      'message' : message,
      'messageType' : messageType,
      'profilePicture' : profilePicture,
      'userType' : UserType.buyer.name.toString(),
    };
  }

  ChatModel({required this.senderId, required this.receiverId, required this.timestamp, required this.senderName, required this.message, required this.messageType, required this.id, required this.profilePicture, required this.sender});
}