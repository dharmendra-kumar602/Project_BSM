import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:take_my_tack/core/model/user_chat.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/firebase/firebase_chat_service.dart';
import 'package:take_my_tack/data/model/response/get_seller_details_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class EnquiryListingScreenPage extends StatefulWidget {
  const EnquiryListingScreenPage({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _EnquiryListingScreenPageState();
}

class _EnquiryListingScreenPageState extends State<EnquiryListingScreenPage> {

  bool isBuyer = Get.arguments ?? true;

  @override
  void initState() {
    var v = TMTUtilities.getUserIDFromToken();
    print(v);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            height: MediaQuery
                .of(context)
                .size
                .height / 8.6,
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 1,
                blurRadius: 2,
                offset: const Offset(0, 3),
              ),
            ], color: Colors.white),
            child: Padding(
              padding: EdgeInsets.only(bottom: 0, top: HeightDimension.h_35),
              child: Align(
                child: Row(
                  children: [
                    const SizedBox(width: 8),
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Row(
                        children: [
                          SizedBox(
                            width: WidthDimension.w_40,
                            height: HeightDimension.h_30,
                            child: Center(
                              child: Image.asset(
                                TMTImages.icBack,
                                color: AppColor.neutral_800,
                                fit: BoxFit.contain,
                                scale: 3.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 4),
                    TMTTextWidget(title: "Enquiries", style: TMTFontStyles.textTeen(
                      fontSize: TMTFontSize.sp_18,
                      color: AppColor.neutral_800,
                      fontWeight: FontWeight.w700,
                    ),),
                    const Spacer(),
                    const SizedBox(width: 20),
                  ],
                ),
              ),
            ),
          ),
          VerticalSpacing(HeightDimension.h_15),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection(FirestoreConstants.pathMessageCollection)
                    .snapshots(),
                builder: (BuildContext context,
                    AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: CircularProgressIndicator(
                        color: Theme.of(context).primaryColor,
                      ),
                    );
                  }
                  if (snapshot.hasData) {
                    if ((snapshot.data?.docs.length ?? 0) > 0) {

                      List<UserChat> sortedResult = [];
                      snapshot.data?.docs.forEach((element) { 
                        if (element.get("groupChatId").toString().contains(isBuyer ? "BUYER_${TMTUtilities.getUserIDFromToken()}" : "-SELLER_${TMTUtilities.getUserIDFromToken()}")) {
                          sortedResult.add(UserChat.fromDocument(element));
                        }
                      });

                      if (sortedResult.isEmpty) {
                        return Padding(
                          padding: EdgeInsets.only(bottom: HeightDimension.h_80),
                          child: const Center(
                            child: TMTTextWidget(title: "No data."),
                          ),
                        );
                      }
                      
                      return ListView.builder(
                        itemBuilder: (context, index){

                          UserChat userChat = sortedResult[index];

                          return GestureDetector(
                            onTap: () async {
                              SellerData args = SellerData(storeId: 0, name: isBuyer ? userChat.receiverName : userChat.senderName, userId: isBuyer ? userChat.chattingWith : userChat.id, description: "", profilePicture: userChat.photoUrl, isBuyer: isBuyer, productId: userChat.productId, productName: userChat.productName, productImage: userChat.productImage, productPrice: userChat.productPrice);
                              var isDeleted = await Get.toNamed(AppRoutes.enquiryChatPage, arguments: args);
                              if (isDeleted ?? false) {
                                FirebaseChatService.removeUser(
                                    snapshot.data?.docs[index], (s) {
                                });
                              }
                            },
                            child: TMTRoundedCornersContainer(
                              borderRadius: BorderRadius.circular(0),
                              padding: EdgeInsets.only(top: HeightDimension.h_10, bottom: HeightDimension.h_10),
                              margin: EdgeInsets.only(bottom: HeightDimension.h_8, top: HeightDimension.h_5),
                              bgColor: AppColor.neutral_100,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  spreadRadius: 1,
                                  blurRadius: 1,
                                  offset: const Offset(0, 1), // changes position of shadow
                                ),
                              ],
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  HorizontalSpacing(WidthDimension.w_20),
                                  SizedBox(
                                    height: HeightDimension.h_70,
                                    width: HeightDimension.h_65,
                                    child: CachedNetworkImage(imageUrl: userChat.productImage, fit: BoxFit.cover,),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_20),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      TMTTextWidget(title: isBuyer ? userChat.receiverName : userChat.senderName, style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_15,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w500,
                                      ),),
                                      SizedBox(
                                        width: WidthDimension.w_150,
                                        child: TMTTextWidget(title: userChat.productName, style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_12,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                        ),),
                                      ),
                                      TMTTextWidget(title: "Price £${userChat.productPrice}", style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w500,
                                      ),),
                                    ],
                                  ),
                                  HorizontalSpacing(WidthDimension.w_20),
                                ],
                              ),
                            ),
                          );
                        },
                        padding: EdgeInsets.zero,
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        itemCount: sortedResult.length,
                      );
                    } else {
                      return Padding(
                        padding: EdgeInsets.only(bottom: HeightDimension.h_80),
                        child: const Center(
                          child: TMTTextWidget(title: "No data."),
                        ),
                      );
                    }
                  }
                  else {
                    return Padding(
                      padding: EdgeInsets.only(bottom: HeightDimension.h_80),
                      child: Center(
                        child: CircularProgressIndicator(
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    );
                  }
              }
            ),
          ),
        ],
      ),
    );
  }
}