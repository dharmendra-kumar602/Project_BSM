import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as sSize;
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/request/post_create_payment_intent_request.dart';
import 'package:take_my_tack/data/model/response/get_buyer_order_detail_response.dart';
import 'package:take_my_tack/data/model/response/get_delivery_address_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_details_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/address/address_screens_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/buyer_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_popup/src/custom_pop_up_menu.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class ConfirmOrderScreen extends StatefulWidget {
  const ConfirmOrderScreen({super.key});

  @override
  State<StatefulWidget> createState() => _ConfirmOrderScreenState();
}

class _ConfirmOrderScreenState extends State<ConfirmOrderScreen> {
  dynamic orderId = Get.arguments;

  final BuyerOrderController _buyerOrderController =
      Get.put(BuyerOrderController());

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  final AddressScreenController _addressScreenController =
  Get.put(AddressScreenController());

  List<AddressData> address = [];

  @override
  void initState() {
   _callApi();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyerOrderController>(
        id: GetControllerBuilders.orderDetailsScreenController,
        init: _buyerOrderController,
        builder: (controller) {
          return TMTBackButton(
            onWillPop: () {
              if (orderId is int) {
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                Get.back();
              }
              return Future.value(false);
            },
            child: Scaffold(
              backgroundColor: AppColor.lightGrey,
              appBar: PreferredSize(
                  preferredSize:
                  sSize.Size.fromHeight(SizeConfig.safeBlockVertical * 9),
                  child: Container(
                    decoration: BoxDecoration(boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 3,
                        offset:
                            const Offset(0, 3), // changes position of shadow
                      ),
                    ], color: AppColor.neutral_100),
                    child: Column(
                      children: [
                        VerticalSpacing(SizeConfig.safeBlockVertical * 7),
                        Row(
                          children: [
                            InkWell(
                              onTap: () {
                                if (orderId is int) {
                                  Get.offAllNamed(AppRoutes.dashBoardScreen);
                                } else {
                                  Get.back();
                                }
                              },
                              child: Row(
                                children: [
                                  HorizontalSpacing(WidthDimension.w_20),
                                  SizedBox(
                                    width: WidthDimension.w_18,
                                    height: HeightDimension.h_15,
                                    child: Image.asset(
                                      TMTImages.icBack,
                                      color: AppColor.neutral_800,
                                    ),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_6),
                                ],
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_6),
                            TMTTextWidget(
                              title: "Order Details",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            const Spacer(),
                            GestureDetector(
                              onTap: () {
                                _checkUserStatus();
                              },
                              child: SizedBox(
                                width: WidthDimension.w_47,
                                height: HeightDimension.h_22,
                                child: Image.asset(
                                  TMTImages.icSell,
                                ),
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_20),
                          ],
                        ),
                        VerticalSpacing(HeightDimension.h_8),
                      ],
                    ),
                  )),
              body: Column(
                children: [
                  Expanded(
                      child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Visibility(
                          visible: (_buyerOrderController.orderDetails?.orderPaymentMappings?.isNotEmpty ?? false) ? _buyerOrderController.orderItemDetails?.orderedItemStatuses?.last.status == "AUTO_CANCELLED"? false : _buyerOrderController.orderDetails?.orderPaymentMappings?.first.paymentStatus != "SUCCEEDED" : false,
                          child: Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.2),
                                    spreadRadius: 2,
                                    blurRadius: 1,
                                    offset: const Offset(2, 0), // changes position of shadow
                                  ),
                                ],
                                color: AppColor.neutral_100,
                                border: Border.all(color: AppColor.neutral_100, width: 0.5)
                            ),
                            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_10, bottom: HeightDimension.h_10),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: TMTTextWidget(title: "Note: Order will be automatically cancelled, if payment is not done within 24 hours.", style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.primary,
                                        fontWeight: FontWeight.w600,
                                      ),),
                                    ),
                                    ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.2),
                                  spreadRadius: 2,
                                  blurRadius: 1,
                                  offset: const Offset(2, 0), // changes position of shadow
                                ),
                              ],
                              color: AppColor.neutral_100,
                              border: Border.all(color: AppColor.neutral_100, width: 0.5)
                          ),
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_20, bottom: HeightDimension.h_20),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TMTTextWidget(title: "Order Date", style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),),
                                  TMTTextWidget(title: DateFormat('dd/MM/yyyy').format(_buyerOrderController.orderDetails?.updatedAt ?? DateTime.now()), style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w500,
                                  ),),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TMTTextWidget(title: "Order ID", style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),),
                                  TMTTextWidget(title: "#${_buyerOrderController.orderDetails?.id ?? ""}", style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w500,
                                  ),),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TMTTextWidget(title: "Order total", style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),),
                                  Row(
                                    children: [
                                      TMTTextWidget(title: "(${_buyerOrderController.getTotalItemsCount()} ${_buyerOrderController
                                          .getTotalItemsCount() <=
                                          1
                                          ? "Item"
                                          : "Items"})", style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_15,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w500,
                                      ),),
                                      HorizontalSpacing(WidthDimension.w_6),
                                      TMTTextWidget(title: _buyerOrderController.getTotalSumAmount(), style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_15,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w500,
                                      ),),
                                    ],
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TMTTextWidget(title: "Payment method", style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),),
                                  TMTTextWidget(title: "ONLINE", style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w500,
                                  ),),
                                ],
                              ),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_5),
                        ListView.builder(
                          itemBuilder: (context, index) {
                            var element = _buyerOrderController
                                .orderDetails?.sellers?[index];
                            return element?.orders?.first.shippingMethod ==
                                    "DELIVERY"
                                ? Container(
                                    margin: EdgeInsets.only(
                                        bottom: HeightDimension.h_10),
                                    decoration: BoxDecoration(
                                        color: AppColor.neutral_100,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.grey.withOpacity(0.2),
                                            spreadRadius: 2,
                                            blurRadius: 3,
                                            offset: const Offset(0,
                                                3), // changes position of shadow
                                          ),
                                        ]),
                                    width: double.infinity,
                                    child: Column(
                                      children: [
                                        Container(
                                          child: Column(
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    left: WidthDimension.w_15,
                                                    right: WidthDimension.w_15,
                                                    top: HeightDimension.h_15,
                                                    bottom:
                                                        HeightDimension.h_15),
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: TMTTextWidget(
                                                        title: element
                                                                ?.seller?.name ??
                                                            "",
                                                        style: TMTFontStyles
                                                            .textTeen(
                                                          fontSize:
                                                              TMTFontSize.sp_16,
                                                          color: AppColor
                                                              .neutral_800,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                width: double.infinity,
                                                padding: EdgeInsets.only(
                                                    top: HeightDimension.h_20,
                                                    bottom:
                                                        HeightDimension.h_20,
                                                    left: WidthDimension.w_15,
                                                    right: WidthDimension.w_15),
                                                color: AppColor.neutral_300,
                                                child: ListView.builder(
                                                  itemBuilder:
                                                      (context, orderIndex) {
                                                    var order = element
                                                        ?.orders?[orderIndex];
                                                    return Padding(
                                                      padding: EdgeInsets.only(
                                                          top: HeightDimension
                                                              .h_5,
                                                          bottom:
                                                              HeightDimension
                                                                  .h_5),
                                                      child: Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        TMTRadius
                                                                            .r_10),
                                                            // Image border
                                                            child: SizedBox(
                                                              height:
                                                                  HeightDimension
                                                                      .h_75,
                                                              width:
                                                                  HeightDimension
                                                                      .h_70,
                                                              child: TMTCachedImage
                                                                  .networkImage(
                                                                      order?.productImage ??
                                                                          "",
                                                                      fit: BoxFit
                                                                          .cover),
                                                            ),
                                                          ),
                                                          HorizontalSpacing(
                                                              WidthDimension
                                                                  .w_15),
                                                          Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                TMTTextWidget(
                                                                  title: order
                                                                          ?.productName ??
                                                                      "",
                                                                  style:
                                                                      TMTFontStyles
                                                                          .text(
                                                                    fontSize:
                                                                        TMTFontSize
                                                                            .sp_14,
                                                                    color: AppColor
                                                                        .neutral_800,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                                Visibility(
                                                                  visible: order
                                                                          ?.productDescription
                                                                          ?.isNotEmpty ??
                                                                      false,
                                                                  child:
                                                                      TMTTextWidget(
                                                                    title: order
                                                                            ?.productDescription ??
                                                                        "",
                                                                    style:
                                                                        TMTFontStyles
                                                                            .text(
                                                                      fontSize:
                                                                          TMTFontSize
                                                                              .sp_12,
                                                                      color: AppColor
                                                                          .textColor,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                    ),
                                                                  ),
                                                                ),
                                                                TMTTextWidget(
                                                                  title:
                                                                  (order?.productDetailsInJson?.sizes?.isNotEmpty ?? false) ? "Size: ${order?.productDetailsInJson?.sizes?.first.attributes?.size ?? "M"}" : "Size: M",
                                                                  style:
                                                                      TMTFontStyles
                                                                          .text(
                                                                    fontSize:
                                                                        TMTFontSize
                                                                            .sp_12,
                                                                    color: AppColor
                                                                        .textColor,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                                TMTTextWidget(
                                                                  title:
                                                                      "Quantity: ${order?.quantity ?? ""}",
                                                                  style:
                                                                      TMTFontStyles
                                                                          .text(
                                                                    fontSize:
                                                                        TMTFontSize
                                                                            .sp_12,
                                                                    color: AppColor
                                                                        .textColor,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          HorizontalSpacing(
                                                              WidthDimension
                                                                  .w_10),
                                                          TMTTextWidget(
                                                            title:
                                                                "£${((order?.salePrice ?? 0) * (order?.quantity ?? 1)).toStringAsFixed(2)}",
                                                            style: TMTFontStyles
                                                                .text(
                                                              fontSize:
                                                                  TMTFontSize
                                                                      .sp_14,
                                                              color: AppColor
                                                                  .neutral_800,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                  shrinkWrap: true,
                                                  itemCount:
                                                      element?.orders?.length ??
                                                          0,
                                                  scrollDirection:
                                                      Axis.vertical,
                                                  physics:
                                                      const NeverScrollableScrollPhysics(),
                                                  padding:
                                                      const EdgeInsets.only(),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.only(
                                              left: WidthDimension.w_20,
                                              right: WidthDimension.w_20,
                                              top: HeightDimension.h_15,
                                              bottom: HeightDimension.h_10),
                                          color: AppColor.neutral_100,
                                          child: Column(
                                            children: [
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  SizedBox(
                                                    width: HeightDimension.h_15,
                                                    height:
                                                        HeightDimension.h_20,
                                                    child: Image.asset(TMTImages
                                                        .icDropLocation),
                                                  ),
                                                  HorizontalSpacing(
                                                      WidthDimension.w_10),
                                                  Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      TMTTextWidget(
                                                        title:
                                                            "Delivery address",
                                                        style: TMTFontStyles
                                                            .textTeen(
                                                          fontSize:
                                                              TMTFontSize.sp_16,
                                                          color: AppColor
                                                              .neutral_800,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                      ),
                                                      Visibility(
                                                        visible: element
                                                            ?.orders
                                                            ?.first
                                                            .productDetailsInJson
                                                            ?.deliveryAddress
                                                            ?.firstName?.isNotEmpty ?? false,
                                                        child: VerticalSpacing(
                                                            HeightDimension.h_15),
                                                      ),
                                                      Visibility(
                                                        visible: element
                                                            ?.orders
                                                            ?.first
                                                            .productDetailsInJson
                                                            ?.deliveryAddress
                                                            ?.firstName?.isNotEmpty ?? false,
                                                        child: TMTTextWidget(
                                                          title: element
                                                                  ?.orders
                                                                  ?.first
                                                                  .productDetailsInJson
                                                                  ?.deliveryAddress
                                                                  ?.firstName ??
                                                              "",
                                                          style: TMTFontStyles
                                                              .textTeen(
                                                            fontSize:
                                                                TMTFontSize.sp_16,
                                                            color: AppColor
                                                                .textColor,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                          ),
                                                        ),
                                                      ),
                                                      VerticalSpacing(
                                                          HeightDimension.h_5),
                                                      TMTTextWidget(
                                                        title:
                                                            "${element?.orders?.first.productDetailsInJson?.deliveryAddress?.address1 ?? ""} ${element?.orders?.first.productDetailsInJson?.deliveryAddress?.city ?? ""}",
                                                        style:
                                                            TMTFontStyles.text(
                                                          fontSize:
                                                              TMTFontSize.sp_14,
                                                          color: AppColor
                                                              .textColor,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                        ),
                                                      ),
                                                      TMTTextWidget(
                                                        title:
                                                            "${element?.orders?.first.productDetailsInJson?.deliveryAddress?.country ?? ""}, ${element?.orders?.first.productDetailsInJson?.deliveryAddress?.postCode ?? ""}",
                                                        style:
                                                            TMTFontStyles.text(
                                                          fontSize:
                                                              TMTFontSize.sp_14,
                                                          color: AppColor
                                                              .textColor,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                        ),
                                                      ),
                                                      VerticalSpacing(
                                                          HeightDimension.h_5),
                                                      Visibility(
                                                        visible: element
                                                                ?.orders
                                                                ?.first
                                                                .productDetailsInJson
                                                                ?.deliveryAddress
                                                                ?.phoneNumber
                                                                ?.isNotEmpty ??
                                                            false,
                                                        child: Row(
                                                          children: [
                                                            TMTTextWidget(
                                                              title:
                                                                  "Phone number - ",
                                                              style:
                                                                  TMTFontStyles
                                                                      .text(
                                                                fontSize:
                                                                    TMTFontSize
                                                                        .sp_14,
                                                                color: AppColor
                                                                    .textColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                              ),
                                                            ),
                                                            TMTTextWidget(
                                                              title: element
                                                                      ?.orders
                                                                      ?.first
                                                                      .productDetailsInJson
                                                                      ?.deliveryAddress
                                                                      ?.phoneNumber ??
                                                                  "",
                                                              style:
                                                                  TMTFontStyles
                                                                      .text(
                                                                fontSize:
                                                                    TMTFontSize
                                                                        .sp_14,
                                                                color: AppColor
                                                                    .textColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(width: double.infinity, height: 2, color: AppColor.dividerColor,),
                                        Visibility(
                                          visible: element?.orders?.first.orderedItemStatuses?.last.status == "AUTO_CANCELLED" ? true : _buyerOrderController.orderDetails?.orderPaymentMappings?.first.paymentStatus == "SUCCEEDED",
                                            child: _buyerOrderController.getTrackingWidget(true, element?.orders?.first.orderedItemStatuses, CancelGetModel(orderId: (orderId is List) ? orderId.first : orderId, sellerId: element?.orders?.first.sellerStoreId ?? 0), ReturnGetModel(orderId: (orderId is List) ? orderId.first : orderId, sellerId: element?.orders?.first.sellerStoreId ?? 0))),
                                        _invoiceButton(element?.seller, element?.orders?.first),
                                      ],
                                    ),
                                  )
                                : Container(
                                    margin: EdgeInsets.only(
                                        bottom: HeightDimension.h_10),
                                    decoration: BoxDecoration(
                                        color: AppColor.neutral_100,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.grey.withOpacity(0.2),
                                            spreadRadius: 2,
                                            blurRadius: 3,
                                            offset: const Offset(0,
                                                3), // changes position of shadow
                                          ),
                                        ]),
                                    width: double.infinity,
                                    child: Column(
                                      children: [
                                        Container(
                                          child: Column(
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    left: WidthDimension.w_15,
                                                    right: WidthDimension.w_15,
                                                    top: HeightDimension.h_15,
                                                    bottom:
                                                        HeightDimension.h_15),
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: TMTTextWidget(
                                                        title: element
                                                                ?.seller?.name ??
                                                            "",
                                                        style: TMTFontStyles
                                                            .textTeen(
                                                          fontSize:
                                                              TMTFontSize.sp_16,
                                                          color: AppColor
                                                              .neutral_800,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                width: double.infinity,
                                                padding: EdgeInsets.only(
                                                    top: HeightDimension.h_20,
                                                    bottom:
                                                        HeightDimension.h_20,
                                                    left: WidthDimension.w_15,
                                                    right: WidthDimension.w_15),
                                                color: AppColor.neutral_300,
                                                child: ListView.builder(
                                                  itemBuilder:
                                                      (context, orderIndex) {
                                                    var order = element
                                                        ?.orders?[orderIndex];
                                                    return Padding(
                                                      padding: EdgeInsets.only(
                                                          top: HeightDimension
                                                              .h_5,
                                                          bottom:
                                                              HeightDimension
                                                                  .h_5),
                                                      child: Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        TMTRadius
                                                                            .r_10),
                                                            // Image border
                                                            child: SizedBox(
                                                              height:
                                                                  HeightDimension
                                                                      .h_75,
                                                              width:
                                                                  HeightDimension
                                                                      .h_70,
                                                              child: TMTCachedImage
                                                                  .networkImage(
                                                                      order?.productImage ??
                                                                          "",
                                                                      fit: BoxFit
                                                                          .cover),
                                                            ),
                                                          ),
                                                          HorizontalSpacing(
                                                              WidthDimension
                                                                  .w_15),
                                                          Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                TMTTextWidget(
                                                                  title: order
                                                                          ?.productName ??
                                                                      "",
                                                                  style:
                                                                      TMTFontStyles
                                                                          .text(
                                                                    fontSize:
                                                                        TMTFontSize
                                                                            .sp_14,
                                                                    color: AppColor
                                                                        .neutral_800,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                                Visibility(
                                                                  visible: order
                                                                          ?.productDescription
                                                                          ?.isNotEmpty ??
                                                                      false,
                                                                  child:
                                                                      TMTTextWidget(
                                                                    title: order
                                                                            ?.productDescription ??
                                                                        "",
                                                                    style:
                                                                        TMTFontStyles
                                                                            .text(
                                                                      fontSize:
                                                                          TMTFontSize
                                                                              .sp_12,
                                                                      color: AppColor
                                                                          .textColor,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                    ),
                                                                  ),
                                                                ),
                                                                TMTTextWidget(
                                                                  title:
                                                                  (order?.productDetailsInJson?.sizes?.isNotEmpty ?? false) ? "Size: ${order?.productDetailsInJson?.sizes?.first.attributes?.size ?? "M"}" : "Size: M",
                                                                  style:
                                                                      TMTFontStyles
                                                                          .text(
                                                                    fontSize:
                                                                        TMTFontSize
                                                                            .sp_12,
                                                                    color: AppColor
                                                                        .textColor,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                                TMTTextWidget(
                                                                  title:
                                                                      "Quantity: ${order?.quantity ?? ""}",
                                                                  style:
                                                                      TMTFontStyles
                                                                          .text(
                                                                    fontSize:
                                                                        TMTFontSize
                                                                            .sp_12,
                                                                    color: AppColor
                                                                        .textColor,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          HorizontalSpacing(
                                                              WidthDimension
                                                                  .w_10),
                                                          TMTTextWidget(
                                                            title:
                                                                "£${((order?.salePrice ?? 0) * (order?.quantity ?? 1)).toStringAsFixed(2)}",
                                                            style: TMTFontStyles
                                                                .text(
                                                              fontSize:
                                                                  TMTFontSize
                                                                      .sp_14,
                                                              color: AppColor
                                                                  .neutral_800,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                  shrinkWrap: true,
                                                  itemCount:
                                                      element?.orders?.length ??
                                                          0,
                                                  scrollDirection:
                                                      Axis.vertical,
                                                  physics:
                                                      const NeverScrollableScrollPhysics(),
                                                  padding:
                                                      const EdgeInsets.only(),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.only(
                                              left: WidthDimension.w_20,
                                              right: WidthDimension.w_20,
                                              top: HeightDimension.h_15,
                                              bottom: HeightDimension.h_10),
                                          color: AppColor.neutral_100,
                                          child: Column(
                                            children: [
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  SizedBox(
                                                    width: HeightDimension.h_15,
                                                    height:
                                                        HeightDimension.h_20,
                                                    child: Image.asset(TMTImages
                                                        .icDropLocation),
                                                  ),
                                                  HorizontalSpacing(
                                                      WidthDimension.w_10),
                                                  Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      TMTTextWidget(
                                                        title: "Pickup address",
                                                        style: TMTFontStyles
                                                            .textTeen(
                                                          fontSize:
                                                              TMTFontSize.sp_16,
                                                          color: AppColor
                                                              .neutral_800,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                      ),
                                                      Visibility(
                                                        visible: element
                                                            ?.orders
                                                            ?.first
                                                            .productDetailsInJson
                                                            ?.pickupAddress
                                                            ?.name?.isNotEmpty ?? false,
                                                        child: VerticalSpacing(
                                                            HeightDimension.h_15),
                                                      ),
                                                      Visibility(
                                                        visible: element
                                                            ?.orders
                                                            ?.first
                                                            .productDetailsInJson
                                                            ?.pickupAddress
                                                            ?.name?.isNotEmpty ?? false,
                                                        child: TMTTextWidget(
                                                          title: element
                                                                  ?.orders
                                                                  ?.first
                                                                  .productDetailsInJson
                                                                  ?.pickupAddress
                                                                  ?.name ??
                                                              "",
                                                          style: TMTFontStyles
                                                              .textTeen(
                                                            fontSize:
                                                                TMTFontSize.sp_16,
                                                            color: AppColor
                                                                .textColor,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                          ),
                                                        ),
                                                      ),
                                                      VerticalSpacing(
                                                          HeightDimension.h_5),
                                                      TMTTextWidget(
                                                        title:
                                                            "${element?.orders?.first.productDetailsInJson?.pickupAddress?.addressLine1 ?? ""} ${element?.orders?.first.productDetailsInJson?.pickupAddress?.city ?? ""}",
                                                        style:
                                                            TMTFontStyles.text(
                                                          fontSize:
                                                              TMTFontSize.sp_14,
                                                          color: AppColor
                                                              .textColor,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                        ),
                                                      ),
                                                      TMTTextWidget(
                                                        title:
                                                            "${element?.orders?.first.productDetailsInJson?.pickupAddress?.country ?? ""}, ${element?.orders?.first.productDetailsInJson?.deliveryAddress?.postCode ?? ""}",
                                                        style:
                                                            TMTFontStyles.text(
                                                          fontSize:
                                                              TMTFontSize.sp_14,
                                                          color: AppColor
                                                              .textColor,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                        ),
                                                      ),
                                                      Visibility(
                                                        visible: element
                                                                ?.orders
                                                                ?.first
                                                                .productDetailsInJson
                                                                ?.pickupAddress
                                                                ?.contact != null,
                                                        child: VerticalSpacing(
                                                            HeightDimension
                                                                .h_5),
                                                      ),
                                                      Visibility(
                                                        visible: element
                                                                ?.orders
                                                                ?.first
                                                                .productDetailsInJson
                                                                ?.pickupAddress
                                                                ?.contact
                                                                != null,
                                                        child: Row(
                                                          children: [
                                                            TMTTextWidget(
                                                              title:
                                                                  "Phone number - ",
                                                              style:
                                                                  TMTFontStyles
                                                                      .text(
                                                                fontSize:
                                                                    TMTFontSize
                                                                        .sp_14,
                                                                color: AppColor
                                                                    .textColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                              ),
                                                            ),
                                                            TMTTextWidget(
                                                              title: element
                                                                      ?.orders
                                                                      ?.first
                                                                      .productDetailsInJson
                                                                      ?.pickupAddress
                                                                      ?.contact ??
                                                                  "",
                                                              style:
                                                                  TMTFontStyles
                                                                      .text(
                                                                fontSize:
                                                                    TMTFontSize
                                                                        .sp_14,
                                                                color: AppColor
                                                                    .textColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(width: double.infinity, height: 2, color: AppColor.dividerColor,),
                                        Visibility(
                                            visible: (_buyerOrderController.orderDetails?.orderPaymentMappings?.isNotEmpty ?? false) ? element?.orders?.first.status == "AUTO_CANCELLED" ? true : _buyerOrderController.orderDetails?.orderPaymentMappings?.first.paymentStatus == "SUCCEEDED" : false,
                                            child: _buyerOrderController.getTrackingWidget(false, element?.orders?.first.orderedItemStatuses, CancelGetModel(orderId: (orderId is List) ? orderId.first : orderId, sellerId: element?.seller?.id ?? 0), ReturnGetModel(orderId: (orderId is List) ? orderId.first : orderId, sellerId: element?.orders?.first.sellerStoreId ?? 0))),
                                        _invoiceButton(element?.seller, element?.orders?.first),
                                      ],
                                    ),
                                  );
                          },
                          itemCount: _buyerOrderController
                                  .orderDetails?.sellers?.length ??
                              0,
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          padding: const EdgeInsets.only(),
                          physics: const NeverScrollableScrollPhysics(),
                        ),
                        Visibility(
                          visible: _buyerOrderController
                                  .orderDetails?.sellers?.isNotEmpty ??
                              false,
                          child: Column(
                            children: [
                              VerticalSpacing(HeightDimension.h_10),
                              Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20,
                                    right: WidthDimension.w_20,
                                    top: HeightDimension.h_10,
                                    bottom: HeightDimension.h_10),
                                color: AppColor.neutral_100,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        TMTTextWidget(
                                          title: "Price Details",
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        const Spacer(),
                                        Row(
                                          children: [
                                            TMTTextWidget(
                                              title: _buyerOrderController
                                                  .getTotalItemsCount()
                                                  .toString(),
                                              style: TMTFontStyles.textTeen(
                                                fontSize: TMTFontSize.sp_14,
                                                color: AppColor.primaryBG,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                            HorizontalSpacing(
                                                WidthDimension.w_4),
                                            TMTTextWidget(
                                              title: _buyerOrderController
                                                          .getTotalItemsCount() <=
                                                      1
                                                  ? "Item"
                                                  : "Items",
                                              style: TMTFontStyles.textTeen(
                                                fontSize: TMTFontSize.sp_14,
                                                color: AppColor.neutral_800,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    Container(
                                      width: double.infinity,
                                      height: 1,
                                      color: AppColor.lightGrey,
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    Row(
                                      children: [
                                        TMTTextWidget(
                                          title: "Item Price",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        const Spacer(),
                                        TMTTextWidget(
                                          title: "£${_buyerOrderController
                                              .getItemPrices().toStringAsFixed(2)}",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_5),
                                    Row(
                                      children: [
                                        TMTTextWidget(
                                          title:
                                          "VAT(${_buyerOrderController.orderDetails?.taxInPercentage}%)",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        const Spacer(),
                                        TMTTextWidget(
                                          title: _buyerOrderController
                                              .getTotalTax(),
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_5),
                                    Row(
                                      children: [
                                        Row(
                                          children: [
                                            TMTTextWidget(
                                              title: "Shipping Charges",
                                              style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_12,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w400,
                                              ),
                                            ),
                                            HorizontalSpacing(
                                                WidthDimension.w_6),
                                            CustomPopupMenu(
                                              menuBuilder: () => TMTRoundedCornersContainer(
                                                borderRadius: BorderRadius.zero,
                                                margin: EdgeInsets.only(
                                                    left: WidthDimension.w_100),
                                                width: WidthDimension.w_190,
                                                height: ((_buyerOrderController.orderDetails?.sellers?.length ?? 0) < 2 && (_buyerOrderController.orderDetails?.sellers?.first.orders?.length ?? 0) <= 2) ? HeightDimension.h_100 : HeightDimension.h_130,
                                                bgColor: AppColor.neutral_100,
                                                borderColor: AppColor.arrowColor,
                                                child: Column(
                                                  children: [
                                                    Container(
                                                      width: double.infinity,
                                                      color:
                                                          AppColor.arrowColor,
                                                      padding: EdgeInsets.only(
                                                          left: WidthDimension
                                                              .w_10,
                                                          right: WidthDimension
                                                              .w_10,
                                                          top: HeightDimension
                                                              .h_2,
                                                          bottom:
                                                              HeightDimension
                                                                  .h_2),
                                                      child: TMTTextWidget(
                                                        title:
                                                            "Shipping Calculations",
                                                        style:
                                                            TMTFontStyles.text(
                                                          fontSize:
                                                              TMTFontSize.sp_12,
                                                          color: AppColor
                                                              .neutral_100,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                    VerticalSpacing(
                                                        HeightDimension.h_5),
                                                    Expanded(
                                                      child:
                                                          SingleChildScrollView(
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            ListView.builder(
                                                              padding:
                                                                  EdgeInsets
                                                                      .zero,
                                                              itemBuilder:
                                                                  (context,
                                                                      index) {
                                                                return Container(
                                                                  padding: EdgeInsets.only(
                                                                      left: WidthDimension
                                                                          .w_10,
                                                                      right: WidthDimension
                                                                          .w_10,
                                                                      top: HeightDimension
                                                                          .h_5,
                                                                      bottom: HeightDimension
                                                                          .h_5),
                                                                  color: AppColor
                                                                      .neutral_100,
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Column(
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          Row(
                                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                            children: [
                                                                              TMTTextWidget(
                                                                                title:
                                                                                    _buyerOrderController.orderDetails?.sellers?[index].seller?.name ?? "",
                                                                                style:
                                                                                    TMTFontStyles.text(
                                                                                  fontSize: TMTFontSize.sp_8,
                                                                                  color: AppColor.textColor,
                                                                                  fontWeight: FontWeight.w600,
                                                                                ),
                                                                              ),
                                                                              VerticalSpacing(HeightDimension.h_5),
                                                                              TMTTextWidget(
                                                                                title:
                                                                                "£${_buyerOrderController.getProductHandlingPrice(index).toStringAsFixed(2)}",
                                                                                style:
                                                                                    TMTFontStyles.text(
                                                                                  fontSize: TMTFontSize.sp_8,
                                                                                  color: AppColor.textColor,
                                                                                  fontWeight: FontWeight.w600,
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                          ListView
                                                                              .builder(
                                                                            padding:
                                                                                EdgeInsets.zero,
                                                                            itemBuilder:
                                                                                (c, i) {
                                                                              double subCost = 0;
                                                                              _buyerOrderController.orderDetails?.sellers?[index].orders?.forEach((element) {
                                                                                subCost = subCost + (element.salePrice ?? 0);
                                                                              });

                                                                              return Column(
                                                                                children: [
                                                                                  Row(
                                                                                    children: [
                                                                                      SizedBox(
                                                                                        width: WidthDimension.w_120,
                                                                                        child: TMTTextWidget(
                                                                                          maxLines: 3,
                                                                                          title: _buyerOrderController.orderDetails?.sellers?[index].orders?[i].productName ?? "",
                                                                                          style: TMTFontStyles.text(
                                                                                            fontSize: TMTFontSize.sp_8,
                                                                                            color: AppColor.textColor,
                                                                                            fontWeight: FontWeight.w500,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      const Spacer(),
                                                                                      HorizontalSpacing(WidthDimension.w_10),
                                                                                      TMTTextWidget(
                                                                                        title: _buyerOrderController.orderDetails?.sellers?[index].orders?.first.shippingMethod ?? "PICKUP",
                                                                                        style: TMTFontStyles.text(
                                                                                          fontSize: TMTFontSize.sp_8,
                                                                                          color: AppColor.textColor,
                                                                                          fontWeight: FontWeight.w500,
                                                                                        ),
                                                                                      )
                                                                                    ],
                                                                                  ),
                                                                                ],
                                                                              );
                                                                            },
                                                                            itemCount:
                                                                                _buyerOrderController.orderDetails?.sellers?[index].orders?.length ?? 0,
                                                                            scrollDirection:
                                                                                Axis.vertical,
                                                                            shrinkWrap:
                                                                                true,
                                                                            physics:
                                                                                const NeverScrollableScrollPhysics(),
                                                                          )
                                                                        ],
                                                                      ),
                                                                      VerticalSpacing(
                                                                          HeightDimension
                                                                              .h_5),
                                                                    ],
                                                                  ),
                                                                );
                                                              },
                                                              shrinkWrap: true,
                                                              physics:
                                                                  const NeverScrollableScrollPhysics(),
                                                              scrollDirection:
                                                                  Axis.vertical,
                                                              itemCount: _buyerOrderController
                                                                      .orderDetails
                                                                      ?.sellers
                                                                      ?.length ??
                                                                  0,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              ),
                                              barrierColor: Colors.transparent,
                                              pressType: PressType.singleClick,
                                              arrowColor: AppColor.arrowColor,
                                              position:
                                                  PreferredPosition.top,
                                              child: SizedBox(
                                                height: HeightDimension.h_15,
                                                width: HeightDimension.h_15,
                                                child: Image.asset(
                                                    TMTImages.icInfo),
                                              ),
                                            )
                                          ],
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        const Spacer(),
                                        TMTTextWidget(
                                          title: "£${_buyerOrderController
                                              .getProductHandlingSumPrice().toStringAsFixed(2)}",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_12,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                    VerticalSpacing(HeightDimension.h_20),
                                    Container(
                                      width: double.infinity,
                                      height: 1,
                                      color: AppColor.lightGrey,
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    Row(
                                      children: [
                                        TMTTextWidget(
                                          title: (_buyerOrderController.orderDetails?.orderPaymentMappings?.isNotEmpty ?? false) ? _buyerOrderController.orderDetails?.orderPaymentMappings?.first.paymentStatus == "SUCCEEDED" ? "Total Amount Paid" : "Total Amount" : "Total Amount",
                                          style: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        const Spacer(),
                                        TMTTextWidget(
                                          title: _buyerOrderController
                                              .getTotalSumAmount(),
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.primaryBG,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_10),
                      ],
                    ),
                  )),
                  Visibility(
                    visible: (_buyerOrderController.orderDetails?.orderPaymentMappings?.isNotEmpty ?? false) ? _buyerOrderController.orderDetails?.sellers?.first.orders?.first.orderedItemStatuses?.last.status == "AUTO_CANCELLED" ? false : _checkOrderTime() : false,
                    child: Container(
                      padding: EdgeInsets.only(
                          left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.3),
                          spreadRadius: 3,
                          blurRadius: 5,
                          offset: const Offset(0, 3), // changes position of shadow
                        ),
                      ], color: AppColor.neutral_100),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TMTTextWidget(title: _buyerOrderController.getTotalSumAmount(),
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_14,
                                  color: AppColor.primaryBG,
                                  fontWeight: FontWeight.w700,
                                ),),
                              TMTTextWidget(
                                title: "Pay Amount", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.textColor,
                                fontWeight: FontWeight.w400,
                              ),),
                            ],
                          ),
                          const Spacer(),
                          InkWell(
                            onTap: () {
                              if (isDateWithinLast24Hours(_buyerOrderController.orderDetails?.createdAt?.subtract(const Duration(minutes: 2)) ?? DateTime.now())) {
                                _startPayment(_buyerOrderController.orderDetails);
                              } else {
                                Get.back();
                                TMTToast.showErrorToast(context, "This order is expired", title: "Alert");
                              }
                            },
                            child: Container(
                              height: HeightDimension.h_50,
                              width: WidthDimension.w_190,
                              padding: EdgeInsets.only(
                                  top: HeightDimension.h_12,
                                  bottom: HeightDimension.h_12,
                                  left: WidthDimension.w_18,
                                  right: WidthDimension.w_18),
                              decoration: BoxDecoration(
                                  color: AppColor.primaryBG,
                                  border: Border.all(
                                      color: AppColor.primaryBG, width: 1),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(TMTRadius.r_30))),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  TMTTextWidget(
                                    title: "PAY NOW",
                                    style: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_18,
                                      color: AppColor.neutral_100,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              bottomNavigationBar: CommonBottomNavigationBar(
                  currentSelectedItem: (orderId is int) ? 3 : 4,
                  onTap: (index) {
                    Get.offAllNamed(AppRoutes.dashBoardScreen,
                        arguments: index);
                  }),
            ),
          );
        });
  }

  /// Check user status
  void _checkUserStatus() {
    if (TMTUtilities.getUserRoleFromToken() == "SELLER") {
      _dashboardController.getSellerRegisterStatus(context, (){
        if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
          Get.toNamed(AppRoutes.sellerDashboard);
        } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
          Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
        } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
          Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
        } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
          _dashboardController.getUpdatedToken(context, (){
            Get.toNamed(
                AppRoutes.sellerPlanDetailsScreen);
          });
        } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
          _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), (){
            Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
          });
        } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
          TMTUtilities.showUserDisabledDialog(context);
        } else {
          Get.toNamed(AppRoutes.sellerDashboard);
        }
      });
    } else {
      if (!TMTLocalStorage.getUserLoggedIn()) {
        Get.offAndToNamed(AppRoutes.loginScreen,
            arguments: AppRoutes.homeScreen);
      } else {
        _dashboardController.getSellerRegisterStatus(context, (){
          if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
            _dashboardController.getUpdatedToken(context, (){
              Get.toNamed(AppRoutes.sellerDashboard);
            });
          } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
            Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
          } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
            Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
          } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
            _dashboardController.getUpdatedToken(context, (){
              Get.toNamed(
                  AppRoutes.sellerPlanDetailsScreen);
            });
          } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
            _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), (){
              Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
            });
          } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
            TMTUtilities.showUserDisabledDialog(context);
          } else {
            Get.toNamed(AppRoutes.registerToSellScreen);
          }
        });
      }
    }
  }

  /// start payment process
  void _startPayment(OrderDetails? orderDetails) {
    try {
      _buyerOrderController.postCreateCustomer(context, (customerId) {
        if (customerId?.isNotEmpty ?? false) {
          _buyerOrderController.getCards(context, (cards) async {
            if (cards != null) {
              if (cards.data.isNotEmpty) {
                await Get.toNamed(AppRoutes.ordersCardsCheckoutScreen, arguments: orderDetails?.id ?? 0)?.then((value){
                  _callApi();
                });
              }
              else {
                _buyerOrderController.postCreatePaymentIntent(context, (data) async {
                  _buyerOrderController.paymentUsingCard(data : data, context: context, orderId: orderDetails?.id ?? 0, callback: (){
                    if (orderId is int) {
                      _buyerOrderController.getOrderDetails(context, orderId);
                    } else {
                      _buyerOrderController.getOrderDetails(context, orderId.first);
                    }
                  });
                }, PostCreatePaymentIntentRequest(
                    amount: _buyerOrderController.getTotalSumAmountInt(),
                    paymentMethod: ["cards"],
                    shipping: PRShipping(address: _getPayAddress()), orderId: orderDetails?.id.toString() ?? ""));
              }
            }
            else {
              _buyerOrderController.postCreatePaymentIntent(context, (data) async {
                _buyerOrderController.paymentUsingCard(data : data, context: context, orderId: orderDetails?.id ?? 0, callback: (){
                  if (orderId is int) {
                    _buyerOrderController.getOrderDetails(context, orderId);
                  } else {
                    _buyerOrderController.getOrderDetails(context, orderId.first);
                  }
                });
              }, PostCreatePaymentIntentRequest(
                  amount: _buyerOrderController.getTotalSumAmountInt(),
                  paymentMethod: ["cards"],
                  shipping: PRShipping(address: _getPayAddress()), orderId: orderDetails?.id.toString() ?? ""));
            }
          });
        } else {

        }
      });
    } catch (e) {
      print(e.toString());
    }
  }

  /// invoice and need help button
  Widget _invoiceButton(SellerSeller? seller, Order? order) {
    return Visibility(
      visible: (_buyerOrderController.orderDetails?.orderPaymentMappings?.isNotEmpty ?? false) ? _buyerOrderController.orderDetails?.orderPaymentMappings?.first.paymentStatus == "SUCCEEDED" : false,
      child: Column(
        children: [
          Container(width: double.infinity, height: 2, color: AppColor.dividerColor,),
          Container(
            color: AppColor.neutral_100,
            width: double.infinity,
            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: (){
                    _buyerOrderController.getOrderInvoice(context, orderId is int ? orderId.toString() : orderId.first.toString(), (){});
                  },
                  child: Container(
                    child: Row(
                      children: [
                        SizedBox(
                          height: HeightDimension.h_18,
                          width: HeightDimension.h_18,
                          child: Image.asset(TMTImages.icOrderInvoice),
                        ),
                        HorizontalSpacing(WidthDimension.w_6),
                        TMTTextWidget(title: "Invoice Download", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_14,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w500,
                        ),),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: (){
                    SellerData args = SellerData(storeId: 0, name: seller?.name ?? "", userId: seller?.id ?? 0, description: "", profilePicture: seller?.storeImage ?? "", isBuyer: true, productId: order?.productId.toString() ?? "", productName: order?.productName ?? "", productImage: order?.productImage ?? "", productPrice: order?.salePrice.toString() ?? "");
                    Get.toNamed(AppRoutes.enquiryChatPage, arguments: args);
                  },
                  child: Container(
                    child: Row(
                      children: [
                        SizedBox(
                          height: HeightDimension.h_18,
                          width: HeightDimension.h_18,
                          child: Image.asset(TMTImages.icOrderNeedHelp),
                        ),
                        HorizontalSpacing(WidthDimension.w_6),
                        TMTTextWidget(title: "Need Help?", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_14,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w500,
                        ),),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  PRAddress _getPayAddress() {
    try {
      return PRAddress(
        line1: address.first.address1,
        line2: address.first.address2,
        postalCode: address.first.postCode,
        city: address.first.city,
        state:  address.first.state,
        country: address.first.country,
      );
    } catch (e) {
      return PRAddress(
          line1: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.addressLine1 ?? "",
          line2: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.addressLine2 ?? "",
          postalCode: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.postCode ?? "",
          city: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.city ?? "",
          state:  "",
          country: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.country ??
              ""
      );
    }
  }

  /// check whether order is within 24 hours
  bool _checkOrderTime() {
    if (_buyerOrderController.orderDetails?.orderPaymentMappings?.first.paymentStatus != "SUCCEEDED") {
      if(isDateWithinLast24Hours(_buyerOrderController.orderDetails?.createdAt ?? DateTime.now())){
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  /// check if given date is within 24 hours
  bool isDateWithinLast24Hours(DateTime inputDate) {
    // Get the current date
    DateTime currentDate = DateTime.now();

    // Calculate the time 24 hours ago from the current date
    DateTime dateAgo = currentDate.subtract(const Duration(days: 1));

    // Check if the input date is greater than or equal to seven days ago
    // and less than or equal to the current date
    var result = (inputDate.isAfter(dateAgo));
    return result;
  }

  /// call apis
  void _callApi() {
    if (TMTLocalStorage.getUserLoggedIn()) {
      _addressScreenController.getAddress(context, callback: (data){
        setState(() {
          address = data ?? [];
        });
      });
    }
    if (orderId is int) {
      _buyerOrderController.getOrderDetails(context, orderId);
    } else {
      _buyerOrderController.getOrderDetails(context, orderId.first);
    }
  }
}
