import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as sSize;
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/model/response/get_buyer_order_detail_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/buyer_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_checkbox.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class ReturnRefundOrderScreen extends StatefulWidget {
  const ReturnRefundOrderScreen({super.key});

  @override
  State<StatefulWidget> createState() => _ReturnRefundOrderScreenState();
}

class _ReturnRefundOrderScreenState extends State<ReturnRefundOrderScreen> {

  final BuyerOrderController _buyerOrderController =
  Get.find<BuyerOrderController>();

  ReturnGetModel args = Get.arguments;
  List<Order?> selectedOrderItems = [];
  bool isAgreedToTerms = false;

  @override
  void initState() {
    _buyerOrderController.getRefundReasonsList(context);
    if (args.productId == null) {
      _buyerOrderController.getOrderDetailsByItems(context, args.orderId, (){
        _showProductSelectionDialog((o) async {
          await Future.delayed(const Duration(milliseconds: 200)).then((value){
            setState(() {
              selectedOrderItems = o;
            });
          });
        });
      });
    } else {
      _buyerOrderController.getOrderDetailsByItems(context, args.orderId, (){
        selectedOrderItems.add(_buyerOrderController.allProductsItems.firstWhereOrNull((element) => element.productId == args.productId));
      });
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyerOrderController>(
        id: GetControllerBuilders.refundOrderScreenController,
        init: _buyerOrderController,
        builder: (controller) {
        return Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: PreferredSize(
              preferredSize: sSize.Size.fromHeight(SizeConfig.safeBlockVertical * 8.5),
              child: Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Column(
                  children: [
                    VerticalSpacing(SizeConfig.safeBlockVertical * 7),
                    Row(
                      children: [
                        InkWell(
                          onTap: (){
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_20),
                              SizedBox(
                                width: WidthDimension.w_18,
                                height: HeightDimension.h_15,
                                child: Image.asset(
                                  TMTImages.icBack,
                                  color: AppColor.neutral_800,
                                  fit: BoxFit.contain,
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_6),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_6),
                        TMTTextWidget(
                          title: "Return and Refund ",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ],
                ),
              )),
          body: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  width: double.infinity,
                  height: MediaQuery.of(context).size.height - (SizeConfig.blockSizeVertical * 21),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        ListView.builder(itemBuilder: (context, index){
                          var e = selectedOrderItems[index];
                          return Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.2),
                                    spreadRadius: 2,
                                    blurRadius: 1,
                                    offset: const Offset(2, 0), // changes position of shadow
                                  ),
                                ],
                                color: AppColor.neutral_100,
                                border: Border.all(color: AppColor.neutral_100, width: 0.5)
                            ),
                            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(TMTRadius.r_10), // Image border
                                  child: SizedBox(
                                    height: HeightDimension.h_80,
                                    width: HeightDimension.h_80,
                                    child: TMTCachedImage.networkImage(e?.productImage ?? "", fit: BoxFit.cover),
                                  ),
                                ),
                                HorizontalSpacing(WidthDimension.w_20),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      TMTTextWidget(title: e?.productName ?? "", style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_14,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w500,
                                      ),),
                                      TMTTextWidget(title: e?.productDescription ?? "", style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w500,
                                      ), maxLines: 1,),
                                      TMTTextWidget(title: (e?.productDetailsInJson?.sizes?.isNotEmpty ?? false) ? "Size: ${e?.productDetailsInJson?.sizes?.first.attributes?.size ?? "M"}" : "Size: M", style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w500,
                                      )),
                                      VerticalSpacing(HeightDimension.h_5),
                                      TMTTextWidget(title: "Price £${e?.salePrice ?? ""}", style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w500,
                                      )),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          );
                        }, itemCount: selectedOrderItems.length, scrollDirection: Axis.vertical, shrinkWrap: true, padding: EdgeInsets.zero, physics: NeverScrollableScrollPhysics(),),
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              TMTTextWidget(
                                title: "Why are you returning this?",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_18,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_10),
                              ListView.builder(
                                itemCount: _buyerOrderController.refundOrderReasons.length,
                                itemBuilder: (context, index){
                                  return InkWell(
                                    onTap: (){
                                      setState(() {
                                        _buyerOrderController.selectedReturnReason = index;
                                      });
                                    },
                                    child: Container(
                                      padding: EdgeInsets.only(top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.only(top: HeightDimension.h_4),
                                            width: HeightDimension.h_15,
                                            height: HeightDimension.h_15,
                                            child: _buyerOrderController.selectedReturnReason == index ? const TMTRoundedCornersContainer(
                                              borderColor: AppColor.primaryBG,
                                              padding: EdgeInsets.all(2),
                                              child: TMTRoundedCornersContainer(
                                                borderColor: AppColor.primaryBG,
                                                bgColor: AppColor.primaryBG,
                                              ),
                                            ) : const TMTRoundedCornersContainer(
                                              borderColor: AppColor.neutral_800,
                                            ),
                                          ),
                                          HorizontalSpacing(WidthDimension.w_10),
                                          Expanded(
                                            child: TMTTextWidget(
                                              title: _buyerOrderController.refundOrderReasons[index].text ?? "",
                                              style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_15,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w400,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                                scrollDirection: Axis.vertical,
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                              ),
                              VerticalSpacing(HeightDimension.h_20),
                              Visibility(
                                visible: _buyerOrderController.selectedReturnReason == _buyerOrderController.refundOrderReasons.length-1,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    TMTTextWidget(
                                      title: "Your reason",
                                      style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_18,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                    TextFormField(
                                      maxLines: 5,
                                      controller: _buyerOrderController.additionalRefundTextController,
                                      onChanged: (v){
                                        setState(() {

                                        });
                                      },
                                      maxLength: 100,
                                      onFieldSubmitted: (v) {
                                        TMTUtilities.closeKeyboard(context);
                                      },
                                      textInputAction: TextInputAction.done,
                                      keyboardType: TextInputType.text,
                                      decoration: InputDecoration(
                                          focusedErrorBorder:  CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                          errorBorder:  CustomOutlineInputBorder(
                                              borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                          enabledBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                          floatingLabelBehavior: FloatingLabelBehavior.auto,
                                          focusedBorder: CustomOutlineInputBorder(
                                              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                          contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 10),
                                          border: CustomOutlineInputBorder(
                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10),
                                          ),
                                          errorMaxLines: 3,
                                          filled: false,
                                          hintText: "",
                                          hintStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500),
                                          labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                      ),
                                    ),
                                    VerticalSpacing(HeightDimension.h_10),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: Row(
                            children: [
                              TMTCustomCheckbox(
                                isChecked: isAgreedToTerms,
                                onChange: (value) {
                                  setState(() {
                                    isAgreedToTerms = !isAgreedToTerms;
                                  });
                                },
                                backgroundColor: AppColor.neutral_100,
                                borderColor: AppColor.neutral_800,
                                icon: Icons.check,
                                iconColor: AppColor.neutral_800,
                                size: 18,
                                iconSize: 14,
                              ),
                              HorizontalSpacing(WidthDimension.w_10),
                              Expanded(
                                child: TMTTextWidget(title: "I agree to return all item(s) in original condition.", style: TMTFontStyles.text(
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                    fontSize: TMTFontSize.sp_12
                                ),),
                              ),
                              HorizontalSpacing(WidthDimension.w_10),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                      left: WidthDimension.w_15,
                      right: WidthDimension.w_15),
                  child: TMTTextButton(
                    isDisable: !isAgreedToTerms,
                    onTap: (){
                      TMTUtilities.closeKeyboard(context);
                      if (_buyerOrderController.selectedReturnReason == -1) {
                        TMTToast.showErrorToast(context, "Please select reason for Return.", title: "Alert");
                        return;
                      }
                      if (_buyerOrderController.selectedReturnReason == _buyerOrderController.refundOrderReasons.length-1) {
                        if (_buyerOrderController.additionalRefundTextController.text.isEmpty) {
                          TMTToast.showErrorToast(context, "Please enter reason for return.", title: "Alert");
                          return;
                        }
                      }
                      _buyerOrderController.postReturnRefundOrder(context, _getOrderIds(), (){
                        showDialog(
                            barrierDismissible: false,
                            context: context, builder: (c){
                          return Material(
                            color: Colors.transparent,
                            child: TMTBackButton(
                              onWillPop: (){
                                return Future.value(false);
                              },
                              child: Center(
                                child: SizedBox(
                                  width: WidthDimension.w_250,
                                  height: HeightDimension.h_240,
                                  child: Stack(
                                    children: [
                                      TMTRoundedCornersContainer(
                                        margin : EdgeInsets.only(top: HeightDimension.h_40),
                                        bgColor : AppColor.neutral_100,
                                        padding: const EdgeInsets.all(20),
                                        borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_15)),
                                        child: Column(
                                          children: [
                                            VerticalSpacing(HeightDimension.h_40),
                                            TMTTextWidget(textAlign: TextAlign.center ,title: "Your return & refund request sent successfully ", style: TMTFontStyles.text(fontWeight: FontWeight.w600, fontSize: TMTFontSize.sp_16)),
                                            VerticalSpacing(HeightDimension.h_20),
                                            Padding(
                                              padding: EdgeInsets.only(left: WidthDimension.w_40, right: WidthDimension.w_40),
                                              child: InkWell(
                                                onTap: (){
                                                  Get.offAllNamed(AppRoutes.dashBoardScreen);
                                                },
                                                child: TMTTextButton(buttonTitle: "DONE", borderRadius: BorderRadius.circular(
                                                  TMTRadius.r_35,
                                                ),),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Row(
                                        mainAxisAlignment : MainAxisAlignment.center,
                                        children: [
                                          TMTRoundedCornersContainer(
                                            boxShadow: [
                                              BoxShadow(
                                                color: Colors.grey.withOpacity(0.3),
                                                spreadRadius: 5,
                                                blurRadius: 7,
                                                offset: const Offset(0, 3), // changes position of shadow
                                              ),
                                            ],
                                            borderRadius: const BorderRadius.all(Radius.circular(50)),
                                            bgColor: AppColor.neutral_100,
                                            padding: const EdgeInsets.all(24),
                                            child: SizedBox(
                                              height: HeightDimension.h_35,
                                              width: HeightDimension.h_35,
                                              child: Image.asset(TMTImages.icTickGreen),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        });
                      });
                    },
                    buttonTitle: "SEND REQUEST",
                  ),
                ),
              ],
            ),
          ),
        );
      }
    );
  }

  void _showProductSelectionDialog(Function(List<Order> order) callback) {
    showDialog(context: context,
        barrierDismissible: false,
        barrierColor: AppColor.neutral_800.withOpacity(0.2),
        builder: (context){
          return WillPopScope(
            onWillPop: () {
              return Future.value(false);
            },
            child: StatefulBuilder(
                builder: (context, setState) {
                return Material(
                  color: Colors.transparent,
                  child: Container(
                      color: AppColor.neutral_100,
                      height: MediaQuery.of(context).size.height / 2,
                      margin: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_80, bottom: HeightDimension.h_80),
                      child: Column(
                        children: [
                          VerticalSpacing(HeightDimension.h_10),
                          Padding(
                            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                            child: TMTTextWidget(title: "Please select product you want to return", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w600,
                            ), textAlign: TextAlign.center,),
                          ),
                          VerticalSpacing(HeightDimension.h_10),
                          Expanded(
                            child: ListView.builder(itemBuilder: (context, index){
                             var e = _buyerOrderController.allProductsItems[index];
                              return  GestureDetector(
                                onTap: (){
                                  setState(() {
                                    _buyerOrderController.allProductsItems[index].isSelected = !(_buyerOrderController.allProductsItems[index].isSelected ?? false);
                                  });
                                },
                                child: Container(
                                  width: double.infinity,
                                  margin: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey.withOpacity(0.2),
                                          spreadRadius: 2,
                                          blurRadius: 1,
                                          offset: const Offset(2, 0), // changes position of shadow
                                        ),
                                      ],
                                      color: AppColor.neutral_100,
                                      border: Border.all(color: (_buyerOrderController.allProductsItems[index].isSelected ?? false) ? AppColor.primary : AppColor.neutral_100, width: (_buyerOrderController.allProductsItems[index].isSelected ?? false) ? 1 : 0.5)
                                  ),
                                  padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_10, bottom: HeightDimension.h_15),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(TMTRadius.r_10), // Image border
                                        child: SizedBox(
                                          height: HeightDimension.h_80,
                                          width: HeightDimension.h_80,
                                          child: TMTCachedImage.networkImage(e.productImage ?? "", fit: BoxFit.cover),
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_20),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            TMTTextWidget(title: e.productName ?? "", style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_14,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w500,
                                            ),),
                                            TMTTextWidget(title: e.productDescription ?? "", style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_12,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w500,
                                            ), maxLines: 1,),
                                            TMTTextWidget(title: (e.productDetailsInJson?.sizes?.isNotEmpty ?? false) ? "Size: ${e.productDetailsInJson?.sizes?.first.attributes?.size ?? ""}" : "Size: M", style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_12,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w500,
                                            )),
                                            VerticalSpacing(HeightDimension.h_5),
                                            TMTTextWidget(title: "Price £${e.salePrice ?? ""}", style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_12,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w500,
                                            )),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              );
                            }, itemCount: _buyerOrderController.allProductsItems.length, padding: const EdgeInsets.only(), scrollDirection: Axis.vertical, shrinkWrap: true,),
                          ),
                          VerticalSpacing(HeightDimension.h_10),
                          Padding(
                            padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, bottom: HeightDimension.h_10),
                            child: TMTTextButton(buttonTitle: "CONTINUE", isDisable: _buyerOrderController.allProductsItems.firstWhereOrNull((element) => element.isSelected == true) == null, onTap: (){
                              Navigator.pop(context);
                              callback.call(_buyerOrderController.allProductsItems.where((element) => element.isSelected == true).toList());
                            },),
                          )
                        ],
                      )
                  ),
                );
              }
            ),
          );
        });
  }

  /// get selected orders ids
  List<int> _getOrderIds() {
    return selectedOrderItems.map((e) => e?.id ?? 0).toList();
  }
}
