import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/model/request/post_create_payment_intent_request.dart';
import 'package:take_my_tack/data/model/response/get_delivery_address_response.dart';
import 'package:take_my_tack/data/model/response/post_create_payment_intent_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/address/address_screens_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/cart/cart_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/buyer_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/loading_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class OrdersCardsCheckoutScreen extends StatefulWidget {
  const OrdersCardsCheckoutScreen({super.key});

  @override
  State<StatefulWidget> createState() => _OrdersCardsCheckoutScreenState();
}

class _OrdersCardsCheckoutScreenState extends State<OrdersCardsCheckoutScreen> {
  final BuyerOrderController _buyerOrderController =
  Get.find<BuyerOrderController>();
  final AddressScreenController _addressScreenController = Get.find<AddressScreenController>();

  int args = Get.arguments;
  int selectedCard = -1;

  @override
  void initState() {
    _buyerOrderController.getCards(context, (data) {

    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyerOrderController>(
        id: GetControllerBuilders.ordersCardsCheckoutScreen,
        init: _buyerOrderController,
        builder: (controller) {
          return TMTBackButton(
            onWillPop: (){
              _showPaymentCancelToast();
              Get.offNamed(AppRoutes.confirmOrderScreen, arguments: args);
              return Future.value(false);
            },
            child: Scaffold(
              appBar: PreferredSize(
                  preferredSize:
                      Size.fromHeight(SizeConfig.safeBlockVertical * 9),
                  child: Container(
                    decoration: BoxDecoration(boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 3,
                        offset: const Offset(0, 3), // changes position of shadow
                      ),
                    ], color: AppColor.neutral_100),
                    child: Column(
                      children: [
                        VerticalSpacing(SizeConfig.safeBlockVertical * 7),
                        Row(
                          children: [
                            InkWell(
                              onTap: () {
                                _showPaymentCancelToast();
                                Get.offNamed(AppRoutes.confirmOrderScreen, arguments: args);
                              },
                              child: Row(
                                children: [
                                  HorizontalSpacing(WidthDimension.w_20),
                                  SizedBox(
                                    width: WidthDimension.w_18,
                                    height: HeightDimension.h_15,
                                    child: Image.asset(
                                      TMTImages.icBack,
                                      color: AppColor.neutral_800,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_6),
                                ],
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_6),
                            TMTTextWidget(
                              title: "Manage Payment",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_20),
                          ],
                        ),
                      ],
                    ),
                  )),
              body: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    VerticalSpacing(HeightDimension.h_20),
                    ListView.builder(
                      itemBuilder: (BuildContext context, int index) {
                        return GestureDetector(
                          onTap: (){
                            setState(() {
                              selectedCard = index;
                            });
                          },
                          child: TMTRoundedCornersContainer(
                            margin: EdgeInsets.only(bottom: HeightDimension.h_15),
                            borderRadius: BorderRadius.circular(18),
                            bgColor: AppColor.neutral_100,
                            borderColor: selectedCard == index ? AppColor.primary: AppColor.neutral_100,
                            width: double.infinity,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                spreadRadius: 3,
                                blurRadius: 3,
                                offset: const Offset(0, 2), // changes position of shadow
                              ),
                            ],
                            padding: EdgeInsets.only(
                                left: WidthDimension.w_15,
                                right: WidthDimension.w_15,
                                top: HeightDimension.h_15,
                                bottom: HeightDimension.h_15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    TMTTextWidget(
                                      title: "Stripe",
                                      style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_16,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    const Spacer(),
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          height: HeightDimension.h_22,
                                          width: WidthDimension.w_70,
                                          child: Image.asset(TMTImages.icVisa),
                                        ),
                                        VerticalSpacing(HeightDimension.h_2),
                                        TMTTextWidget(
                                          title: _buyerOrderController.cardsData[index].card.funding == "credit" ? "   CREDIT CARD" : "   DEBIT CARD",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_10,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                VerticalSpacing(HeightDimension.h_20),
                                TMTTextWidget(
                                    title: "CARD NUMBER",
                                    style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_10,
                                      color: AppColor.textColor,
                                      fontWeight: FontWeight.w400,
                                    )),
                                VerticalSpacing(HeightDimension.h_10),
                                TMTTextWidget(
                                    title: "**** **** *${_buyerOrderController.cardsData[index].card.last4}",
                                    style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_16,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.w400,
                                    )),
                              ],
                            ),
                          ),
                        );
                      },
                      itemCount: _buyerOrderController.cardsData.length,
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      padding: EdgeInsets.only(
                          left: WidthDimension.w_20, right: WidthDimension.w_20),
                      physics: const NeverScrollableScrollPhysics(),
                    ),
                    GestureDetector(
                      onTap: (){
                        setState(() {
                          selectedCard = _buyerOrderController.cardsData.length + 1;
                        });
                      },
                      child: TMTRoundedCornersContainer(
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            spreadRadius: 3,
                            blurRadius: 3,
                            offset: const Offset(0, 2), // changes position of shadow
                          ),
                        ],
                        borderColor: selectedCard == _buyerOrderController.cardsData.length + 1 ? AppColor.primary : AppColor.neutral_100,
                        borderRadius: BorderRadius.circular(18),
                        margin: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                        bgColor: AppColor.neutral_100,
                        width: double.infinity,
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_15, bottom: HeightDimension.h_15
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: HeightDimension.h_18,
                              width: WidthDimension.w_18,
                              child: Image.asset(TMTImages.icPlusPrimary),
                            ),
                            HorizontalSpacing(WidthDimension.w_6),
                            TMTTextWidget(title: "Use/Add Another Card", style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.primary,
                              fontWeight: FontWeight.w700,
                            ),)
                          ],
                        ),
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_20),
                  ],
                ),
              ),
              bottomNavigationBar: /*Container(
                width: double.infinity,
                padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, bottom: HeightDimension.h_10, top: HeightDimension.h_10),
                child: TMTTextButton(buttonTitle: "CONTINUE", onTap: (){
                  if (selectedCard == _cartController.cardsData.length + 1) {
                    _makePayment(context);
                  } else {
                    _cartController.makePaymentOffSession(context, _cartController.cardsData[selectedCard], (data){
                      Navigator.pop(context);
                      Get.offNamed(AppRoutes.confirmOrderScreen, arguments: PaymentIntent(id: data!.id, amount: data.amount, created: data.created.toString(), currency: data.currency, status: PaymentIntentsStatus.Succeeded, clientSecret: data.clientSecret, livemode: data.livemode, captureMethod: CaptureMethod.Manual, confirmationMethod: ConfirmationMethod.Automatic));
                    });
                  }
                }, isDisable: selectedCard == -1,),
              )*/
              Container(
                padding: EdgeInsets.only(
                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                height: HeightDimension.h_80,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    spreadRadius: 3,
                    blurRadius: 5,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TMTTextWidget(title: _buyerOrderController.getTotalSumAmount(),
                          style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.primaryBG,
                            fontWeight: FontWeight.w700,
                          ),),
                        TMTTextWidget(
                          title: "Pay Amount", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.textColor,
                          fontWeight: FontWeight.w400,
                        ),),
                      ],
                    ),
                    const Spacer(),
                    InkWell(
                      onTap: () {
                        if (selectedCard == -1) {
                          return;
                        }
                        if (selectedCard == _buyerOrderController.cardsData.length + 1) {
                          _makePayment(context);
                        } else {
                          _buyerOrderController.makePaymentOffSession(context, _buyerOrderController.cardsData[selectedCard], (data){
                            TMTToast.showSuccessToast(context, "Payment successful, Seller would be shipping your order in 2-3 business days");
                            Get.offNamed(AppRoutes.confirmOrderScreen, arguments: args);
                          }, args.toString(), _buyerOrderController.orderDetails?.grandTotal?.toInt() ?? 0, AddressData(id: _addressScreenController.defaultAddress!.id, userId: _addressScreenController.defaultAddress!.userId, address1: _addressScreenController.defaultAddress!.address1, address2: _addressScreenController.defaultAddress!.address2, postCode: _addressScreenController.defaultAddress!.postCode, city: _addressScreenController.defaultAddress!.city, state: _addressScreenController.defaultAddress!.state, country: _addressScreenController.defaultAddress!.country, street: _addressScreenController.defaultAddress!.street, firstName: _addressScreenController.defaultAddress!.firstName, phoneNumber: _addressScreenController.defaultAddress!.phoneNumber, lastName: _addressScreenController.defaultAddress!.lastName, isDefault: _addressScreenController.defaultAddress!.isDefault, createdAt: _addressScreenController.defaultAddress!.createdAt, updatedAt: _addressScreenController.defaultAddress!.updatedAt));
                        }
                      },
                      child: Container(
                        height: HeightDimension.h_50,
                        width: WidthDimension.w_190,
                        padding: EdgeInsets.only(
                            top: HeightDimension.h_12,
                            bottom: HeightDimension.h_12,
                            left: WidthDimension.w_18,
                            right: WidthDimension.w_18),
                        decoration: BoxDecoration(
                            color: selectedCard == -1 ? AppColor.neutral_100 : AppColor.primaryBG,
                            border: Border.all(
                                color: AppColor.primaryBG, width: 1),
                            borderRadius: const BorderRadius.all(
                                Radius.circular(TMTRadius.r_30))),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TMTTextWidget(
                              title: selectedCard == _buyerOrderController.cardsData.length + 1 ? "CONTINUE" : "PAY NOW",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: selectedCard == -1 ? AppColor.primary : AppColor.neutral_100,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }

  /// make payment using card
   _makePayment(BuildContext context) {
     _buyerOrderController.postCreatePaymentIntent(context, (data) {
      paymentUsingCard(data : data, context: context);
    }, PostCreatePaymentIntentRequest(
        amount: _buyerOrderController.orderDetails?.grandTotal?.toInt() ?? 0,
        paymentMethod: ["cards"],
        shipping: PRShipping(address: PRAddress(
            line1: _addressScreenController.defaultAddress?.address1 ?? "",
            line2: _addressScreenController.defaultAddress?.address1 ?? "",
            postalCode: _addressScreenController.defaultAddress?.postCode ??
                "",
            city: _addressScreenController.defaultAddress?.city ?? "",
            state: _addressScreenController.defaultAddress?.state ?? "",
            country: _addressScreenController.defaultAddress?.country ??
                "")), orderId: _buyerOrderController.orderDetails!.id.toString()));
  }

  /// handle payment
  Future<void> _handlePayPress(PIData data, BuildContext context) async {
    if (_buyerOrderController.card == null) {
      return;
    }
    var paymentIntent;
    try {
      paymentIntent = await Stripe.instance.confirmPayment(
        paymentIntentClientSecret: data.clientSecret,
        data: const PaymentMethodParams.card(
          paymentMethodData: PaymentMethodData(
            billingDetails: BillingDetails(),
          ),
        ),
        options: PaymentMethodOptions(
          setupFutureUsage:
          _buyerOrderController.saveCard == true ? PaymentIntentsFutureUsage.OffSession : null,
        ),
      );
      if (kDebugMode) {
        print(paymentIntent);
      }
      if (paymentIntent.status == PaymentIntentsStatus.Succeeded) {
        if (!context.mounted) return;
        TMTToast.showSuccessToast(context, "Payment successful, Seller would be shipping your order in 2-3 business days");
      } else {
        if (!context.mounted) return;
        TMTToast.showErrorToast(context, paymentIntent.toString());
      }
      Navigator.pop(context);
      Get.offNamed(AppRoutes.confirmOrderScreen, arguments: args);
    } catch (e) {
      Get.offNamed(AppRoutes.confirmOrderScreen, arguments: args);
      if (e is StripeException) {
        TMTToast.showErrorToast(context, e.error.message ?? e.toString());
      } else {
        TMTToast.showErrorToast(context, e.toString());
      }
      if (kDebugMode) {
        print("Error : ${e.toString()}");
      }
    }
    return;
  }

  /// make payment using card
  Future<void> paymentUsingCard({PIData? data, required BuildContext context}) async {
    /// Stripe payment
    Stripe.publishableKey = "pk_test_51NPfpzSCzdOYRdbbDTCvvwFC1Exjx58UMUmOcHtKtUy85iamihgoj2kkKidqYB5PrYKS93I3nrjWBDxbNloFWHLh00qwEgFafB";
    await Stripe.instance.applySettings();
    if (!context.mounted) return;
    if (data != null) {
      showDialog(
          barrierDismissible: false,
          context: context, builder: (context) {
        return StatefulBuilder(
            builder: (c, setState) {
              return Material(
                color: Colors.white,
                child: TMTBackButton(
                  onWillPop: () {
                    return Future.value(false);
                  },
                  child: Container(
                    padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                    child: Column(
                      children: [
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: (){
                                Navigator.pop(c);
                                Get.offNamed(AppRoutes.confirmOrderScreen, arguments: args);
                              },
                              child: SizedBox(
                                height: HeightDimension.h_20,
                                width: HeightDimension.h_20,
                                child: Image.asset(TMTImages.icBack, color: AppColor.neutral_800,),
                              ),
                            ),
                            TMTTextWidget(title: "ADD CARD DETAILS", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_18, fontWeight: FontWeight.w700, color: AppColor.neutral_700),),
                            SizedBox(
                              height: HeightDimension.h_20,
                              width: HeightDimension.h_20,
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        CardField(
                          enablePostalCode: true,
                          countryCode: 'GB',
                          postalCodeHintText: 'Enter the UK postal code',
                          onCardChanged: (card) {
                            setState(() {
                              _buyerOrderController.card = card;
                            });
                          },
                        ),
                        const SizedBox(height: 20),
                        CheckboxListTile(
                          activeColor: AppColor.primary,
                          controlAffinity: ListTileControlAffinity.leading,
                          value: _buyerOrderController.saveCard,
                          onChanged: (value) {
                            setState(() {
                              _buyerOrderController.saveCard = value;
                            });
                          },
                          title: const Text('Save card during payment'),
                        ),
                        LoadingButton(
                          onPressed: _buyerOrderController.card?.complete == true
                              ? () async {
                            await _handlePayPress(data, c);
                          }
                              : null,
                          text: 'Pay',
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              );
            }
        );
      });
    }
  }

  /// show payment cancel toast
  void _showPaymentCancelToast() {
    TMTToast.showErrorToast(context, "Do not worry, we have placed your order. You can try paying again", title: "Payment Failed");
  }
}
