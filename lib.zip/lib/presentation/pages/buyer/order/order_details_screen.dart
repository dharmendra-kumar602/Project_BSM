import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart' as sSize;
import 'package:intl/intl.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/request/post_create_payment_intent_request.dart';
import 'package:take_my_tack/data/model/response/get_buyer_order_detail_response.dart';
import 'package:take_my_tack/data/model/response/get_delivery_address_response.dart';
import 'package:take_my_tack/data/model/response/get_order_item_response.dart';
import 'package:take_my_tack/data/model/response/post_create_order_response.dart';
import 'package:take_my_tack/data/repository_implementation/payment_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/address/address_screens_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/cart/cart_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/buyer_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_popup/src/custom_pop_up_menu.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class OrderDetailsScreen extends StatefulWidget {
  const OrderDetailsScreen({super.key});

  @override
  State<StatefulWidget> createState() => _OrderDetailsScreenState();
}

class _OrderDetailsScreenState extends State<OrderDetailsScreen> {

  final BuyerOrderController _buyerOrderController =
  Get.find<BuyerOrderController>();

  final AddressScreenController _addressScreenController =
  Get.put(AddressScreenController());

  var orderId = Get.arguments;
  List<AddressData> address = [];

  @override
  void initState() {
    _callAPI();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyerOrderController>(
        id: GetControllerBuilders.orderItemDetailsScreenController,
        init: _buyerOrderController,
        builder: (controller) {
        return Scaffold(
          backgroundColor: AppColor.lightGrey,
          appBar: PreferredSize(
              preferredSize:
              sSize.Size.fromHeight(SizeConfig.safeBlockVertical * 9),
              child: Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset:
                    const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Column(
                  children: [
                    VerticalSpacing(SizeConfig.safeBlockVertical * 7),
                    Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_20),
                              SizedBox(
                                width: WidthDimension.w_18,
                                height: HeightDimension.h_15,
                                child: Image.asset(
                                  TMTImages.icBack,
                                  color: AppColor.neutral_800,
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_6),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_6),
                        Expanded(
                          child: TMTTextWidget(
                            maxLines: 1,
                            title: _buyerOrderController.orderItemDetails?.productName ?? "",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                    VerticalSpacing(HeightDimension.h_8),
                  ],
                ),
              )),
          body: Column(
            children: [
              Visibility(
                visible: ((_buyerOrderController.orderItemDetails?.status == "REJECTED") && _getRejectReason().isNotEmpty),
                child: Padding(
                  padding: EdgeInsets.only(top: HeightDimension.h_15, left: WidthDimension.w_15, right: WidthDimension.w_15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TMTTextWidget(title: "Order Rejected", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_14,
                        color: AppColor.primary,
                        fontWeight: FontWeight.w600,
                      ),),
                      CustomPopupMenu(
                        menuBuilder: () => TMTRoundedCornersContainer(
                          borderRadius: BorderRadius.zero,
                          margin: EdgeInsets.only(left: WidthDimension.w_100),
                          width: WidthDimension.w_190,
                          bgColor: AppColor.neutral_100,
                          borderColor: AppColor.arrowColor,
                          child: Column(
                            children: [
                              Container(
                                width: double.infinity,
                                color: AppColor.arrowColor,
                                padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                                child: TMTTextWidget(title: _getRejectReason(), style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_12,
                                  color: AppColor.neutral_100,
                                  fontWeight: FontWeight.w500,
                                ),),
                              ),
                            ],
                          ),
                        ),
                        barrierColor: Colors.transparent,
                        pressType: PressType.singleClick,
                        arrowColor: AppColor.arrowColor,
                        position: PreferredPosition.bottom,
                        child: TMTTextWidget(title: "Details", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.primary,
                            fontWeight: FontWeight.w600,
                            textDecoration: TextDecoration.underline
                        ),),
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      VerticalSpacing(HeightDimension.h_20),
                      Center(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(TMTRadius.r_10), // Image border
                          child: SizedBox(
                            height: HeightDimension.h_122,
                            width: HeightDimension.h_115,
                            child: TMTCachedImage.networkImage(_buyerOrderController.orderItemDetails?.productImage ?? "", fit: BoxFit.cover),
                          ),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_10),
                      TMTTextWidget(title: "Order ID: #${_buyerOrderController.orderItemDetails?.orderId}", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_12,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w400,
                      ),),
                      VerticalSpacing(HeightDimension.h_4),
                      TMTTextWidget(title: _buyerOrderController.orderItemDetails?.productName ?? "", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_14,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w400,
                      ),),
                      TMTTextWidget(title: "Sold By: ${_buyerOrderController.orderItemDetails?.sellerStore?.name ?? ""}", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_12,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w400,
                      ),),
                      TMTTextWidget(title: "Size: M", style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_12,
                        color: AppColor.textColor,
                        fontWeight: FontWeight.w400,
                      ),),
                      VerticalSpacing(HeightDimension.h_15),
                      Visibility(
                        visible: (_buyerOrderController.orderItemDetails?.order?.orderPaymentMappings?.isNotEmpty ?? false) ? _buyerOrderController.orderItemDetails?.orderedItemStatuses?.last.status == "AUTO_CANCELLED" ? true : _buyerOrderController.orderItemDetails?.order?.orderPaymentMappings?.first.paymentStatus == "SUCCEEDED" : false,
                        child: Container(
                          margin: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                            child: _buyerOrderController.getTrackingWidget(_buyerOrderController.orderItemDetails?.shippingMethod != "PICKUP", _buyerOrderController.orderItemDetails?.orderedItemStatuses, CancelGetModel(orderId: _buyerOrderController.orderItemDetails?.orderId ?? 0, sellerId: _buyerOrderController.orderItemDetails?.sellerStore?.id ?? 0), ReturnGetModel(orderId: _buyerOrderController.orderItemDetails?.orderId ?? 0, sellerId: _buyerOrderController.orderItemDetails?.sellerStore?.id ?? 0, productId: _buyerOrderController.orderItemDetails?.productId))),
                      ),
                      VerticalSpacing(HeightDimension.h_10),
                      GestureDetector(
                        onTap: () async {
                          await Get.toNamed(AppRoutes.confirmOrderScreen, arguments: [_buyerOrderController.orderItemDetails?.orderId])?.then((value) {
                            _buyerOrderController.getOrderItemDetails(context, orderId, callback: (id){
                              _buyerOrderController.getOrderDetails(context, id!, callback: () async {
                                await Future.delayed(const Duration(milliseconds: 200)).then((value){
                                  setState(() {

                                  });
                                });
                              });
                            });
                          });
                        },
                        child: Container(
                          color: AppColor.neutral_100,
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                          child: Row(
                            children: [
                              TMTTextWidget(title: "Order Details", style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_16,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w800,
                              ),),
                              const Spacer(),
                              SizedBox(
                                height: HeightDimension.h_18,
                                width: HeightDimension.h_18,
                                child: Image.asset(TMTImages.icNext, color: AppColor.neutral_800,),
                              )
                            ],
                          ),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_20),
                      _getAddress(_buyerOrderController.orderItemDetails?.shippingMethod != "PICKUP", _buyerOrderController.orderItemDetails?.productDetailsInJson),
                      VerticalSpacing(HeightDimension.h_15),
                    ],
                  ),
                ),
              ),
              Visibility(
                visible: (_buyerOrderController.orderItemDetails?.order?.orderPaymentMappings?.isNotEmpty ?? false) ? _buyerOrderController.orderItemDetails?.orderedItemStatuses?.last.status == "AUTO_CANCELLED" ? false : _checkOrderTime() : false,
                child: Container(
                  padding: EdgeInsets.only(
                      left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                  decoration: BoxDecoration(boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 3,
                      blurRadius: 5,
                      offset: const Offset(0, 3), // changes position of shadow
                    ),
                  ], color: AppColor.neutral_100),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TMTTextWidget(title: _buyerOrderController.getTotalSumAmount(),
                            style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.primaryBG,
                              fontWeight: FontWeight.w700,
                            ),),
                          TMTTextWidget(
                            title: "Pay Amount", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_12,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w400,
                          ),),
                        ],
                      ),
                      const Spacer(),
                      InkWell(
                        onTap: () {
                          if (isDateWithinLast24Hours(_buyerOrderController.orderItemDetails?.createdAt?.subtract(const Duration(minutes: 2)) ?? DateTime.now())) {
                            _startPayment(_buyerOrderController.orderItemDetails);
                          } else {
                            Get.back();
                            TMTToast.showErrorToast(context, "This order is expired", title: "Alert");
                          }
                        },
                        child: Container(
                          height: HeightDimension.h_50,
                          width: WidthDimension.w_190,
                          padding: EdgeInsets.only(
                              top: HeightDimension.h_12,
                              bottom: HeightDimension.h_12,
                              left: WidthDimension.w_18,
                              right: WidthDimension.w_18),
                          decoration: BoxDecoration(
                              color: AppColor.primaryBG,
                              border: Border.all(
                                  color: AppColor.primaryBG, width: 1),
                              borderRadius: const BorderRadius.all(
                                  Radius.circular(TMTRadius.r_30))),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TMTTextWidget(
                                title: "PAY NOW",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_18,
                                  color: AppColor.neutral_100,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          bottomNavigationBar: CommonBottomNavigationBar(
              currentSelectedItem: 4,
              onTap: (index) {
                Get.offAllNamed(AppRoutes.dashBoardScreen,
                    arguments: index);
              }),
        );
      }
    );
  }

  /// get widget based on pickup / delivery
  Widget _getAddress(bool isDeliveryTracking, ProductDetailsInJson? productDetailsInJson) {
    if (isDeliveryTracking) {
      return Container(
        width: double.infinity,
        padding: EdgeInsets.only(
            left: WidthDimension.w_20,
            right: WidthDimension.w_20,
            top: HeightDimension.h_15,
            bottom: HeightDimension.h_15),
        color: AppColor.neutral_100,
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: HeightDimension.h_15,
                  height: HeightDimension.h_20,
                  child: Image.asset(TMTImages.icDropLocation),
                ),
                HorizontalSpacing(WidthDimension.w_10),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TMTTextWidget(title: "Delivery address", style: TMTFontStyles.textTeen(
                      fontSize: TMTFontSize.sp_16,
                      color: AppColor.neutral_800,
                      fontWeight: FontWeight.w700,
                    ),),
                    VerticalSpacing(HeightDimension.h_15),
                    TMTTextWidget(title: productDetailsInJson?.deliveryAddress?.firstName ?? "", style: TMTFontStyles.textTeen(
                      fontSize: TMTFontSize.sp_16,
                      color: AppColor.textColor,
                      fontWeight: FontWeight.w700,
                    ),),
                    VerticalSpacing(HeightDimension.h_5),
                    TMTTextWidget(title: "${productDetailsInJson?.deliveryAddress?.address1 ?? ""} ${productDetailsInJson?.deliveryAddress?.city ?? ""}", style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_14,
                      color: AppColor.textColor,
                      fontWeight: FontWeight.w400,
                    ),),
                    TMTTextWidget(title: "${productDetailsInJson?.deliveryAddress?.country ?? ""}, ${productDetailsInJson?.deliveryAddress?.postCode ?? ""}", style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_14,
                      color: AppColor.textColor,
                      fontWeight: FontWeight.w400,
                    ),),
                    Visibility(
                        visible: productDetailsInJson?.deliveryAddress?.phoneNumber?.isNotEmpty ?? false,
                        child: VerticalSpacing(HeightDimension.h_5)),
                    Visibility(
                      visible: productDetailsInJson?.deliveryAddress?.phoneNumber?.isNotEmpty ?? false,
                      child: Row(
                        children: [
                          TMTTextWidget(title: "Phone number - ", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                          TMTTextWidget(title: productDetailsInJson?.deliveryAddress?.phoneNumber ?? "", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w400,
                          ),),
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ],
        ),
      );
    } else {
      return Container(
        width: double.infinity,
        padding: EdgeInsets.only(
            left: WidthDimension.w_20,
            right: WidthDimension.w_20,
            top: HeightDimension.h_15,
            bottom: HeightDimension.h_15),
        color: AppColor.neutral_100,
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: HeightDimension.h_15,
                  height: HeightDimension.h_20,
                  child: Image.asset(TMTImages.icDropLocation),
                ),
                HorizontalSpacing(WidthDimension.w_10),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TMTTextWidget(title: "Pickup address", style: TMTFontStyles.textTeen(
                      fontSize: TMTFontSize.sp_16,
                      color: AppColor.neutral_800,
                      fontWeight: FontWeight.w700,
                    ),),
                    VerticalSpacing(HeightDimension.h_15),
                    TMTTextWidget(title: productDetailsInJson?.pickupAddress?.name ?? "", style: TMTFontStyles.textTeen(
                      fontSize: TMTFontSize.sp_16,
                      color: AppColor.textColor,
                      fontWeight: FontWeight.w700,
                    ),),
                    VerticalSpacing(HeightDimension.h_5),
                    TMTTextWidget(title: "${productDetailsInJson?.pickupAddress?.addressLine1 ?? ""} ${productDetailsInJson?.pickupAddress?.city ?? ""}", style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_14,
                      color: AppColor.textColor,
                      fontWeight: FontWeight.w400,
                    ),),
                    TMTTextWidget(title: "${productDetailsInJson?.pickupAddress?.country ?? ""}, ${productDetailsInJson?.pickupAddress?.postCode ?? ""}", style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_14,
                      color: AppColor.textColor,
                      fontWeight: FontWeight.w400,
                    ),),
                    Visibility(
                        visible: productDetailsInJson?.pickupAddress?.contact?.isNotEmpty ?? false,
                        child: VerticalSpacing(HeightDimension.h_5)),
                    Visibility(
                      visible: productDetailsInJson?.pickupAddress?.contact?.isNotEmpty ?? false,
                      child: Row(
                        children: [
                          TMTTextWidget(title: "Phone number - ", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          ),),
                          TMTTextWidget(title: productDetailsInJson?.pickupAddress?.contact ?? "", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w400,
                          ),),
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ],
        ),
      );
    }
  }

  /// start payment process
  void _startPayment(OrderItemDetails? orderItemDetails) {
    try {
      _buyerOrderController.postCreateCustomer(context, (customerId) {
        if (customerId?.isNotEmpty ?? false) {
          _buyerOrderController.getCards(context, (cards) async {
            if (cards != null) {
              if (cards.data.isNotEmpty) {
                await Get.toNamed(AppRoutes.ordersCardsCheckoutScreen, arguments: orderItemDetails?.orderId ?? 0)?.then((value){
                  _callAPI();
                });
              }
              else {
                _buyerOrderController.postCreatePaymentIntent(context, (data) async {
                  _buyerOrderController.paymentUsingCard(data : data, context: context, orderId: orderItemDetails?.orderId ?? 0);
                }, PostCreatePaymentIntentRequest(
                    amount: _buyerOrderController.getTotalSumAmountInt(),
                    paymentMethod: ["cards"],
                    shipping: PRShipping(address: _getPayAddress()), orderId: orderItemDetails?.orderId.toString() ?? ""));
              }
            }
            else {
              _buyerOrderController.postCreatePaymentIntent(context, (data) async {
                _buyerOrderController.paymentUsingCard(data : data, context: context, orderId: orderItemDetails?.orderId ?? 0);
              }, PostCreatePaymentIntentRequest(
                  amount: _buyerOrderController.getTotalSumAmountInt(),
                  paymentMethod: ["cards"],
                  shipping: PRShipping(address: _getPayAddress()), orderId: orderItemDetails?.orderId.toString() ?? ""));
            }
          });
        }
        else {
          _buyerOrderController.postCreatePaymentIntent(context, (data) async {
            _buyerOrderController.paymentUsingCard(data : data, context: context, orderId: orderItemDetails?.orderId ?? 0);
          }, PostCreatePaymentIntentRequest(
              amount: _buyerOrderController.getTotalSumAmountInt(),
              paymentMethod: ["cards"],
              shipping: PRShipping(address: _getPayAddress()), orderId: orderItemDetails?.orderId.toString() ?? ""));
        }
      });
    } catch (e) {
      print(e.toString());
    }
  }

  PRAddress _getPayAddress() {
    try {
      return PRAddress(
        line1: address.first.address1,
        line2: address.first.address2,
        postalCode: address.first.postCode,
        city: address.first.city,
        state:  address.first.state,
        country: address.first.country,
      );
    } catch (e) {
      return PRAddress(
          line1: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.addressLine1 ?? "",
          line2: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.addressLine2 ?? "",
          postalCode: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.postCode ?? "",
          city: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.city ?? "",
          state:  "",
          country: _buyerOrderController.orderDetails?.sellers?.first.orders?.first.productDetailsInJson?.pickupAddress?.country ??
              ""
      );
    }
  }

  /// get reason for rejection
  String _getRejectReason() {
    if (_buyerOrderController.orderItemDetails?.orderedItemStatuses?.isNotEmpty ?? false) {
      String v = _buyerOrderController.orderItemDetails?.orderedItemStatuses?.last.otherReasonText ?? "";
      if (v.isEmpty) {
        return _buyerOrderController.orderItemDetails?.orderedItemStatuses?.last.reason?.text ?? "";
      } else {
        return v;
      }
    } else {
      return "";
    }
  }

  /// call api
  void _callAPI() {
    if (TMTLocalStorage.getUserLoggedIn()) {
      _addressScreenController.getAddress(context, callback: (data){
        setState(() {
          address = data ?? [];
        });
      });
    }
    _buyerOrderController.getOrderItemDetails(context, orderId, callback: (id){
      _buyerOrderController.getOrderDetails(context, id!, callback: () async {
        await Future.delayed(const Duration(milliseconds: 200)).then((value){
          setState(() {

          });
        });
      });
    });
  }

  /// check whether order is within 24 hours
  bool _checkOrderTime() {
    if (_buyerOrderController.orderItemDetails?.order?.orderPaymentMappings?.first.paymentStatus != "SUCCEEDED") {
      if(isDateWithinLast24Hours(_buyerOrderController.orderItemDetails?.createdAt ?? DateTime.now())){
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  /// check if given date is within 24 hours
  bool isDateWithinLast24Hours(DateTime inputDate) {
    // Get the current date
    DateTime currentDate = DateTime.now();

    // Calculate the time 24 hours ago from the current date
    DateTime dateAgo = currentDate.subtract(const Duration(days: 1));

    // Check if the input date is greater than or equal to seven days ago
    // and less than or equal to the current date
    var result = (inputDate.isAfter(dateAgo));
    return result;
  }
}