import 'package:device_info_plus/device_info_plus.dart';
import 'package:dio/dio.dart';
import 'package:external_path/external_path.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/apis.dart';
import 'package:take_my_tack/data/model/request/post_create_payment_intent_request.dart';
import 'package:take_my_tack/data/model/request/post_make_payment_request.dart';
import 'package:take_my_tack/data/model/response/get_buyer_order_detail_response.dart';
import 'package:take_my_tack/data/model/response/get_buyer_orders_response.dart';
import 'package:take_my_tack/data/model/response/get_cancel_reasons_response.dart';
import 'package:take_my_tack/data/model/response/get_cards_response.dart';
import 'package:take_my_tack/data/model/response/get_delivery_address_response.dart';
import 'package:take_my_tack/data/model/response/get_order_item_response.dart';
import 'package:take_my_tack/data/model/response/get_refund_reasons_response.dart';
import 'package:take_my_tack/data/model/response/post_create_payment_intent_response.dart';
import 'package:take_my_tack/data/model/response/post_payment_off_session_response.dart';
import 'package:take_my_tack/data/repository_implementation/payment_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/product_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/utils/pdf_viewer.dart';
import 'package:take_my_tack/presentation/widgets/loading_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_back_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_popup/src/platform/platform.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';
import 'package:take_my_tack/data/model/response/get_cards_response.dart' as _od;
import 'package:take_my_tack/data/model/response/get_buyer_order_detail_response.dart' as _orderDetails;
import 'package:stripe_platform_interface/src/models/payment_methods.dart' as _pm;
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:lecle_downloads_path_provider/lecle_downloads_path_provider.dart';

class BuyerOrderController extends GetxController {

  ProductRepositoryImpl productRepositoryImpl = ProductRepositoryImpl();

  PaymentRepositoryImpl paymentRepositoryImpl = PaymentRepositoryImpl();

  List<BuyerOrderData> _orders = [];
  _orderDetails.OrderDetails? orderDetails;
  OrderItemDetails? orderItemDetails;
  final TextEditingController searchTextController = TextEditingController();

  String? selectedStatus = "Orders";
  var ordersStatusList = [
    "Orders",
    "Cancelled",
    "Delivered",
    "Returned",
    "In Transit",
  ];

  String? selectedTime = "Last 30 day";
  var ordersTimeList = [
    "Last 30 day",
    "2023",
    "2022",
    "2021",
    "Older",
  ];

  /// cancel order stuff
  int selectedReason = -1;
  TextEditingController additionalTextController = TextEditingController();
  List<CancelOrderReason> cancelOrderReasons = [];

  /// return order stuff
  int selectedReturnReason = -1;
  TextEditingController additionalRefundTextController = TextEditingController();
  List<RefundReason> refundOrderReasons = [];
  List<Order> allProductsItems = [];

  CardFieldInputDetails? card;
  bool? saveCard = true;
  List<CardResponseData> cardsData = [];

  /*
   Method use to get buyer orders.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getOrders (BuildContext context) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        try {
          const Loading().start(context);
        } catch (e) {

        }
        try {
          var response = await productRepositoryImpl.getBuyerOrders(selectedStatus == "In Transit" ? "In_transit" : selectedStatus , selectedTime);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              _orders = right.data ?? [];
             update([GetControllerBuilders.orderListingScreenController]);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get buyer orders.
   Parameter- BuildContext context, int orderId.
   Return -> No Return type.
  */
  void getOrderDetails (BuildContext context, int orderId, {Function? callback}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getOrderDetailsById(orderId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              orderDetails = right.orderDetails;
              update([GetControllerBuilders.orderDetailsScreenController]);
              callback?.call();
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get buyer orders.
   Parameter- BuildContext context, int orderId.
   Return -> No Return type.
  */
  void getOrderDetailsByItems (BuildContext context, int orderId, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getOrderDetailsById(orderId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              allProductsItems = [];
              right.orderDetails?.sellers?.forEach((element) {
                element.orders?.forEach((e) {
                  allProductsItems.add(e);
                });
              });
              update([GetControllerBuilders.refundOrderScreenController]);
              callback.call();
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get buyer order item.
   Parameter- BuildContext context, int orderId.
   Return -> No Return type.
  */
  void getOrderItemDetails (BuildContext context, int orderId, {Function(int? id)? callback}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getOrderItemDetailsById(orderId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              orderItemDetails = right.orderDetails;
              update([GetControllerBuilders.orderItemDetailsScreenController]);
              callback?.call(orderItemDetails?.orderId);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// get filtered orders
  List<BuyerOrderData> getFilteredOrders () {
    if (searchTextController.text.isNotEmpty) {
      return _orders.where((element) => element.productName.toLowerCase().contains(searchTextController.text.toLowerCase())).toList();
    }
    return _orders;
  }

  /// get total items count
  int getTotalItemsCount() {
    int count = 0;
    orderDetails?.sellers?.forEach((element) {
      element.orders?.forEach((element) {
        count = count + (element.quantity ?? 0);
      });
    });
    return count;
  }

  /// get total sum price of items
  double getItemPrices() {
    double subCostPrice = 0;
    orderDetails?.sellers?.forEach((element) {
      subCostPrice = subCostPrice + (element.subCost ?? 0);
    });
    return subCostPrice;
  }

  /// get product handling price charges
  double getProductHandlingPrice(int index) {
    try {
      /// calculate sub cost of products
      double subCost = 0;
      orderDetails?.sellers![index].orders!.forEach((element) {
        subCost = subCost + element.salePrice!;
      });

      var charges = 0;
      if (orderDetails?.sellers![index].orders!.first.shippingMethod == "PICKUP") {
        charges = ((orderDetails?.shippingSummary![index].seller!.pickupFromStoreHandlingCharges ?? 0));
      }
      else {
        charges = (orderDetails?.shippingSummary![index].seller!.isFreeShippingEnabled == 1 &&  subCost > (orderDetails?.shippingSummary![index].seller!.freeShippingMinimumCost ?? 0)) ? 0 : (orderDetails?.shippingSummary![index].totalWeightShippingCost ?? 0);
      }
      return charges.toDouble();
    } catch (error) {
      return 0;
    }
  }

  double getProductHandlingSumPrice () {
    try {
      double subCost = 0;
      for (int i=0; i<(orderDetails?.sellers!.length ?? 0); i++) {
        subCost = subCost + getProductHandlingPrice(i);
      }
      return subCost;
    } catch (error) {
      return 0;
    }
  }

  /// get total tax
  String getTotalTax() {
    var grossTax = calculatePercentage(getItemPrices().toDouble(), orderDetails?.taxInPercentage?.toDouble() ?? 0);
    return "£${grossTax.toStringAsFixed(2)}";
  }

  /// get total sum price of items
  int getItemCost() {
    int subCostPrice = 0;
    orderDetails?.sellers?.forEach((element) {
      element.orders?.forEach((oElement) {
        subCostPrice = subCostPrice + (oElement.salePrice ?? 0);
      });
    });
    return subCostPrice;
  }

  /// get total payable amount
  String getTotalSumAmount() {
    var grossTax = calculatePercentage(getItemPrices().toDouble(), orderDetails?.taxInPercentage?.toDouble() ?? 0);
    var priceWithoutShipping = getItemPrices() + grossTax;
    var sum = priceWithoutShipping + getProductHandlingSumPrice();
    return "£${sum.toStringAsFixed(2)}";
  }

  /// get total payable amount
  int getTotalSumAmountInt() {

    List<double> prices = [];
    double totalWithoutTax = 0;
    for(int i = 0; i< (orderDetails?.sellers?.length ?? 0); i++) {

      if (orderDetails!.sellers?[i].orders?.first.shippingMethod == "PICKUP") {
        double sum = getItemCost().toDouble() + (orderDetails!.sellers?[i].seller?.pickupFromStoreHandlingCharges ?? 0);
        prices.add(sum);
      } else {
        double sum = (orderDetails!.sellers?[i].seller?.isFreeShippingEnabled == 1 &&  getItemCost().toDouble() > (orderDetails!.sellers?[i].seller?.freeShippingMinimumCost ?? 0)) ? getItemCost().toDouble() : getItemCost().toDouble() + (orderDetails?.sellers?[i].seller?.freeShippingMinimumCost ?? 0);
        prices.add(sum);
      }
      totalWithoutTax += prices[i];
    }

    var grossTax = calculatePercentage(totalWithoutTax, orderDetails?.taxInPercentage?.toDouble() ?? 0);
    var sum = totalWithoutTax + grossTax;
    return sum.toInt();
  }

  /// get percentage of given value
  double calculatePercentage(double value, double percentage) {
    double result = (value * percentage) / 100;
    return result;
  }

  /*
   Method use to get cancel reasons list.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getCancelReasonsList (BuildContext context) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getCancelRequestReasons();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              cancelOrderReasons = right.cancelOrderReasons ?? [];
              update([GetControllerBuilders.cancelOrderScreenController]);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to cancel order.
   Parameter- BuildContext context, int orderId, Function callback.
   Return -> No Return type.
  */
  void postCancelOrder (BuildContext context, int sellerId, int orderId, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.postCancelOrder(sellerId, orderId, cancelOrderReasons[selectedReason].id ?? 0, additionalTextController.text);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              selectedReason = -1;
              additionalTextController.clear();
              callback.call();
            } else {
              if (right.error?.messages.first == "Invalid Access Token" || right.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get return/refund reasons list.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getRefundReasonsList (BuildContext context) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getRefundRequestReasons();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              refundOrderReasons = right.refundReasons ?? [];
              update([GetControllerBuilders.refundOrderScreenController]);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to download order invoice.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getOrderInvoice (BuildContext context, String orderId, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      if (androidInfo.version.sdkInt>32) {
        var status1 = await Permission.manageExternalStorage.status;
        if (!status1.isGranted) {
          await Permission.manageExternalStorage.request();
        }
      } else {
        var status = await Permission.storage.status;
        if (!status.isGranted) {
          await Permission.storage.request();
        }
      }
      if (value) {
        const Loading().start(context);
        try {
          var fileName = "${orderId}_invoice.pdf";
          File file;
          if (Platform.isIOS) {
            final dir = await getApplicationDocumentsDirectory();
            String? downloadsDirectoryPath = (await DownloadsPath.downloadsDirectory())?.path;
            file = File('${downloadsDirectoryPath ?? dir.path}/$fileName');
            download2("${Apis.baseUrl}${Apis.getOrderInvoice(orderId)}", file, context, fileName);
          }
          if (Platform.isAndroid) {
            int version = (double.tryParse(androidInfo.version.release) ?? 0.0).toInt();
            var path = version < 13 ? (await getExternalStorageDirectory())!.path :
            await ExternalPath.getExternalStoragePublicDirectory(ExternalPath.DIRECTORY_DOWNLOADS);
            file = File('$path/$fileName');
            download2("${Apis.baseUrl}${Apis.getOrderInvoice(orderId)}", file, context, fileName);
          }
        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
          if (error is PlatformException && error.code.contains("access_denied")) {
            var status = await Permission.storage.request();
            if (status == PermissionStatus.denied) {
              showPopup(context, message: "Storage permissions are required.", positiveText: "Okay", negativeText: "Dismiss", callBack: (e){});
              return;
            }
          } else {
            TMTToast.showErrorToast(context, "Something went wrong.");
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// download pdf
  Future download2(String url, File file, BuildContext context, String name) async {
    try {
      var response = await Dio().get(
        url,
        options: Options(
            responseType: ResponseType.bytes,
            headers: {"access-token": TMTLocalStorage.getString(GetXStorageConstants.jwtToken)},
            followRedirects: false,
            validateStatus: (status) {
              return status! < 500;
            }),
      );
      if (kDebugMode) {
        print(response.headers);
      }
      var raf = file.openSync(mode: FileMode.write);
      // response.data is List<int> type
      raf.writeFromSync(response.data);
      await raf.close();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PdfViewerPage(pdfPath: raf.path, name: name,),
        ),
      );
    } catch (e) {
      print(e);
    }
  }

  static void showPopup(
      BuildContext context,
      {String title = "Alert",
        required String message,
        required String positiveText,
        required String negativeText,
        required Function(bool isYes) callBack}) {
    showDialog(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext c) {
        return Center(
          child: Material(
            color: Colors.transparent,
            child: Container(
              width: 300,
              decoration: BoxDecoration(
                  color: AppColor.white,
                  borderRadius: BorderRadius.circular(14)
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  VerticalSpacing(20),
                  Text(
                    title,
                    style: TMTFontStyles.text(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.red),
                  ),
                  VerticalSpacing(10),
                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Divider(color: Colors.red),
                  ),
                  VerticalSpacing(10),
                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Text(
                      textAlign: TextAlign.center,
                      message,
                      style: TMTFontStyles.text(fontSize: 16.0),
                    ),
                  ),
                  VerticalSpacing(10),
                  TextButton(
                    child: Text(positiveText, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.red),),
                    onPressed: () async {
                      callBack.call(true);
                      Navigator.of(context).pop();
                    },
                  ),
                  VerticalSpacing(10)
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /*
   Method use to return order.
   Parameter- BuildContext context, int orderId, Function callback.
   Return -> No Return type.
  */
  void postReturnRefundOrder (BuildContext context, List<int> orderIds, Function callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.postRefundOrder(orderIds, refundOrderReasons[selectedReturnReason].id ?? 0, additionalRefundTextController.text);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              selectedReturnReason = -1;
              additionalRefundTextController.clear();
              callback.call();
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// return tracking widget
  Widget getTrackingWidget(bool isDeliveryTracking, List<OrderedItemStatus>? orderedItemStatuses, CancelGetModel args, ReturnGetModel returnArgs) {
    var lastStatus = "PENDING";
    try {
      lastStatus = orderedItemStatuses?.last.status.toString() ?? "";
    } catch (e) {}
    if (lastStatus.isEmpty) {
      return const SizedBox.shrink();
    }
    if (lastStatus.contains("AUTO_CANCELLED")) {
      return Container(
        width: double.infinity,
        color: AppColor.neutral_100,
        margin: EdgeInsets.only(
            bottom: HeightDimension.h_10),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              color: AppColor.primary,
              height: HeightDimension.h_46,
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment.center,
                children: [
                  HorizontalSpacing(
                      WidthDimension.w_10),
                  SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      TMTRoundedCornersContainer(
                        padding:
                        const EdgeInsets
                            .all(2),
                        bgColor: AppColor
                            .neutral_100,
                        child: Image.asset(
                          TMTImages
                              .icTickGreen, color: AppColor.primary,),
                      )
                  ),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                  TMTTextWidget(
                    title: "Order expired",
                    style: TMTFontStyles.text(
                      fontSize:
                      TMTFontSize.sp_15,
                      color: AppColor
                          .neutral_100,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                  const Spacer(),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                ],
              ),
            ),
          ],
        ),
      );
    }

    if ((orderedItemStatuses?.map((e) => e.status).toList().firstWhereOrNull((element) => element == "REJECTED") != null)) {
      return Container(
        width: double.infinity,
        color: AppColor.neutral_100,
        margin: EdgeInsets.only(
            bottom: HeightDimension.h_10),
        padding: EdgeInsets.only(
            top: HeightDimension.h_5),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              color: AppColor.neutral_100,
              height: HeightDimension.h_46,
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment.center,
                children: [
                  HorizontalSpacing(
                      WidthDimension.w_10),
                  SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      TMTRoundedCornersContainer(
                        padding:
                        const EdgeInsets
                            .all(2),
                        bgColor: AppColor
                            .green,
                        child: Image.asset(
                          TMTImages
                              .icTickGreen, color: Colors.white,),
                      )
                  ),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                  TMTTextWidget(
                    title: "Order Rejected",
                    style: TMTFontStyles.text(
                      fontSize:
                      TMTFontSize.sp_15,
                      color: AppColor.textColor,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                  const Spacer(),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              color: (lastStatus == "REJECTED") ? AppColor.green : AppColor.neutral_100,
              height: HeightDimension.h_46,
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment.center,
                children: [
                  HorizontalSpacing(
                      WidthDimension.w_10),
                  SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getRejectedTickIcon(0, lastStatus)
                  ),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                  TMTTextWidget(
                    title: "Refund Awaited",
                    style: TMTFontStyles.text(
                      fontSize:
                      TMTFontSize.sp_15,
                      color: (lastStatus == "REJECTED") ? AppColor
                          .neutral_100 : AppColor.textColor,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                  const Spacer(),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              color: lastStatus == "REFUNDED" ? AppColor.green : AppColor.neutral_100,
              height: HeightDimension.h_46,
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment.center,
                children: [
                  HorizontalSpacing(
                      WidthDimension.w_10),
                  SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getRejectedTickIcon(2, lastStatus)
                  ),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                  TMTTextWidget(
                    title: "Refund Amount Credited",
                    style: TMTFontStyles.text(
                      fontSize:
                      TMTFontSize.sp_15,
                      color: lastStatus == "REFUNDED" ? AppColor
                          .neutral_100 : AppColor.textColor,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                  const Spacer(),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                ],
              ),
            ),
          ],
        ),
      );
    }

    if (lastStatus.contains("REFUND") || lastStatus == "CANCELLED") {
      return Container(
        width: double.infinity,
        color: AppColor.neutral_100,
        margin: EdgeInsets.only(
            bottom: HeightDimension.h_10),
        padding: EdgeInsets.only(
            top: HeightDimension.h_5),
        child: Column(
          children: [
            Visibility(
              visible: (orderedItemStatuses?.map((e) => e.status).toList().firstWhereOrNull((element) => element == "CANCELLED") != null),
              child: Container(
                width: double.infinity,
                color: lastStatus == "" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                        height:
                        HeightDimension.h_14,
                        width:
                        HeightDimension.h_14,
                        child:
                        _getRefundTickIcon(-1, lastStatus)
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: "Order Cancelled",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
            ),
            Container(
              width: double.infinity,
              color: (lastStatus == "REFUND_REQUESTED" || lastStatus == "CANCELLED") ? AppColor.green : AppColor.neutral_100,
              height: HeightDimension.h_46,
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment.center,
                children: [
                  HorizontalSpacing(
                      WidthDimension.w_10),
                  SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getRefundTickIcon(0, lastStatus)
                  ),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                  TMTTextWidget(
                    title: (orderedItemStatuses?.map((e) => e.status.toString()).toList().contains("CANCELLED") ?? false) ? "Refund Requested" : "Return/Refund Requested",
                    style: TMTFontStyles.text(
                      fontSize:
                      TMTFontSize.sp_15,
                      color: (lastStatus == "REFUND_REQUESTED" || lastStatus == "CANCELLED") ? AppColor
                          .neutral_100 : AppColor.textColor,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                  const Spacer(),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                ],
              ),
            ),
            Visibility(
              visible: lastStatus != "CANCELLED",
              child: Container(
                width: double.infinity,
                color: lastStatus == "REFUND_REQ_APPROVED" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getRefundTickIcon(1, lastStatus)
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: (orderedItemStatuses?.map((e) => e.status.toString()).toList().contains("CANCELLED") ?? false) ? "Refund Request Approved" : "Return/Refund Approved",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "REFUND_REQ_APPROVED" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
            ),
            Visibility(
              visible: lastStatus == "REFUND_REQ_REJECTED",
              child: Container(
                width: double.infinity,
                color: lastStatus == "REFUND_REQ_REJECTED" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getRefundTickIcon(2, lastStatus)
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: (orderedItemStatuses?.map((e) => e.status.toString()).toList().contains("CANCELLED") ?? false) ? "Refund Request Rejected" : "Return/Refund Rejected",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "REFUND_REQ_REJECTED" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
            ),
            Visibility(
              visible: lastStatus != "CANCELLED",
              child: Container(
                width: double.infinity,
                color: lastStatus == "REFUND_PRODUCT_COLLECTED" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getRefundTickIcon(3, lastStatus)
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: (orderedItemStatuses?.map((e) => e.status.toString()).toList().contains("CANCELLED") ?? false) ? "Product Received By Seller" : "Product Received By Seller",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "REFUND_PRODUCT_COLLECTED" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
            ),
            Container(
              width: double.infinity,
              color: lastStatus == "REFUNDED" ? AppColor.green : AppColor.neutral_100,
              height: HeightDimension.h_46,
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment.center,
                children: [
                  HorizontalSpacing(
                      WidthDimension.w_10),
                  SizedBox(
                    height:
                    HeightDimension.h_14,
                    width:
                    HeightDimension.h_14,
                    child:
                    _getRefundTickIcon(4, lastStatus)
                  ),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                  TMTTextWidget(
                    title: (orderedItemStatuses?.map((e) => e.status.toString()).toList().contains("CANCELLED") ?? false) ? "Refund Amount Credited" : "Return/Refund Credited",
                    style: TMTFontStyles.text(
                      fontSize:
                      TMTFontSize.sp_15,
                      color: lastStatus == "REFUNDED" ? AppColor
                          .neutral_100 : AppColor.textColor,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                  const Spacer(),
                  HorizontalSpacing(
                      WidthDimension.w_15),
                ],
              ),
            ),
          ],
        ),
      );
    }
    else {
      if (isDeliveryTracking) {
        return Container(
          width: double.infinity,
          color: AppColor.neutral_100,
          margin: EdgeInsets.only(
              bottom: HeightDimension.h_10),
          padding: EdgeInsets.only(
              top: HeightDimension.h_5),
          child: Column(
            children: [
              Container(
                width: double.infinity,
                color: lastStatus == "PENDING" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                        height:
                        HeightDimension.h_14,
                        width:
                        HeightDimension.h_14,
                        child:
                        _getDeliveryTickIcon(0, lastStatus)
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: "Order Placed",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "PENDING" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    Visibility(
                      visible: lastStatus == "PENDING" && isDateWithinLast7Days(orderedItemStatuses?.last.createdAt ?? DateTime.now()),
                      child: GestureDetector(
                        onTap: () {
                          Get.toNamed(AppRoutes.cancelOrderScreen, arguments: args);
                        },
                        child: TMTRoundedCornersContainer(
                          child: TMTTextWidget(title: "Cancel", style: TMTFontStyles.text(color: lastStatus == "PENDING" ? AppColor.neutral_100 : AppColor.green, fontWeight: FontWeight.w800),),
                        ),
                      ),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                color: lastStatus == "PROCESSING" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getDeliveryTickIcon(1, lastStatus),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: "Order Confirmed",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "PROCESSING" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    Visibility(
                      visible: lastStatus == "PROCESSING" && isDateWithinLast7Days(orderedItemStatuses?.last.createdAt ?? DateTime.now()),
                      child: GestureDetector(
                        onTap: () {
                          Get.toNamed(AppRoutes.cancelOrderScreen, arguments: args);
                        },
                        child: TMTRoundedCornersContainer(
                          child: TMTTextWidget(title: "Cancel", style: TMTFontStyles.text(color: lastStatus == "PROCESSING" ? AppColor.neutral_100 : AppColor.green, fontWeight: FontWeight.w800),),
                        ),
                      ),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                color: lastStatus == "SHIPPED" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getDeliveryTickIcon(2, lastStatus),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: "Processing",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "SHIPPED" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                color: lastStatus == "DELIVERED" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getDeliveryTickIcon(3, lastStatus),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: "Delivered",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "DELIVERED" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    Visibility(
                      visible: (lastStatus == "DELIVERED" && isDateWithinLast7Days(orderedItemStatuses?.last.createdAt ?? DateTime.now())),
                      child: GestureDetector(
                        onTap: () {
                          Get.toNamed(AppRoutes.returnRefundOrderScreen, arguments: returnArgs);
                        },
                        child: TMTRoundedCornersContainer(
                          child: TMTTextWidget(title: "Return/Refund", style: TMTFontStyles.text(color: lastStatus == "DELIVERED" ? AppColor.neutral_100 : AppColor.green, fontWeight: FontWeight.w800),),
                        ),
                      ),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
            ],
          ),
        );
      } else {
        return Container(
          width: double.infinity,
          color: AppColor.neutral_100,
          margin: EdgeInsets.only(
              bottom: HeightDimension.h_10),
          padding: EdgeInsets.only(
              top: HeightDimension.h_5),
          child: Column(
            children: [
              Container(
                width: double.infinity,
                color: lastStatus == "PENDING" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                        height:
                        HeightDimension.h_14,
                        width:
                        HeightDimension.h_14,
                        child:
                        _getPickupTickIcon(0, lastStatus)
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: "Order Placed",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "PENDING" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    Visibility(
                      visible: lastStatus == "PENDING" && isDateWithinLast7Days(orderedItemStatuses?.last.createdAt ?? DateTime.now()),
                      child: GestureDetector(
                        onTap: () {
                          Get.toNamed(AppRoutes.cancelOrderScreen, arguments: args);
                        },
                        child: TMTRoundedCornersContainer(
                          child: TMTTextWidget(title: "Cancel", style: TMTFontStyles.text(color: lastStatus == "PENDING" ? AppColor.neutral_100 : AppColor.green, fontWeight: FontWeight.w800),),
                        ),
                      ),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                color: lastStatus == "" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getPickupTickIcon(1, lastStatus),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: "Order Confirmed",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    Visibility(
                      visible: lastStatus == "" && isDateWithinLast7Days(orderedItemStatuses?.last.createdAt ?? DateTime.now()),
                      child: GestureDetector(
                        onTap: () {
                          Get.toNamed(AppRoutes.cancelOrderScreen, arguments: args);
                        },
                        child: TMTRoundedCornersContainer(
                          child: TMTTextWidget(title: "Cancel", style: TMTFontStyles.text(color: lastStatus == "" ? AppColor.neutral_100 : AppColor.green, fontWeight: FontWeight.w800),),
                        ),
                      ),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                color: lastStatus == "PROCESSING" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getPickupTickIcon(2, lastStatus),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: "Ready for pickup",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "PROCESSING" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    Visibility(
                      visible: lastStatus == "PROCESSING" && isDateWithinLast7Days(orderedItemStatuses?.last.createdAt ?? DateTime.now()),
                      child: GestureDetector(
                        onTap: () {
                          Get.toNamed(AppRoutes.cancelOrderScreen, arguments: args);
                        },
                        child: TMTRoundedCornersContainer(
                          child: TMTTextWidget(title: "Cancel", style: TMTFontStyles.text(color: lastStatus == "PROCESSING" ? AppColor.neutral_100 : AppColor.green, fontWeight: FontWeight.w800),),
                        ),
                      ),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                color: lastStatus == "DELIVERED" ? AppColor.green : AppColor.neutral_100,
                height: HeightDimension.h_46,
                child: Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    HorizontalSpacing(
                        WidthDimension.w_10),
                    SizedBox(
                      height:
                      HeightDimension.h_14,
                      width:
                      HeightDimension.h_14,
                      child:
                      _getPickupTickIcon(3, lastStatus),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    TMTTextWidget(
                      title: "Order Complete",
                      style: TMTFontStyles.text(
                        fontSize:
                        TMTFontSize.sp_15,
                        color: lastStatus == "DELIVERED" ? AppColor
                            .neutral_100 : AppColor.textColor,
                        fontWeight:
                        FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                    Visibility(
                      visible: (lastStatus == "DELIVERED" && isDateWithinLast7Days(orderedItemStatuses?.last.createdAt ?? DateTime.now())),
                      child: GestureDetector(
                        onTap: () {
                          Get.toNamed(AppRoutes.returnRefundOrderScreen, arguments: returnArgs);
                        },
                        child: TMTRoundedCornersContainer(
                          child: TMTTextWidget(title: "Return/Refund", style: TMTFontStyles.text(color: lastStatus == "DELIVERED" ? AppColor.neutral_100 : AppColor.green, fontWeight: FontWeight.w800),),
                        ),
                      ),
                    ),
                    HorizontalSpacing(
                        WidthDimension.w_15),
                  ],
                ),
              ),
            ],
          ),
        );
      }
    }
  }

  /// get tick icon
  Widget _getDeliveryTickIcon(int position, String lastStatus) {
    if (position == 0) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "PENDING" ? AppColor
            .neutral_100 : (lastStatus == "PROCESSING" || lastStatus == "SHIPPED" || lastStatus == "DELIVERED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "PENDING" ? AppColor.green : Colors.white,),
      );
    } else if (position == 1) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "PROCESSING" ? AppColor
            .neutral_100 : (lastStatus == "SHIPPED" || lastStatus == "DELIVERED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "PROCESSING" ? AppColor.green : Colors.white,),
      );
    } else if (position == 2) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "SHIPPED" ? AppColor
            .neutral_100 : (lastStatus == "DELIVERED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "SHIPPED" ? AppColor.green : Colors.white,),
      );
    } else {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "DELIVERED" ? AppColor
            .neutral_100 : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "DELIVERED" ? AppColor.green : Colors.white,),
      );
    }
  }

  /// get tick icon
  Widget _getPickupTickIcon(int position, String lastStatus) {
    if (position == 0) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "PENDING" ? AppColor
            .neutral_100 : (lastStatus == "PROCESSING" || lastStatus == "SHIPPED" || lastStatus == "DELIVERED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "PENDING" ? AppColor.green : Colors.white,),
      );
    } else if (position == 1) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "" ? AppColor
            .neutral_100 : (lastStatus == "PROCESSING" || lastStatus == "DELIVERED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "" ? AppColor.green : Colors.white,),
      );
    } else if (position == 2) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "PROCESSING" ? AppColor
            .neutral_100 : (lastStatus == "DELIVERED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "PROCESSING" ? AppColor.green : Colors.white,),
      );
    } else {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "DELIVERED" ? AppColor
            .neutral_100 : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "DELIVERED" ? AppColor.green : Colors.white,),
      );
    }
  }

  /// get tick icon
  Widget _getRefundTickIcon(int position, String lastStatus) {
    if (position == -1) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: (lastStatus == "CANCELLED" || lastStatus == "REFUND_REQUESTED" || lastStatus == "REFUND_REQ_APPROVED" || lastStatus == "REFUND_REQ_REJECTED" || lastStatus == "REFUND_PRODUCT_COLLECTED" || lastStatus == "REFUNDED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: Colors.white,),
      );
    }
    else if (position == 0) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: (lastStatus == "REFUND_REQUESTED" || lastStatus == "CANCELLED") ? AppColor
            .neutral_100 : (lastStatus == "REFUND_REQ_APPROVED" || lastStatus == "REFUND_REQ_REJECTED" || lastStatus == "REFUND_PRODUCT_COLLECTED" || lastStatus == "REFUNDED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: (lastStatus == "REFUND_REQUESTED" || lastStatus == "CANCELLED") ? AppColor.green : Colors.white,),
      );
    } else if (position == 1) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "REFUND_REQ_APPROVED" ? AppColor
            .neutral_100 : (lastStatus == "REFUND_REQ_REJECTED" || lastStatus == "REFUND_PRODUCT_COLLECTED" || lastStatus == "REFUNDED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "REFUND_REQ_APPROVED" ? AppColor.green : Colors.white,),
      );
    } else if (position == 2) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "REFUND_REQ_REJECTED" ? AppColor
            .neutral_100 : (lastStatus == "REFUND_PRODUCT_COLLECTED" || lastStatus == "REFUNDED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "REFUND_REQ_REJECTED" ? AppColor.green : Colors.white,),
      );
    } else if (position == 3) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "REFUND_PRODUCT_COLLECTED" ? AppColor
            .neutral_100 : (lastStatus == "REFUNDED") ? AppColor
            .green : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "REFUND_PRODUCT_COLLECTED" ? AppColor.green : Colors.white,),
      );
    } else {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "REFUNDED" ? AppColor
            .neutral_100 : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "REFUNDED" ? AppColor.green : Colors.white,),
      );
    }
  }

  /// get tick icon
  Widget _getRejectedTickIcon(int position, String lastStatus) {
   if (position == 0) {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: (lastStatus == "REJECTED") ? AppColor
            .neutral_100 : AppColor.green,
        child: Image.asset(
          TMTImages
              .icTickGreen, color: (lastStatus == "REJECTED") ? AppColor.green : Colors.white,),
      );
    }
   else {
      return TMTRoundedCornersContainer(
        padding:
        const EdgeInsets
            .all(2),
        bgColor: lastStatus == "REFUNDED" ? AppColor
            .neutral_100 : const Color(
            0xFFBBBBBB),
        child: Image.asset(
          TMTImages
              .icTickGreen, color: lastStatus == "REFUNDED" ? AppColor.green : Colors.white,),
      );
    }
  }

  /*
   Method use to create payment intent.
   Parameter- BuildContext context, Function callback.
   Return -> No Return type.
  */
  void postCreatePaymentIntent (BuildContext context, Function (PIData? data) callback, PostCreatePaymentIntentRequest request) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        try {
          const Loading().start(context);
        } catch (e) {}
        try {
          var response = await paymentRepositoryImpl.postCreatePaymentIntent(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              callback.call(right.data);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                callback.call(right.data);
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// make payment using card
  Future<void> paymentUsingCard({PIData? data, required BuildContext context, required int orderId, Function? callback}) async {
    /// Stripe payment
    Stripe.publishableKey = "pk_test_51NPfpzSCzdOYRdbbDTCvvwFC1Exjx58UMUmOcHtKtUy85iamihgoj2kkKidqYB5PrYKS93I3nrjWBDxbNloFWHLh00qwEgFafB";
    await Stripe.instance.applySettings();
    if (!context.mounted) return;
    if (data != null) {
      showDialog(
          barrierDismissible: false,
          context: context, builder: (context) {
        return StatefulBuilder(
            builder: (c, setState) {
              return Material(
                color: Colors.white,
                child: TMTBackButton(
                  onWillPop: () {
                    return Future.value(false);
                  },
                  child: Container(
                    padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                    child: Column(
                      children: [
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: (){
                                Navigator.pop(c);
                                TMTToast.showErrorToast(context, "Do not worry, we have placed your order. You can try paying again", title: "Payment Failed");
                              },
                              child: SizedBox(
                                height: HeightDimension.h_20,
                                width: HeightDimension.h_20,
                                child: Image.asset(TMTImages.icBack, color: AppColor.neutral_800,),
                              ),
                            ),
                            TMTTextWidget(title: "ADD CARD DETAILS", style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_18, fontWeight: FontWeight.w700, color: AppColor.neutral_700),),
                            SizedBox(
                              height: HeightDimension.h_20,
                              width: HeightDimension.h_20,
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        CardField(
                          enablePostalCode: true,
                          countryCode: 'GB',
                          postalCodeHintText: 'Enter the UK postal code',
                          onCardChanged: (c) {
                            setState(() {
                              card = c;
                            });
                          },
                        ),
                        const SizedBox(height: 20),
                        CheckboxListTile(
                          activeColor: AppColor.primary,
                          controlAffinity: ListTileControlAffinity.leading,
                          value: saveCard,
                          onChanged: (value) {
                            setState(() {
                              saveCard = value;
                            });
                          },
                          title: const Text('Save card during payment'),
                        ),
                        LoadingButton(
                          onPressed: card?.complete == true
                              ? () async {
                            await _handlePayPress(data, c, orderId, callback: callback);
                          }
                              : null,
                          text: 'Pay',
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              );
            }
        );
      });
    }
  }

  /// handle payment
  Future<void> _handlePayPress(PIData data, BuildContext context, int orderId, {Function? callback}) async {
    if (card == null) {
      return;
    }
    var paymentIntent;
    try {
      paymentIntent = await Stripe.instance.confirmPayment(
        paymentIntentClientSecret: data.clientSecret,
        data: const PaymentMethodParams.card(
          paymentMethodData: PaymentMethodData(
            billingDetails: _pm.BillingDetails(),
          ),
        ),
        options: PaymentMethodOptions(
          setupFutureUsage:
          saveCard == true ? PaymentIntentsFutureUsage.OffSession : null,
        ),
      );
      if (kDebugMode) {
        print(paymentIntent);
      }
      if (paymentIntent.status == PaymentIntentsStatus.Succeeded) {
        if (!context.mounted) return;
        TMTToast.showSuccessToast(context, "Payment successful, Seller would be shipping your order in 2-3 business days");
      } else {
        if (!context.mounted) return;
        TMTToast.showErrorToast(context, paymentIntent.toString());
      }
      Navigator.pop(context);
      if (callback == null) {
        Get.offNamed(AppRoutes.confirmOrderScreen, arguments: orderId);
      } else {
       callback.call();
      }
    } catch (e) {
      Navigator.pop(context);
      Get.offNamed(AppRoutes.confirmOrderScreen, arguments: orderId);
      if (e is StripeException) {
        TMTToast.showErrorToast(context, e.error.message ?? e.toString());
      } else {
        TMTToast.showErrorToast(context, e.toString());
      }
      if (kDebugMode) {
        print("Error : ${e.toString()}");
      }
    }
    return;
  }

  /// check if given date is within 7 days
  bool isDateWithinLast7Days(DateTime inputDate) {
    // Get the current date
    DateTime currentDate = DateTime.now();

    // Calculate the date 7 days ago from the current date
    DateTime sevenDaysAgo = currentDate.subtract(const Duration(days: 7));

    // Check if the input date is greater than or equal to seven days ago
    // and less than or equal to the current date
    return inputDate.isAfter(sevenDaysAgo) && inputDate.isBefore(currentDate);
  }

  /*
   Method use to create customer.
   Parameter- BuildContext context, Function callback.
   Return -> No Return type.
  */
  void postCreateCustomer (BuildContext context, Function(String? customerId) callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await paymentRepositoryImpl.postCreateCustomer();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              callback.call(right.customerId);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get cards.
   Parameter- BuildContext context, Function callback.
   Return -> No Return type.
  */
  void getCards (BuildContext context, Function(_od.OrderDetails? data) callback) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await paymentRepositoryImpl.getCards();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              cardsData = right.orderDetails?.data ?? [];
              callback.call(right.orderDetails);
              update([GetControllerBuilders.ordersCardsCheckoutScreen]);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                callback.call(right.orderDetails);
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get cards.
   Parameter- BuildContext context, Function callback.
   Return -> No Return type.
  */
  void makePaymentOffSession (BuildContext context, CardResponseData cardsData, Function(POSData? data) callback, String orderId, int totalAmount, AddressData defaultAddress) {
    var params = PostMakePaymentOffSessionRequest(amount: totalAmount, paymentMethodId: cardsData.id, shipping: PORShipping(address: POAddress(line1: defaultAddress.address1, line2: defaultAddress.address2, postalCode: defaultAddress.postCode, city: defaultAddress.city, state: defaultAddress.state, country: defaultAddress.country)), orderId: orderId);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await paymentRepositoryImpl.postPaymentOffSession(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              callback.call(right.data);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}

class CancelGetModel {
  final int orderId;
  final int sellerId;

  CancelGetModel({required this.orderId, required this.sellerId});
}

class ReturnGetModel {
  final int orderId;
  final int sellerId;
  int? productId;

  ReturnGetModel({required this.orderId, required this.sellerId, this.productId});
}