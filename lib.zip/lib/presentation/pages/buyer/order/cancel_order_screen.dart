import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/model/response/get_buyer_order_detail_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/buyer_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class CancelOrderScreen extends StatefulWidget {
  const CancelOrderScreen({super.key});

  @override
  State<StatefulWidget> createState() => _CancelOrderScreenState();
}

class _CancelOrderScreenState extends State<CancelOrderScreen> {

  final BuyerOrderController _buyerOrderController =
  Get.find<BuyerOrderController>();

  CancelGetModel args = Get.arguments;

  @override
  void initState() {
    _buyerOrderController.getCancelReasonsList(context);
    _buyerOrderController.getOrderDetails(context, args.orderId);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyerOrderController>(
        id: GetControllerBuilders.cancelOrderScreenController,
        init: _buyerOrderController,
        builder: (controller) {
        return Scaffold(
          resizeToAvoidBottomInset: true,
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_10, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: (){
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_20),
                              SizedBox(
                                width: WidthDimension.w_18,
                                height: HeightDimension.h_15,
                                child: Image.asset(
                                  TMTImages.icBack,
                                  color: AppColor.neutral_800,
                                  fit: BoxFit.contain,
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_6),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_6),
                        Expanded(
                          child: TMTTextWidget(
                            maxLines: 1,
                            title: "Cancel Order",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_10),
                        GestureDetector(
                          onTap: (){
                            showDialog(context: context, 
                                barrierDismissible: true,
                                barrierColor: AppColor.neutral_800.withOpacity(0.2),
                                builder: (context){
                              return GestureDetector(
                                onTap: (){
                                  Navigator.pop(context);
                                },
                                child: Material(
                                  color: Colors.transparent,
                                  child: Container(
                                    color: AppColor.neutral_100,
                                      height: MediaQuery.of(context).size.height / 2,
                                    margin: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_80, bottom: HeightDimension.h_80),
                                    child: Column(
                                      children: [
                                        VerticalSpacing(HeightDimension.h_10),
                                        Padding(
                                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Expanded(
                                                child: TMTTextWidget(title: "Cancelling products", style: TMTFontStyles.text(
                                                  fontSize: TMTFontSize.sp_18,
                                                  color: AppColor.neutral_800,
                                                  fontWeight: FontWeight.w600,
                                                ), textAlign: TextAlign.center),
                                              ),
                                            ],
                                          ),
                                        ),
                                        VerticalSpacing(HeightDimension.h_10),
                                        Expanded(
                                          child: ListView.builder(itemBuilder: (context, index){
                                           var e;
                                            try {
                                              e = _buyerOrderController.orderDetails?.sellers?.firstWhere((element) => element.seller?.id == args.sellerId).orders?[index];
                                            } catch (e) {
                                              return Container();
                                            }
                                            return  Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                            boxShadow: [
                                  BoxShadow(
                                          color: Colors.grey.withOpacity(0.2),
                                          spreadRadius: 2,
                                          blurRadius: 1,
                                          offset: const Offset(2, 0), // changes position of shadow
                                  ),
                            ],
                            color: AppColor.neutral_100,
                            border: Border.all(color: AppColor.neutral_100, width: 0.5)
                        ),
                        padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_10, bottom: HeightDimension.h_15),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ClipRRect(
                                  borderRadius: BorderRadius.circular(TMTRadius.r_10), // Image border
                                  child: SizedBox(
                                          height: HeightDimension.h_80,
                                          width: HeightDimension.h_80,
                                          child: TMTCachedImage.networkImage(e?.productImage ?? "", fit: BoxFit.cover),
                                  ),
                            ),
                            HorizontalSpacing(WidthDimension.w_20),
                            Expanded(
                                  child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            SizedBox(
                                              width: WidthDimension.w_150,
                                              child: TMTTextWidget(title: e?.productName ?? "", style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_14,
                                                color: AppColor.neutral_800,
                                                fontWeight: FontWeight.w500,
                                              ),),
                                            ),
                                            SizedBox(
                                              width: WidthDimension.w_150,
                                              child: TMTTextWidget(title: e?.productDescription ?? "", style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_12,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w500,
                                              ), maxLines: 1,),
                                            ),
                                            TMTTextWidget(title: (e?.productDetailsInJson?.sizes?.isNotEmpty ?? false) ? "Size: ${e?.productDetailsInJson?.sizes?.first.attributes?.size ?? ""}" : "Size: M", style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_12,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w500,
                                            )),
                                            VerticalSpacing(HeightDimension.h_5),
                                            TMTTextWidget(title: "Price £${e?.salePrice ?? ""}", style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_12,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w500,
                                            )),
                                          ],
                                  ),
                            )
                          ],
                        ),
                      );
                                          }, itemCount: _OrdersListLength(), padding: EdgeInsets.only(), scrollDirection: Axis.vertical, shrinkWrap: true,),
                                        ),
                                      ],
                                    )
                                  ),
                                ),
                              );
                            });
                          },
                          child: SizedBox(
                            height: HeightDimension.h_18,
                            width: HeightDimension.h_18,
                            child: Image.asset(TMTImages.icInfo),
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              VerticalSpacing(HeightDimension.h_10),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                  child: Column(
                    children: [
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 2,
                                blurRadius: 1,
                                offset: const Offset(2, 0), // changes position of shadow
                              ),
                            ],
                            color: AppColor.neutral_100,
                            border: Border.all(color: AppColor.neutral_100, width: 0.5)
                        ),
                        padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                SizedBox(
                                  height: HeightDimension.h_16,
                                  width: HeightDimension.h_16,
                                  child: Image.asset(TMTImages.icReturnRound),
                                ),
                                HorizontalSpacing(WidthDimension.w_10),
                                TMTTextWidget(
                                  title: "Eligible For Return",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_12,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                            TMTTextWidget(
                              title: "View Policy",
                              style: TMTFontStyles.textHarbinger(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.primaryBG,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_10),
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TMTTextWidget(
                              title: "Reason for the cancellation",
                              style: TMTFontStyles.textTeen(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_5),
                            TMTTextWidget(
                              title: "Please specify the exact reason for the cancellation. This is to improve our services.",
                              style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.textColor,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                            VerticalSpacing(HeightDimension.h_15),
                            Container(
                              color: AppColor.neutral_600,
                              height: 0.5,
                              width: double.infinity,
                            ),
                            VerticalSpacing(HeightDimension.h_15),
                            ListView.builder(
                              itemCount: _buyerOrderController.cancelOrderReasons.length,
                              itemBuilder: (context, index){
                                return InkWell(
                                  onTap: (){
                                    setState(() {
                                      _buyerOrderController.selectedReason = index;
                                    });
                                  },
                                  child: Container(
                                    padding: EdgeInsets.only(top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(top: HeightDimension.h_4),
                                          width: HeightDimension.h_15,
                                          height: HeightDimension.h_15,
                                          child: _buyerOrderController.selectedReason == index ? const TMTRoundedCornersContainer(
                                            borderColor: AppColor.primaryBG,
                                            child: TMTRoundedCornersContainer(
                                              borderColor: AppColor.primaryBG,
                                              bgColor: AppColor.primaryBG,
                                            ),
                                          ) : const TMTRoundedCornersContainer(
                                            borderColor: AppColor.neutral_800,
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        Expanded(
                                          child: TMTTextWidget(
                                            title: _buyerOrderController.cancelOrderReasons[index].text ?? "",
                                            style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_15,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              padding: EdgeInsets.only(),
                            ),
                            VerticalSpacing(HeightDimension.h_20),
                            Visibility(
                              visible: _buyerOrderController.selectedReason == _buyerOrderController.cancelOrderReasons.length-1,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  TMTTextWidget(
                                    title: "Additional information",
                                    style: TMTFontStyles.textTeen(
                                      fontSize: TMTFontSize.sp_18,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_10),
                                  TextFormField(
                                    maxLines: 5,
                                    maxLength: 100,
                                    controller: _buyerOrderController.additionalTextController,
                                    keyboardType: TextInputType.text,
                                    textInputAction: TextInputAction.done,
                                    onChanged: (v){
                                      setState(() {

                                      });
                                    },
                                    onFieldSubmitted: (v) {
                                      TMTUtilities.closeKeyboard(context);
                                    },
                                    decoration: InputDecoration(
                                        focusedErrorBorder:  CustomOutlineInputBorder(
                                            borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                        errorBorder:  CustomOutlineInputBorder(
                                            borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                        enabledBorder: CustomOutlineInputBorder(
                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                        floatingLabelBehavior: FloatingLabelBehavior.auto,
                                        focusedBorder: CustomOutlineInputBorder(
                                            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10)),
                                        contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 10),
                                        border: CustomOutlineInputBorder(
                                          borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_10),
                                        ),
                                        errorMaxLines: 3,
                                        filled: false,
                                        hintText: "",
                                        hintStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500),
                                        labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                                    ),
                                  ),
                                  VerticalSpacing(HeightDimension.h_10),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_15,
                            right: WidthDimension.w_15,
                            top: HeightDimension.h_10,
                            bottom: HeightDimension.h_10
                        ),
                        child: TMTTextButton(
                          onTap: (){
                            TMTUtilities.closeKeyboard(context);
                            if (_buyerOrderController.selectedReason == -1) {
                              TMTToast.showErrorToast(context, "Please select reason for the cancellation.", title: "Alert");
                              return;
                            }
                            if (_buyerOrderController.selectedReason == _buyerOrderController.cancelOrderReasons.length-1) {
                              if (_buyerOrderController.additionalTextController.text.isEmpty) {
                                TMTToast.showErrorToast(context, "Please enter reason for cancellation.", title: "Alert");
                                return;
                              }
                            }
                            _buyerOrderController.postCancelOrder(context, args.sellerId, _buyerOrderController.orderDetails?.id ?? 0, (){
                              TMTToast.showSuccessToast(context, "Your order has cancelled successfully.", title: "Order Cancelled");
                              Get.offAllNamed(AppRoutes.dashBoardScreen);
                            });
                          },
                          buttonTitle: "CANCEL ORDER",
                          textStyle: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_100,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      }
    );
  }

  /// orders length count
  int _OrdersListLength() {
    try {
      return _buyerOrderController.orderDetails?.sellers?.firstWhere((element) => element.seller?.id == args.sellerId).orders?.length ?? 0;
    } catch (e) {
      return 0;
    }
  }
}
