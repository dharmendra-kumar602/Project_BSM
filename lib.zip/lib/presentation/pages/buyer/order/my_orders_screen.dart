import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/response/get_buyer_orders_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/buyer_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_popup/src/custom_pop_up_menu.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';

class MyOrdersScreen extends StatefulWidget {
  const MyOrdersScreen({super.key});

  @override
  State<StatefulWidget> createState() => _MyOrdersScreenState();
}

class _MyOrdersScreenState extends State<MyOrdersScreen> {

  final CustomPopupMenuController _popupController = CustomPopupMenuController();

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  final BuyerOrderController _buyerOrderController =
  Get.put(BuyerOrderController());

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      _buyerOrderController.getOrders(context);
    },);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyerOrderController>(
        id: GetControllerBuilders.orderListingScreenController,
        init: _buyerOrderController,
        builder: (controller) {
        return Scaffold(
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: const BoxDecoration(color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: (){
                            _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.userProfileScreen, navBarItemIndex: AppRoutesIdentifiers.userProfileScreen);
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              Container(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: "My Orders",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const Spacer(),
                        HorizontalSpacing(WidthDimension.w_10),
                        GestureDetector(
                          onTap: () {
                            Get.toNamed(AppRoutes.cartScreen, arguments: false);
                          },
                          child: SizedBox(
                            height: HeightDimension.h_20,
                            width: HeightDimension.h_20,
                            child: Image.asset(TMTImages.icCart),
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_15),
                        GestureDetector(
                          onTap: () {
                            _checkUserStatus();
                          },
                          child: SizedBox(
                            height: HeightDimension.h_22,
                            width: HeightDimension.h_48,
                            child: Image.asset(TMTImages.icSell),
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              VerticalSpacing(HeightDimension.h_10),
              Container(
                margin: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                child: Row(
                  children: [
                    Expanded(
                      child: TMTRoundedCornersContainer(
                        borderColor: AppColor.neutral_800,
                        borderWidth: 0.5,
                        height: HeightDimension.h_35,
                        bgColor: AppColor.neutral_100,
                        borderRadius:
                        const BorderRadius.all(Radius.circular(TMTRadius.r_35)),
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_15,
                            right: WidthDimension.w_15),
                        child: Row(
                          children: [
                            SizedBox(
                              height: HeightDimension.h_18,
                              width: HeightDimension.h_18,
                              child: Image.asset(
                                TMTImages.icSearch,
                                color: AppColor.textColor,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            Expanded(
                                child: TextField(
                                  onChanged: (v){
                                    setState(() {

                                    });
                                  },
                                  decoration: InputDecoration.collapsed(
                                      hintText: "Search your order here",
                                      hintStyle: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w500,
                                      )),
                                  controller: _buyerOrderController.searchTextController,
                                )),
                            HorizontalSpacing(WidthDimension.w_10),
                            GestureDetector(
                              onTap: () {
                                setState(() {
                                  _buyerOrderController.searchTextController.clear();
                                });
                                TMTUtilities.closeKeyboard(context);
                              },
                              child: SizedBox(
                                height: HeightDimension.h_12,
                                width: HeightDimension.h_12,
                                child: Image.asset(
                                  TMTImages.icErrorToastCancel,
                                  color: AppColor.neutral_800,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_10),
                    CustomPopupMenu(
                      menuBuilder: () => StatefulBuilder(
                          builder: (context, setState) {
                            return Center(
                              child: Stack(
                                children: [
                                  TMTRoundedCornersContainer(
                                    padding: EdgeInsets.only(bottom: HeightDimension.h_60),
                                    width: MediaQuery.of(context).size.width - 40,
                                    height: HeightDimension.h_290,
                                    bgColor: AppColor.neutral_100,
                                    child: SingleChildScrollView(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_20),
                                            child: TMTTextWidget(title: "Order Status", style: TMTFontStyles.textTeen(
                                                fontWeight: FontWeight.w700,
                                                fontSize: TMTFontSize.sp_16,
                                                color: AppColor.neutral_800
                                            ),),
                                          ),
                                          VerticalSpacing(HeightDimension.h_10),
                                          Container(
                                            width: double.infinity,
                                            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                            child: Wrap(
                                                direction: Axis.horizontal,
                                                children: _buyerOrderController.ordersStatusList.map((e) =>  GestureDetector(
                                                  onTap: (){
                                                    setState(() {
                                                      if (_buyerOrderController.selectedStatus == e) {
                                                        _buyerOrderController.selectedStatus = null;
                                                      } else {
                                                        _buyerOrderController.selectedStatus = e;
                                                      }
                                                    });
                                                  },
                                                  child: Container(
                                                    margin: EdgeInsets.only(bottom: HeightDimension.h_10, right: WidthDimension.w_8),
                                                    decoration: BoxDecoration(
                                                        border: Border.all(
                                                          width: 0.5,
                                                          color: _buyerOrderController.selectedStatus == e ? AppColor.primaryBG : AppColor.neutral_800,
                                                        ),
                                                        borderRadius: const BorderRadius.all(Radius.circular(20))
                                                    ),
                                                    child: Padding(
                                                      padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_4, bottom: HeightDimension.h_4),
                                                      child: TMTTextWidget(title: e, style: TMTFontStyles.text(color: _buyerOrderController.selectedStatus == e ? AppColor.primaryBG : AppColor.neutral_800),),
                                                    ),
                                                  ),
                                                )).toList()
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_10),
                                            child: TMTTextWidget(title: "Order Time", style: TMTFontStyles.textTeen(
                                                fontWeight: FontWeight.w700,
                                                fontSize: TMTFontSize.sp_16,
                                                color: AppColor.neutral_800
                                            ),),
                                          ),
                                          VerticalSpacing(HeightDimension.h_10),
                                          Container(
                                            width: double.infinity,
                                            padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                            child: Wrap(
                                                direction: Axis.horizontal,
                                                children: _buyerOrderController.ordersTimeList.map((e) =>  GestureDetector(
                                                  onTap: (){
                                                    setState(() {
                                                      if (_buyerOrderController.selectedTime == e) {
                                                        _buyerOrderController.selectedTime = null;
                                                      } else {
                                                        _buyerOrderController.selectedTime = e;
                                                      }
                                                    });
                                                  },
                                                  child: Container(
                                                    margin: EdgeInsets.only(bottom: HeightDimension.h_10, right: WidthDimension.w_8),
                                                    decoration: BoxDecoration(
                                                        border: Border.all(
                                                          width: 0.5,
                                                          color: _buyerOrderController.selectedTime == e ? AppColor.primaryBG : AppColor.neutral_800,
                                                        ),
                                                        borderRadius: const BorderRadius.all(Radius.circular(20))
                                                    ),
                                                    child: Padding(
                                                      padding: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10, top: HeightDimension.h_4, bottom: HeightDimension.h_4),
                                                      child: TMTTextWidget(title: e, style: TMTFontStyles.text(color: _buyerOrderController.selectedTime == e ? AppColor.primaryBG : AppColor.neutral_800),),
                                                    ),
                                                  ),
                                                )).toList()
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: HeightDimension.h_18,
                                    left: HeightDimension.h_19,
                                    right: HeightDimension.h_19,
                                    child: SizedBox(
                                      height: HeightDimension.h_37,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          Expanded(
                                            child: TMTTextButton(
                                              border: Border.all(color: AppColor.neutral_800),
                                              color: AppColor.neutral_100,
                                              textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_800, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                                              onTap: () {
                                                setState(() {
                                                  _buyerOrderController.selectedTime = null;
                                                  _buyerOrderController.selectedStatus = null;
                                                  _buyerOrderController.getOrders(context);
                                                });
                                                _popupController.hideMenu();
                                              }, buttonTitle: 'CANCEL',
                                            ),
                                          ),
                                          HorizontalSpacing(WidthDimension.w_8),
                                          Expanded(
                                            child: TMTTextButton(
                                              onTap: () {
                                                _popupController.hideMenu();
                                                setState(() {
                                                  _buyerOrderController.getOrders(context);
                                                });
                                              }, buttonTitle: 'APPLY',
                                              textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }
                      ),
                      horizontalMargin: 0,
                      verticalMargin: 0,
                      barrierColor: AppColor.neutral_800.withOpacity(0.3),
                      pressType: PressType.singleClick,
                      arrowColor: AppColor.neutral_100,
                      arrowSize: 25,
                      controller: _popupController,
                      position: PreferredPosition.bottom,
                      child: TMTRoundedCornersContainer(
                        borderColor: AppColor.neutral_800,
                        borderWidth: 0.5,
                        height: HeightDimension.h_35,
                        bgColor: AppColor.neutral_100,
                        borderRadius:
                        const BorderRadius.all(Radius.circular(TMTRadius.r_35)),
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_15,
                            right: WidthDimension.w_15),
                        child: Row(
                          children: [
                            SizedBox(
                              height: HeightDimension.h_18,
                              width: HeightDimension.h_18,
                              child: Image.asset(
                                TMTImages.icSettingProduct,
                                color: AppColor.textColor,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            TMTTextWidget(title: "Filter", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_12,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w500,
                            ),),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              VerticalSpacing(HeightDimension.h_15),
              Expanded(
                child: Stack(
                  children: [
                    SingleChildScrollView(
                      child: Container(
                        child: Column(
                          children: [
                            ListView.builder(
                              itemBuilder: (BuildContext c, int index){
                                var e = _buyerOrderController.getFilteredOrders()[index];
                                return GestureDetector(
                                  onTap: (){
                                    Get.toNamed(AppRoutes.orderDetailsScreen, arguments: e.id);
                                  },
                                  child: Container(
                                    margin: EdgeInsets.only(bottom: HeightDimension.h_2),
                                    width: double.infinity,
                                    decoration: const BoxDecoration(
                                      color: AppColor.neutral_100,
                                    ),
                                    padding: EdgeInsets.only(top: HeightDimension.h_8, bottom: HeightDimension.h_8, left: WidthDimension.w_10, right: WidthDimension.w_10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          height: HeightDimension.h_70,
                                          width: HeightDimension.h_70,
                                          child: _getImage(e),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_20),
                                        SizedBox(
                                          width: WidthDimension.w_195,
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              TMTTextWidget(title: _getTitle(e), style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_14,
                                                color: _getColor(e),
                                                fontWeight: FontWeight.w500,
                                              ), maxLines: 2,),
                                              const VerticalSpacing(2),
                                              TMTTextWidget(title: _convertTime(e.updatedAt), style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_11,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w500,
                                              ), maxLines: 2,),
                                              const VerticalSpacing(2),
                                              TMTTextWidget(title: "${e.productName} ${e.productDescription}", style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_11,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w500,
                                              ), maxLines: 1,),
                                              const VerticalSpacing(2),
                                              TMTTextWidget(title: "Price £${e.salePrice.toStringAsFixed(2)}", style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_11,
                                                color: AppColor.neutral_800,
                                                fontWeight: FontWeight.w500,
                                              ), maxLines: 1,),
                                            ],
                                          ),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        SizedBox(
                                          height: HeightDimension.h_16,
                                          width: HeightDimension.h_16,
                                          child: Image.asset(TMTImages.icNext,),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                              shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              physics: const NeverScrollableScrollPhysics(),
                              padding: EdgeInsets.zero,
                              itemCount: _buyerOrderController.getFilteredOrders().length,
                            ),
                            /*Container(
                              margin: EdgeInsets.only(bottom: HeightDimension.h_2),
                              width: double.infinity,
                              decoration: const BoxDecoration(
                                  color: AppColor.neutral_100,
                              ),
                              padding: EdgeInsets.only(top: HeightDimension.h_8, bottom: HeightDimension.h_8, left: WidthDimension.w_10, right: WidthDimension.w_10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    height: HeightDimension.h_70,
                                    width: HeightDimension.h_70,
                                    child: Image.asset(TMTImages.category7, fit: BoxFit.contain,),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_20),
                                  SizedBox(
                                    width: WidthDimension.w_195,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        TMTTextWidget(title: "Order not placed", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.yellowColor,
                                          fontWeight: FontWeight.w500,
                                        ), maxLines: 2,),
                                        const VerticalSpacing(2),
                                        TMTTextWidget(title: "Product name product details ...", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_11,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                        ), maxLines: 1,),
                                        const VerticalSpacing(2),
                                        TMTTextWidget(title: "Price £1200", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_11,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ), maxLines: 1,),
                                      ],
                                    ),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_10),
                                  SizedBox(
                                    height: HeightDimension.h_16,
                                    width: HeightDimension.h_16,
                                    child: Image.asset(TMTImages.icNext,),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(bottom: HeightDimension.h_2),
                              width: double.infinity,
                              decoration: const BoxDecoration(
                                  color: AppColor.neutral_100,
                              ),
                              padding: EdgeInsets.only(top: HeightDimension.h_8, bottom: HeightDimension.h_8, left: WidthDimension.w_10, right: WidthDimension.w_10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    height: HeightDimension.h_70,
                                    width: HeightDimension.h_70,
                                    child: Image.asset(TMTImages.category3, fit: BoxFit.contain,),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_20),
                                  SizedBox(
                                    width: WidthDimension.w_195,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        TMTTextWidget(title: "Cancelled on feb 18", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.primaryBG,
                                          fontWeight: FontWeight.w500,
                                        ), maxLines: 2,),
                                        const VerticalSpacing(2),
                                        TMTTextWidget(title: "Product name product details ...", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_11,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                        ), maxLines: 1,),
                                        const VerticalSpacing(2),
                                        TMTTextWidget(title: "Price £1200", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_11,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ), maxLines: 1,),
                                      ],
                                    ),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_10),
                                  SizedBox(
                                    height: HeightDimension.h_16,
                                    width: HeightDimension.h_16,
                                    child: Image.asset(TMTImages.icNext,),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(bottom: HeightDimension.h_2),
                              width: double.infinity,
                              decoration: const BoxDecoration(
                                  color: AppColor.neutral_100,
                              ),
                              padding: EdgeInsets.only(top: HeightDimension.h_8, bottom: HeightDimension.h_8, left: WidthDimension.w_10, right: WidthDimension.w_10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    height: HeightDimension.h_70,
                                    width: HeightDimension.h_70,
                                    child: Image.asset(TMTImages.category6, fit: BoxFit.contain,),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_20),
                                  SizedBox(
                                    width: WidthDimension.w_195,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        TMTTextWidget(title: "Delivered on jan 16", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.green,
                                          fontWeight: FontWeight.w500,
                                        ), maxLines: 2,),
                                        const VerticalSpacing(2),
                                        TMTTextWidget(title: "Product name product details ...", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_11,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w500,
                                        ), maxLines: 1,),
                                        const VerticalSpacing(2),
                                        TMTTextWidget(title: "Price £1500", style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_11,
                                          color: AppColor.neutral_800,
                                          fontWeight: FontWeight.w500,
                                        ), maxLines: 1,),
                                      ],
                                    ),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_10),
                                  SizedBox(
                                    height: HeightDimension.h_16,
                                    width: HeightDimension.h_16,
                                    child: Image.asset(TMTImages.icNext,),
                                  ),
                                ],
                              ),
                            ),*/
                          ],
                        ),
                      ),
                    ),
                    Visibility(child: Center(child: TMTTextWidget(title: "No order found."),), visible: _buyerOrderController.getFilteredOrders().isEmpty,)
                  ],
                ),
              ),
            ],
          ),
        );
      }
    );
  }

  /// get order image
  _getImage(BuyerOrderData e) {
    try {
      return TMTCachedImage.networkImage(e.productImage ?? "", fit: BoxFit.contain,);
    } catch (e) {
      return TMTCachedImage.networkImage("", fit: BoxFit.contain,);
    }
  }

  /// Check user status
  void _checkUserStatus() {

    if (TMTUtilities.getUserRoleFromToken() == "SELLER") {
      _dashboardController.getSellerRegisterStatus(context, (){
        if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
          Get.toNamed(AppRoutes.sellerDashboard);
        } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
          Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
        } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
          Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
        } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
          _dashboardController.getUpdatedToken(context, (){
            Get.toNamed(
                AppRoutes.sellerPlanDetailsScreen);
          });
        } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
          _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), (){
            Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
          });
        } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
          TMTUtilities.showUserDisabledDialog(context);
        } else {
          Get.toNamed(AppRoutes.sellerDashboard);
        }
      });
    } else {
      if (!TMTLocalStorage.getUserLoggedIn()) {
        Get.offAndToNamed(AppRoutes.loginScreen,
            arguments: AppRoutes.homeScreen);
      } else {
        _dashboardController.getSellerRegisterStatus(context, (){
          if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
            _dashboardController.getUpdatedToken(context, (){
              Get.toNamed(AppRoutes.sellerDashboard);
            });
          } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
            Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
          } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
            Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
          } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
            _dashboardController.getUpdatedToken(context, (){
              Get.toNamed(
                  AppRoutes.sellerPlanDetailsScreen);
            });
          } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
            _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), (){
              Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
            });
          } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
            TMTUtilities.showUserDisabledDialog(context);
          } else {
            Get.toNamed(AppRoutes.registerToSellScreen);
          }
        });
      }
    }
  }

  /// get title
  String _getTitle(BuyerOrderData e) {
    if (e.status == "PENDING") {
      return "Order placed";
    } else if (e.status == "PROCESSING") {
      return "Order confirmed";
    } else if (e.status == "SHIPPED") {
      return "In Transit";
    } else if (e.status == "DELIVERED") {
      return "Delivered";
    } else if (e.status == "CANCELLED") {
      return "Cancelled";
    } else if (e.status == "REJECTED") {
      return "Rejected";
    } else if (e.status == "REFUND_REQUESTED") {
      return "Refund requested";
    } else if (e.status == "REFUND_REQ_APPROVED") {
      return "Refund approved";
    } else if (e.status == "REFUND_REQ_REJECTED") {
      return "Refund rejected";
    } else if (e.status == "REFUND_PRODUCT_COLLECTED") {
      return "Refund product collected";
    } else if (e.status == "REFUNDED") {
      return "Refunded";
    } else if (e.status == "AUTO_CANCELLED") {
      return "Order expired";
    } else {
      return e.productName;
    }
  }

  /// get color
  Color _getColor(BuyerOrderData e) {
    if (e.status == "PENDING") {
      return AppColor.neutral_800;
    } else if (e.status == "PROCESSING") {
      return AppColor.neutral_800;
    } else if (e.status == "SHIPPED") {
      return AppColor.neutral_800;
    } else if (e.status == "DELIVERED") {
      return AppColor.green;
    } else if (e.status == "CANCELLED") {
      return AppColor.primary;
    } else if (e.status == "REJECTED") {
      return AppColor.primary;
    } else if (e.status == "REFUND_REQUESTED") {
      return AppColor.neutral_800;
    } else if (e.status == "REFUND_REQ_APPROVED") {
      return AppColor.neutral_800;
    } else if (e.status == "REFUND_REQ_REJECTED") {
      return AppColor.neutral_800;
    } else if (e.status == "REFUND_PRODUCT_COLLECTED") {
      return AppColor.neutral_800;
    } else if (e.status == "REFUNDED") {
      return AppColor.neutral_800;
    } else if (e.status == "AUTO_CANCELLED") {
      return AppColor.primary;
    } else {
      return AppColor.neutral_800;
    }
  }

  String _convertTime(DateTime updatedAt) {
    // Format the date using the intl package
    String formattedDate = DateFormat("d MMM yyyy").format(updatedAt);
    return formattedDate;
  }
}