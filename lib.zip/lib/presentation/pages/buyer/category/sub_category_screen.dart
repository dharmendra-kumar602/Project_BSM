import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_notification/tmt_notification_bell.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_tabs/custom_tab_bar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_tabs/indicator/custom_indicator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_tabs/indicator/linear_indicator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_tabs/transform/color_transform.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class SubCategoryScreen extends StatefulWidget {
  const SubCategoryScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SubCategoryScreenState();
}

class _SubCategoryScreenState extends State<SubCategoryScreen> {

  final PageController _controller = PageController(initialPage: 0);
  final CustomTabBarController _tabBarController = CustomTabBarController();

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  final CategoryController _categoryController =
  Get.find<CategoryController>();

  Widget getTabBarChild(BuildContext context, int index) {
    return TabBarItem(
      index: index,
      transform: ColorsTransform(
          highlightColor: Colors.pink,
          normalColor: Colors.black,
          builder: (context, color) {
            return Container(
              margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
              alignment: Alignment.center,
              constraints: const BoxConstraints(minWidth: 70),
              child: TMTTextWidget(title: _categoryController.getChildCategory()[index].name, style: TMTFontStyles.textTeen(
                fontSize: TMTFontSize.sp_16,
                color: _tabBarController.currentIndex == index ? AppColor.neutral_800 : AppColor.textColor,
                fontWeight: FontWeight.w700,
              ),),
            );
          }),
    );
  }

  @override
  void initState() {
    if (_categoryController.selectedCategory?.sub.isNotEmpty ?? false) {
      _categoryController.updateSelectChildCategory(_categoryController.selectedCategory!.sub.first);
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CategoryController>(
        id: GetControllerBuilders.categoryScreenController,
        init: _categoryController,
        builder: (controller) {
        return Scaffold(
          appBar: PreferredSize(
              preferredSize: Size.fromHeight(SizeConfig.safeBlockVertical * 13.5),
              child: Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 1,
                    blurRadius: 2,
                    offset: const Offset(0, 2), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Column(
                  children: [
                    VerticalSpacing(SizeConfig.safeBlockVertical * 6),
                    Row(
                      children: [
                        InkWell(
                          onTap: (){
                            _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.categoryScreen, navBarItemIndex: AppRoutesIdentifiers.categoryScreen);
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_2),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: _categoryController.selectedCategory?.name ?? "",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: (){
                            Get.toNamed(AppRoutes.searchScreen);
                          },
                          child: SizedBox(
                            height: HeightDimension.h_18,
                            width: HeightDimension.h_18,
                            child: Image.asset(
                              TMTImages.icSearch,
                              color: AppColor.neutral_800,
                            ),
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_12),
                        GestureDetector(
                          onTap: () async {
                            await Get.toNamed(AppRoutes.notificationScreen);
                          },
                          child: TMTNotificationBell(isBuyer: true),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                    Spacer(),
                    CustomTabBar(
                      onTapItem: (index){
                        if (_categoryController.selectedCategory?.sub.isNotEmpty ?? false) {
                          _categoryController.updateSelectChildCategory(_categoryController.selectedCategory!.sub[index]);
                        }
                      },
                      tabBarController: _tabBarController,
                      height: HeightDimension.h_40,
                      itemCount: _categoryController.getChildCategory().length,
                      builder: getTabBarChild,
                      indicator: LinearIndicator(color: Colors.pink, bottom: 3, width: WidthDimension.w_100),
                      pageController: _controller,
                    ),
                  ],
                ),
              )),
          body: PageView.builder(
              controller: _controller,
              itemCount: _categoryController.getChildCategory().length,
              onPageChanged: (int page){
                if (_categoryController.selectedCategory?.sub.isNotEmpty ?? false) {
                  _categoryController.updateSelectChildCategory(_categoryController.selectedCategory!.sub[page]);
                }
              },
              itemBuilder: (context, index) {
                return SizedBox(
                  width: double.infinity,
                  child: ListView.builder(
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: (){
                          _categoryController.updateSelectGrandChildCategory(_categoryController.getGrandChildCategory()[index]);
                          Get.toNamed(AppRoutes.categoryListingScreen, arguments: [_categoryController.getGrandChildCategory()[index].name]);
                        },
                        child: Container(
                          margin: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_12),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  SizedBox(
                                    width: MediaQuery.of(context).size.width - 95,
                                    child: TMTTextWidget(
                                      title: _categoryController.getGrandChildCategory()[index].name,
                                      style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_13,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_10),
                                  const Spacer(),
                                  SizedBox(
                                    height: HeightDimension.h_10,
                                    width: HeightDimension.h_10,
                                    child: Image.asset(
                                      TMTImages.icNext,
                                      color: AppColor.neutral_800,
                                    ),
                                  ),
                                ],
                              ),
                              VerticalSpacing(SizeConfig.safeBlockVertical * 1.7),
                              Container(
                                width: double.infinity,
                                height: 0.5,
                                color: const Color(0xFFD1D1D1),
                              )
                            ],
                          ),
                        ),
                      );
                    },
                    itemCount: _categoryController.getGrandChildCategory().length,
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                  ),
                );
              }),
        );
      }
    );
  }
}
