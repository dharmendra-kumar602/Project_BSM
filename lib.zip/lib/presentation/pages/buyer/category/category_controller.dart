import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/request/get_all_categories_request.dart';
import 'package:take_my_tack/data/model/request/get_products_by_categoryId_request.dart';
import 'package:take_my_tack/data/model/request/get_products_by_sellerid_request.dart';
import 'package:take_my_tack/data/model/request/post_apply_filters_request.dart';
import 'package:take_my_tack/data/model/response/get_all_categories_response.dart';
import 'package:take_my_tack/data/model/response/get_products_by_brand_id_response.dart';
import 'package:take_my_tack/data/model/response/get_products_by_category_id_response.dart';
import 'package:take_my_tack/data/model/response/get_products_by_seller_id_response.dart';
import 'package:take_my_tack/data/repository_implementation/dashboard_repository_impl.dart';
import 'package:take_my_tack/data/repository_implementation/product_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class CategoryController extends GetxController {

  DashboardRepositoryImpl dashboardRepositoryImpl = DashboardRepositoryImpl();
  ProductRepositoryImpl productRepositoryImpl = ProductRepositoryImpl();
  List<int> selectedCategoriesFilters = [];
  List<int> selectedBrandsFilters = [];
  List<int> selectedSellersFilters = [];

  CategoryData? data;
  List<CategoryDatum> productsByCategories = [];
  List<CategoryDatum> allProducts = [];

  CategoryObj? selectedCategory;
  CategoryObj? selectedChildCategory;
  CategoryObj? selectedGrandChildCategory;

  int totalCount = 0;
  int limit = 20;
  int offset = 0;

  int selectedSorting = 2;

  List<String> sortingFilters = [
    "JUST_ADDED",
    "HIGH_TO_LOW",
    "LOW_TO_HIGH",
    "DISCOUNT",
  ];

  List filtersIds = [];
  List filtersValues = [];

  /// brand products
  List<BrandProductData> brandProductsData = [];

  /// brand products
  List<SellerProducts> sellersProductsData = [];

  /*
   Method use to get selected category id.
   Parameter- No parameters.
   Return -> int id.
  */
  int getSelectedCategoryId () {
    if (selectedGrandChildCategory != null) {
      return selectedGrandChildCategory!.id;
    } else if (selectedChildCategory != null) {
      return selectedChildCategory!.id;
    } else {
      return selectedCategory?.id ?? 0;
    }
  }

  /*
   Method use to get child categories based on selected category.
   Parameter- No parameters.
   Return -> List<Datum>.
  */
  List<CategoryObj> getChildCategory () {
    if (selectedCategory == null) {
      return [];
    } else {
      var result = data?.categories.firstWhereOrNull((element) => element.id == selectedCategory?.id)?.sub ?? [];
      return result;
    }
  }

  /*
   Method use to get grand child categories based on selected child category.
   Parameter- No parameters.
   Return -> List<Datum>.
  */
  List<CategoryObj> getGrandChildCategory () {
    if (selectedChildCategory == null) {
      return [];
    } else {
      var result = selectedChildCategory?.sub ?? [];
      return result;
    }
  }

  /*
   Method use to update selected category.
   Parameter- Datum category.
   Return -> No Return type.
  */
  void updateSelectCategory (CategoryObj category) {
    selectedCategory = category;
    update([GetControllerBuilders.categoryScreenController]);
  }

  /*
   Method use to update selected child category.
   Parameter- Datum category.
   Return -> No Return type.
  */
  void updateSelectChildCategory (CategoryObj category) {
    selectedChildCategory = category;
    update([GetControllerBuilders.categoryScreenController]);
  }

  /*
   Method use to update selected grand child category.
   Parameter- Datum category.
   Return -> No Return type.
  */
  void updateSelectGrandChildCategory (CategoryObj category) {
    selectedGrandChildCategory = category;
    update([GetControllerBuilders.categoryScreenController]);
  }

  /*
   Method use to get all categories.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getAllCategories (BuildContext context) {
    var request = GetAllCategoriesRequest(limit: 50, offSet: 0
    );
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getAllCategories(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              data = right.data;
             update([GetControllerBuilders.categoryScreenController]);
            } else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get Products By Category Id.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getProductsByCategoryId (BuildContext context, int id) {
    GetProductsByCategoryIdRequest request = GetProductsByCategoryIdRequest(pageSize: limit, pageNumber: offset, categoryId: id, sortId: sortingFilters[selectedSorting]);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getProductsByCategoryId(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              productsByCategories = right.data ?? [];
              productsByCategories.forEach((element) {
                element.isLiked = (TMTLocalStorage.getWishlistItems().firstWhereOrNull((e) => element.productVariations?.first.id == e.variationId) != null);
              });
              update([GetControllerBuilders.categoryScreenController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get Products By Seller Id.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getProductsBySellerId (BuildContext context, int sellerStoreId, {List? filtersIds, List? filtersValues}) {
    var params = GetProductsBySellerIdRequest(pageSize: limit, pageNumber: offset, sellerId: sellerStoreId, sortId: sortingFilters[selectedSorting], filtersIds: filtersIds, filtersValues: filtersValues);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getProductsBySellerId(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              sellersProductsData = right.data ?? [];
              update([GetControllerBuilders.categoryScreenController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get just added products.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getJustAddedProducts (BuildContext context) {
   NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getProducts();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              allProducts = right.data ?? [];
              allProducts.forEach((element) {
                element.isLiked = (TMTLocalStorage.getWishlistItems().firstWhereOrNull((e) => element.productVariations?.first.id == e.variationId)?.isLiked ?? false);
              });
              update([GetControllerBuilders.categoryScreenController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to apply filters.
   Parameter- BuildContext context.
   Return -> Product list.
  */
  void applyFilters(BuildContext context, PostProductFiltersReruest params) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.postApplyFilters(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              productsByCategories = [];
              productsByCategories = right.products?.map((e) => CategoryDatum(title: e.title, description: e.description, badgeId: e.badgeId, createdAt: e.createdAt, id: e.id, badge: CBadge(name: e.badge?.name, title: e.badge?.title, image: e.badge?.image, description: e.badge?.description), productVariations: e.productVariations?.map((e) => CProductVariation(id: e.id, salePrice: e.salePrice, maxRetailPrice: e.maxRetailPrice, productImages: e.productImages?.map((e) => CProductImage(imageName: e.imageName)).toList())).toList())).toList() ?? [];
              productsByCategories.forEach((element) {
                element.isLiked = (TMTLocalStorage.getWishlistItems().firstWhereOrNull((e) => element.productVariations?.first.id == e.variationId) != null);
              });
              selectedCategoriesFilters = params.categoryIds ?? [];
              selectedBrandsFilters = params.brands ?? [];
              selectedSellersFilters = params.sellers ?? [];
              update([GetControllerBuilders.categoryScreenController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to apply filters for brands.
   Parameter- BuildContext context.
   Return -> Product list.
  */
  void applyBrandsFilters(BuildContext context, PostProductFiltersReruest params) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.postApplyFilters(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              brandProductsData = [];
              brandProductsData = right.products?.map((e) => BrandProductData(title: e.title, description: e.description, badgeId: e.badgeId, createdAt: e.createdAt, id: e.id, badge: BBadge(name: e.badge?.name, title: e.badge?.title, image: e.badge?.image, description: e.badge?.description), productVariations: e.productVariations?.map((e) => BProductVariation(id: e.id, salePrice: e.salePrice, maxRetailPrice: e.maxRetailPrice, productImages: e.productImages?.map((e) => BProductImage(imageName: e.imageName)).toList())).toList())).toList() ?? [];
              brandProductsData.forEach((element) {
                element.isLiked = (TMTLocalStorage.getWishlistItems().firstWhereOrNull((e) => element.productVariations?.first.id == e.variationId) != null);
              });
              selectedCategoriesFilters = params.categoryIds ?? [];
              selectedBrandsFilters = params.brands ?? [];
              selectedSellersFilters = params.sellers ?? [];
              update([GetControllerBuilders.productsByBrandIdScreenController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to apply filters for sellers.
   Parameter- BuildContext context.
   Return -> Product list.
  */
  void applySellersFilters(BuildContext context, PostProductFiltersReruest params) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.postApplyFilters(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              sellersProductsData = [];
              sellersProductsData = right.products?.map((e) => SellerProducts(title: e.title, description: e.description, badgeId: e.badgeId, createdAt: e.createdAt, id: e.id, badge: SBadge(name: e.badge?.name, title: e.badge?.title, image: e.badge?.image, description: e.badge?.description), productVariations: e.productVariations?.map((e) => ProductVariation(id: e.id, salePrice: e.salePrice, maxRetailPrice: e.maxRetailPrice, productImages: e.productImages?.map((e) => ProductImage(imageName: e.imageName)).toList())).toList())).toList() ?? [];
              sellersProductsData.forEach((element) {
                element.isLiked = (TMTLocalStorage.getWishlistItems().firstWhereOrNull((e) => element.productVariations?.first.id == e.variationId) != null);
              });
              selectedCategoriesFilters = params.categoryIds ?? [];
              selectedBrandsFilters = params.brands ?? [];
              selectedSellersFilters = params.sellers ?? [];
              update([GetControllerBuilders.sellersProductListingController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get Products by Brand Id.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getProductsByBrandId (BuildContext context, String brandId, Function callback) {
    GetProductsByBrandIdRequest request = GetProductsByBrandIdRequest(pageSize: limit, pageNumber: offset, brandId: brandId, sortId: sortingFilters[selectedSorting]);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getProductsByBrandId(request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              brandProductsData = right.data ?? [];
              callback.call();
              update([GetControllerBuilders.productsByBrandIdScreenController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}