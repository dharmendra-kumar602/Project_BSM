import 'dart:math';
import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/model/response/get_all_categories_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_notification/tmt_notification_bell.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<StatefulWidget> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  final CategoryController _categoryController =
  Get.find<CategoryController>();

  final List<Color> _colors = [
    const Color(0xFFF1E5D9),
    const Color(0xFFFFE3D9),
    const Color(0xFFFFEAEF),
    const Color(0xFFDDDDDD),
    const Color(0xFFE1F2FF),
    const Color(0xCDE1F2FF),
  ];

  Random random = Random();
  Color? previousColor;

  /// get color by index from color list
  Color getColor(int index) {
    final wrappedIndex = index % _colors.length;
    return _colors[wrappedIndex];
  }

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      _categoryController.getAllCategories(context);
    },);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CategoryController>(
        id: GetControllerBuilders.categoryScreenController,
        init: _categoryController,
        builder: (controller) {
        return Scaffold(
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: (){
                            _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.homeScreen, navBarItemIndex: AppRoutesIdentifiers.homeScreen);
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: "Categories",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: (){
                            Get.toNamed(AppRoutes.searchScreen);
                          },
                          child: SizedBox(
                            height: HeightDimension.h_18,
                            width: HeightDimension.h_18,
                            child: Image.asset(
                              TMTImages.icSearch,
                              color: AppColor.neutral_800,
                            ),
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_12),
                        GestureDetector(
                          onTap: () async {
                            await Get.toNamed(AppRoutes.notificationScreen);
                          },
                          child: TMTNotificationBell(isBuyer: true),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        padding: const EdgeInsets.all(12.0),
                        itemBuilder: (context, index){
                          return InkWell(
                            highlightColor: Colors.blue.withOpacity(0.1),
                            splashColor: Colors.blue.withOpacity(0.2),
                            onTap: (){
                              _categoryController.updateSelectCategory(_categoryController.data!.categories[index]);
                              if (_categoryController.data!.categories[index].sub.isNotEmpty) {
                                _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.subCategoryScreen, navBarItemIndex: AppRoutesIdentifiers.categoryScreen);
                              } else {
                                Get.toNamed(AppRoutes.categoryListingScreen, arguments: [_categoryController.data!.categories[index].name]);
                              }
                            },
                            child: index.floor().isEven ?
                            Stack(
                              children: [
                                TMTCustomBorderContainer(
                                  height: HeightDimension.h_100,
                                  margin: EdgeInsets.only(left: WidthDimension.w_8, right: WidthDimension.w_8, top: HeightDimension.h_8, bottom: HeightDimension.h_8),
                                  borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_15)),
                                  bgColor: getColor(index),
                                  child: Row(
                                    children: [
                                      HorizontalSpacing(WidthDimension.w_15),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            TMTTextWidget(title: _categoryController.data!.categories[index].name.toString().toUpperCase(), style: TMTFontStyles.textTeen(
                                              fontSize: TMTFontSize.sp_18,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w700,
                                            ),),
                                            VerticalSpacing(HeightDimension.h_5),
                                            TMTTextWidget(title: _categoryController.data!.categories[index].description.toString(), style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_12,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w400,
                                            ),),
                                          ],
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_10),
                                      SizedBox(
                                        width: WidthDimension.w_120,
                                        height: double.infinity,
                                      ),
                                      HorizontalSpacing(WidthDimension.w_10),
                                    ],
                                  ),
                                ),
                                Positioned(
                                  top: -2,
                                  right: WidthDimension.w_15,
                                  child: SizedBox(
                                    height: HeightDimension.h_110,
                                    width: WidthDimension.w_120,
                                    child: TMTCachedImage.networkImage(_categoryController.data!.categories[index].imageName),
                                  ),
                                ),
                              ],
                            ) :
                            Stack(
                              children: [
                                TMTCustomBorderContainer(
                                  height: HeightDimension.h_100,
                                  margin: EdgeInsets.only(left: WidthDimension.w_8, right: WidthDimension.w_8, top: HeightDimension.h_8, bottom: HeightDimension.h_8),
                                  borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_15)),
                                  bgColor: getColor(index),
                                  child: Row(
                                    children: [
                                      HorizontalSpacing(WidthDimension.w_10),
                                      SizedBox(
                                        width: WidthDimension.w_120,
                                        height: double.infinity,
                                      ),
                                      HorizontalSpacing(WidthDimension.w_20),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            TMTTextWidget(title: _categoryController.data!.categories[index].name.toString().toUpperCase(), style: TMTFontStyles.textTeen(
                                              fontSize: TMTFontSize.sp_18,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w700,
                                            ),),
                                            VerticalSpacing(HeightDimension.h_5),
                                            TMTTextWidget(title: _categoryController.data!.categories[index].description.toString(), style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_12,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w400,
                                            ), textAlign: TextAlign.start,),
                                          ],
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_15),
                                    ],
                                  ),
                                ),
                                Positioned(
                                  top: -2,
                                  left: WidthDimension.w_15,
                                  child: SizedBox(
                                    height: HeightDimension.h_110,
                                    width: WidthDimension.w_120,
                                    child: TMTCachedImage.networkImage(_categoryController.data!.categories[index].imageName, fit: BoxFit.contain,),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                        itemCount: _categoryController.data?.categories.length ?? 0,
                      ),
                      Visibility(
                        visible: (_categoryController.data?.categories.isNotEmpty ?? false),
                        child: InkWell(
                          highlightColor: Colors.blue.withOpacity(0.1),
                          splashColor: Colors.blue.withOpacity(0.2),
                          onTap: (){
                            _dashboardController.getBrandList(context, (brands) {
                              if (brands?.isNotEmpty ?? false) {
                                Get.toNamed(AppRoutes.brandsListingScreen, arguments: brands);
                              }
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(left: 12, right: 12),
                            child: Stack(
                              children: [
                                TMTCustomBorderContainer(
                                  height: HeightDimension.h_100,
                                  margin: EdgeInsets.only(left: WidthDimension.w_8, right: WidthDimension.w_8, top: HeightDimension.h_8, bottom: HeightDimension.h_8),
                                  borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_15)),
                                  bgColor: const Color(0xCDE1F2FF),
                                  child: Row(
                                    children: [
                                      HorizontalSpacing(WidthDimension.w_10),
                                      SizedBox(
                                        width: WidthDimension.w_120,
                                        height: double.infinity,
                                      ),
                                      HorizontalSpacing(WidthDimension.w_20),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            TMTTextWidget(title: "Brands".toUpperCase(), style: TMTFontStyles.textTeen(
                                              fontSize: TMTFontSize.sp_18,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w700,
                                            ),),
                                            VerticalSpacing(HeightDimension.h_5),
                                            TMTTextWidget(title: "Shop by brands", style: TMTFontStyles.text(
                                              fontSize: TMTFontSize.sp_12,
                                              color: AppColor.textColor,
                                              fontWeight: FontWeight.w400,
                                            ), textAlign: TextAlign.start,),
                                          ],
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_15),
                                    ],
                                  ),
                                ),
                                Positioned(
                                  top: -2,
                                  left: WidthDimension.w_15,
                                  child: SizedBox(
                                    height: HeightDimension.h_110,
                                    width: WidthDimension.w_120,
                                    child: Image.asset(TMTImages.icBellCategory, fit: BoxFit.contain,),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      }
    );
  }
}
