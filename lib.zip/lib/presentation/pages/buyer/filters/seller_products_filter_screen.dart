import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:take_my_tack/data/model/request/post_apply_filters_request.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/filters/product_filters_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_checkbox.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class SellerProductsFilterScreen extends StatefulWidget {
  int sellerStoreId;
  SellerProductsFilterScreen({super.key, required this.sellerStoreId});

  @override
  State<StatefulWidget> createState() => _SellerProductsFilterScreenState();
}

class _SellerProductsFilterScreenState extends State<SellerProductsFilterScreen> {

  final ProductFiltersController _productFiltersController = Get.put(ProductFiltersController());
  final CategoryController _categoryController = Get.find<CategoryController>();

  @override
  void initState() {
    _productFiltersController.getSellerProductsFilters(context, _categoryController.filtersIds);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.lightGrey,
      body: GetBuilder<ProductFiltersController>(
          id: GetControllerBuilders.productFiltersController,
          init: _productFiltersController,
          builder: (controller) {
          return Column(
            children: [
              Container(
                color: AppColor.neutral_100,
                padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                child: Row(
                  children: [
                    TMTTextWidget(title: "Filters", style: TMTFontStyles.textTeen(
                      fontSize: TMTFontSize.sp_18,
                      color: AppColor.neutral_800,
                      fontWeight: FontWeight.w700,
                    ),),
                    const Spacer(),
                    GestureDetector(
                      onTap: (){
                        setState(() {
                          _productFiltersController.categories.forEach((element) {
                           element.isSelected = false;
                         });
                          _productFiltersController.brands.forEach((element) {
                           element.isSelected = false;
                         });
                          _productFiltersController.location.forEach((element) {
                           element.isSelected = false;
                         });
                          _productFiltersController.color.forEach((element) {
                            element.isSelected = false;
                          });
                          _productFiltersController.size.forEach((element) {
                            element.isSelected = false;
                          });
                          _productFiltersController.material.forEach((element) {
                            element.isSelected = false;
                          });
                          _productFiltersController.tackType.forEach((element) {
                            element.isSelected = false;
                          });
                          _productFiltersController.filling.forEach((element) {
                            element.isSelected = false;
                          });
                          _categoryController.filtersIds = [];
                          _categoryController.filtersValues = [];
                        });
                      },
                      child: TMTTextWidget(title: "CLEAR ALL", style: TMTFontStyles.textHarbinger(
                        fontSize: TMTFontSize.sp_13,
                        color: AppColor.primaryBG,
                        fontWeight: FontWeight.w400,
                        textDecoration: TextDecoration.underline
                      ),),
                    ),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                height: 1,
                color: const Color(0xFFE6E6E6),
              ),
              Expanded(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: WidthDimension.w_130,
                      child: ListView.builder(itemBuilder: (context, index){
                        return InkWell(
                          onTap: (){
                            setState(() {
                              _productFiltersController.selectedFiltersCategoriesIndex = index;
                            });
                          },
                          child: Container(
                            color: _productFiltersController.selectedFiltersCategoriesIndex == index ? AppColor.neutral_100 : AppColor.lightGrey,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15),
                                  child: TMTTextWidget(title: index == 0 ? "Categories" : index == 1 ? "Brands" : index == 2 ? "Location" : index == 2 ? "Color" : index == 3 ? "Color" : index == 4 ? "Size" : index == 5 ? "Material" : index == 6 ? "Tack Type" : index == 7 ? "Filling" : "Attributes", style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_14,
                                    color: AppColor.neutral_800,
                                    fontWeight: _productFiltersController.selectedFiltersCategoriesIndex == index ? FontWeight.w500 : FontWeight.w300,
                                  ),),
                                ),
                                VerticalSpacing(HeightDimension.h_8),
                                Container(
                                  width: double.infinity,
                                  height: 0.5,
                                  color: const Color(0xFFD1D1D1),
                                ),
                              ],
                            ),
                          ),
                        );
                      }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: 8, padding: EdgeInsets.zero,),
                    ),
                    Expanded(
                      child: Container(
                        height: MediaQuery.of(context).size.height,
                        padding: EdgeInsets.only(left: WidthDimension.w_10),
                        color: AppColor.neutral_100,
                        child: _getViewByCategory(_productFiltersController.selectedFiltersCategoriesIndex),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        }
      ),
      bottomNavigationBar: Container(
        height: HeightDimension.h_45,
        decoration: BoxDecoration(boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 3,
            blurRadius: 5,
            offset: const Offset(0, 3), // changes position of shadow
          ),
        ], color: AppColor.neutral_100),
        child: Stack(
          children: [
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: (){
                        Navigator.pop(context);
                      },
                      child: Center(
                        child: TMTTextWidget(title: "CLOSE", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w500,
                        ),),
                      ),
                    ),
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: (){
                        List ids = [];
                        List values = [];
                        Navigator.pop(context);

                        var selectedCategories = _productFiltersController.categories.where((element) => element.isSelected).toList();
                        ids.addAll(selectedCategories.map((e) => e.id).toList());
                        values.addAll(selectedCategories.map((e) => e.name).toList());
                        var selectedBrands = _productFiltersController.brands.where((element) => element.isSelected).toList();
                        ids.addAll(selectedBrands.map((e) => e.id).toList());
                        values.addAll(selectedBrands.map((e) => e.name).toList());
                        var selectedLocation = _productFiltersController.location.where((element) => element.isSelected).toList();
                        ids.addAll(selectedLocation.map((e) => e.id).toList());
                        values.addAll(selectedLocation.map((e) => e.address1).toList());
                        var selectedColor = _productFiltersController.color.where((element) => element.isSelected).toList();
                        ids.addAll(selectedColor.map((e) => e.id).toList());
                        values.addAll(selectedColor.map((e) => e.value).toList());
                        var selectedSize = _productFiltersController.size.where((element) => element.isSelected).toList();
                        ids.addAll(selectedSize.map((e) => e.id).toList());
                        values.addAll(selectedSize.map((e) => e.value).toList());
                        var selectedMaterial = _productFiltersController.material.where((element) => element.isSelected).toList();
                        ids.addAll(selectedMaterial.map((e) => e.id).toList());
                        values.addAll(selectedMaterial.map((e) => e.value).toList());
                        var selectedTackType = _productFiltersController.tackType.where((element) => element.isSelected).toList();
                        ids.addAll(selectedTackType.map((e) => e.id).toList());
                        values.addAll(selectedTackType.map((e) => e.value).toList());

                        _categoryController.filtersIds = ids;
                        _categoryController.filtersValues = values;
                        _categoryController.getProductsBySellerId(context, widget.sellerStoreId, filtersIds: ids, filtersValues: values);
                      },
                      child: Center(
                        child: TMTTextWidget(title: "APPLY", style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w500,
                        ),),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.only(top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  width: 1,
                  height: double.infinity,
                  color: const Color(0XFFC1C1C1),
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  /*
  - Method use to get view by selected category.
  - Parameter- No Parameter.
  - Return -> Widget.
  */
  Widget _getViewByCategory(int selectedFiltersCategoriesIndex) {
    switch (selectedFiltersCategoriesIndex) {
      case 0: /// categories
        return SingleChildScrollView(
          child: Column(
            key: UniqueKey(),
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15, right: WidthDimension.w_15),
                child: Row(
                  children: [
                    TMTCustomCheckbox(
                      isChecked: (_productFiltersController.categories.where((element) => element.isSelected == false).toList().isEmpty),
                      onChange: (value) {
                        setState(() {
                          if ((_productFiltersController.categories.where((element) => element.isSelected == false).toList().isEmpty)) {
                            _productFiltersController.categories.forEach((element) {
                              element.isSelected = false;
                            });
                          } else {
                            _productFiltersController.categories.forEach((element) {
                              element.isSelected = true;
                            });
                          }
                        });
                      },
                      backgroundColor: AppColor.primaryBG,
                      borderColor: AppColor.primaryBG,
                      icon: Icons.check,
                      iconColor: AppColor.neutral_100,
                      size: 16,
                      borderWidth: 1,
                      iconSize: 14,
                    ),
                    HorizontalSpacing(WidthDimension.w_8),
                    TMTTextWidget(title: "Select All", style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_16,
                      color: AppColor.neutral_800,
                      fontWeight: FontWeight.w500,
                    ),),
                  ],
                ),
              ),
              ListView.builder(itemBuilder: (context, index){
                return InkWell(
                  onTap: (){
                    setState(() {
                      _productFiltersController.categories[index].isSelected = !_productFiltersController.categories[index].isSelected;
                    });
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15),
                        child: Row(
                          children: [
                            SizedBox(
                              height: HeightDimension.h_14,
                              width: HeightDimension.h_14,
                              child: Image.asset(_productFiltersController.categories[index].isSelected ? TMTImages.icTickThin : TMTImages.icTickThinGrey, fit: BoxFit.contain),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            Expanded(
                              child: TMTTextWidget(title: _productFiltersController.categories[index].name ?? "", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_14,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w500,
                              ),),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_5),
                      Container(
                        margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                        width: double.infinity,
                        height: 0.5,
                        color: const Color(0xFFD1D1D1),
                      ),
                    ],
                  ),
                );
              }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _productFiltersController.categories.length, padding: EdgeInsets.only(bottom: HeightDimension.h_150), physics: NeverScrollableScrollPhysics(),),
            ],
          ),
        );
      case 1: /// brands
        return SingleChildScrollView(
          child: Column(
            key: UniqueKey(),
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15, right: WidthDimension.w_15),
                child: Row(
                  children: [
                    TMTCustomCheckbox(
                      isChecked: (_productFiltersController.brands.where((element) => element.isSelected == false).toList().isEmpty),
                      onChange: (value) {
                        setState(() {
                          if (_productFiltersController.brands.where((element) => element.isSelected == false).toList().isEmpty) {
                            _productFiltersController.brands.forEach((element) {
                              element.isSelected = false;
                            });
                          } else {
                            _productFiltersController.brands.forEach((element) {
                              element.isSelected = true;
                            });
                          }
                        });
                      },
                      backgroundColor: AppColor.primaryBG,
                      borderColor: AppColor.primaryBG,
                      icon: Icons.check,
                      iconColor: AppColor.neutral_100,
                      size: 16,
                      borderWidth: 1,
                      iconSize: 14,
                    ),
                    HorizontalSpacing(WidthDimension.w_8),
                    TMTTextWidget(title: "Select All", style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_16,
                      color: AppColor.neutral_800,
                      fontWeight: FontWeight.w500,
                    ),),
                  ],
                ),
              ),
              ListView.builder(itemBuilder: (context, index){
                return InkWell(
                  onTap: (){
                    setState(() {
                      _productFiltersController.brands[index].isSelected = !_productFiltersController.brands[index].isSelected;
                    });
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15),
                        child: Row(
                          children: [
                            SizedBox(
                              height: HeightDimension.h_14,
                              width: HeightDimension.h_14,
                              child: Image.asset(_productFiltersController.brands[index].isSelected ? TMTImages.icTickThin : TMTImages.icTickThinGrey, fit: BoxFit.contain),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            Expanded(
                              child: TMTTextWidget(title: _productFiltersController.brands[index].name ?? "", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_14,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w500,
                              ),),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_5),
                      Container(
                        margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                        width: double.infinity,
                        height: 0.5,
                        color: const Color(0xFFD1D1D1),
                      ),
                    ],
                  ),
                );
              }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _productFiltersController.brands.length, padding: EdgeInsets.only(bottom: HeightDimension.h_150), physics: NeverScrollableScrollPhysics(),),
            ],
          ),
        );
      case 2: /// location
        return SingleChildScrollView(
          child: Column(
            key: UniqueKey(),
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15, right: WidthDimension.w_15),
                child: Row(
                  children: [
                    TMTCustomCheckbox(
                      isChecked: (_productFiltersController.location.where((element) => element.isSelected == false).toList().isEmpty),
                      onChange: (value) {
                        setState(() {
                          if ((_productFiltersController.location.where((element) => element.isSelected == false).toList().isEmpty)) {
                            _productFiltersController.location.forEach((element) {
                              element.isSelected = false;
                            });
                          } else {
                            _productFiltersController.location.forEach((element) {
                              element.isSelected = true;
                            });
                          }
                        });
                      },
                      backgroundColor: AppColor.primaryBG,
                      borderColor: AppColor.primaryBG,
                      icon: Icons.check,
                      iconColor: AppColor.neutral_100,
                      size: 16,
                      borderWidth: 1,
                      iconSize: 14,
                    ),
                    HorizontalSpacing(WidthDimension.w_8),
                    TMTTextWidget(title: "Select All", style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_16,
                      color: AppColor.neutral_800,
                      fontWeight: FontWeight.w500,
                    ),),
                  ],
                ),
              ),
              ListView.builder(itemBuilder: (context, index){
                return InkWell(
                  onTap: (){
                    setState(() {
                      _productFiltersController.location[index].isSelected = !_productFiltersController.location[index].isSelected;
                    });
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15),
                        child: Row(
                          children: [
                            SizedBox(
                              height: HeightDimension.h_14,
                              width: HeightDimension.h_14,
                              child: Image.asset(_productFiltersController.location[index].isSelected ? TMTImages.icTickThin : TMTImages.icTickThinGrey, fit: BoxFit.contain),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            Expanded(
                              child: TMTTextWidget(title: _productFiltersController.location[index].address1 ?? "", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_14,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w500,
                              ),),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_5),
                      Container(
                        margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                        width: double.infinity,
                        height: 0.5,
                        color: const Color(0xFFD1D1D1),
                      ),
                    ],
                  ),
                );
              }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _productFiltersController.location.length, padding: EdgeInsets.only(bottom: HeightDimension.h_150), physics: NeverScrollableScrollPhysics(),),
            ],
          ),
        );
      case 3: /// Color
        return SingleChildScrollView(child: Column(
            key: UniqueKey(),
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15, right: WidthDimension.w_15),
                child: Row(
                  children: [
                    TMTCustomCheckbox(
                      isChecked: (_productFiltersController.color.where((element) => element.isSelected == false).toList().isEmpty),
                      onChange: (value) {
                        setState(() {
                          if ((_productFiltersController.color.where((element) => element.isSelected == false).toList().isEmpty)) {
                            _productFiltersController.color.forEach((element) {
                              element.isSelected = false;
                            });
                          } else {
                            _productFiltersController.color.forEach((element) {
                              element.isSelected = true;
                            });
                          }
                        });
                      },
                      backgroundColor: AppColor.primaryBG,
                      borderColor: AppColor.primaryBG,
                      icon: Icons.check,
                      iconColor: AppColor.neutral_100,
                      size: 16,
                      borderWidth: 1,
                      iconSize: 14,
                    ),
                    HorizontalSpacing(WidthDimension.w_8),
                    TMTTextWidget(title: "Select All", style: TMTFontStyles.text(
                      fontSize: TMTFontSize.sp_16,
                      color: AppColor.neutral_800,
                      fontWeight: FontWeight.w500,
                    ),),
                  ],
                ),
              ),
              ListView.builder(itemBuilder: (context, index){
                return InkWell(
                  onTap: (){
                    setState(() {
                      _productFiltersController.color[index].isSelected = !_productFiltersController.color[index].isSelected;
                    });
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15),
                        child: Row(
                          children: [
                            SizedBox(
                              height: HeightDimension.h_14,
                              width: HeightDimension.h_14,
                              child: Image.asset(_productFiltersController.color[index].isSelected ? TMTImages.icTickThin : TMTImages.icTickThinGrey, fit: BoxFit.contain),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            Expanded(
                              child: TMTTextWidget(title: _productFiltersController.color[index].value ?? "", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_14,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w500,
                              ),),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_5),
                      Container(
                        margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                        width: double.infinity,
                        height: 0.5,
                        color: const Color(0xFFD1D1D1),
                      ),
                    ],
                  ),
                );
              }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _productFiltersController.color.length, padding: EdgeInsets.only(bottom: HeightDimension.h_150), physics: NeverScrollableScrollPhysics(),),
            ],
          ),);
      case 4: /// Size
        return SingleChildScrollView(child: Column(
          key: UniqueKey(),
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15, right: WidthDimension.w_15),
              child: Row(
                children: [
                  TMTCustomCheckbox(
                    isChecked: (_productFiltersController.size.where((element) => element.isSelected == false).toList().isEmpty),
                    onChange: (value) {
                      setState(() {
                        if ((_productFiltersController.size.where((element) => element.isSelected == false).toList().isEmpty)) {
                          _productFiltersController.size.forEach((element) {
                            element.isSelected = false;
                          });
                        } else {
                          _productFiltersController.size.forEach((element) {
                            element.isSelected = true;
                          });
                        }
                      });
                    },
                    backgroundColor: AppColor.primaryBG,
                    borderColor: AppColor.primaryBG,
                    icon: Icons.check,
                    iconColor: AppColor.neutral_100,
                    size: 16,
                    borderWidth: 1,
                    iconSize: 14,
                  ),
                  HorizontalSpacing(WidthDimension.w_8),
                  TMTTextWidget(title: "Select All", style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    color: AppColor.neutral_800,
                    fontWeight: FontWeight.w500,
                  ),),
                ],
              ),
            ),
            ListView.builder(itemBuilder: (context, index){
              return InkWell(
                onTap: (){
                  setState(() {
                    _productFiltersController.size[index].isSelected = !_productFiltersController.size[index].isSelected;
                  });
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15),
                      child: Row(
                        children: [
                          SizedBox(
                            height: HeightDimension.h_14,
                            width: HeightDimension.h_14,
                            child: Image.asset(_productFiltersController.size[index].isSelected ? TMTImages.icTickThin : TMTImages.icTickThinGrey, fit: BoxFit.contain),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                          Expanded(
                            child: TMTTextWidget(title: _productFiltersController.size[index].value ?? "", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w500,
                            ),),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                        ],
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_5),
                    Container(
                      margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                      width: double.infinity,
                      height: 0.5,
                      color: const Color(0xFFD1D1D1),
                    ),
                  ],
                ),
              );
            }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _productFiltersController.size.length, padding: EdgeInsets.only(bottom: HeightDimension.h_150), physics: NeverScrollableScrollPhysics(),),
          ],
        ),);
      case 5: /// Material
        return SingleChildScrollView(child: Column(
          key: UniqueKey(),
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15, right: WidthDimension.w_15),
              child: Row(
                children: [
                  TMTCustomCheckbox(
                    isChecked: (_productFiltersController.material.where((element) => element.isSelected == false).toList().isEmpty),
                    onChange: (value) {
                      setState(() {
                        if ((_productFiltersController.material.where((element) => element.isSelected == false).toList().isEmpty)) {
                          _productFiltersController.material.forEach((element) {
                            element.isSelected = false;
                          });
                        } else {
                          _productFiltersController.material.forEach((element) {
                            element.isSelected = true;
                          });
                        }
                      });
                    },
                    backgroundColor: AppColor.primaryBG,
                    borderColor: AppColor.primaryBG,
                    icon: Icons.check,
                    iconColor: AppColor.neutral_100,
                    size: 16,
                    borderWidth: 1,
                    iconSize: 14,
                  ),
                  HorizontalSpacing(WidthDimension.w_8),
                  TMTTextWidget(title: "Select All", style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    color: AppColor.neutral_800,
                    fontWeight: FontWeight.w500,
                  ),),
                ],
              ),
            ),
            ListView.builder(itemBuilder: (context, index){
              return InkWell(
                onTap: (){
                  setState(() {
                    _productFiltersController.material[index].isSelected = !_productFiltersController.material[index].isSelected;
                  });
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15),
                      child: Row(
                        children: [
                          SizedBox(
                            height: HeightDimension.h_14,
                            width: HeightDimension.h_14,
                            child: Image.asset(_productFiltersController.material[index].isSelected ? TMTImages.icTickThin : TMTImages.icTickThinGrey, fit: BoxFit.contain),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                          Expanded(
                            child: TMTTextWidget(title: _productFiltersController.material[index].value ?? "", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w500,
                            ),),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                        ],
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_5),
                    Container(
                      margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                      width: double.infinity,
                      height: 0.5,
                      color: const Color(0xFFD1D1D1),
                    ),
                  ],
                ),
              );
            }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _productFiltersController.material.length, padding: EdgeInsets.only(bottom: HeightDimension.h_150), physics: NeverScrollableScrollPhysics(),),
          ],
        ),);
      case 6: /// Tack Type
        return SingleChildScrollView(child: Column(
          key: UniqueKey(),
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15, right: WidthDimension.w_15),
              child: Row(
                children: [
                  TMTCustomCheckbox(
                    isChecked: (_productFiltersController.tackType.where((element) => element.isSelected == false).toList().isEmpty),
                    onChange: (value) {
                      setState(() {
                        if ((_productFiltersController.tackType.where((element) => element.isSelected == false).toList().isEmpty)) {
                          _productFiltersController.tackType.forEach((element) {
                            element.isSelected = false;
                          });
                        } else {
                          _productFiltersController.tackType.forEach((element) {
                            element.isSelected = true;
                          });
                        }
                      });
                    },
                    backgroundColor: AppColor.primaryBG,
                    borderColor: AppColor.primaryBG,
                    icon: Icons.check,
                    iconColor: AppColor.neutral_100,
                    size: 16,
                    borderWidth: 1,
                    iconSize: 14,
                  ),
                  HorizontalSpacing(WidthDimension.w_8),
                  TMTTextWidget(title: "Select All", style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    color: AppColor.neutral_800,
                    fontWeight: FontWeight.w500,
                  ),),
                ],
              ),
            ),
            ListView.builder(itemBuilder: (context, index){
              return InkWell(
                onTap: (){
                  setState(() {
                    _productFiltersController.tackType[index].isSelected = !_productFiltersController.tackType[index].isSelected;
                  });
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15),
                      child: Row(
                        children: [
                          SizedBox(
                            height: HeightDimension.h_14,
                            width: HeightDimension.h_14,
                            child: Image.asset(_productFiltersController.tackType[index].isSelected ? TMTImages.icTickThin : TMTImages.icTickThinGrey, fit: BoxFit.contain),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                          Expanded(
                            child: TMTTextWidget(title: _productFiltersController.tackType[index].value ?? "", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w500,
                            ),),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                        ],
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_5),
                    Container(
                      margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                      width: double.infinity,
                      height: 0.5,
                      color: const Color(0xFFD1D1D1),
                    ),
                  ],
                ),
              );
            }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _productFiltersController.tackType.length, padding: EdgeInsets.only(bottom: HeightDimension.h_150), physics: NeverScrollableScrollPhysics(),),
          ],
        ),);
      case 7: /// Filling
        return SingleChildScrollView(child: Column(
          key: UniqueKey(),
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15, right: WidthDimension.w_15),
              child: Row(
                children: [
                  TMTCustomCheckbox(
                    isChecked: (_productFiltersController.filling.where((element) => element.isSelected == false).toList().isEmpty),
                    onChange: (value) {
                      setState(() {
                        if ((_productFiltersController.filling.where((element) => element.isSelected == false).toList().isEmpty)) {
                          _productFiltersController.filling.forEach((element) {
                            element.isSelected = false;
                          });
                        } else {
                          _productFiltersController.filling.forEach((element) {
                            element.isSelected = true;
                          });
                        }
                      });
                    },
                    backgroundColor: AppColor.primaryBG,
                    borderColor: AppColor.primaryBG,
                    icon: Icons.check,
                    iconColor: AppColor.neutral_100,
                    size: 16,
                    borderWidth: 1,
                    iconSize: 14,
                  ),
                  HorizontalSpacing(WidthDimension.w_8),
                  TMTTextWidget(title: "Select All", style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    color: AppColor.neutral_800,
                    fontWeight: FontWeight.w500,
                  ),),
                ],
              ),
            ),
            ListView.builder(itemBuilder: (context, index){
              return InkWell(
                onTap: (){
                  setState(() {
                    _productFiltersController.filling[index].isSelected = !_productFiltersController.filling[index].isSelected;
                  });
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: WidthDimension.w_15, top: HeightDimension.h_15),
                      child: Row(
                        children: [
                          SizedBox(
                            height: HeightDimension.h_14,
                            width: HeightDimension.h_14,
                            child: Image.asset(_productFiltersController.filling[index].isSelected ? TMTImages.icTickThin : TMTImages.icTickThinGrey, fit: BoxFit.contain),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                          Expanded(
                            child: TMTTextWidget(title: _productFiltersController.filling[index].value ?? "", style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w500,
                            ),),
                          ),
                          HorizontalSpacing(WidthDimension.w_10),
                        ],
                      ),
                    ),
                    VerticalSpacing(HeightDimension.h_5),
                    Container(
                      margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                      width: double.infinity,
                      height: 0.5,
                      color: const Color(0xFFD1D1D1),
                    ),
                  ],
                ),
              );
            }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _productFiltersController.filling.length, padding: EdgeInsets.only(bottom: HeightDimension.h_150), physics: NeverScrollableScrollPhysics(),),
          ],
        ),);
      default:
        return Container();
    }
  }
}