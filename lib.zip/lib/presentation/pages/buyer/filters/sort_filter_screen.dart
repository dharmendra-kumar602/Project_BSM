import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/model/request/post_apply_filters_request.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class SortFilterScreen extends StatefulWidget {
  bool? isSellerProducts;
  int? sellerId;
  int? brandId;
  bool isEmpty;
  bool isTrend;
  SortFilterScreen({super.key, this.isSellerProducts = false, this.sellerId, this.brandId, this.isEmpty = false, this.isTrend = false});

  @override
  State<StatefulWidget> createState() => _SortFilterScreenState();
}

class _SortFilterScreenState extends State<SortFilterScreen> {

  var sortFilters = [
    "Just Added",
    "Price - High To Low",
    "Price - Low To High",
    "Discount"
  ];

  final CategoryController _categoryController =
  Get.find<CategoryController>();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.pop(context);
      },
      child: Scaffold(
        backgroundColor: AppColor.neutral_800.withOpacity(0.4),
        body: Column(
          children:  [
            const Spacer(),
            Column(
              children: [
                const SizedBox(height: 200,),
                Container(
                  width: MediaQuery.of(context).size.width,
                  margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                  decoration: BoxDecoration(
                      color: AppColor.neutral_100,
                      borderRadius: BorderRadius.circular(TMTRadius.r_15)
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: WidthDimension.w_20, top: HeightDimension.h_15, right: WidthDimension.w_20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            TMTTextWidget(title: "SORT BY", style:  TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_11,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w300,
                            ),),
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_10),
                      Container(
                        height: 1,
                        width: double.infinity,
                        color: const Color(0xFFE6E6E6),
                      ),
                      ListView.builder(itemBuilder: (context, index) {
                        return InkWell(
                          onTap: (){
                            setState(() {
                              _categoryController.selectedSorting = index;
                            });
                            if (!widget.isEmpty) {  
                              (widget.isSellerProducts ?? false) ? _categoryController.applySellersFilters(context, PostProductFiltersReruest(attributes: [], pageSize: _categoryController.limit, pageNumber: _categoryController.offset, sellers: _categoryController.selectedSellersFilters, sortId: _categoryController.sortingFilters[_categoryController.selectedSorting], isTrending: widget.isTrend)) : widget.brandId == null ? _categoryController.applyFilters(context, PostProductFiltersReruest(attributes: [], pageSize: _categoryController.limit, pageNumber: _categoryController.offset, categoryIds: _categoryController.selectedCategoriesFilters, brands: _categoryController.selectedBrandsFilters, sortId: _categoryController.sortingFilters[_categoryController.selectedSorting], isTrending: widget.isTrend)) : _categoryController.applyBrandsFilters(context, PostProductFiltersReruest(attributes: [], pageSize: _categoryController.limit, pageNumber: _categoryController.offset, brands: _categoryController.selectedBrandsFilters, categoryIds: _categoryController.selectedCategoriesFilters, sortId: _categoryController.sortingFilters[_categoryController.selectedSorting], isTrending: widget.isTrend));
                            }
                            Navigator.pop(context);
                          },
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: WidthDimension.w_20, top: HeightDimension.h_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(title: sortFilters[index], style:  _categoryController.selectedSorting == index ? TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_16,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w500,
                                ) : TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_16,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),),
                              ),
                              VerticalSpacing(HeightDimension.h_5)
                            ],
                          ),
                        );
                      }, itemCount: sortFilters.length, shrinkWrap: true, scrollDirection: Axis.vertical, padding: EdgeInsets.zero,),
                      VerticalSpacing(HeightDimension.h_10),
                    ],
                  ),
                ),
                ClipPath(
                  clipper: MessageClipper(),
                  child: Container(
                    height: 20,
                    width: MediaQuery.of(context).size.width - WidthDimension.w_100,
                    color: AppColor.neutral_100,
                  ),
                ),
              ],
            )
          ],
        ),
        bottomNavigationBar: Container(
          margin: EdgeInsets.only(bottom: HeightDimension.h_50),
          height: HeightDimension.h_48,
        ),
      ),
    );
  }
}

class MessageClipper extends CustomClipper<Path> {

  @override
  Path getClip(Size size) {

    var firstOffset = Offset(size.width * 0.1, 0.0);
    var secondPoint = Offset(size.width * 0.15, size.height );
    var lastPoint = Offset(size.width * 0.2, 0.0);
    var path = Path()
      ..moveTo(firstOffset.dx, firstOffset.dy)
      ..lineTo(secondPoint.dx, secondPoint.dy)
      ..lineTo(lastPoint.dx, lastPoint.dy)
      ..close();


    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {

    return true;
  }

}