import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/filters_final_models.dart';
import 'package:take_my_tack/data/model/request/post_apply_filters_request.dart';
import 'package:take_my_tack/data/model/response/get_product_filters_response.dart';
import 'package:take_my_tack/data/repository_implementation/product_repository_impl.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class ProductFiltersController extends GetxController {

  ProductRepositoryImpl productRepositoryImpl = ProductRepositoryImpl();

  int selectedFiltersCategoriesIndex = 2;

  List<FilterCategory> categories = [];
  List<Brand> brands = [];
  List<Location> location = [];
  List<Color> color = [];
  List<Color> size = [];
  List<Color> material = [];
  List<Color> tackType = [];
  List<Color> filling = [];

  /*
   Method use to get product filters.
   Parameter- BuildContext context.
   Return -> Filters list.
  */
  void getProductFilters (BuildContext context, List<int> selectedCategoryIds, List<int> selectedBrandIds, List<int> selectedSellers) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getProductFilters();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              categories = right.data?.categories ?? [];
              brands = right.data?.brands ?? [];
              location = right.data?.location ?? [];
              color = right.data?.color ?? [];
              size = right.data?.size ?? [];
              material = right.data?.material ?? [];
              tackType = right.data?.tackType ?? [];
              filling = right.data?.filling ?? [];

              categories.forEach((element) {
                if (selectedCategoryIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });
              brands.forEach((element) {
                if (selectedBrandIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });
              update([GetControllerBuilders.productFiltersController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get seller products filters.
   Parameter- BuildContext context.
   Return -> Filters list.
  */
  void getSellerProductsFilters (BuildContext context, List filtersIds) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getProductFilters();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              categories = right.data?.categories ?? [];
              brands = right.data?.brands ?? [];
              location = right.data?.location ?? [];
              color = right.data?.color ?? [];
              size = right.data?.size ?? [];
              material = right.data?.material ?? [];
              tackType = right.data?.tackType ?? [];
              filling = right.data?.filling ?? [];


              categories.forEach((element) {
                if (filtersIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });
              brands.forEach((element) {
                if (filtersIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });
              location.forEach((element) {
                if (filtersIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });
              color.forEach((element) {
                if (filtersIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });
              size.forEach((element) {
                if (filtersIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });
              material.forEach((element) {
                if (filtersIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });
              tackType.forEach((element) {
                if (filtersIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });
              filling.forEach((element) {
                if (filtersIds.contains(element.id)) {
                  element.isSelected = true;
                }
              });

              update([GetControllerBuilders.productFiltersController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}