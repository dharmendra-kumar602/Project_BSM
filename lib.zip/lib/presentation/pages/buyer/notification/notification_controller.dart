import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/response/get_notifications_response.dart';
import 'package:take_my_tack/data/repository_implementation/dashboard_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class NotificationController extends GetxController {

  DashboardRepositoryImpl dashboardRepositoryImpl = DashboardRepositoryImpl();

  List<NotificationData> notification = [];

  /*
   Method use to get notifications.
   Parameter- BuildContext context
   Return -> No Return type.
  */
  void getNotifications (BuildContext context, String userRole, {Function()? callBack}) {
    if (!TMTLocalStorage.getUserLoggedIn()) {
      return;
    }
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getNotifications();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              notification = right.data?.where((element) => element.notificationRelatedTo == "ticket" ? true : element.userRole == userRole).toList() ?? [];
              update([GetControllerBuilders.notificationControllerScreen]);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to read notification.
   Parameter- BuildContext context, String id
   Return -> No Return type.
  */
  void putReadNotifications (BuildContext context, String id, {Function()? callBack}) {
    if (!TMTLocalStorage.getUserLoggedIn()) {
      return;
    }
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.putReadNotification(id);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              callBack?.call();
              update([GetControllerBuilders.notificationControllerScreen]);
            } else {
              if (right.responseHeader?.error?.messages.first == "Invalid Access Token" || right.responseHeader?.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
              }
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}