import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/response/get_notifications_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_orders_response.dart';
import 'package:take_my_tack/data/model/response/get_support_tickets_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/notification/notification_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/buyer_order_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/support_ticket/support_ticket_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/order/seller_order_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<StatefulWidget> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {

  final NotificationController _notificationController =
  Get.find<NotificationController>();

  final DashboardController _dashboardController = Get.find<DashboardController>();

  String userRole = Get.arguments ?? "BUYER";

  @override
  void initState() {
    _getNotifications(context, userRole);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NotificationController>(
        id: GetControllerBuilders.notificationControllerScreen,
        init: _notificationController,
        builder: (controller) {
        return Scaffold(
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: (){
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              Container(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: "Notifications",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: _notificationController.notification.isNotEmpty ? ListView.builder(
                  padding: EdgeInsets.only(top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                  itemBuilder: (BuildContext context,int index){
                  return InkWell(
                    onTap: (){
                      _onNotificationClick(_notificationController.notification[index], index);
                    },
                    child: Stack(
                      children: [
                        Container(
                          margin: EdgeInsets.only(bottom: HeightDimension.h_2),
                          width: double.infinity,
                          decoration: BoxDecoration(
                              color: AppColor.neutral_100,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.2),
                                  spreadRadius: 1,
                                  blurRadius: 1,
                                  offset: const Offset(0, 1), // changes position of shadow
                                ),
                              ]
                          ),
                          padding: EdgeInsets.only(top: HeightDimension.h_8, bottom: HeightDimension.h_8, left: WidthDimension.w_10, right: WidthDimension.w_10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _notificationController.notification[index].isRead == 0 ? HorizontalSpacing(WidthDimension.w_10) : SizedBox.shrink(),
                              Container(
                                margin: EdgeInsets.only(left: WidthDimension.w_20),
                                height: HeightDimension.h_55,
                                width: HeightDimension.h_55,
                                child: (_notificationController.notification[index].image?.isEmpty ?? true) ? Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Image.asset(TMTImages.logo, fit: BoxFit.cover,),
                                ) : Image.network(_notificationController.notification[index].image ?? "", fit: BoxFit.cover,),
                              ),
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: WidthDimension.w_170,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    TMTTextWidget(title: _notificationController.notification[index].title ?? "", style: TMTFontStyles.text(
                                      fontSize: TMTFontSize.sp_14,
                                      color: AppColor.neutral_800,
                                      fontWeight: FontWeight.w500,
                                    ), maxLines: 2,),
                                    const VerticalSpacing(2),
                                    Visibility(
                                      visible: _notificationController.notification[index].text?.isNotEmpty ?? false,
                                      child: TMTTextWidget(title: _notificationController.notification[index].text ?? "", style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_11,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w500,
                                      ), maxLines: 1,),
                                    ),
                                    const VerticalSpacing(2),
                                    Visibility(
                                      visible: (_notificationController.notification[index].price != null || _notificationController.notification[index].subText.toString().isNotEmpty),
                                      child: TMTTextWidget(title: _notificationController.notification[index].price == null ? _notificationController.notification[index].subText ?? "" : "£${_notificationController.notification[index].price.toStringAsFixed(2)}", style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_11,
                                        color: AppColor.neutral_800,
                                        fontWeight: FontWeight.w500,
                                      ), maxLines: 1,),
                                    ),
                                  ],
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_10),
                              Spacer(),
                              SizedBox(
                                height: HeightDimension.h_16,
                                width: HeightDimension.h_16,
                                child: Image.asset(TMTImages.icNext,),
                              ),
                              HorizontalSpacing(WidthDimension.w_20),
                            ],
                          ),
                        ),
                        Positioned(
                          top: 0,
                          bottom: 0,
                          left: WidthDimension.w_15,
                          child: Visibility(
                            visible: _notificationController.notification[index].isRead == 0,
                            child: TMTRoundedContainer(
                              height: HeightDimension.h_5,
                              width: HeightDimension.h_5,
                              bgColor: AppColor.primary,
                            ),
                          ),
                        )
                      ],
                    ),
                  );
                }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _notificationController.notification.length,) : const Center(child: TMTTextWidget(title: "No notification found."),),
              ),
            ],
          ),
        );
      }
    );
  }

  /// on notification click check type and redirect user to screen
  Future<void> _onNotificationClick(NotificationData notification, int index) async {
    try {
      switch (notification.notificationRelatedTo) {
        case "order":
          if (notification.userRole == "SELLER") {
            var controller = Get.put(SellerOrderController());
            controller.getSellerOrders(context, (data) async {
              var v = data?.where((element) => element.id == notification.notificationRelationId).toList() ?? [];
              if (v.isNotEmpty) {
                await Get.toNamed(AppRoutes.sellerOrderDetailsScreen, arguments: v.first);
              }
            }, "");
          } else {
            await Get.toNamed(AppRoutes.confirmOrderScreen, arguments: [notification.notificationRelationId]);
          }
          break;
        case "orderItem":
          Get.put(BuyerOrderController());
          await Get.toNamed(AppRoutes.orderDetailsScreen, arguments: notification.notificationRelationId);
          break;
        case "product":
          await Get.toNamed(AppRoutes.productDetailScreen, arguments: [notification.notificationRelationId, -1]);
          break;
        case "ticket":
          Get.put(SupportTicketController()).selectedTicket = Ticket(id: notification.notificationRelationId ?? 0, title: notification.title ?? "", description: notification.text ?? "", status: "", userId: notification.toUserId ?? 0, createdAt: notification.createdAt ?? DateTime.now(), updatedAt: notification.updatedAt ?? DateTime.now());
          await Get.toNamed(AppRoutes.ticketDetailsPage);
          break;
        case "seller":
          _checkUserStatus();
          break;
        case "documents":
          await Get.toNamed(AppRoutes.uploadDocumentScreen);
          break;
        default:
          break;
      }
    } catch (e) {}
    if (notification.isRead == 0) {
      if (!mounted) return;
      _notificationController.putReadNotifications(context, notification.id.toString(), callBack: (){
        setState(() {
          _getNotifications(context, userRole);
        });
      });
    }
  }

  /// Check user status
  void _checkUserStatus() {

    if (TMTUtilities.getUserRoleFromToken() == "SELLER") {
      _dashboardController.getSellerRegisterStatus(context, () async {
        if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
          await Get.toNamed(AppRoutes.sellerDashboard);
        } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
          await Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
        } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
          await Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
        } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
          _dashboardController.getUpdatedToken(context, () async {
            await Get.toNamed(
                AppRoutes.sellerPlanDetailsScreen);
          });
        } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
          _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), () async {
            await Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
          });
        } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
          TMTUtilities.showUserDisabledDialog(context);
        } else {
          await Get.toNamed(AppRoutes.sellerDashboard);
        }
      });
    } else {
      if (!TMTLocalStorage.getUserLoggedIn()) {
        Get.offAndToNamed(AppRoutes.loginScreen,
            arguments: AppRoutes.homeScreen);
      } else {
        _dashboardController.getSellerRegisterStatus(context, () async {
          if (TMTLocalStorage.getSellerStatus() == "COMPLETED") {
            _dashboardController.getUpdatedToken(context, () async {
              await Get.toNamed(AppRoutes.sellerDashboard);
            });
          } else if (TMTLocalStorage.getSellerStatus() == "REJECTED") {
            await Get.toNamed(AppRoutes.requestStatusScreen, arguments: false);
          } else if (TMTLocalStorage.getSellerStatus() == "PENDING") {
            await Get.toNamed(AppRoutes.requestStatusScreen, arguments: true);
          } else if (TMTLocalStorage.getSellerStatus() == "VERIFIED") {
            _dashboardController.getUpdatedToken(context, () async {
              await Get.toNamed(
                  AppRoutes.sellerPlanDetailsScreen);
            });
          } else if (TMTLocalStorage.getSellerStatus() == "UN_VERIFIED") {
            _dashboardController.resendOtp(context, TMTLocalStorage.getSellerId().toString(), () async {
              await Get.toNamed(AppRoutes.sellerConfirmationOTPScreen, arguments: TMTLocalStorage.getSellerId());
            });
          } else if (TMTLocalStorage.getSellerStatus() == "DISABLED") {
            TMTUtilities.showUserDisabledDialog(context);
          } else {
            await Get.toNamed(AppRoutes.registerToSellScreen);
          }
        });
      }
    }
  }

  /// call api
  _getNotifications (context, userRole) {
    _notificationController.getNotifications(context, userRole);
  }
}
