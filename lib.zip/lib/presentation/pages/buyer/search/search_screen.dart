import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/model/response/get_search_products_response.dart';
import 'package:take_my_tack/data/repository_implementation/product_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {

  ProductRepositoryImpl productRepositoryImpl = ProductRepositoryImpl();

  final TextEditingController searchTextController = TextEditingController();

  int _pageSize = 20;
  int _pageKey = 0;

  final PagingController<int, SearchResult> _pagingController =
  PagingController(firstPageKey: 0);

  @override
  void initState() {
    _pagingController.addPageRequestListener((pageKey) {
      _pageKey = pageKey;
      searchProducts();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(SizeConfig.safeBlockVertical * 10),
          child: Container(
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 3,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ], color: AppColor.neutral_100),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Row(
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_20),
                          SizedBox(
                            width: WidthDimension.w_18,
                            height: HeightDimension.h_15,
                            child: Image.asset(
                              TMTImages.icBack,
                              color: AppColor.neutral_800,
                              fit: BoxFit.cover,
                            ),
                          ),
                          HorizontalSpacing(WidthDimension.w_6),
                        ],
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_6),
                    Expanded(
                      child: TMTRoundedCornersContainer(
                        borderColor: AppColor.neutral_800,
                        borderWidth: 0.5,
                        height: HeightDimension.h_35,
                        bgColor: AppColor.neutral_100,
                        borderRadius:
                        const BorderRadius.all(Radius.circular(TMTRadius.r_35)),
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_15,
                            right: WidthDimension.w_15),
                        child: Row(
                          children: [
                            SizedBox(
                              height: HeightDimension.h_18,
                              width: HeightDimension.h_18,
                              child: Image.asset(
                                TMTImages.icSearch,
                                color: AppColor.textColor,
                              ),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            Expanded(
                                child: TextField(
                                  decoration: InputDecoration.collapsed(
                                      hintText: "Search",
                                      hintStyle: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w500,
                                      )),
                                  controller: searchTextController,
                                  onChanged: (v){
                                    searchProducts();
                                  },
                                )),
                            HorizontalSpacing(WidthDimension.w_10),
                            GestureDetector(
                              onTap: () {
                                searchTextController.clear();
                                _pagingController.itemList?.clear();
                                TMTUtilities.closeKeyboard(context);
                              },
                              child: SizedBox(
                                height: HeightDimension.h_12,
                                width: HeightDimension.h_12,
                                child: Image.asset(
                                  TMTImages.icErrorToastCancel,
                                  color: AppColor.neutral_800,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_20),
                  ],
                ),
                VerticalSpacing(SizeConfig.safeBlockVertical * 2),
              ],
            ),
          )),
      body: Column(
        children: [
          VerticalSpacing(HeightDimension.h_10),
          Expanded(
            child: PagedListView<int, SearchResult>(
              shrinkWrap: true,
              pagingController: _pagingController,
              builderDelegate: PagedChildBuilderDelegate<SearchResult>(
                itemBuilder: (context, item, index) => InkWell(
                  onTap: (){
            Get.toNamed(AppRoutes.productDetailScreen, arguments: [item.id]);
            },
              child: Container(
                margin: EdgeInsets.only(top: HeightDimension.h_8, left: WidthDimension.w_20, right: WidthDimension.w_20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: TMTTextWidget(title: item.title, style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w300,
                          ),),
                        ),
                        const Spacer(),
                        SizedBox(
                          height: HeightDimension.h_16,
                          width: HeightDimension.h_16,
                          child: Image.asset(TMTImages.icNextType2, color: AppColor.neutral_800,),
                        ),
                      ],
                    ),
                    VerticalSpacing(HeightDimension.h_10),
                    Container(
                      height: 0.5,
                      width: double.infinity,
                      color: const Color(0xFFD1D1D1),
                    ),
                  ],
                ),
              ),
            ),
                noMoreItemsIndicatorBuilder: (context) { return const SizedBox.shrink();},
                newPageErrorIndicatorBuilder: (context) { return const SizedBox.shrink();},
                newPageProgressIndicatorBuilder: (context) { return const SizedBox.shrink();},
                noItemsFoundIndicatorBuilder: (context) { return Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(child: const TMTTextWidget(title: "No product found."),),
                      ],
                    ),
                  ],
                );},
                firstPageErrorIndicatorBuilder: (context) { return const SizedBox.shrink();},
                firstPageProgressIndicatorBuilder: (context) { return const SizedBox.shrink();},
              ),
            ),
          ),
        ],
      )
    );
  }

  /*
   Method use to get search results.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void searchProducts () async {
    if (searchTextController.text.toString().length < 3) {
      await Future.delayed(const Duration(milliseconds: 250));
      setState(() {
        _pagingController.itemList?.clear();
      });
      return;
    }
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getSearchProducts(searchTextController.text.toString(), _pageKey, _pageSize);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              _pagingController.itemList?.clear();
              var newItems = right.data;
              final isLastPage = newItems.length < _pageSize;
              if (isLastPage) {
                _pagingController.appendLastPage(newItems);
              } else {
                final nextPageKey = _pageKey + newItems.length;
                _pagingController.appendPage(newItems, nextPageKey);
              }
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
          _pagingController.error = error;
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}
