import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/model/response/get_search_products_response.dart';
import 'package:take_my_tack/data/repository_implementation/product_repository_impl.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class SearchScreenController extends GetxController {




}