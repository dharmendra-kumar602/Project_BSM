import 'package:carousel_slider/carousel_controller.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/request/get_product_by_productId_request.dart';
import 'package:take_my_tack/data/model/response/get_product_by_product_id_response.dart';
import 'package:take_my_tack/data/model/response/get_seller_details_response.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/data/repository_implementation/product_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class ProductDetailController extends GetxController {

  final CarouselController carouselController = CarouselController();
  var isCurrentIndex = 0;
  ProductRepositoryImpl productRepositoryImpl = ProductRepositoryImpl();

  Data? productData;

  int selectedColor = 0;
  int selectedSize = 0;
  int selectedMaterial = 0;
  int selectedTackType= 0;
  int selectedFilling= 0;
  int selectedVariation = 0;
  int selectedAttributeId = 0;

  List<ProductAttributeMapping> productColors = [];
  List<ProductAttributeMapping> productSizes = [];
  List<ProductAttributeMapping> productMaterial = [];
  List<ProductAttributeMapping> productTackType = [];
  List<ProductAttributeMapping> productFilling = [];

  SellerData? sellerData;

  bool addedToWishList = false;
  bool addedToCart = false;

  /// Method use to check if products already saved in local Database.
  checkProductsInLocalDB(int productId) async {
    bool hasWishlistItem = TMTLocalStorage.getWishlistItems().where((element) => element.productId == productId).toList().isNotEmpty;
    addedToWishList = hasWishlistItem;
    await Future.delayed(const Duration(milliseconds: 200));
    update([GetControllerBuilders.productDetailController]);
  }

  /// Method use to change current index.
  changeCurrentIndexValue(int index) {
    isCurrentIndex = index;
    carouselController.animateToPage(index);
    update([GetControllerBuilders.productDetailController]);
  }

  /*
   Method use to get product details by product id.
   Parameter- BuildContext context, int id.
   Return -> No Return type.
  */
  void getProductsByProductId(BuildContext context, int productId, int variationId, {bool deeplink = false}) {
    GetProductByProductIdRequest request = GetProductByProductIdRequest(
        productId: productId);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getProductByProductId(
              request);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              productData = right.data;
              if (right.data?.product == null) {
                /// check if product is recent viewed list, if yes then remove it and redirect user back
                if (TMTLocalStorage.getRecentlyViewedItems().firstWhereOrNull((element) => element.productId == productId) != null) {
                  TMTLocalStorage.removeFromRecentlyViewed(WishlistModel(productId: productId, variationId: variationId, variation: Variation(id: variationId, salePrice: 0, maxRetailPrice: 0, weightInPound: 0, productImages: [], product: WishlistProduct(id: 0, title: "", description: "", sellerStore: WishlistSellerStore(id: 0)))));
                }
                TMTToast.showErrorToast(context, "Selected product have been sold or removed by the seller and is no longer available.", title: "Product Not Available");
                if (deeplink) {
                  Get.offAllNamed(AppRoutes.dashBoardScreen);
                } else {
                  Navigator.pop(context);
                }
                return;
              }
              if (right.data?.product?.productVariations?.isEmpty ?? true) {
                /// check if product is recent viewed list, if yes then remove it and redirect user back
                if (TMTLocalStorage.getRecentlyViewedItems().firstWhereOrNull((element) => element.productId == productId) != null) {
                  TMTLocalStorage.removeFromRecentlyViewed(WishlistModel(productId: productId, variationId: variationId, variation: Variation(id: variationId, salePrice: 0, maxRetailPrice: 0, weightInPound: 0, productImages: [], product: WishlistProduct(id: 0, title: "", description: "", sellerStore: WishlistSellerStore(id: 0)))));
                }
                TMTToast.showErrorToast(context, "Selected product have been sold or removed by the seller and is no longer available.", title: "Product Not Available");
                if (deeplink) {
                  Get.offAllNamed(AppRoutes.dashBoardScreen);
                } else {
                  Navigator.pop(context);
                }
                return;
              }

              List<ProductAttributeMapping> mapping = [];
              for (int i = 0; i < (right.data?.product?.productVariations?.length ?? 0); i++) {
                right.data?.product?.productVariations?[i].productAttributeMappings?.forEach((element) {
                  element.variation = i;
                  mapping.add(element);
                });
              }
              productColors = removeDuplicatesByValue(mapping.where((element) => element.attributeName == "Color").toList());
              productSizes = removeDuplicatesByValue(mapping.where((element) => element.attributeName == "Size").toList());
              productMaterial = removeDuplicatesByValue(mapping.where((element) => element.attributeName == "Material").toList());
              productTackType = removeDuplicatesByValue(mapping.where((element) => element.attributeName == "TackType").toList());
              productFilling = removeDuplicatesByValue(mapping.where((element) => element.attributeName == "Filling").toList());

              if (right.data?.product?.productVariations?.first.inStock == 0) {
                /// check if product is recent viewed list, if yes then remove it and redirect user back
                if (TMTLocalStorage.getRecentlyViewedItems().firstWhereOrNull((element) => element.productId == productId) != null) {
                  TMTLocalStorage.removeFromRecentlyViewed(WishlistModel(productId: productId, variationId: variationId, variation: Variation(id: variationId, salePrice: 0, maxRetailPrice: 0, weightInPound: 0, productImages: [], product: WishlistProduct(id: 0, title: "", description: "", sellerStore: WishlistSellerStore(id: 0)))));
                }
              } else {
                addToRecentViewedProduct(context, WishlistModel(productId: productId, variationId: productData?.product?.productVariations?[selectedVariation].id ?? 0, variation: Variation(id: productData?.product?.productVariations?.first.id ?? 0, salePrice: productData?.product?.productVariations?.first.salePrice ?? 0, maxRetailPrice: productData?.product?.productVariations?.first.maxRetailPrice ?? 0, weightInPound: 0, productImages: productData?.product?.productVariations?.first.productImages?.map((e) => WishlistProductImage(imageName: e.imageName ?? "")).toList() ?? [], product: WishlistProduct(id: productData?.product?.productVariations?.first.id ?? 0, title: productData?.product?.title ?? "", description: productData?.product?.description ?? "", sellerStore: WishlistSellerStore(id: 0)))));
              }

              try {
                if (variationId != -1) {
                  for (int i=0; i<(productData?.product?.productVariations?.length ?? 0); i++) {
                    if (productData?.product?.productVariations?[i].id == variationId) {
                      selectedVariation = i;
                    }
                  }
                }
              } catch (e) {
                selectedVariation = 0;
              }
            update([GetControllerBuilders.productDetailController]);
            } else {
            TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get seller details by seller id.
   Parameter- BuildContext context, int sellerId.
   Return -> No Return type.
  */
  void getSellerDetailsById(BuildContext context, int sellerId) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await productRepositoryImpl.getSellerDetails(
              sellerId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              sellerData = right.data;
              update([GetControllerBuilders.productSellerDetailController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to remove Duplicates by Value.
   Parameter- List<ProductAttributeMapping> list.
   Return -> List<ProductAttributeMapping>.
  */
  List<ProductAttributeMapping> removeDuplicatesByValue(List<ProductAttributeMapping> list) {
    Set<String> uniqueValues = <String>{};
    List<ProductAttributeMapping> uniqueList = [];

    for (var item in list) {
      if (!uniqueValues.contains(item.value)) {
        uniqueValues.add(item.value ?? "");
        uniqueList.add(item);
      }
    }
    return uniqueList;
  }


  /*
   Method use for add product to recently viewed list.
   Parameter- BuildContext context, int variationId, int productId.
   Return -> No Return type.
  */
  void addToRecentViewedProduct (BuildContext context, WishlistModel wishlistModel) {
    TMTLocalStorage.addToRecentlyViewed(wishlistModel);
    update([GetControllerBuilders.homePageController]);
    return;
  }

  /*
   Method used to update Size and Variation.
   Parameter- int index.
   Return -> No Return type.
  */
  void updateSize(int index) {
    selectedSize = index;
    selectedVariation = productSizes[index].variation;
    update([GetControllerBuilders.productDetailController]);
  }

  /*
   Method used to update Color and Variation.
   Parameter- int index.
   Return -> No Return type.
  */
  void updateColor(int index) {
    selectedColor = index;
    update([GetControllerBuilders.productDetailController]);
  }

  /*
   Method used to update material and Variation.
   Parameter- int index.
   Return -> No Return type.
  */
  void updateMaterial(int index) {
    selectedMaterial = index;
    selectedVariation = productMaterial[index].variation;
    update([GetControllerBuilders.productDetailController]);
  }

  /*
   Method used to update TackType and Variation.
   Parameter- int index.
   Return -> No Return type.
  */
  void updateTackType(int index) {
    selectedTackType = index;
    selectedVariation = productTackType[index].variation;
    update([GetControllerBuilders.productDetailController]);
  }

  /*
   Method used to update Filling and Variation.
   Parameter- int index.
   Return -> No Return type.
  */
  void updateFilling(int index) {
    selectedFilling = index;
    selectedVariation = productFilling[index].variation;
    update([GetControllerBuilders.productDetailController]);
  }
}