import 'package:app_settings/app_settings.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/response/get_cart_response.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/product_detail/product_detail_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_readmore_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key});

  @override
  State<StatefulWidget> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {

  final ProductDetailController _productDetailController =
      Get.put(ProductDetailController());

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  List<int?> args = Get.arguments ?? [];

  @override
  void initState() {
    try {
      var params = Get.parameters['id'];
      print("TMTLINK - ${params}");
      if (params?.isNotEmpty ?? false) {
        var v = int.parse(params!);
        print("TMTLINK - ${v}");
        args.insert(0, v);
      }
    } catch (e) {
      print("yeh error aya bhai $e");
    }
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      _callApi();
    },);
    super.initState();
  }

  /// call api's
  _callApi () {
    try {
      _productDetailController.getProductsByProductId(context, args.first!, args.length == 2 ? args[1]! : -1, deeplink: Get.parameters['id'] != null);
      _productDetailController.checkProductsInLocalDB(args.first!);
    } catch (e) {
      _productDetailController.getProductsByProductId(context, args.first!, 0, deeplink: Get.parameters['id'] != null );
      _productDetailController.checkProductsInLocalDB(args.first!);
    }
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return GetBuilder<ProductDetailController>(
        id: GetControllerBuilders.productDetailController,
        init: _productDetailController,
        builder: (controller) {
        return AnnotatedRegion(
          value: SystemUiOverlayStyle.dark,
          child: Scaffold(
            body: Column(
              children: [
                Container(
                  color: AppColor.neutral_100.withOpacity(0.2),
                  width: double.infinity,
                  height: HeightDimension.h_28,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        (_productDetailController.productData?.product?.productVariations
                            ?.isEmpty ?? true)
                            ? SizedBox(
                          height: HeightDimension.h_330, width: double.infinity,)
                            : _productDetailController.productData?.product
                            ?.productVariations?[_productDetailController
                            .selectedVariation].productImages?.length == 1
                            ? Stack(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              height: HeightDimension.h_300,
                              child: TMTCachedImage.networkImage(
                                _productDetailController.productData?.product
                                    ?.productVariations?[_productDetailController
                                    .selectedVariation].productImages?.first.imageName ??
                                    "",
                                fit: BoxFit.cover,
                              ),
                            ),
                            Positioned(
                              top: HeightDimension.h_18,
                              right: WidthDimension.w_20,
                              left: WidthDimension.w_20,
                              child: Row(
                                children: [
                                  InkWell(
                                    onTap: (){
                                      if (Get.parameters['id']?.isNotEmpty ?? false) {
                                        Get.offAllNamed(AppRoutes.dashBoardScreen);
                                      } else {
                                        Get.back();
                                      }
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.all(6.0),
                                      decoration: const BoxDecoration(
                                          image: DecorationImage(
                                              image: AssetImage(TMTImages.icRoundWhiteBG))),
                                      child: SizedBox(
                                        height: HeightDimension.h_18,
                                        width: HeightDimension.h_18,
                                        child: Image.asset(
                                          TMTImages.icBack,
                                          color: AppColor.neutral_800,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const Spacer(),
                                  GestureDetector(
                                    onTap: () async {
                                      await Get.toNamed(AppRoutes.cartScreen, arguments: false);
                                      setState(() {
                                        _callApi();
                                      });
                                    },
                                    child: Stack(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(top: HeightDimension.h_5, right: HeightDimension.h_5),
                                          padding: const EdgeInsets.all(6.0),
                                          decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(TMTImages.icRoundWhiteBG))),
                                          child: Stack(
                                            children: [
                                              SizedBox(
                                                height: HeightDimension.h_20,
                                                width: HeightDimension.h_20,
                                                child: Image.asset(
                                                  TMTImages.icCart,
                                                  color: AppColor.neutral_800,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Visibility(
                                          visible: TMTLocalStorage.getCartItems().isNotEmpty,
                                          child: Positioned(
                                            top: 0,
                                            right: 0,
                                            child: TMTRoundedCornersContainer(
                                                bgColor: AppColor.primaryBG,
                                                padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                child: TMTTextWidget(title: TMTLocalStorage.getCartItems().length.toString(), style: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontSize: 10),)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_4),
                                  GestureDetector(
                                    onTap: () async {
                                      await Get.toNamed(AppRoutes.wishListScreen, arguments: false);
                                      setState(() {
                                        _callApi();
                                      });
                                    },
                                    child: Stack(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(top: HeightDimension.h_5, right: HeightDimension.h_5),
                                          padding: const EdgeInsets.all(6.0),
                                          decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(TMTImages.icRoundWhiteBG))),
                                          child: Stack(
                                            children: [
                                              SizedBox(
                                                height: HeightDimension.h_20,
                                                width: HeightDimension.h_20,
                                                child: Image.asset(
                                                  TMTImages.icHeart,
                                                  color: AppColor.neutral_800,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Visibility(
                                          visible: TMTLocalStorage.getWishlistItems().isNotEmpty,
                                          child: Positioned(
                                            top: 0,
                                            right: 0,
                                            child: TMTRoundedCornersContainer(
                                                bgColor: AppColor.primaryBG,
                                                padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                child: TMTTextWidget(title: TMTLocalStorage.getWishlistItems().length.toString() ?? "", style: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontSize: 10),)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  HorizontalSpacing(WidthDimension.w_4),
                                  GestureDetector(
                                    onTap: (){
                                      Share.share('Check out this product https://sharetakemytack.page.link/productDetailScreen?id=${args.first!}');
                                      TMTUtilities.createFirstPostLink(args.first!);
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.all(6.0),
                                      decoration: const BoxDecoration(
                                          image: DecorationImage(
                                              image: AssetImage(TMTImages.icRoundWhiteBG))),
                                      child: SizedBox(
                                        height: HeightDimension.h_20,
                                        width: HeightDimension.h_20,
                                        child: Image.asset(
                                          TMTImages.icShareWB,
                                          color: AppColor.neutral_800,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        )
                            : Column(
                          children: [
                            Stack(
                              children: [
                                CarouselSlider(
                                  items: _productDetailController.productData?.product!.productVariations?[_productDetailController.selectedVariation].productImages?.map((e){
                                    return SizedBox(
                                      width: double.infinity,
                                      height: HeightDimension.h_300,
                                      child: TMTCachedImage.networkImage(
                                        e.imageName ?? "",
                                        fit: BoxFit.cover,
                                      ),
                                    );
                                  }).toList(),
                                  carouselController: _productDetailController.carouselController,
                                  options: CarouselOptions(
                                      autoPlayAnimationDuration:
                                          const Duration(milliseconds: 1000),
                                      autoPlay: true,
                                      viewportFraction: 1.0,
                                      enlargeCenterPage: false,
                                      height: HeightDimension.h_330,
                                      onPageChanged: (index, reason) {
                                        _productDetailController.isCurrentIndex = index;
                                        _productDetailController.update(
                                            [GetControllerBuilders.productDetailController]);
                                      }),
                                ),
                                Positioned(
                                  top: HeightDimension.h_18,
                                  right: WidthDimension.w_20,
                                  left: WidthDimension.w_20,
                                  child: Row(
                                    children: [
                                      InkWell(
                                        onTap: (){
                                          if (Get.parameters['id']?.isNotEmpty ?? false) {
                                            Get.offAllNamed(AppRoutes.dashBoardScreen);
                                          } else {
                                            Get.back();
                                          }
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.all(6.0),
                                          decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(TMTImages.icRoundWhiteBG))),
                                          child: SizedBox(
                                            height: HeightDimension.h_18,
                                            width: HeightDimension.h_18,
                                            child: Image.asset(
                                              TMTImages.icBack,
                                              color: AppColor.neutral_800,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const Spacer(),
                                      GestureDetector(
                                        onTap: () async {
                                          await Get.toNamed(AppRoutes.cartScreen, arguments: false);
                                          setState(() {
                                            _callApi();
                                          });
                                        },
                                        child: Stack(
                                          children: [
                                            Container(
                                              margin: EdgeInsets.only(top: HeightDimension.h_5, right: HeightDimension.h_5),
                                              padding: const EdgeInsets.all(6.0),
                                              decoration: const BoxDecoration(
                                                  image: DecorationImage(
                                                      image: AssetImage(TMTImages.icRoundWhiteBG))),
                                              child: Stack(
                                                children: [
                                                  SizedBox(
                                                    height: HeightDimension.h_20,
                                                    width: HeightDimension.h_20,
                                                    child: Image.asset(
                                                      TMTImages.icCart,
                                                      color: AppColor.neutral_800,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Visibility(
                                              visible: TMTLocalStorage.getCartItems().isNotEmpty,
                                              child: Positioned(
                                                top: 0,
                                                right: 0,
                                                child: TMTRoundedCornersContainer(
                                                    bgColor: AppColor.primaryBG,
                                                    padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                    child: TMTTextWidget(title: TMTLocalStorage.getCartItems().length.toString() ?? "", style: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontSize: 10),)),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_4),
                                      GestureDetector(
                                        onTap: () async {
                                          await Get.toNamed(AppRoutes.wishListScreen, arguments: false);
                                          setState(() {
                                            _callApi();
                                          });
                                        },
                                        child: Stack(
                                          children: [
                                            Container(
                                              margin: EdgeInsets.only(top: HeightDimension.h_5, right: HeightDimension.h_5),
                                              padding: const EdgeInsets.all(6.0),
                                              decoration: const BoxDecoration(
                                                  image: DecorationImage(
                                                      image: AssetImage(TMTImages.icRoundWhiteBG))),
                                              child: Stack(
                                                children: [
                                                  SizedBox(
                                                    height: HeightDimension.h_20,
                                                    width: HeightDimension.h_20,
                                                    child: Image.asset(
                                                      TMTImages.icHeart,
                                                      color: AppColor.neutral_800,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Visibility(
                                              visible: TMTLocalStorage.getWishlistItems().isNotEmpty,
                                              child: Positioned(
                                                top: 0,
                                                right: 0,
                                                child: TMTRoundedCornersContainer(
                                                    bgColor: AppColor.primaryBG,
                                                    padding: EdgeInsets.only(left: WidthDimension.w_6, right: WidthDimension.w_6, top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                    child: TMTTextWidget(title: TMTLocalStorage.getWishlistItems().length.toString() ?? "", style: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontSize: 10),)),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_4),
                                      GestureDetector(
                                        onTap: (){
                                          Share.share('Check out this product https://sharetakemytack.page.link/productDetailScreen?id=${args.first!}');
                                          TMTUtilities.createFirstPostLink(args.first!);
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.all(6.0),
                                          decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(TMTImages.icRoundWhiteBG))),
                                          child: SizedBox(
                                            height: HeightDimension.h_20,
                                            width: HeightDimension.h_20,
                                            child: Image.asset(
                                              TMTImages.icShareWB,
                                              color: AppColor.neutral_800,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                            VerticalSpacing(HeightDimension.h_20),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: _productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].productImages?.asMap().entries.map((entry) {
                                return Container(
                                  width: 14.0,
                                  height: 2.0,
                                  margin: const EdgeInsets.only(right: 2, left: 2),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: _productDetailController.isCurrentIndex ==
                                                  entry.key
                                              ? AppColor.primary
                                              : AppColor.sliderIndicatorDisabledColor,
                                          width: 0.5),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(TMTRadius.r_20)),
                                      color:
                                          _productDetailController.isCurrentIndex == entry.key
                                              ? AppColor.primary
                                              : AppColor.sliderIndicatorDisabledColor),
                                );
                              }).toList() ?? [],
                            ),
                          ],
                        ),
                        Visibility(
                          visible: _getVisibility(),
                          child: Column(
                            children: [
                              VerticalSpacing(HeightDimension.h_20),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(
                                  title: "Note: This product is no longer available in stock.",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_12,
                                    color: AppColor.primary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_20),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(
                            title: _productDetailController.productData?.product?.brand?.name ?? "",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_8),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(
                            title:
                            _productDetailController.productData?.product?.title ?? "",
                            style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_12,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_8),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(
                            title: (_productDetailController.productData?.product?.productVariations?.isEmpty ?? true) ? "" : _productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].salePrice == null ? "" : "£${_productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].salePrice?.toStringAsFixed(2)}",
                            style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.primaryBG,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Container(
                          margin: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          width: double.infinity,
                          height: 2,
                          color: AppColor.dividerColor,
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(
                            title: "Description",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_15,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_8),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: ReadMoreText(
                            '${_productDetailController.productData?.product?.description ?? ""} ',
                            trimLines: 2,
                            colorClickableText: AppColor.neutral_800,
                            trimMode: TrimMode.Line,
                            trimCollapsedText: 'READ MORE',
                            trimExpandedText: '',
                            style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.textColor,
                              fontWeight: FontWeight.w400,
                            ),
                            lessStyle: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w600,
                            ),
                            moreStyle: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_14,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w600,
                                textDecoration: TextDecoration.underline),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Container(
                          margin: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          width: double.infinity,
                          height: 2,
                          color: AppColor.dividerColor,
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(title: "Category", style:
                          TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_15,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_10),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(title: _productDetailController.productData?.product?.category?.name ?? "", style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_15,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w500,
                          )),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Container(
                          margin: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          width: double.infinity,
                          height: 2,
                          color: AppColor.dividerColor,
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20, bottom: HeightDimension.h_5),
                          child: Row(
                            children: [
                              TMTTextWidget(
                                title: "Additional Details",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),

                        Visibility(
                          visible: _productDetailController.productData?.product?.productVariations?.isNotEmpty ?? false,
                          child: Padding(
                            padding: EdgeInsets.only(
                                left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TMTTextWidget(
                                  title: "Condition",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                TMTTextWidget(
                                  title: (_productDetailController.productData?.product?.productVariations?.isEmpty ?? true) ? "" : _productDetailController.productData?.product?.productVariations?.first.condition.toString() ?? "",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Visibility(
                          visible: _productDetailController.productData?.product?.productVariations?.isNotEmpty ?? false,
                          child: Padding(
                            padding: EdgeInsets.only(
                                left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TMTTextWidget(
                                  title: "Weight",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                TMTTextWidget(
                                  title: (_productDetailController.productData?.product?.productVariations?.isEmpty ?? true) ? "" : "${_productDetailController.productData?.product?.productVariations?.first.weight.toString() ?? ""} kg",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.textColor,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TMTTextWidget(
                                title: "Length",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              TMTTextWidget(
                                title: (_productDetailController.productData?.product?.productVariations?.isEmpty ?? true) ? "" : "${_productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].length.toString() ?? ""} cm",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TMTTextWidget(
                                title: "Width",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              TMTTextWidget(
                                title: (_productDetailController.productData?.product?.productVariations?.isEmpty ?? true) ? "" : "${_productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].width.toString() ?? ""} cm",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TMTTextWidget(
                                title: "Height",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              TMTTextWidget(
                                title: (_productDetailController.productData?.product?.productVariations?.isEmpty ?? true) ? "" : "${_productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].height.toString() ?? ""} cm",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TMTTextWidget(
                                title: "Processing Time",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              TMTTextWidget(
                                title: _productDetailController.productData?.product?.processingTime ?? "",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ),

                        Visibility(
                          visible: _productDetailController.productSizes.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              VerticalSpacing(HeightDimension.h_15),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(
                                  title: "Size",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                height: HeightDimension.h_30,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: ListView.builder(itemBuilder: (context, index){
                                  return GestureDetector(
                                    onTap: (){
                                      _productDetailController.updateSize(index);
                                    },
                                    child: Container(
                                      padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4, right: WidthDimension.w_4),
                                      decoration: BoxDecoration(
                                          color: _productDetailController.selectedSize == index
                                              ? AppColor.primaryBG
                                              : AppColor.neutral_100,
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_30)),
                                          border: Border.all(
                                              color: _productDetailController.selectedSize == index
                                                  ? AppColor.primaryBG
                                                  : AppColor.textColor,
                                              width: 1)),
                                      child: Center(
                                        child: TMTTextWidget(
                                          title: _productDetailController.productSizes.isNotEmpty ? _productDetailController.productSizes[0].value ?? "" : "",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_10,
                                            color: _productDetailController.selectedSize == index
                                                ? AppColor.neutral_100
                                                : AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: 1,),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: _productDetailController.productColors.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              VerticalSpacing(HeightDimension.h_15),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(
                                  title: "Colour",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                height: HeightDimension.h_30,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: ListView.builder(
                                  itemBuilder: (context, index){
                                  return GestureDetector(
                                    onTap: (){
                                      _productDetailController.updateColor(index);
                                    },
                                    child: _productDetailController.selectedColor == index ?
                                    Container(
                                      padding: const EdgeInsets.all(2),
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4, right: WidthDimension.w_4),
                                      decoration: BoxDecoration(
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_30)),
                                          border: Border.all(
                                              color: AppColor.primaryBG,
                                              width: 1)),
                                      child: Container(
                                          height: HeightDimension.h_28,
                                          width: HeightDimension.h_25,
                                          decoration: BoxDecoration(
                                              color:
                                              _productDetailController.productColors.isNotEmpty ? _getColorByName(_productDetailController.productColors[0].value ?? "") : Colors.black,
                                              borderRadius: const BorderRadius.all(
                                                  Radius.circular(TMTRadius.r_30)),
                                              border: Border.all(
                                                  color: _productDetailController.productColors.isNotEmpty ? _getColorByName(_productDetailController.productColors[0].value ?? "") : Colors.grey,
                                                  width: 1))
                                      ),
                                    ) :
                                    Container(
                                        height: HeightDimension.h_28,
                                        width: HeightDimension.h_30,
                                        margin: EdgeInsets.only(
                                            left: WidthDimension.w_4, right: WidthDimension.w_4),
                                        decoration: BoxDecoration(
                                            color:
                                            _getColorByName(_productDetailController.productColors[index].value ?? ""),
                                            borderRadius: const BorderRadius.all(
                                                Radius.circular(TMTRadius.r_30)),
                                            border: Border.all(
                                                color: _getColorByName(_productDetailController.productColors[index].value ?? ""),
                                                width: 1))
                                    ),
                                  );
                                }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: 1,)
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: _productDetailController.productMaterial.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              VerticalSpacing(HeightDimension.h_15),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(
                                  title: "Material",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                height: HeightDimension.h_30,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: ListView.builder(itemBuilder: (context, index){
                                  return GestureDetector(
                                    onTap: (){
                                      _productDetailController.updateMaterial(index);
                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4, right: WidthDimension.w_4),
                                      padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      decoration: BoxDecoration(
                                          color: _productDetailController.selectedMaterial == index
                                              ? AppColor.primaryBG
                                              : AppColor.neutral_100,
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_30)),
                                          border: Border.all(
                                              color: _productDetailController.selectedMaterial == index
                                                  ? AppColor.primaryBG
                                                  : AppColor.textColor,
                                              width: 1)),
                                      child: Center(
                                        child: TMTTextWidget(
                                          title: _productDetailController.productMaterial.isNotEmpty ? _productDetailController.productMaterial[0].value ?? "" : "",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_10,
                                            color: _productDetailController.selectedMaterial == index
                                                ? AppColor.neutral_100
                                                : AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: 1,),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: _productDetailController.productTackType.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              VerticalSpacing(HeightDimension.h_15),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(
                                  title: "Tack Type",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                height: HeightDimension.h_30,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: ListView.builder(itemBuilder: (context, index){
                                  return GestureDetector(
                                    onTap: (){
                                      _productDetailController.updateTackType(index);
                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4, right: WidthDimension.w_4),
                                      padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      decoration: BoxDecoration(
                                          color: _productDetailController.selectedTackType == index
                                              ? AppColor.primaryBG
                                              : AppColor.neutral_100,
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_30)),
                                          border: Border.all(
                                              color: _productDetailController.selectedTackType == index
                                                  ? AppColor.primaryBG
                                                  : AppColor.textColor,
                                              width: 1)),
                                      child: Center(
                                        child: TMTTextWidget(
                                          title: _productDetailController.productTackType.isNotEmpty ? _productDetailController.productTackType[0].value ?? "" : "",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_10,
                                            color: _productDetailController.selectedTackType == index
                                                ? AppColor.neutral_100
                                                : AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: 1,),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: _productDetailController.productFilling.isNotEmpty,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              VerticalSpacing(HeightDimension.h_15),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: TMTTextWidget(
                                  title: "Filling",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_15,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                height: HeightDimension.h_30,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_15, right: WidthDimension.w_15),
                                child: ListView.builder(itemBuilder: (context, index){
                                  return GestureDetector(
                                    onTap: (){
                                      _productDetailController.updateFilling(index);
                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(
                                          left: WidthDimension.w_4, right: WidthDimension.w_4),
                                      padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                                      decoration: BoxDecoration(
                                          color: _productDetailController.selectedFilling == index
                                              ? AppColor.primaryBG
                                              : AppColor.neutral_100,
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(TMTRadius.r_30)),
                                          border: Border.all(
                                              color: _productDetailController.selectedFilling == index
                                                  ? AppColor.primaryBG
                                                  : AppColor.textColor,
                                              width: 1)),
                                      child: Center(
                                        child: TMTTextWidget(
                                          title: _productDetailController.productFilling.isNotEmpty ? _productDetailController.productFilling[0].value ?? "" : "",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_10,
                                            color: _productDetailController.selectedFilling == index
                                                ? AppColor.neutral_100
                                                : AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }, scrollDirection: Axis.horizontal, shrinkWrap: true, itemCount: 1,),
                              ),
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                margin: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                width: double.infinity,
                                height: 2,
                                color: AppColor.dividerColor,
                              ),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextWidget(
                            title: "Seller Details",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_15,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: Row(
                            children: [
                              TMTTextWidget(
                                title: "Sold by",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_14,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_6),
                              TMTTextWidget(
                                title: _productDetailController.productData?.product?.sellerStore?.name ?? "",
                                style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_14,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              const Spacer(),
                              GestureDetector(
                                onTap: () async {
                                  await Get.toNamed(AppRoutes.productSellerDetailScreen, arguments: _productDetailController.productData?.product?.sellerStore?.id ?? 0);
                                  setState(() {
                                    _callApi();
                                  });
                                },
                                child: TMTTextWidget(
                                  title: "VIEW DETAILS",
                                  style: TMTFontStyles.textHarbinger(
                                    fontSize: TMTFontSize.sp_14,
                                    color: AppColor.primaryBG,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_15),
                        Container(
                          margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
                          width: double.infinity,
                          height: HeightDimension.h_90,
                          color: const Color(0xFFEEEEEE),
                          child: Stack(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        height: HeightDimension.h_30,
                                        width: HeightDimension.h_30,
                                        child: Image.asset(TMTImages.icGenuineProduct),
                                      ),
                                      VerticalSpacing(HeightDimension.h_8),
                                      TMTTextWidget(title: "Verified Seller", style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_14,
                                        color: AppColor.primaryBG,
                                        fontWeight: FontWeight.w700,
                                      ),),
                                    ],
                                  ),
                                  Container(color: AppColor.neutral_400, width: 2, height: double.infinity, margin: EdgeInsets.only(top: HeightDimension.h_10, bottom: HeightDimension.h_10),),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        height: HeightDimension.h_30,
                                        width: HeightDimension.h_30,
                                        child: Image.asset(TMTImages.icQualityChecked),
                                      ),
                                      VerticalSpacing(HeightDimension.h_8),
                                      TMTTextWidget(title: "Security Checked", style: TMTFontStyles.textTeen(
                                        fontSize: TMTFontSize.sp_14,
                                        color: AppColor.primaryBG,
                                        fontWeight: FontWeight.w700,
                                      ),)
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: (_productDetailController.productData?.product?.sellerStore?.storePickupAddress != null),
                          child: Column(
                            children: [
                              VerticalSpacing(HeightDimension.h_15),
                              Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(
                                    left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    TMTTextWidget(
                                      title: "Pickup Address:  ",
                                      style: TMTFontStyles.text(
                                        fontSize: TMTFontSize.sp_12,
                                        color: AppColor.textColor,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    Expanded(
                                      child: TMTTextWidget(
                                        title: _getCompleteAddress(),
                                        style: TMTFontStyles.text(
                                          fontSize: TMTFontSize.sp_12,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_20),
                      ],
                    ),),
                ),
              ],
            ),
            bottomNavigationBar: Container(
              padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
              height: HeightDimension.h_80,
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.3),
                  spreadRadius: 3,
                  blurRadius: 5,
                  offset: const Offset(0, 3), // changes position of shadow
                ),
              ], color: AppColor.neutral_100),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: (){
                        if (_productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].inStock == 0) {
                          return;
                        }
                        _dashboardController.addToWishList(context, wishlistModel : WishlistModel(productId: args.first!, variationId: _productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].id ?? 0, variation: Variation(id: _productDetailController.productData?.product?.productVariations?.first.id ?? 0, salePrice: _productDetailController.productData?.product?.productVariations?.first.salePrice ?? 0, maxRetailPrice: _productDetailController.productData?.product?.productVariations?.first.maxRetailPrice ?? 0, weightInPound: 0, productImages: _productDetailController.productData?.product?.productVariations?.first.productImages?.map((e) => WishlistProductImage(imageName: e.imageName ?? "")).toList() ?? [], product: WishlistProduct(id: args.first!, title: _productDetailController.productData?.product?.title ?? "", description: _productDetailController.productData?.product?.description ?? "", sellerStore: WishlistSellerStore(id: 0)))), (isAdded){
                          setState(() {
                            _productDetailController.addedToWishList = isAdded;
                          });
                        });
                      },
                      child: Container(
                        padding: EdgeInsets.only(top: HeightDimension.h_10, bottom: HeightDimension.h_10, left: WidthDimension.w_15, right: WidthDimension.w_15),
                        decoration: BoxDecoration(
                          color: AppColor.neutral_100,
                          border: Border.all(color: AppColor.primaryBG, width: 1),
                          borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_30))
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: HeightDimension.h_18,
                              width: HeightDimension.h_18,
                              child: Image.asset(_productDetailController.addedToWishList ? TMTImages.icHeartEnabled : TMTImages.icHeart, color: AppColor.primaryBG,),
                            ),
                            HorizontalSpacing(WidthDimension.w_10),
                            TMTTextWidget(title: "WISHLIST", style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.primaryBG,
                              fontWeight: FontWeight.w700,
                            ),)
                          ],
                        ),
                      ),
                    ),
                  ),
                  HorizontalSpacing(WidthDimension.w_10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        if (_productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].inStock == 0) {
                          return;
                        }
                        if ((TMTLocalStorage.getCartItems().firstWhereOrNull((element) => element.productId == args.first!) != null)) {
                          await Get.toNamed(AppRoutes.cartScreen, arguments: false);
                          if (!mounted) return;
                          setState(() {
                            _callApi();
                          });
                          return;
                        }
                        _dashboardController.addToCart(context, _productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].id ?? 0, args.first!, CartData(sellers: [], sizes: [], cartFinalData: [], tax: 0, cartId: 0), (){
                          setState(() {
                            _productDetailController.productData?.isInCart = true;
                          });
                        }, 1);
                      },
                      child: Container(
                        padding: EdgeInsets.only(top: HeightDimension.h_12, bottom: HeightDimension.h_12, left: WidthDimension.w_18, right: WidthDimension.w_18),
                        decoration: BoxDecoration(
                          color: AppColor.primaryBG,
                          border: Border.all(color: AppColor.primaryBG, width: 1),
                          borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_30))
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TMTTextWidget(title: (TMTLocalStorage.getCartItems().firstWhereOrNull((element) => element.productId == args.first!) != null) ? "VIEW CART" : "ADD TO CART", style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.neutral_100,
                              fontWeight: FontWeight.w700,
                            ),),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }
    );
  }

  /// get color by name
  Color _getColorByName(String value) {
    switch (value) {
      case "Black": return Colors.black;
      case "Brown": return Colors.brown;
      case "Tan": return const Color(0xFFD2B48C);
      case "Navy": return const Color(0xFF000080);
      case "Green": return const Color(0xFF00FF00);
      case "White": return const Color(0xFFFFFFFF);
      case "Beige": return const Color(0xFFf5f5dc);
      case "Red": return const Color(0xFFFF0000);
      case "Blue": return Colors.blue;
      case "Yellow": return const Color(0xFFFFFF00);
      case "Orange": return const Color(0xFFFFA500);
      case "Pink": return const Color(0xFFffc0cb);
      case "Rose": return const Color(0xFFFF007F);
      case "Gold": return const Color(0xFFFFD700);
      case "Silver": return const Color(0xFFC0C0C0);
      case "Bronze": return const Color(0xFFCD7F32);
      default: return Colors.black;
    }
  }

  /// get complete address
  String _getCompleteAddress() {
    return "${_productDetailController.productData?.product?.sellerStore?.storePickupAddress?.address1}, ${_productDetailController.productData?.product?.sellerStore?.storePickupAddress?.city}, ${_productDetailController.productData?.product?.sellerStore?.storePickupAddress?.state}, ${_productDetailController.productData?.product?.sellerStore?.storePickupAddress?.country}";
  }

  bool _getVisibility() {
    if (_productDetailController.productData?.product?.productVariations?.isEmpty ?? true) {
      return false;
    }
    return _productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].inStock == 0;
  }
}
