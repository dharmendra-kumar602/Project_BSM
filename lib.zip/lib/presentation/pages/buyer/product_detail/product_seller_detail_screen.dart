import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/product_detail/product_detail_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_readmore_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';

class ProductSellerDetailScreen extends StatefulWidget {
  const ProductSellerDetailScreen({super.key});

  @override
  State<StatefulWidget> createState() => _ProductSellerDetailScreenState();
}

class _ProductSellerDetailScreenState extends State<ProductSellerDetailScreen> {

  final ProductDetailController _productDetailController =
  Get.find<ProductDetailController>();

  int sellerId = Get.arguments;

  @override
  void initState() {
    _productDetailController.getSellerDetailsById(context, sellerId);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(
        id: GetControllerBuilders.productSellerDetailController,
        init: _productDetailController,
        builder: (controller) {
        return Scaffold(
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_6),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        TMTTextWidget(
                          title: "Seller Detail",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: Image.asset(TMTImages.bgSellerHeader, fit: BoxFit.fitWidth,),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Padding(
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_20, right: WidthDimension.w_20),
                        child: TMTTextWidget(
                          title: _productDetailController.sellerData?.name ?? "",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_24,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Container(
                        margin: EdgeInsets.only(
                            left: WidthDimension.w_20, right: WidthDimension.w_20),
                        width: double.infinity,
                        height: 2,
                        color: AppColor.dividerColor,
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Padding(
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_20, right: WidthDimension.w_20),
                        child: TMTTextWidget(
                          title: "About Seller",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_15,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Padding(
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_20, right: WidthDimension.w_20),
                        child: ReadMoreText(
                          _productDetailController.sellerData?.description ?? "",
                          trimLines: 4,
                          colorClickableText: AppColor.neutral_800,
                          trimMode: TrimMode.Line,
                          trimCollapsedText: 'READ MORE',
                          trimExpandedText: '',
                          style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.textColor,
                            fontWeight: FontWeight.w400,
                          ),
                          lessStyle: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_14,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w600,
                          ),
                          moreStyle: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_14,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w600,
                              textDecoration: TextDecoration.underline),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Container(
                        margin: EdgeInsets.only(
                            left: WidthDimension.w_20, right: WidthDimension.w_20),
                        width: double.infinity,
                        height: 2,
                        color: AppColor.dividerColor,
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Container(
                        margin: EdgeInsets.only(
                            left: WidthDimension.w_15, right: WidthDimension.w_15),
                        width: double.infinity,
                        height: HeightDimension.h_90,
                        color: AppColor.dividerColor,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  height: HeightDimension.h_50,
                                  width: HeightDimension.h_50,
                                  child: Image.asset(TMTImages.icVerifiedBadge),
                                ),
                                VerticalSpacing(HeightDimension.h_8),
                                TMTTextWidget(
                                  title: "Verified Seller",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_14,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w700,
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Padding(
                        padding: EdgeInsets.only(
                            left: WidthDimension.w_20, right: WidthDimension.w_20),
                        child: TMTTextWidget(
                          title: "Ask question to the seller",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_15,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      GestureDetector(
                        onTap: (){
                          if (!TMTLocalStorage.getUserLoggedIn()) {
                            showDialog(
                              barrierDismissible: true,
                                context: context,
                                builder: (c){
                              return Material(
                                color: Colors.transparent,
                                child: BackdropFilter(
                                  filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                                  child: GestureDetector(
                                    onTap: (){
                                      Navigator.pop(context);
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(color: AppColor.neutral_800.withOpacity(0.5)),
                                      width: double.infinity,
                                      height: double.infinity,
                                      child: Center(
                                        child: GestureDetector(
                                          onTap: (){

                                          },
                                          child: TMTRoundedCornersContainer(
                                            width: WidthDimension.w_286,
                                            height: HeightDimension.h_140,
                                            bgColor: AppColor.neutral_100,
                                            borderRadius:
                                            const BorderRadius.all(Radius.circular(TMTRadius.r_15)),
                                            padding: const EdgeInsets.only(top: TMTDimension.padding_20, left: TMTDimension.padding_20, right: TMTDimension.padding_20),
                                            child: Column(
                                              children: [
                                                TMTTextWidget(
                                                  title: "Please login to continue.",
                                                  style: TMTFontStyles.textTeen(
                                                    fontSize: TMTFontSize.sp_18,
                                                    color: AppColor.primaryBG,
                                                    fontWeight: FontWeight.w700,
                                                  ),
                                                ),
                                                VerticalSpacing(HeightDimension.h_15),
                                                InkWell(
                                                    onTap: (){
                                                      Get.offAndToNamed(AppRoutes.loginScreen, arguments: AppRoutes.homeScreen);
                                                    },
                                                    child: Container(height: HeightDimension.h_40, margin: EdgeInsets.only(left: HeightDimension.h_20, right: HeightDimension.h_20),child: const TMTTextButton(buttonTitle: "Login"),)),
                                                VerticalSpacing(HeightDimension.h_10),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    TMTTextWidget(
                                                      title: "New customer?",
                                                      style: TMTFontStyles.textTeen(
                                                        fontSize: TMTFontSize.sp_12,
                                                        color: AppColor.textColor,
                                                        fontWeight: FontWeight.w800,
                                                      ),
                                                    ),
                                                    HorizontalSpacing(WidthDimension.w_4),
                                                    GestureDetector(
                                                      onTap: (){
                                                        Get.offAndToNamed(AppRoutes.signUpScreen);
                                                      },
                                                      child: TMTTextWidget(
                                                        title: "Start here.",
                                                        style: TMTFontStyles.textTeen(
                                                          fontSize: TMTFontSize.sp_12,
                                                          color: AppColor.primaryBG,
                                                          fontWeight: FontWeight.w800,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            });
                            return;
                          }
                          if (TMTUtilities.getUserIDFromToken() == _productDetailController.sellerData?.userId) {
                            return;
                          }
                          var args = _productDetailController.sellerData;
                          args?.productId = _productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].id.toString();
                          args?.productName = _productDetailController.productData?.product?.title;
                          args?.productImage = _productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].productImages?.first.imageName;
                          args?.productPrice = _productDetailController.productData?.product?.productVariations?[_productDetailController.selectedVariation].salePrice.toString();
                          Get.toNamed(AppRoutes.enquiryChatPage, arguments: args);
                        },
                        child: Container(
                          width: WidthDimension.w_180,
                          height: HeightDimension.h_37,
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TMTTextButton(
                            padding: EdgeInsets.zero,
                            buttonTitle: "Ask a question",
                            textStyle: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_13,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w400,
                            ),
                            color: AppColor.neutral_200,
                            border: Border.all(color: const Color(0xFFC7C7C7)),
                          ),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Container(
                        margin: EdgeInsets.only(
                            left: WidthDimension.w_20, right: WidthDimension.w_20),
                        width: double.infinity,
                        height: 2,
                        color: AppColor.dividerColor,
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      InkWell(
                        onTap: (){
                          Get.toNamed(AppRoutes.sellerProductsListingScreen, arguments: {
                            "seller": _productDetailController.productData?.product?.sellerStore?.name ?? _productDetailController.sellerData?.name ?? "",
                            "sellerStoreId": sellerId
                          });
                        },
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: Row(
                            children: [
                              TMTTextWidget(
                                title: "View More ${_productDetailController.sellerData?.name ?? ""} Products",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_15,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const Spacer(),
                              SizedBox(
                                height: HeightDimension.h_10,
                                width: HeightDimension.h_10,
                                child: Image.asset(
                                  TMTImages.icNext,
                                  color: AppColor.neutral_800,
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                      Container(
                        margin: EdgeInsets.only(
                            left: WidthDimension.w_20, right: WidthDimension.w_20),
                        width: double.infinity,
                        height: 2,
                        color: AppColor.dividerColor,
                      ),
                      VerticalSpacing(HeightDimension.h_15),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      }
    );
  }
}
