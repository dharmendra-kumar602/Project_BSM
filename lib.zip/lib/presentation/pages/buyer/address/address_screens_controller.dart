import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/post_add_delivery_address_request.dart';
import 'package:take_my_tack/data/model/response/get_delivery_address_response.dart';
import 'package:take_my_tack/data/repository_implementation/dashboard_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class AddressScreenController extends GetxController {

  final DashboardRepositoryImpl _dashboardRepositoryImpl = DashboardRepositoryImpl();

  List<AddressData> addressData = [];
  AddressData? defaultAddress;
  int defaultAddressIndex = 0;

  var nameTextController = TextEditingController();
  var phoneTextController = TextEditingController();
  var addressTextController = TextEditingController();
  var streetTextController = TextEditingController();
  var cityTextController = TextEditingController();
  var stateTextController = TextEditingController();
  var countryTextController = TextEditingController();
  var postCodeTextController = TextEditingController();
  String selectedCountryDropdown = "";

  var nameFocusNode = FocusNode();
  var phoneFocusNode = FocusNode();
  var addressFocusNode = FocusNode();
  var streetFocusNode = FocusNode();
  var cityFocusNode = FocusNode();
  var stateFocusNode = FocusNode();
  var countryFocusNode = FocusNode();
  var postCodeFocusNode = FocusNode();

  /*
   Method use to get address.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getAddress (BuildContext context, {Function(List<AddressData>? data)? callback}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _dashboardRepositoryImpl.getDeliveryAddress();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              addressData = right.data ?? [];
              defaultAddress = right.data?.firstWhereOrNull((element) => element.isDefault == 1);
              for (int i=0; i<addressData.length; i++) {
                if (addressData[i].isDefault == 1) {
                  defaultAddressIndex = i;
                }
              }
              callback?.call(right.data);
              update([GetControllerBuilders.addressListingScreenController]);
            }
            else {
              if (right.responseHeader.error?.messages.first == "Invalid Access Token" || right.responseHeader.error?.messages.first == "Please Provide User Token or Cart Items.") {
                TMTToast.showErrorToast(context, "Your account is logged in another device, Please re-login again.", title: "Alert");
                TMTLocalStorage.clear();
                Get.offAllNamed(AppRoutes.dashBoardScreen);
              } else {
                TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
              }
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to add new address.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void addNewAddress (BuildContext context, {Function? callback}) {
    var params = PostAddDeliveryAddressRequest(requestHeader: DioUtils.getRequestHeaderModel(), city: cityTextController.text, state: stateTextController.text, country: selectedCountryDropdown, postCode: postCodeTextController.text, isDefault: false, address1: addressTextController.text, street: streetTextController.text, firstName: nameTextController.text, phoneNumber: phoneTextController.text, addressId: '');
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _dashboardRepositoryImpl.postAddDeliveryAddress(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              clearControllers();
              TMTToast.showSuccessToast(context, right.responseHeader.message);
              callback?.call();
            }
            else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update delivery address.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void updateAddress (BuildContext context, int id, {Function? callback}) {
    var params = PostAddDeliveryAddressRequest(requestHeader: DioUtils.getRequestHeaderModel(), city: cityTextController.text, state: stateTextController.text, country: selectedCountryDropdown, postCode: postCodeTextController.text, isDefault: false, address1: addressTextController.text, street: streetTextController.text, firstName: nameTextController.text, phoneNumber: phoneTextController.text, addressId: id.toString());
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _dashboardRepositoryImpl.putUpdateDeliveryAddress(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              clearControllers();
              TMTToast.showSuccessToast(context, right.message);
              callback?.call();
            }
            else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update delivery address.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void deleteAddress (BuildContext context, int id, {Function? callback}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _dashboardRepositoryImpl.deleteDeliveryAddress(id);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              callback?.call();
            }
            else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to update default address.
   Parameter- BuildContext context, int addressId.
   Return -> No Return type.
  */
  void setDefaultAddress (BuildContext context, int addressId, {Function? callback}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _dashboardRepositoryImpl.postSetDefaultAddress(addressId);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              TMTToast.showSuccessToast(context, right.message);
              callback?.call();
            }
            else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get default address.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getDefaultAddress (BuildContext context, {Function? callback}) {
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await _dashboardRepositoryImpl.getDefaultAddress();
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              /// todo
              callback?.call();
            }
            else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });
        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /// clear all text controllers
  void clearControllers() {
    nameTextController.clear();
    phoneTextController.clear();
    addressTextController.clear();
    streetTextController.clear();
    cityTextController.clear();
    stateTextController.clear();
    countryTextController.clear();
    postCodeTextController.clear();
    selectedCountryDropdown = "";
  }
}