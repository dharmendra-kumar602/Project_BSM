import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/address/address_screens_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';

class AddressListingScreen extends StatefulWidget {
  const AddressListingScreen({super.key});

  @override
  State<StatefulWidget> createState() => _AddressListingScreenState();
}

class _AddressListingScreenState extends State<AddressListingScreen> {

  bool cameFromCart = Get.arguments ?? false;

  final AddressScreenController _addressScreenController =
  Get.put(AddressScreenController());

  @override
  void initState() {
    _addressScreenController.getAddress(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AddressScreenController>(
        id: GetControllerBuilders.addressListingScreenController,
        init: _addressScreenController,
        builder: (controller) {
        return Scaffold(
          backgroundColor: AppColor.lightGrey,
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_2),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_6),
                        TMTTextWidget(
                          title: "Address",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: _addressScreenController.addressData.isNotEmpty ? SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Visibility(
                        visible: _addressScreenController.addressData.isNotEmpty,
                        child: Padding(
                          padding: EdgeInsets.only(
                              top: HeightDimension.h_15,
                              bottom: HeightDimension.h_15,
                              left: WidthDimension.w_20,
                              right: WidthDimension.w_20),
                          child: TMTTextWidget(
                            title: "Default Address",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                      ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          var e = _addressScreenController.addressData[index];
                          return InkWell(
                            onTap: (){
                              _addressScreenController.setDefaultAddress(context, e.id, callback: (){
                                setState(() {
                                  _addressScreenController.defaultAddressIndex = index;
                                });
                              });
                            },
                            child: Container(
                              margin: EdgeInsets.only(
                                  bottom: HeightDimension.h_10),
                              width: double.infinity,
                              padding: EdgeInsets.only(
                                  left: WidthDimension.w_20,
                                  right: WidthDimension.w_20,
                                  top: HeightDimension.h_15,
                                  bottom: HeightDimension.h_15),
                              color: AppColor.neutral_100,
                              child: Column(
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        width: HeightDimension.h_15,
                                        height: HeightDimension.h_15,
                                        child: _addressScreenController.defaultAddressIndex == index ? const TMTRoundedCornersContainer(
                                          borderColor: AppColor.primaryBG,
                                          padding: EdgeInsets.all(2),
                                          child: TMTRoundedCornersContainer(
                                            borderColor: AppColor.primaryBG,
                                            bgColor: AppColor.primaryBG,
                                          ),
                                        ) : const TMTRoundedCornersContainer(
                                          borderColor: AppColor.neutral_800,
                                        ),
                                      ),
                                      HorizontalSpacing(WidthDimension.w_10),
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          TMTTextWidget(
                                            title: "${e.firstName} ${e.lastName}",
                                            style: TMTFontStyles.textTeen(
                                              fontSize: TMTFontSize.sp_16,
                                              color: AppColor.neutral_800,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          VerticalSpacing(HeightDimension.h_8),
                                          SizedBox(
                                            width: MediaQuery.of(context).size.width - WidthDimension.w_100,
                                            child: TMTTextWidget(
                                              title: "${e.street}, ${e.city}, ${e.state}",
                                              style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_14,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w400,
                                              ),
                                            ),
                                          ),
                                          VerticalSpacing(HeightDimension.h_4),
                                          SizedBox(
                                            width: MediaQuery.of(context).size.width - WidthDimension.w_100,
                                            child: TMTTextWidget(
                                              title: "${e.country}, ${e.postCode}",
                                              style: TMTFontStyles.text(
                                                fontSize: TMTFontSize.sp_14,
                                                color: AppColor.textColor,
                                                fontWeight: FontWeight.w400,
                                              ),
                                            ),
                                          ),
                                          VerticalSpacing(HeightDimension.h_8),
                                          Row(
                                            children: [
                                              TMTTextWidget(
                                                title: "Phone number - ",
                                                style: TMTFontStyles.text(
                                                  fontSize: TMTFontSize.sp_14,
                                                  color: AppColor.textColor,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                              TMTTextWidget(
                                                title: e.phoneNumber,
                                                style: TMTFontStyles.text(
                                                  fontSize: TMTFontSize.sp_14,
                                                  color: AppColor.textColor,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  VerticalSpacing(HeightDimension.h_15),
                                  Padding(
                                    padding: EdgeInsets.only(left: WidthDimension.w_25),
                                    child: Row(
                                      children: [
                                        TMTTextButton(
                                          onTap: () async {
                                            await Get.toNamed(AppRoutes.editAddressScreen, arguments: e);
                                            setState(() {
                                              _addressScreenController.getAddress(context);
                                            });
                                          },
                                          height: HeightDimension.h_35,
                                          width: WidthDimension.w_93,
                                          buttonTitle: "EDIT",
                                          textStyle: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ),
                                          color: AppColor.neutral_100,
                                          border: Border.all(color: AppColor.neutral_800),
                                          borderRadius:
                                          BorderRadius.circular(TMTRadius.r_30),
                                        ),
                                        HorizontalSpacing(WidthDimension.w_10),
                                        TMTTextButton(
                                          onTap: (){
                                            _addressScreenController.deleteAddress(context, e.id, callback: (){
                                              _addressScreenController.getAddress(context);
                                            });
                                          },
                                          height: HeightDimension.h_35,
                                          width: WidthDimension.w_93,
                                          buttonTitle: "DELETE",
                                          textStyle: TMTFontStyles.textTeen(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ),
                                          color: AppColor.neutral_100,
                                          border: Border.all(color: AppColor.neutral_800),
                                          borderRadius:
                                          BorderRadius.circular(TMTRadius.r_30),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        padding: EdgeInsets.zero,
                        itemCount: _addressScreenController.addressData.length,
                      ),
                      VerticalSpacing(HeightDimension.h_20),
                    ],
                  ),
                ) : const Center(
                  child: TMTTextWidget(title: "No address found."),
                ),
              ),
              Container(
                color: AppColor.neutral_100,
                width: double.infinity,
                height: HeightDimension.h_92,
                padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () async {
                          _addressScreenController.clearControllers();
                          await Get.toNamed(AppRoutes.addNewAddressScreen);
                          setState(() {
                            _addressScreenController.getAddress(context);
                          });
                        },
                        child: Container(
                          padding: EdgeInsets.only(
                              top: HeightDimension.h_12,
                              bottom: HeightDimension.h_12,
                              left: WidthDimension.w_18,
                              right: WidthDimension.w_18),
                          decoration: BoxDecoration(
                              border: Border.all(color: AppColor.neutral_800, width: 0.5),
                              borderRadius: const BorderRadius.all(
                                  Radius.circular(TMTRadius.r_30))),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TMTTextWidget(
                                title: "ADD NEW ADDRESS",
                                style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_14,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Visibility(
                visible: cameFromCart,
                child: Container(
                  padding: EdgeInsets.only(
                      left: WidthDimension.w_15, right: WidthDimension.w_15),
                  height: HeightDimension.h_90,
                  decoration: BoxDecoration(boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 3,
                      blurRadius: 5,
                      offset: const Offset(0, 3), // changes position of shadow
                    ),
                  ], color: AppColor.neutral_100),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Expanded(
                        child: InkWell(
                          onTap: (){
                            Get.back();
                          },
                          child: Container(
                            padding: EdgeInsets.only(
                                top: HeightDimension.h_12,
                                bottom: HeightDimension.h_12,
                                left: WidthDimension.w_18,
                                right: WidthDimension.w_18),
                            decoration: BoxDecoration(
                                color: AppColor.primaryBG,
                                border: Border.all(color: AppColor.primaryBG, width: 1),
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(TMTRadius.r_30))),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                TMTTextWidget(
                                  title: "CONTINUE",
                                  style: TMTFontStyles.textTeen(
                                    fontSize: TMTFontSize.sp_18,
                                    color: AppColor.neutral_100,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        );
      }
    );
  }

}