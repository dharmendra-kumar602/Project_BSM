
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/pages/buyer/address/address_screens_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_field.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';
import '../../../../data/model/response/get_address_by_post_code_response.dart';

class AddNewAddressScreen extends StatefulWidget {
  const AddNewAddressScreen({super.key});

  @override
  State<StatefulWidget> createState() => _AddNewAddressScreenState();
}

class _AddNewAddressScreenState extends State<AddNewAddressScreen> {

  final AddressScreenController _addressScreenController =
  Get.find<AddressScreenController>();

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  final _formKey = GlobalKey<FormState>();
  List<PostCodeAddress> postCodeAddresses = [];

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AddressScreenController>(
        id: GetControllerBuilders.addNewAddressScreenController,
        init: _addressScreenController,
        builder: (controller) {
        return Scaffold(
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                              HorizontalSpacing(WidthDimension.w_2),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_6),
                        TMTTextWidget(
                          title: "Add Address",
                          style: TMTFontStyles.textTeen(
                            fontSize: TMTFontSize.sp_18,
                            color: AppColor.neutral_800,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              top: HeightDimension.h_20,
                              bottom: HeightDimension.h_10,
                              left: WidthDimension.w_20,
                              right: WidthDimension.w_20),
                          child: TMTTextWidget(
                            title: "Contact Details",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                          color: AppColor.neutral_100,
                          child: Column(
                            children: [
                              TMTTextField(
                                contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                floatingLabelBehavior: FloatingLabelBehavior.never,
                                hintText: "Name*",
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                validator: Validator.nameValidate,
                                controller: _addressScreenController.nameTextController,
                                focusNode:
                                _addressScreenController.nameFocusNode,
                                onChanged: (v){
                                  setState(() {

                                  });
                                },
                                onFieldSubmitted: (v){
                                  _addressScreenController.phoneFocusNode.requestFocus();
                                },
                              ),
                              VerticalSpacing(HeightDimension.h_5),
                              TMTTextField(
                                contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                floatingLabelBehavior: FloatingLabelBehavior.never,
                                hintText: "Phone Number*",
                                controller: _addressScreenController.phoneTextController,
                                keyboardType: const TextInputType.numberWithOptions(signed: true, decimal: true),
                                textInputAction: TextInputAction.done,
                                validator: Validator.mobileNumberValidate,
                                focusNode:
                                _addressScreenController.phoneFocusNode,
                                onChanged: (v){
                                  setState(() {

                                  });
                                },
                                onFieldSubmitted: (v){
                                  _addressScreenController.addressFocusNode.requestFocus();
                                },
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              top: HeightDimension.h_15,
                              bottom: HeightDimension.h_10,
                              left: WidthDimension.w_20,
                              right: WidthDimension.w_20),
                          child: TMTTextWidget(
                            title: "Address",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20, top: HeightDimension.h_15, bottom: HeightDimension.h_15),
                          color: AppColor.neutral_100,
                          child: Column(
                            children: [
                              TMTTextField(
                                contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                floatingLabelBehavior: FloatingLabelBehavior.never,
                                hintText: "Postcode",
                                controller: _addressScreenController.postCodeTextController,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                validator: Validator.postCodeValidate,
                                focusNode:
                                _addressScreenController.postCodeFocusNode,
                                onChanged: (v){
                                  setState(() {

                                  });
                                },
                                onFieldSubmitted: (v){
                                  _dashboardController.getCompleteAddressByPostCode(context, (data){
                                    TMTUtilities.closeKeyboard(context);
                                    _setDataInFields(context, controller, data);
                                  }, v);
                                },
                              ),
                              VerticalSpacing(HeightDimension.h_5),
                              TMTTextField(
                                contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                floatingLabelBehavior: FloatingLabelBehavior.never,
                                hintText: "Country*",
                                controller: _addressScreenController.countryTextController,
                                focusNode:
                                _addressScreenController.countryFocusNode,
                                onChanged: (v){
                                  setState(() {

                                  });
                                },
                                onFieldSubmitted: (v){
                                  _addressScreenController.cityFocusNode.requestFocus();
                                },
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                validator: Validator.countryValidate,
                              ),
                              VerticalSpacing(HeightDimension.h_5),
                              TMTTextField(
                                contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                floatingLabelBehavior: FloatingLabelBehavior.never,
                                hintText: "City*",
                                controller: _addressScreenController.cityTextController,
                                focusNode:
                                _addressScreenController.cityFocusNode,
                                onChanged: (v){
                                  setState(() {

                                  });
                                },
                                onFieldSubmitted: (v){
                                  _addressScreenController.stateFocusNode.requestFocus();
                                },
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                validator: Validator.cityValidate,
                              ),
                              VerticalSpacing(HeightDimension.h_5),
                              TMTTextField(
                                contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                floatingLabelBehavior: FloatingLabelBehavior.never,
                                hintText: "County*",
                                controller: _addressScreenController.stateTextController,
                                focusNode:
                                _addressScreenController.stateFocusNode,
                                onChanged: (v){
                                  setState(() {

                                  });
                                },
                                onFieldSubmitted: (v){
                                  _addressScreenController.streetFocusNode.requestFocus();
                                },
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                validator: Validator.countyValidate,
                              ),
                              VerticalSpacing(HeightDimension.h_5),
                              TMTTextField(
                                contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                floatingLabelBehavior: FloatingLabelBehavior.never,
                                hintText: "Street/Locality*",
                                controller: _addressScreenController.streetTextController,
                                textInputAction: TextInputAction.done,
                                validator: Validator.streetValidate,
                                focusNode:
                                _addressScreenController.streetFocusNode,
                                onChanged: (v){
                                  setState(() {

                                  });
                                },
                                onFieldSubmitted: (v){
                                  _addressScreenController.addressFocusNode.requestFocus();
                                },
                                keyboardType: TextInputType.streetAddress,
                              ),
                              VerticalSpacing(HeightDimension.h_5),
                              TMTTextField(
                                contentPadding: EdgeInsets.only(bottom: HeightDimension.h_8, left: WidthDimension.w_15, right: WidthDimension.w_15),
                                floatingLabelBehavior: FloatingLabelBehavior.never,
                                hintText: "Address*",
                                controller: _addressScreenController.addressTextController,
                                keyboardType: TextInputType.streetAddress,
                                textInputAction: TextInputAction.done,
                                validator: Validator.addressLineValidate,
                                focusNode:
                                _addressScreenController.addressFocusNode,
                                onChanged: (v){
                                  setState(() {

                                  });
                                },
                                onFieldSubmitted: (v){
                                  TMTUtilities.closeKeyboard(context);
                                },
                              ),
                            ],
                          ),
                        ),
                        VerticalSpacing(HeightDimension.h_20),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          bottomNavigationBar: Container(
            padding: EdgeInsets.only(
                left: WidthDimension.w_15, right: WidthDimension.w_15),
            height: HeightDimension.h_90,
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.3),
                spreadRadius: 3,
                blurRadius: 5,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ], color: AppColor.neutral_100),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () {
                      if (_formKey.currentState!.validate()) {
                        if (_addressScreenController.selectedCountryDropdown.isEmpty) {
                          TMTToast.showErrorToast(context, "Please select country.", title: "Alert");
                          return;
                        }
                        _addressScreenController.addNewAddress(context, callback: (){
                          Get.back();
                        });
                      }
                      TMTUtilities.closeKeyboard(context);
                    },
                    child: Container(
                      padding: EdgeInsets.only(
                          top: HeightDimension.h_12,
                          bottom: HeightDimension.h_12,
                          left: WidthDimension.w_18,
                          right: WidthDimension.w_18),
                      decoration: BoxDecoration(
                          color: AppColor.primaryBG,
                          border: Border.all(color: AppColor.primaryBG, width: 1),
                          borderRadius: const BorderRadius.all(
                              Radius.circular(TMTRadius.r_30))),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TMTTextWidget(
                            title: "ADD ADDRESS",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_18,
                              color: AppColor.neutral_100,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    );
  }

  /// set data in fields
  void _setDataInFields(BuildContext context, AddressScreenController controller, List<PostCodeAddress> data) {
    setState(() {
      postCodeAddresses = data;
      if (postCodeAddresses.isNotEmpty) {
        controller.countryTextController.text = postCodeAddresses.first.country ?? "";
        controller.cityTextController.text = postCodeAddresses.first.city ?? "";
        controller.stateTextController.text = postCodeAddresses.first.county ?? "";
        controller.streetTextController.text = postCodeAddresses.first.locality ?? "";
        controller.addressTextController.text = "${postCodeAddresses.first.line1 ?? ""} ${postCodeAddresses.first.line2 ?? ""} ${postCodeAddresses.first.line3 ?? ""} ${postCodeAddresses.first.line4 ?? ""}";
      }
    });
  }
}
