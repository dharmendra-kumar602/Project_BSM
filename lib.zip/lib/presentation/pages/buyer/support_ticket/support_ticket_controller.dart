import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:take_my_tack/core/error/failure.dart';
import 'package:take_my_tack/data/datasource/remote/services/dio/dio_utils.dart';
import 'package:take_my_tack/data/model/request/post_send_message_request.dart';
import 'package:take_my_tack/data/model/request/post_support_ticket_request.dart';
import 'package:take_my_tack/data/model/response/get_support_tickets_response.dart';
import 'package:take_my_tack/data/model/response/get_ticket_chat_response.dart';
import 'package:take_my_tack/data/repository_implementation/dashboard_repository_impl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/utils/network_utils.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';

class SupportTicketController extends GetxController {

  TextEditingController titleTextController = TextEditingController();
  TextEditingController descriptionTextController = TextEditingController();
  TextEditingController messageTextController = TextEditingController();
  FocusNode titleFocusNode = FocusNode();
  FocusNode descriptionFocusNode = FocusNode();

  DashboardRepositoryImpl dashboardRepositoryImpl = DashboardRepositoryImpl();

  List<Ticket> tickets = [];
  Chat? chatDetail;
  Ticket? selectedTicket;

  int selectedRange = 1;

  /*
   Method use to get support ticket.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getSupportTickets (BuildContext context) {
    var params = PostSupportTicketRequest(requestHeader: DioUtils.getRequestHeaderModel(), title: titleTextController.text, description: descriptionTextController.text, pageSize: 50, pageNumber: 0, time: selectedRange == 1 ? "DAYS_30" : selectedRange == 2 ? "MONTHS_3" : selectedRange == 3 ? "MONTHS_6" : "MONTHS_12",);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getSupportTickets(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              tickets.clear();
              tickets = right.tickets;
              update([GetControllerBuilders.supportTicketController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to create support ticket.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void createSupportTickets (BuildContext context) {
    var params = PostSupportTicketRequest(requestHeader: DioUtils.getRequestHeaderModel(), title: titleTextController.text, description: descriptionTextController.text);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.postSupportTicket(params);
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader.error == null) {
              TMTToast.showSuccessToast(context, right.responseHeader.message);
              selectedTicket = Ticket(id: right.ticket.id, title: right.ticket.title, description: right.ticket.description, status: right.ticket.status, userId: right.ticket.userId, createdAt: right.ticket.createdAt, updatedAt: right.ticket.updatedAt);
              getSupportTickets(context);
              titleTextController.clear();
              descriptionTextController.clear();
              Get.offNamed(AppRoutes.ticketDetailsPage);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to get support ticket chat detail.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void getSupportTicketChat (BuildContext context) {
    var params = PostSupportTicketRequest(requestHeader: DioUtils.getRequestHeaderModel(), title: titleTextController.text, description: descriptionTextController.text, pageSize: 50, pageNumber: 0, time: selectedRange == 1 ? "DAYS_30" : selectedRange == 2 ? "MONTHS_3" : selectedRange == 3 ? "MONTHS_6" : "MONTHS_12",);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.getTicketDetailsByUserId(params, selectedTicket?.id.toString() ?? "");
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.responseHeader?.error == null) {
              chatDetail = null;
              chatDetail = right.chat;
              if (selectedTicket?.status.isEmpty ?? true) {
                selectedTicket?.status = chatDetail?.status ?? "";
              }
              update([GetControllerBuilders.supportTicketController]);
            } else {
              TMTToast.showErrorToast(context, right.responseHeader?.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }

  /*
   Method use to send message.
   Parameter- BuildContext context.
   Return -> No Return type.
  */
  void sendMessage (BuildContext context, String userType) {
    var params = PostSendTicketMessageRequest(requestHeader: DioUtils.getRequestHeaderModel(), message: messageTextController.text, userType: userType);
    NetWorkUtility.isInternetAvailable().then((value) async {
      if (value) {
        const Loading().start(context);
        try {
          var response = await dashboardRepositoryImpl.postSendTicketMessage(params, selectedTicket?.id.toString() ?? "");
          response.fold((left) {
            if (left is ServerFailure) {
              /// show exception
              TMTToast.showErrorToast(context, left.message ?? '');
            }
          }, (right) {
            if (right.error == null) {
              messageTextController.clear();
              TMTToast.showSuccessToast(context, right.message);
              getSupportTicketChat(context);
            } else {
              TMTToast.showErrorToast(context, right.error?.messages.first ?? "");
            }
          });

        } catch (error) {
          TMTToast.showErrorToast(context, error.toString());
          if (kDebugMode) {
            print(error);
          }
        } finally {
          Loading.stop();
        }
      }
      else {
        /// No internet connection dialog
      }
    });
  }
}