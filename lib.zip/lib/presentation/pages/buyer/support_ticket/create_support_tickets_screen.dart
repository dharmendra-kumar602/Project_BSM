import 'package:flutter/material.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/pages/buyer/support_ticket/support_ticket_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/utils/validator.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class CreateSupportTicketsScreen extends StatefulWidget {
  const CreateSupportTicketsScreen({super.key});

  @override
  State<StatefulWidget> createState() => _CreateSupportTicketsScreenState();
}

class _CreateSupportTicketsScreenState extends State<CreateSupportTicketsScreen> {

  final SupportTicketController _supportTicketController =
  Get.find<SupportTicketController>();
  bool isKeyboardVisible = false;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    KeyboardVisibilityController().onChange.listen((bool visible) {
      setState(() {
        isKeyboardVisible = visible;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      extendBody: true,
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height/9.3,
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 2,
                blurRadius: 3,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ], color: AppColor.neutral_100),
            child: Padding(
              padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Row(
                  children: [
                    InkWell(
                      onTap: (){
                        _supportTicketController.titleTextController.clear();
                        _supportTicketController.descriptionTextController.clear();
                        Get.back();
                      },
                      child: Row(
                        children: [
                          HorizontalSpacing(WidthDimension.w_10),
                          SizedBox(
                            width: WidthDimension.w_40,
                            height: HeightDimension.h_30,
                            child: Center(
                              child: Image.asset(
                                TMTImages.icBack,
                                color: AppColor.neutral_800,
                                fit: BoxFit.contain,
                                scale: 3.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    TMTTextWidget(
                      title: "Create Support Ticket",
                      style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_18,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    HorizontalSpacing(WidthDimension.w_20),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: GetBuilder<SupportTicketController>(
                  id: GetControllerBuilders.supportTicketController,
                  init: _supportTicketController,
                  builder: (controller) {
                  return Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        VerticalSpacing(SizeConfig.safeBlockVertical * 2),
                        SizedBox(
                          height: HeightDimension.h_127,
                          width: double.infinity,
                          child: Image.asset(TMTImages.headerSupportTicket, fit: BoxFit.fill,),
                        ),
                        VerticalSpacing(SizeConfig.safeBlockVertical * 2),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              TMTTextWidget(title: "Enter Title", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w600,
                              ),),
                              Expanded(
                                child: TMTTextWidget(title: " (maximum 40 letters required):", style: TMTFontStyles.textTeen(
                                  fontSize: TMTFontSize.sp_14,
                                  color: AppColor.textColor,
                                  fontWeight: FontWeight.w400,
                                ),),
                              ),
                            ],
                          ),
                        ),
                        VerticalSpacing(SizeConfig.safeBlockVertical * 1),
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TextFormField(
                            maxLength: 40,
                            controller: _supportTicketController.titleTextController,
                            validator: Validator.titleValidate,
                            onChanged: (v){
                            },
                            onFieldSubmitted: (v) {
                              _supportTicketController.descriptionFocusNode.requestFocus();
                            },
                            decoration: InputDecoration(
                                fillColor: AppColor.neutral_100,
                                focusedErrorBorder:  CustomOutlineInputBorder(
                                    borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                errorBorder:  CustomOutlineInputBorder(
                                    borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                enabledBorder: CustomOutlineInputBorder(
                                    borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                floatingLabelBehavior: FloatingLabelBehavior.auto,
                                focusedBorder: CustomOutlineInputBorder(
                                    borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 12),
                                border: CustomOutlineInputBorder(
                                  borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
                                ),
                                errorMaxLines: 3,
                                filled: true,
                                labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                            ),
                          ),
                        ),
                        VerticalSpacing(SizeConfig.safeBlockVertical * 0.2),
                        Padding(
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              TMTTextWidget(title: "Enter Description:", style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_18,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w600,
                              ),),
                            ],
                          ),
                        ),
                        VerticalSpacing(SizeConfig.safeBlockVertical * 1),
                        Container(
                          color: AppColor.transparent,
                          height: HeightDimension.h_165,
                          width: double.infinity,
                          padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                          child: TextFormField(
                            maxLines: 8,
                            validator: Validator.descriptionValidate,
                            controller: _supportTicketController.descriptionTextController,
                            onChanged: (v){
                            },
                            onFieldSubmitted: (v) {
                              TMTUtilities.closeKeyboard(context);
                            },
                            keyboardType: TextInputType.text,
                            focusNode: _supportTicketController.descriptionFocusNode,
                            decoration: InputDecoration(
                              fillColor: AppColor.neutral_100,
                                focusedErrorBorder:  CustomOutlineInputBorder(
                                    borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                errorBorder:  CustomOutlineInputBorder(
                                    borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                enabledBorder: CustomOutlineInputBorder(
                                    borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                floatingLabelBehavior: FloatingLabelBehavior.auto,
                                focusedBorder: CustomOutlineInputBorder(
                                    borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
                                contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 8),
                                border: CustomOutlineInputBorder(
                                  borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
                                ),
                                errorMaxLines: 3,
                                filled: true,
                                labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
                            ),
                          ),
                        ),
                        Visibility(
                          visible: isKeyboardVisible,
                          child: SizedBox(height: HeightDimension.h_300),
                        ),
                       ],
                    ),
                  );
                }
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        margin: EdgeInsets.only(bottom: HeightDimension.h_20),
        padding: EdgeInsets.only(
            left: WidthDimension.w_20, right: WidthDimension.w_20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Expanded(
              child: InkWell(
                onTap: (){
                  if (_formKey.currentState!.validate()) {
                    _supportTicketController.createSupportTickets(context);
                  }
                  TMTUtilities.closeKeyboard(context);
                },
                child: Container(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_14,
                      bottom: HeightDimension.h_14,
                      left: WidthDimension.w_18,
                      right: WidthDimension.w_18),
                  decoration: BoxDecoration(
                      color: AppColor.primaryBG,
                      border: Border.all(color: AppColor.neutral_800, width: 0.5),
                      borderRadius: const BorderRadius.all(
                          Radius.circular(TMTRadius.r_30))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TMTTextWidget(
                        title: "SUBMIT",
                        style: TMTFontStyles.textTeen(
                          fontSize: TMTFontSize.sp_18,
                          color: AppColor.neutral_100,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
