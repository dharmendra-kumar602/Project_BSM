import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:take_my_tack/presentation/pages/buyer/notification/notification_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/support_ticket/support_ticket_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_utilities.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class TicketDetailsPage extends StatefulWidget {
  const TicketDetailsPage({super.key});

  @override
  State<StatefulWidget> createState() => _TicketDetailsPageState();
}

class _TicketDetailsPageState extends State<TicketDetailsPage> {

  final SupportTicketController _supportTicketController =
  Get.find<SupportTicketController>();

  @override
  void initState() {
    _supportTicketController.getSupportTicketChat(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SupportTicketController>(
        id: GetControllerBuilders.supportTicketController,
        init: _supportTicketController,
        builder: (controller) {
        return Scaffold(
          resizeToAvoidBottomInset: true,
          body: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height/9.3,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 3,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ], color: AppColor.neutral_100),
                child: Padding(
                  padding: EdgeInsets.only(bottom: HeightDimension.h_10, top: HeightDimension.h_25),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: (){
                            Get.back();
                          },
                          child: Row(
                            children: [
                              HorizontalSpacing(WidthDimension.w_10),
                              SizedBox(
                                width: WidthDimension.w_40,
                                height: HeightDimension.h_30,
                                child: Center(
                                  child: Image.asset(
                                    TMTImages.icBack,
                                    color: AppColor.neutral_800,
                                    fit: BoxFit.contain,
                                    scale: 3.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_4),
                        Expanded(
                          child: TMTTextWidget(
                            maxLines: 1,
                            title: _supportTicketController.selectedTicket?.title ?? "Title of the ticket",
                            style: TMTFontStyles.textTeen(
                              fontSize: TMTFontSize.sp_16,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        HorizontalSpacing(WidthDimension.w_20),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: GetBuilder<SupportTicketController>(
                    id: GetControllerBuilders.supportTicketController,
                    init: _supportTicketController,
                    builder: (controller) {
                      return ListView.builder(itemBuilder: (context, index){
                        var e = _supportTicketController.chatDetail?.ticketChat?[index];
                        return e?.userId != TMTUtilities.getUserIDFromToken() ?
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  constraints: BoxConstraints(maxWidth: WidthDimension.w_185),
                                  padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_8, bottom: HeightDimension.h_8),
                                  decoration: const BoxDecoration(
                                      color: Color(0xFFFFEAEB),
                                      borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_20))
                                  ),
                                  child: TMTTextWidget(title: e?.msg ?? "", style: TMTFontStyles.text(), maxLines: 20,),
                                ),
                                VerticalSpacing(HeightDimension.h_5),
                                Padding(
                                  padding: EdgeInsets.only(left: WidthDimension.w_10),
                                  child: TMTTextWidget(title: _getDate(e?.updatedAt), style: TMTFontStyles.text(fontSize: TMTFontSize.sp_8), textAlign: TextAlign.left,),
                                ),
                                VerticalSpacing(HeightDimension.h_10),
                              ],
                            ),
                          ],
                        ) :
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  constraints: BoxConstraints(maxWidth: WidthDimension.w_185),
                                  padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_8, bottom: HeightDimension.h_8),
                                  decoration: const BoxDecoration(
                                      color: Color(0xFFED2024),
                                      borderRadius: BorderRadius.all(Radius.circular(TMTRadius.r_25))
                                  ),
                                  child: TMTTextWidget(title: e?.msg ?? "", style: TMTFontStyles.text(color: AppColor.neutral_100), maxLines: 20),
                                ),
                                VerticalSpacing(HeightDimension.h_5),
                                Padding(
                                  padding: EdgeInsets.only(right: WidthDimension.w_10),
                                  child: TMTTextWidget(title: _getDate(e?.updatedAt), style: TMTFontStyles.text(fontSize: TMTFontSize.sp_8), textAlign: TextAlign.right,),
                                ),
                                VerticalSpacing(HeightDimension.h_10),
                              ],
                            ),
                          ],
                        );
                      }, itemCount: _supportTicketController.chatDetail?.ticketChat?.length ?? 0, scrollDirection: Axis.vertical, padding: const EdgeInsets.all(20),);
                    }
                ),
              ),
            ],
          ),
          bottomNavigationBar: (_supportTicketController.selectedTicket?.status == "RESOLVED") ?
          TMTRoundedCornersContainer(
            bgColor: const Color(0xFFEEEEEE),
            borderColor: AppColor.neutral_800,
            borderRadius: BorderRadius.circular(TMTRadius.r_15),
            padding: EdgeInsets.only(top: HeightDimension.h_5, bottom: HeightDimension.h_5, left: WidthDimension.w_20, right: WidthDimension.w_20),
            margin: EdgeInsets.only(bottom: HeightDimension.h_20, left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: WidthDimension.w_250,
                  child: RichText(
                    textAlign: TextAlign.center,
                    maxLines: 50,
                    text: TextSpan(
                        text:
                        "Admin has resolved the chat. The ticket ",
                        style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w400,
                        ),
                        children: [
                          TextSpan(
                              text: '#${_supportTicketController.selectedTicket?.id}',
                              style: TMTFontStyles.text(
                                  fontSize: TMTFontSize.sp_12,
                                  color: AppColor.neutral_800,
                                  fontWeight: FontWeight.bold,
                                  textDecoration: TextDecoration.underline
                              ),
                          ),
                          TextSpan(
                              text: ' has been closed.',
                              style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.w400,
                              ),
                          ),
                        ]
                    ),
                  ),
                ),
              ],
            ),
          ) : (_supportTicketController.selectedTicket?.status == "AWAITED") ?
          TMTRoundedCornersContainer(
            bgColor: const Color(0xFFEEEEEE),
            borderColor: AppColor.neutral_800,
            borderRadius: BorderRadius.circular(TMTRadius.r_15),
            padding: EdgeInsets.only(top: HeightDimension.h_5, bottom: HeightDimension.h_5, left: WidthDimension.w_20, right: WidthDimension.w_20),
            margin: EdgeInsets.only(bottom: HeightDimension.h_20, left: WidthDimension.w_20, right: WidthDimension.w_20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: WidthDimension.w_250,
                  child: RichText(
                    textAlign: TextAlign.center,
                    maxLines: 50,
                    text: TextSpan(
                        text:
                        "A response is pending from admin. The ticket ",
                        style: TMTFontStyles.text(
                          fontSize: TMTFontSize.sp_12,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w400,
                        ),
                        children: [
                          TextSpan(
                            text: '#${_supportTicketController.selectedTicket?.id}',
                            style: TMTFontStyles.text(
                                fontSize: TMTFontSize.sp_12,
                                color: AppColor.neutral_800,
                                fontWeight: FontWeight.bold,
                                textDecoration: TextDecoration.underline
                            ),
                          ),
                          TextSpan(
                            text: ' has been raised.',
                            style: TMTFontStyles.text(
                              fontSize: TMTFontSize.sp_12,
                              color: AppColor.neutral_800,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ]
                    ),
                  ),
                ),
              ],
            ),
          ) :
          Padding(
            padding: MediaQuery.of(context).viewInsets,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: TMTRoundedCornersContainer(
                    borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_30)),
                    height: HeightDimension.h_45,
                    margin: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_15, bottom: HeightDimension.h_20,),
                    bgColor: AppColor.neutral_100,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 3,
                        offset: const Offset(0, 3), // changes position of shadow
                      ),
                    ],
                    padding: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15, top: HeightDimension.h_10, bottom: HeightDimension.h_10),
                    child: Row(children: [
                      Expanded(child: TextField(style: TMTFontStyles.text(), decoration: const InputDecoration.collapsed(hintText: "Type a message"), controller: _supportTicketController.messageTextController, onSubmitted: (v){
                        if (v.isNotEmpty) {
                          TMTUtilities.closeKeyboard(context);
                          _supportTicketController.sendMessage(context, "SELLER");
                        }
                      },)),
                      HorizontalSpacing(WidthDimension.w_8),
                      GestureDetector(
                        onTap: (){
                          if (_supportTicketController.messageTextController.text.isNotEmpty) {
                            TMTUtilities.closeKeyboard(context);
                            _supportTicketController.sendMessage(context, "SELLER");
                          }
                        },
                        child: SizedBox(
                          height: HeightDimension.h_18,
                          width: HeightDimension.h_18,
                          child: Image.asset(TMTImages.icSendRed),
                        ),
                      )
                    ],),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    );
  }

  /// Returns the difference (in full days) between the provided date and today.
  static String _getDate(DateTime? time) {
    if (time == null) {
      return "";
    }
    var statusDate = '';
    try {
      final DateTime serverDate = time;
      DateTime now = DateTime.now();
      final int dateDiff = DateTime(serverDate.year, serverDate.month, serverDate.day).difference(DateTime(now.year, now.month, now.day)).inDays.abs();
      if (dateDiff == 0) {
        String time = DateFormat('hh:mm a').format(serverDate);
        statusDate = time;
        return statusDate;
      } else {
        String time = DateFormat('dd MMM yy hh:mm a').format(serverDate);
        statusDate = time;
        return statusDate;
      }
    } catch (error) {
      debugPrint(error.toString());
      return statusDate;
    }
  }
}