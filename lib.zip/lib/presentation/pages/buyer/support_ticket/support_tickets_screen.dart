import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/support_ticket/support_ticket_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/utils/tmt_webview.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text_button.dart';
import 'package:url_launcher/url_launcher.dart';

class SupportTicketsScreen extends StatefulWidget {
  const SupportTicketsScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SupportTicketsScreenState();
}

class _SupportTicketsScreenState extends State<SupportTicketsScreen> {

  final SupportTicketController _supportTicketController =
  Get.put(SupportTicketController());

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      _supportTicketController.getSupportTickets(context);
    },);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: (){
        _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.userProfileScreen, navBarItemIndex: AppRoutesIdentifiers.userProfileScreen);
        return Future.value(false);
      },
      child: Scaffold(
        body: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height/9.3,
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 2,
                  blurRadius: 3,
                  offset: const Offset(0, 3), // changes position of shadow
                ),
              ], color: AppColor.neutral_100),
              child: Padding(
                padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Row(
                    children: [
                      InkWell(
                        onTap: (){
                          _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.userProfileScreen, navBarItemIndex: AppRoutesIdentifiers.userProfileScreen);
                          },
                        child: Row(
                          children: [
                            HorizontalSpacing(WidthDimension.w_10),
                            SizedBox(
                              width: WidthDimension.w_40,
                              height: HeightDimension.h_30,
                              child: Center(
                                child: Image.asset(
                                  TMTImages.icBack,
                                  color: AppColor.neutral_800,
                                  fit: BoxFit.contain,
                                  scale: 3.4,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      TMTTextWidget(
                        title: "Support Tickets",
                        style: TMTFontStyles.textTeen(
                          fontSize: TMTFontSize.sp_18,
                          color: AppColor.neutral_800,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      HorizontalSpacing(WidthDimension.w_20),
                      const Spacer(),
                      GestureDetector(
                        onTap: (){
                          Get.toNamed(AppRoutes.createSupportTicketsScreen);
                        },
                        child: SizedBox(
                          height: HeightDimension.h_20,
                          width: HeightDimension.h_20,
                          child: Image.asset(TMTImages.icAddBlackBg),
                        ),
                      ),
                      HorizontalSpacing(WidthDimension.w_20),
                    ],
                  ),
                ),
              ),
            ),
            Expanded(
              child: GetBuilder<SupportTicketController>(
                  id: GetControllerBuilders.supportTicketController,
                  init: _supportTicketController,
                  builder: (controller) {
                  return Column(
                    children: [
                      Expanded(
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              VerticalSpacing(HeightDimension.h_15),
                              Padding(
                                padding: EdgeInsets.only(left: WidthDimension.w_20, right: WidthDimension.w_20),
                                child: Row(
                                  children: [
                                    Row(
                                      children: [
                                        TMTTextWidget(
                                          title: "Queries from ",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.textColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        TMTTextWidget(
                                          title: _supportTicketController.selectedRange == 1 ? "Last 30 Days" : _supportTicketController.selectedRange == 2 ? "Last 3 Months" : _supportTicketController.selectedRange == 3 ? "Last 6 Months" : "Last 12 Months",
                                          style: TMTFontStyles.text(
                                            fontSize: TMTFontSize.sp_14,
                                            color: AppColor.neutral_800,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ],
                                    ),
                                    HorizontalSpacing(WidthDimension.w_10),
                                    const Spacer(),
                                    GestureDetector(
                                      onTap: (){
                                        showDialog(context: context, builder: (c){
                                          return StatefulBuilder(
                                              builder: (context, setState) {
                                              return WillPopScope(
                                                onWillPop: () {
                                                  return Future.value(false);
                                                },
                                                child: Material(
                                                  color: Colors.transparent,
                                                  child: Center(
                                                    child: Stack(
                                                      children: [
                                                        TMTRoundedCornersContainer(
                                                          padding: EdgeInsets.only(bottom: HeightDimension.h_60),
                                                          width: MediaQuery.of(context).size.width - 40,
                                                          height: HeightDimension.h_270,
                                                          bgColor: AppColor.neutral_100,
                                                          child: SingleChildScrollView(
                                                            child: Column(
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                VerticalSpacing(HeightDimension.h_15),
                                                                InkWell(
                                                                  onTap: (){
                                                                    setState((){
                                                                      _supportTicketController.selectedRange = 1;
                                                                      _supportTicketController.update([GetControllerBuilders.supportTicketController]);
                                                                    });
                                                                   },
                                                                  child: TMTRoundedCornersContainer(
                                                                    bgColor: _supportTicketController.selectedRange == 1 ? AppColor.primaryBG.withOpacity(0.2) : AppColor.neutral_100,
                                                                    borderColor: _supportTicketController.selectedRange == 1 ? AppColor.primaryBG : AppColor.neutral_800,
                                                                    margin: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                                                    padding: EdgeInsets.only(top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                                    width: double.infinity,
                                                                    height: HeightDimension.h_30,
                                                                    child: Row(
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                      children: [
                                                                        TMTTextWidget(
                                                                          title: "Last 30 Days",
                                                                          style: TMTFontStyles.text(
                                                                            fontSize: TMTFontSize.sp_14,
                                                                            color: AppColor.neutral_800,
                                                                            fontWeight: FontWeight.w600,
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                VerticalSpacing(HeightDimension.h_10),
                                                                InkWell(
                                                                  onTap: (){
                                                                    setState((){
                                                                      _supportTicketController.selectedRange = 2;
                                                                      _supportTicketController.update([GetControllerBuilders.supportTicketController]);
                                                                    });
                                                                   },
                                                                  child: TMTRoundedCornersContainer(
                                                                    bgColor: _supportTicketController.selectedRange == 2 ? AppColor.primaryBG.withOpacity(0.2) : AppColor.neutral_100,
                                                                    borderColor: _supportTicketController.selectedRange == 2 ? AppColor.primaryBG : AppColor.neutral_800,
                                                                    margin: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                                                    padding: EdgeInsets.only(top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                                    width: double.infinity,
                                                                    height: HeightDimension.h_30,
                                                                    child: Row(
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                      children: [
                                                                        TMTTextWidget(
                                                                          title: "Last 3 Months",
                                                                          style: TMTFontStyles.text(
                                                                            fontSize: TMTFontSize.sp_14,
                                                                            color: AppColor.neutral_800,
                                                                            fontWeight: FontWeight.w600,
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                VerticalSpacing(HeightDimension.h_10),
                                                                InkWell(
                                                                  onTap: (){
                                                                    setState((){
                                                                      _supportTicketController.selectedRange = 3;
                                                                      _supportTicketController.update([GetControllerBuilders.supportTicketController]);
                                                                    });
                                                                  },
                                                                  child: TMTRoundedCornersContainer(
                                                                    bgColor: _supportTicketController.selectedRange == 3 ? AppColor.primaryBG.withOpacity(0.2) : AppColor.neutral_100,
                                                                    borderColor: _supportTicketController.selectedRange == 3 ? AppColor.primaryBG : AppColor.neutral_800,
                                                                    margin: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                                                    padding: EdgeInsets.only(top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                                    width: double.infinity,
                                                                    height: HeightDimension.h_30,
                                                                    child: Row(
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                      children: [
                                                                        TMTTextWidget(
                                                                          title: "Last 6 Months",
                                                                          style: TMTFontStyles.text(
                                                                            fontSize: TMTFontSize.sp_14,
                                                                            color: AppColor.neutral_800,
                                                                            fontWeight: FontWeight.w600,
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                VerticalSpacing(HeightDimension.h_10),
                                                                InkWell(
                                                                  onTap: (){
                                                                    setState((){
                                                                      _supportTicketController.selectedRange = 4;
                                                                      _supportTicketController.update([GetControllerBuilders.supportTicketController]);
                                                                    });
                                                                    },
                                                                  child: TMTRoundedCornersContainer(
                                                                    bgColor: _supportTicketController.selectedRange == 4 ? AppColor.primaryBG.withOpacity(0.2) : AppColor.neutral_100,
                                                                    borderColor: _supportTicketController.selectedRange == 4 ? AppColor.primaryBG : AppColor.neutral_800,
                                                                    margin: EdgeInsets.only(left: WidthDimension.w_10, right: WidthDimension.w_10),
                                                                    padding: EdgeInsets.only(top: HeightDimension.h_2, bottom: HeightDimension.h_2),
                                                                    width: double.infinity,
                                                                    height: HeightDimension.h_30,
                                                                    child: Row(
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                      children: [
                                                                        TMTTextWidget(
                                                                          title: "Last 12 Months",
                                                                          style: TMTFontStyles.text(
                                                                            fontSize: TMTFontSize.sp_14,
                                                                            color: AppColor.neutral_800,
                                                                            fontWeight: FontWeight.w600,
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                VerticalSpacing(HeightDimension.h_15),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          bottom: HeightDimension.h_15,
                                                          left: HeightDimension.h_20,
                                                          right: HeightDimension.h_20,
                                                          child: SizedBox(
                                                            height: HeightDimension.h_37,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.end,
                                                              children: [
                                                                Expanded(
                                                                  child: TMTTextButton(
                                                                    border: Border.all(color: AppColor.neutral_800),
                                                                    color: AppColor.neutral_100,
                                                                    textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_800, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                                                                    onTap: () {
                                                                        _supportTicketController.selectedRange = 1;
                                                                        _supportTicketController.update([GetControllerBuilders.supportTicketController]);
                                                                        _supportTicketController.getSupportTickets(context);
                                                                      Navigator.pop(c);
                                                                    }, buttonTitle: 'CANCEL',
                                                                  ),
                                                                ),
                                                                HorizontalSpacing(WidthDimension.w_8),
                                                                Expanded(
                                                                  child: TMTTextButton(
                                                                    onTap: () {
                                                                      Navigator.pop(c);
                                                                      _supportTicketController.getSupportTickets(context);
                                                                    }, buttonTitle: 'APPLY',
                                                                    textStyle: TMTFontStyles.textTeen(color: AppColor.neutral_100, fontWeight: FontWeight.w800, fontSize: TMTFontSize.sp_14,),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              );
                                            }
                                          );
                                        }, barrierDismissible: false);
                                      },
                                      child: TMTTextWidget(
                                        title: "CHANGE",
                                        style: TMTFontStyles.textHarbinger(
                                          fontSize: TMTFontSize.sp_14,
                                          color: AppColor.primaryBG,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              VerticalSpacing(HeightDimension.h_10),
                              ListView.builder(itemBuilder: (context, index) {
                                var e = _supportTicketController.tickets[index];
                                return InkWell(
                                  onTap: () async {
                                    _supportTicketController.selectedTicket = e;
                                    await Get.toNamed(AppRoutes.ticketDetailsPage);
                                    if (!mounted) return;
                                    _supportTicketController.getSupportTickets(context);
                                  },
                                  child: Column(
                                    children: [
                                      VerticalSpacing(HeightDimension.h_15),
                                      Padding(
                                        padding: EdgeInsets.only(left: WidthDimension.w_25, right: WidthDimension.w_25),
                                        child: Row(
                                          children: [
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width / 1.5),
                                                  child: TMTTextWidget(
                                                    maxLines: 3,
                                                    title: e.title,
                                                    style: TMTFontStyles.text(
                                                      fontSize: TMTFontSize.sp_14,
                                                      color: AppColor.neutral_800,
                                                      fontWeight: FontWeight.w500,
                                                    ),
                                                  ),
                                                ),
                                                VerticalSpacing(HeightDimension.h_4),
                                                Row(
                                                  children: [
                                                    TMTTextWidget(
                                                      title: DateFormat('E, d MMM').format(e.updatedAt),
                                                      style: TMTFontStyles.text(
                                                        fontSize: TMTFontSize.sp_10,
                                                        color: AppColor.textColor,
                                                        fontWeight: FontWeight.w400,
                                                      ),
                                                    ),
                                                    HorizontalSpacing(WidthDimension.w_12),
                                                    Container(
                                                      height: HeightDimension.h_12,
                                                      width: 2,
                                                      color: const Color(0xFF595959),
                                                    ),
                                                    HorizontalSpacing(WidthDimension.w_12),
                                                    SizedBox(
                                                      width: WidthDimension.w_50,
                                                      child: TMTTextWidget(
                                                        maxLines: 2,
                                                        title: textStatus(e.status),
                                                        style: TMTFontStyles.text(
                                                          fontSize: TMTFontSize.sp_10,
                                                          color: statusColor(e.status),
                                                          fontWeight: FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                            const Spacer(),
                                            HorizontalSpacing(WidthDimension.w_10),
                                            SizedBox(
                                              height: HeightDimension.h_12,
                                              width: HeightDimension.h_12,
                                              child: Image.asset(TMTImages.icNext, color: AppColor.neutral_800,),
                                            )
                                          ],
                                        ),
                                      ),
                                      VerticalSpacing(HeightDimension.h_15),
                                      Container(
                                        width: double.infinity,
                                        height: 0.5,
                                        color: const Color(0xFF595959),
                                      ),
                                    ],
                                  ),
                                );
                              }, shrinkWrap: true, scrollDirection: Axis.vertical, itemCount: _supportTicketController.tickets.length, padding: EdgeInsets.zero, physics: const NeverScrollableScrollPhysics(),),
                              VerticalSpacing(HeightDimension.h_20),
                             ],
                          ),
                        ),
                      ),
                      VerticalSpacing(SizeConfig.safeBlockVertical * 1),
                      GestureDetector(
                        onTap: () async {
                          if (await canLaunchUrl(Uri.parse("http://ficode@ficodeqa.com/static/misc/buyer_faq.pdf"))) {
                          await launchUrl(Uri.parse("http://ficode@ficodeqa.com/static/misc/buyer_faq.pdf"), mode: LaunchMode.externalApplication,);
                          } else {
                          throw 'Could not launch ${Uri.parse("http://ficode@ficodeqa.com/static/misc/buyer_faq.pdf")}';
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.only(
                              left: WidthDimension.w_15, right: WidthDimension.w_15),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Expanded(
                                child: Container(
                                  padding: EdgeInsets.only(
                                      top: HeightDimension.h_14,
                                      bottom: HeightDimension.h_14,
                                      left: WidthDimension.w_18,
                                      right: WidthDimension.w_18),
                                  decoration: BoxDecoration(
                                      color: AppColor.neutral_100,
                                      border: Border.all(color: AppColor.neutral_800, width: 0.5),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(TMTRadius.r_30))),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      TMTTextWidget(
                                        title: "BUYER FAQs",
                                        style: TMTFontStyles.textTeen(
                                          fontSize: TMTFontSize.sp_16,
                                          color: AppColor.textColor,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      VerticalSpacing(SizeConfig.safeBlockVertical * 2),
                    ],
                  );
                }
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Check status
  String textStatus(String status) {
    if (status == "WIP") {
      return "OPEN";
    } else if (status == "AWAITED") {
      return "NEW";
    } else {
      return "CLOSED";
    }
  }

  /// Check status color
  Color statusColor(String status) {
    if (status == "WIP") {
      return AppColor.yellowColor;
    } else if (status == "AWAITED") {
      return AppColor.primaryBG;
    } else {
      return AppColor.green;
    }
  }
}
