// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:take_my_tack/presentation/resources/app_color.dart';
// import 'package:take_my_tack/presentation/resources/constants.dart';
// import 'package:take_my_tack/presentation/resources/dimension.dart';
// import 'package:take_my_tack/presentation/resources/font_size.dart';
// import 'package:take_my_tack/presentation/resources/font_style.dart';
// import 'package:take_my_tack/presentation/resources/images.dart';
// import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
// import 'package:take_my_tack/presentation/widgets/tmt_text.dart';
//
// class BuyerFaqs extends StatefulWidget {
//   BuyerFaqs({super.key});
//
//   @override
//   _BuyerFaqs createState() => _BuyerFaqs();
// }
//
// class _BuyerFaqs extends State<BuyerFaqs> {
//   bool _isLoading = true;
//   int _totalPages = 0;
//   int _currentPage = 0;
//
//   PDFViewController? _pdfViewController;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColor.neutral_600,
//       appBar: AppBar(
//         centerTitle: false,
//         backgroundColor: AppColor.white,
//         leading: InkWell(
//           onTap: () {
//             Get.back();
//           },
//           child: Container(
//             width: WidthDimension.w_10,
//             height: HeightDimension.h_20,
//             child: Center(
//               child: Image.asset(
//                 TMTImages.icBack,
//                 color: AppColor.neutral_800,
//                 fit: BoxFit.contain,
//                 scale: 3.5,
//               ),
//             ),
//           ),
//         ),
//         title: Padding(
//           padding: const EdgeInsets.only(right: 20),
//           child: TMTTextWidget(
//             title: "BUYER FAQs",
//             style: TMTFontStyles.textTeen(
//               fontSize: TMTFontSize.sp_18,
//               color: AppColor.neutral_800,
//               fontWeight: FontWeight.w700,
//             ),
//           ),
//         ),
//       ),
//       body: Stack(
//         children: [
//           PDFView(
//             filePath: "https://www.orimi.com/pdf-test.pdf",
//             onViewCreated: (PDFViewController pdfViewController) {
//               setState(() {
//                 _pdfViewController = pdfViewController;
//               });
//               _pdfViewController!.setPage(_currentPage);
//             },
//             onRender: (pages) {
//               setState(() {
//                 _isLoading = false;
//                 _totalPages = pages!;
//               });
//             },
//             onPageChanged: (int? page, int? total) {
//               setState(() {
//                 _currentPage = page ?? 0;
//               });
//             },
//           ),
//           if (_isLoading)
//             const Center(child: CircularProgressIndicator()),
//           Positioned(
//             bottom: 8,
//             right: 8,
//             child: Text('Page $_currentPage of $_totalPages'),
//           ),
//         ],
//       ),
//     );
//   }
// }