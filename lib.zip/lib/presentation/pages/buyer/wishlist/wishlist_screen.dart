import 'dart:ui';
import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/core/model/wishlist_model.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/data/model/request/post_add_to_wishlist_request.dart';
import 'package:take_my_tack/data/model/response/get_cart_response.dart';
import 'package:take_my_tack/data/model/response/get_wishlist_response.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_bottom_navbar.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';
import 'package:take_my_tack/presentation/widgets/tmt_internet_dialog.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class WishListScreen extends StatefulWidget {
  const WishListScreen({super.key});

  @override
  State<StatefulWidget> createState() => _WishListScreenState();
}

class _WishListScreenState extends State<WishListScreen> {

  var cameFromDashBoard = Get.arguments ?? true;

  final DashboardController _dashboardController =
  Get.find<DashboardController>();

  @override
  void initState() {
    InternetPopup().initializeCustomWidget(context: context, widget: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TMTRoundedCornersContainer(
          padding: EdgeInsets.only(left: WidthDimension.w_20,
              right: WidthDimension.w_20,
              top: HeightDimension.h_20,
              bottom: HeightDimension.h_20),
          bgColor: AppColor.neutral_100,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('No Connection', style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_16,
                  fontWeight: FontWeight.w700,
                  color: AppColor.neutral_800,), textAlign: TextAlign.center,),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                child: Text('Please check your internet connectivity',
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                    fontWeight: FontWeight.w600,
                    color: AppColor.textColor,), textAlign: TextAlign.center,),
              ),
              GestureDetector(
                onTap: () {
                  AppSettings.openAppSettings(type: AppSettingsType.wifi);
                },
                child: Padding(
                  padding: EdgeInsets.only(
                      top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                  child: Text('Okay', style: TMTFontStyles.text(
                    fontSize: TMTFontSize.sp_16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.neutral_700,),),
                ),
              ),
            ],
          ),
        ),
      ],
    ), callback: () {
      _getWishlistItems(context);
    },);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return GetBuilder<DashboardController>(
        id: GetControllerBuilders.dashboardController,
        init: _dashboardController,
        builder: (controller) {
        return Scaffold(
          body: Stack(
            children: [
              Column(
                children: [
                  Container(
                    height: MediaQuery.of(context).size.height/9.3,
                    decoration: BoxDecoration(boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 3,
                        offset: const Offset(0, 3), // changes position of shadow
                      ),
                    ], color: AppColor.neutral_100),
                    child: Padding(
                      padding: EdgeInsets.only(bottom: HeightDimension.h_5, top: HeightDimension.h_25),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Row(
                          children: [
                            InkWell(
                              onTap: (){
                                try {
                                  if (!cameFromDashBoard) {
                                    Get.back();
                                    return;
                                  }
                                } catch (e) {
                                  Get.back();
                                }
                                _dashboardController.changeSelectedPage(pageIndex: AppRoutesIdentifiers.homeScreen, navBarItemIndex: AppRoutesIdentifiers.homeScreen);
                              },
                              child: Row(
                                children: [
                                  HorizontalSpacing(WidthDimension.w_10),
                                  SizedBox(
                                    width: WidthDimension.w_40,
                                    height: HeightDimension.h_30,
                                    child: Center(
                                      child: Image.asset(
                                        TMTImages.icBack,
                                        color: AppColor.neutral_800,
                                        fit: BoxFit.contain,
                                        scale: 3.4,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Row(
                              children: [
                                TMTTextWidget(
                                  title: "Wishlist",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_18,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                HorizontalSpacing(WidthDimension.w_4),
                                _dashboardController.finalList.isNotEmpty ? TMTTextWidget(
                                  title: "(${_dashboardController.finalList.length} items)",
                                  style: TMTFontStyles.text(
                                    fontSize: TMTFontSize.sp_13,
                                    color: AppColor.neutral_800,
                                    fontWeight: FontWeight.w300,
                                  ),
                                ) : const SizedBox.shrink(),
                              ],
                            ),
                            HorizontalSpacing(WidthDimension.w_20),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          VerticalSpacing(SizeConfig.safeBlockVertical * 3),
                          GridView.count(
                            childAspectRatio: MediaQuery.of(context).size.width / (MediaQuery.of(context).size.height / 1.65),
                            shrinkWrap: true,
                            padding: EdgeInsets.only(
                                left: WidthDimension.w_12,
                                right: WidthDimension.w_12),
                            physics: const NeverScrollableScrollPhysics(),
                            crossAxisCount: 2,
                            children: _dashboardController.finalList.map((e) {
                              return InkWell(
                                onTap: () async {
                                  await Get.toNamed(AppRoutes.productDetailScreen, arguments: [e.variation.product.id, e.variation.id]);
                                  setState(() {
                                    _getWishlistItems(context);
                                  });
                                },
                                child: Container(
                                  margin: EdgeInsets.only(
                                      bottom: HeightDimension.h_8,
                                      left: HeightDimension.h_5,
                                      right: HeightDimension.h_5),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Stack(
                                        children: [
                                          SizedBox(
                                            height: SizeConfig.safeBlockVertical * 14.5,
                                            width: double.infinity,
                                            child: TMTCachedImage.networkImage(
                                              e.variation.productImages.isNotEmpty ? e.variation.productImages.first.imageName : "",
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                          Visibility(
                                            visible: false,
                                            child: Positioned(
                                              left: 0,
                                              top: HeightDimension.h_5,
                                              child: SizedBox(
                                                height: HeightDimension.h_10,
                                                child: Image.asset(TMTImages.icBestOffer),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                      VerticalSpacing(HeightDimension.h_4),
                                      Container(
                                        width: double.infinity,
                                        padding: EdgeInsets.only(
                                            left: WidthDimension.w_8, right: WidthDimension.w_8),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            TMTTextWidget(
                                              maxLines: 1,
                                              title: e.variation.product.title,
                                              style: TMTFontStyles.text(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: TMTFontSize.sp_12,
                                                  color: AppColor.neutral_800),
                                            ),
                                            TMTTextWidget(
                                              maxLines: 1,
                                              title: e.variation.product.description,
                                              style: TMTFontStyles.text(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: TMTFontSize.sp_10,
                                                  color: AppColor.textColor),
                                            ),
                                            TMTTextWidget(
                                                maxLines: 1,
                                                title: "£${e.variation.salePrice.toStringAsFixed(2)}",
                                                style: TMTFontStyles.text(
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: TMTFontSize.sp_10,
                                                    color: AppColor.neutral_800)),
                                            VerticalSpacing(HeightDimension.h_4),
                                            GestureDetector(
                                              onTap: (){},
                                              child: Row(
                                                children: [
                                                  Expanded(
                                                    child: GestureDetector(
                                                      onTap: (){
                                                        _dashboardController.addToCart(context, e.variation.id, e.variation.product.id, CartData(sellers: [], sizes: [], cartFinalData: [], tax: 0, cartId: 0), (){
                                                          setState(() {
                                                            _dashboardController.removeFromWishList(context, e.variation.id.toString(), e.variation.product.id, (){
                                                              _getWishlistItems(context);
                                                            });
                                                          });
                                                        }, 1);
                                                      },
                                                      child: TMTRoundedCornersContainer(
                                                        padding: EdgeInsets.only(left: WidthDimension.w_4, right: WidthDimension.w_4, top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                                                        bgColor: AppColor.primaryBG,
                                                        child: Center(
                                                          child: TMTTextWidget(
                                                            maxLines: 1,
                                                            style: TMTFontStyles.textTeen(
                                                                fontSize: TMTFontSize.sp_11,
                                                                fontWeight: FontWeight.w700,
                                                                color: AppColor.neutral_100),
                                                            title: 'Move To Cart',
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  HorizontalSpacing(WidthDimension.w_6),
                                                  GestureDetector(
                                                    onTap: (){
                                                      _dashboardController.removeFromWishList(context, e.variation.id.toString(), e.variation.product.id, (){
                                                       setState(() {
                                                         _getWishlistItems(context);
                                                       });
                                                      });
                                                    },
                                                    child: SizedBox(
                                                      height: HeightDimension.h_25,
                                                      width: HeightDimension.h_25,
                                                      child: Image.asset(TMTImages.icDeleteWB),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            VerticalSpacing(HeightDimension.h_4),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                          VerticalSpacing(SizeConfig.safeBlockVertical * 3),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Visibility(
                visible: (_dashboardController.finalList.isEmpty),
                child: Center(
                  child: Padding(
                    padding: EdgeInsets.only(left: WidthDimension.w_40, right: WidthDimension.w_40),
                    child: TMTTextWidget(
                      textAlign: TextAlign.center,
                      title: "Your wish-list is feeling a little empty. Let's bring some joy to it!.",
                      style: TMTFontStyles.text(
                        fontSize: TMTFontSize.sp_12,
                        color: AppColor.neutral_800,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
          bottomNavigationBar: _getNavBar(),
        );
      }
    );
  }

  /// call api's to get data
  Future<void> _getWishlistItems(BuildContext context) async {
    try {
      if (TMTLocalStorage.getUserLoggedIn()) {
        _dashboardController.getLocalWishlistData(context);
        _dashboardController.getWishList(context, callBack: (){
          var serverList = _dashboardController.serverList;
          var localList = _dashboardController.localList;

          // Combine localList and serverList into a single list
          List<WishlistDatum> combinedList = [...localList, ...serverList];

          // Final list containing unique items
          List<WishlistDatum> finalList = [];

          finalList = removeDuplicates(combinedList);

          _dashboardController.finalList = finalList;
          _dashboardController.finalList.removeWhere((element) => element.variation.id == 0 && element.variation.product.id == 0);
          _dashboardController.finalList.removeWhere((element) => element.variation.id == element.variation.product.id);
          if (_dashboardController.finalList.isNotEmpty) {
            _dashboardController.addBulkToWishList(context, (){
            }, _dashboardController.finalList.map((e) => Item(productId: e.variation.product.id, variationId: e.variation.id)).toList());
          }
          TMTLocalStorage.clearWishlist();
          _dashboardController.finalList.forEach((element) {
            TMTLocalStorage.addToWishlist(WishlistModel(productId: element.variation.product.id, variationId: element.variation.id, variation: element.variation));
          });
        });
      }
      else {
        _dashboardController.getLocalWishlistData(context);
        _dashboardController.finalList.removeWhere((element) => element.variation.id == 0 && element.variation.product.id == 0);
        _dashboardController.finalList.removeWhere((element) => element.variation.id == element.variation.product.id);
        _dashboardController.finalList = removeDuplicates(_dashboardController.localList);
        TMTLocalStorage.clearWishlist();
        _dashboardController.finalList.forEach((element) {
          TMTLocalStorage.addToWishlist(WishlistModel(productId: element.variation.product.id, variationId: element.variation.id, variation: element.variation));
        });
        await Future.delayed(Duration(milliseconds: 100));
        setState(() {

        });
      }
    } catch (e) {
      print(e.toString());
    }
  }

  /// remove duplicates
  List<WishlistDatum> removeDuplicates(List<WishlistDatum> list) {
    try {
      Set<int> variationIds = Set<int>();
      List<WishlistDatum> result = [];

      for (var item in list) {
        if (!variationIds.contains(item.variation.id)) {
          variationIds.add(item.variation.id);
          result.add(item);
        }
      }
      return result;
    } catch (e) {
      return [];
    }
  }

  /// get navbar
  _getNavBar() {
    try {
      return cameFromDashBoard ? const SizedBox.shrink() : CommonBottomNavigationBar(
          currentSelectedItem: 2, onTap: (index) {
        Get.offAllNamed(AppRoutes.dashBoardScreen, arguments: index);
      });
    } catch (e) {
      return SizedBox.shrink();
    }
  }
}
