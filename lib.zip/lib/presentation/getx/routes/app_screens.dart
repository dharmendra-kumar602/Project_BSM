import 'package:get/get.dart';
import 'package:take_my_tack/presentation/getx/routes/app_routes.dart';
import 'package:take_my_tack/presentation/pages/buyer/address/address_listing_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/address/edit_address_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/forgot_password/forgot_password_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/forgot_password/reset_password/reset_password_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/forgot_password/verify_otp/verify_forgot_otp_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/login/login_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/signup/signup_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/authentication/verify_otp/verify_otp_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/address/add_address_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/cart/cards_checkout_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/cart/cart_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_listing_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/category_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/category/sub_category_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/enquiry/enquiry_chat_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/enquiry/enquiry_listing_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/filters/products_filter_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/filters/sort_filter_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/home/brands_listing_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/home/home_page.dart';
import 'package:take_my_tack/presentation/pages/buyer/home/just_added_products_listing_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/home/products_by_brand_id_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/home/sellers_listing_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/notification/notification_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/cancel_order_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/confirm_order_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/my_orders_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/order_details_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/orders_cards_checkout_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/order/return_refund_order_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/product_detail/product_detail_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/product_detail/product_seller_detail_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/product_detail/seller_products_listing_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/search/search_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/support_ticket/buyer_faqs.dart';
import 'package:take_my_tack/presentation/pages/buyer/support_ticket/create_support_tickets_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/support_ticket/support_tickets_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/support_ticket/ticket_detail_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/user_profile/change_password_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/user_profile/edit_profile_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/user_profile/user_profile_screen.dart';
import 'package:take_my_tack/presentation/pages/buyer/wishlist/wishlist_screen.dart';
import 'package:take_my_tack/presentation/pages/intro_pages/intro_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/add_bank_page/add_bank_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/authentication/register_to_sell_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/authentication/request_status_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/authentication/seller_otp_confirmation_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/authentication/seller_plan_details_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/dashboard/seller_dashboard.dart';
import 'package:take_my_tack/presentation/pages/seller/document_verification/document_request_approved_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/document_verification/document_request_awaited_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/document_verification/document_request_cancel_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/document_verification/upload_document_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/manage_shiping_page/manage_shiping_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/order/seller_order_details_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/order/seller_order_listing_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/product/add_product_attributes_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/product/add_product_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/product/add_product_shipment_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/product/select_category_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/product/seller_product_detail_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/product/seller_product_list_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/seller_profile/seller_edit_profile_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/seller_profile/seller_profile_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/storage_stats/storage_media_stats_screen.dart';
import 'package:take_my_tack/presentation/pages/seller/support_ticket/seller_support_tickets_screen.dart';
import 'package:take_my_tack/presentation/pages/splash/splash_screen.dart';

class AppPages {

  static const Duration duration = Duration(milliseconds: 500);
  static const Transition transition = Transition.cupertino;
  static var list = [
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: "/",
      page: () => const SplashScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.splashScreen,
      page: () => const SplashScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.introPage,
      page: () => const IntroScreen(),
    ),
    GetPage(
      name: AppRoutes.loginScreen,
      page: () => const LoginScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.signUpScreen,
      page: () => const SignupScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.verifyOTPScreen,
      page: () => const VerifyOTPScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.forgotPasswordScreen,
      page: () => const ForgotPasswordScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.verifyForgotOTPScreen,
      page: () => const VerifyForgotOTPScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.resetPasswordScreen,
      page: () => const ResetPasswordScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.dashBoardScreen,
      page: () => const DashBoardScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.categoryScreen,
      page: () => const CategoryScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.categoryListingScreen,
      page: () => const CategoryListingScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.wishListScreen,
      page: () => const WishListScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.productDetailScreen,
      page: () => const ProductDetailScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.productSellerDetailScreen,
      page: () => const ProductSellerDetailScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sortFilterScreen,
      page: () => SortFilterScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.productsFilterScreen,
      page: () => ProductsFilterScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.enquiryChatPage,
      page: () => const EnquiryChatPage(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.enquiryListingScreenPage,
      page: () => const EnquiryListingScreenPage(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.cartScreen,
      page: () => const CartScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.subCategoryScreen,
      page: () => const SubCategoryScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.notificationScreen,
      page: () => const NotificationScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.searchScreen,
      page: () => const SearchScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.addNewAddressScreen,
      page: () => const AddNewAddressScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.confirmOrderScreen,
      page: () => const ConfirmOrderScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.homeScreen,
      page: () => const HomePage(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.supportTicketsScreen,
      page: () => const SupportTicketsScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerSupportTicketsScreen,
      page: () => const SellerSupportTicketsScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.ticketDetailsPage,
      page: () => const TicketDetailsPage(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.userProfileScreen,
      page: () => const UserProfileScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerProductsListingScreen,
      page: () => const SellerProductsListingScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.changePasswordScreen,
      page: () => const ChangePasswordScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.editProfileScreen,
      page: () => const EditProfileScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.justAddedProductsListingScreen,
      page: () => const JustAddedProductsListingScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.createSupportTicketsScreen,
      page: () => const CreateSupportTicketsScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.registerToSellScreen,
      page: () => const RegisterToSellScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerConfirmationOTPScreen,
      page: () => const SellerConfirmationOTPScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerPlanDetailsScreen,
      page: () => const SellerPlanDetailsScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.requestStatusScreen,
      page: () => const RequestStatusScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.myOrdersScreen,
      page: () => const MyOrdersScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.orderDetailsScreen,
      page: () => const OrderDetailsScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.cancelOrderScreen,
      page: () => const CancelOrderScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.returnRefundOrderScreen,
      page: () => const ReturnRefundOrderScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerProfileScreen,
      page: () => const SellerProfileScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerDashboard,
      page: () => const SellerDashboard(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.uploadDocumentScreen,
      page: () => const UploadDocumentScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.documentRequestAwaitedScreen,
      page: () => const DocumentRequestAwaitedScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.documentRequestCancelScreen,
      page: () => const DocumentRequestCancelScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.addProductScreen,
      page: () => const AddProductScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.selectCategoryScreen,
      page: () => const SelectCategoryScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.addProductAttributesScreen,
      page: () => const AddProductAttributesScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.addProductShipmentScreen,
      page: () => const AddProductShipmentScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerProductListScreen,
      page: () => const SellerProductListScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.addressListingScreen,
      page: () => const AddressListingScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.editAddressScreen,
      page: () => const EditAddressScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.cardsCheckoutScreen,
      page: () => const CardsCheckoutScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerProductDetailScreen,
      page: () => const SellerProductDetailScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerOrderListingScreen,
      page: () => const SellerOrderListingScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerOrderDetailsScreen,
      page: () => const SellerOrderDetailsScreen(),
    ),
    GetPage(
      transitionDuration: Duration.zero,
      transition: transition,
      name: AppRoutes.sellerEditProfileScreen,
      page: () => const SellerEditProfileScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.manageShippingScreen,
      page: () => const ManageShippingScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.addBankScreen,
      page: () => const AddBankScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.storageMediaStatsScreen,
      page: () => const StorageMediaStatsScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.sellersListingScreen,
      page: () => const SellersListingScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.brandsListingScreen,
      page: () => const BrandsListingScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.productsByBrandIdScreen,
      page: () => const ProductsByBrandIdScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.documentRequestApprovedScreen,
      page: () => const DocumentRequestApprovedScreen(),
    ),
    GetPage(
      transitionDuration: duration,
      transition: transition,
      name: AppRoutes.ordersCardsCheckoutScreen,
      page: () => const OrdersCardsCheckoutScreen(),
    ),
  ];
}
