import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:take_my_tack/presentation/pages/buyer/dashboard/dashboard_controller.dart';
import 'package:take_my_tack/presentation/pages/buyer/notification/notification_controller.dart';
import 'package:take_my_tack/presentation/pages/seller/dashboard/seller_dashboard_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';

class TMTNotificationBell extends StatefulWidget {
  bool isBuyer;
  TMTNotificationBell({super.key, required this.isBuyer});

  @override
  State<StatefulWidget> createState() => _TMTNotificationBellState();
}

class _TMTNotificationBellState extends State<TMTNotificationBell> {

  final NotificationController _notificationController =
  Get.put(NotificationController());

  @override
  void initState() {
    _notificationController.getNotifications(context, widget.isBuyer ? "BUYER" : "SELLER");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NotificationController>(
        id: GetControllerBuilders.notificationControllerScreen,
        init: _notificationController,
        builder: (controller) {
        return Stack(
          children: [
            SizedBox(
              height: HeightDimension.h_19,
              width: HeightDimension.h_19,
              child: Image.asset(TMTImages.icBell,
                  color: AppColor.neutral_800),
            ),
            Positioned(
              top: 3,
              right: 1,
              child: Visibility(
                visible: _getVisibility(),
                child: const Center(
                  child: TMTRoundedContainer(
                    height: 10,
                    width: 10,
                    bgColor: AppColor.primary,
                  ),
                ),
              ),
            )
          ],
        );
      }
    );
  }

  /// get visibility
  bool _getVisibility() {
    try {
      var data = _notificationController.notification.where((element) => element.notificationRelatedTo == "ticket" ? true : element.userRole == (widget.isBuyer ? "BUYER" : "SELLER")).toList().where((element) => element.isRead == 0).toList().isNotEmpty;
      return data;
    } catch (e) {
      return false;
    }
  }
}