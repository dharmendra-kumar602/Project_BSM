import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/images.dart';

const defaultValue = 56.0;

class Loading extends StatelessWidget {
  static OverlayEntry? _currentLoading;

  const Loading({super.key});

  static OverlayState? _overlayState;

  static bool get isShown => _currentLoading != null;

  void start(BuildContext context,
      {ThemeData? themeData,
      Color? overlayColor,
      double? overlayFromTop,
      double? overlayFromBottom,
      bool isAppbarOverlay = true,
      bool isBottomBarOverlay = true,
      bool isSafeAreaOverlay = true}) {
    var safeBottomPadding = MediaQuery.of(context).padding.bottom;
    var defaultPaddingTop = 0.0;
    var defaultPaddingBottom = 0.0;
    if (!isAppbarOverlay) {
      isSafeAreaOverlay = false;
    }
    if (!isSafeAreaOverlay) {
      defaultPaddingTop = defaultValue;
      defaultPaddingBottom = defaultValue + safeBottomPadding;
    } else {
      defaultPaddingTop = defaultValue;
      defaultPaddingBottom = defaultValue;
    }

    _overlayState = Overlay.of(context);
    if (_currentLoading == null) {
      _currentLoading = OverlayEntry(builder: (context) {
        return Stack(
          children: <Widget>[
            _overlayWidget(
                isSafeAreaOverlay,
                overlayColor,
                isAppbarOverlay ? 0.0 : overlayFromTop ?? defaultPaddingTop,
                isBottomBarOverlay
                    ? 0.0
                    : overlayFromBottom ?? defaultPaddingBottom),
            const Center(
                child: Loading()),
          ],
        );
      });

      try {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_currentLoading != null) {
            _overlayState?.insert(_currentLoading!);
          }
        });
      } catch (e) {}
    }
  }

  static Widget _overlayWidget(bool isSafeArea, Color? overlayColor,
      double overlayFromTop, double overlayFromBottom) {
    return isSafeArea
        ? BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
          child: Container(
              color: overlayColor ?? AppColor.neutral_100.withOpacity(0.7),
              margin:
                  EdgeInsets.only(top: overlayFromTop, bottom: overlayFromBottom),
            ),
        )
        : SafeArea(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
              child: Container(
                color: overlayColor ?? AppColor.neutral_100.withOpacity(0.7),
              margin:
                  EdgeInsets.only(top: overlayFromTop, bottom: overlayFromBottom),
          ),
            ));
  }

  static void stop() async {
    await Future.delayed(const Duration(milliseconds: 800)); /// Add some delay for better UI visuals
    if (_currentLoading != null) {
      try {
        _currentLoading?.remove();
      } catch (e) {
        print(e.toString());
      } finally {
        _currentLoading = null;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
        child: SizedBox(height : HeightDimension.h_120, width : WidthDimension.w_220,child: Image.asset(TMTGifs.horseLoaderGif)));
  }
}
