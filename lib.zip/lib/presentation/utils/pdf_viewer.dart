import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';

class PdfViewerPage extends StatelessWidget {
  final String pdfPath;
  final String name;

  PdfViewerPage({required this.pdfPath, required this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColor.primary,
        title: Text(name),
      ),
      body: PDFView(
        filePath: pdfPath,
        enableSwipe: true,
        swipeHorizontal: false,
        pageFling: false,
        onRender: (pages) {
          // PDF document is rendered and pages are available.
        },
        onError: (error) {
          // Handle any errors that occur.
          print(error);
        },
        onPageError: (page, error) {
          // Handle errors for a specific page.
          print('Error on page $page: $error');
        },
      ),
    );
  }
}
