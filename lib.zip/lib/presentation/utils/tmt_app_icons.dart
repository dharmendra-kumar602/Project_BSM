import 'package:flutter/widgets.dart';

class MyFlutterApp {
  MyFlutterApp._();

  static const _kFontFam = 'TMTAppIcons';
  static const _kFontFam1 = 'IconEyeClose';

  static const IconData icEyeCloseGrey = IconData(0xe800, fontFamily: _kFontFam);
  ///static const IconData icEyeOpen = IconData(0xf06e, fontFamily: _kFontFam);
  static const IconData icEyeClose = IconData(0xf070, fontFamily: _kFontFam);
  static const IconData icEyeOpen = IconData(0xf06e, fontFamily: _kFontFam1);
}
