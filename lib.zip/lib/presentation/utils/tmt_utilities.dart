import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:take_my_tack/data/datasource/local/getx_storage.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/constants.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';

class TMTUtilities {

  /// used to get status of device keyboard
  static bool isKeyboardShowing() {
    return WidgetsBinding.instance.window.viewInsets.bottom > 0;
  }

  /// used to hide device keyboard
  static closeKeyboard(BuildContext context) {
    FocusScopeNode currentFocus = FocusScope.of(context);
    if (!currentFocus.hasPrimaryFocus) {
      currentFocus.unfocus();
    }
  }

  /// retrieve user name from JWT token
  static String getUserNameFromToken () {
    try {
      String token = TMTLocalStorage.getString(GetXStorageConstants.jwtToken);
      if (token.isEmpty) {
        return "";
      } else {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(token);
        return decodedToken["name"];
      }
    } catch (error) {
      return "";
    }
  }

  /// retrieve user id from JWT token
  static int getUserIDFromToken () {
    try {
      String token = TMTLocalStorage.getString(GetXStorageConstants.jwtToken);
      if (token.isEmpty) {
        return -1;
      } else {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(token);
        return decodedToken["id"];
      }
    } catch (error) {
      return -1;
    }
  }

  /// retrieve user email from JWT token
  static String getUserEmailFromToken () {
    try {
      String token = TMTLocalStorage.getString(GetXStorageConstants.jwtToken);
      if (token.isEmpty) {
        return "";
      } else {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(token);
        return decodedToken["email"];
      }
    } catch (error) {
      return "";
    }
  }

  /// retrieve user role from JWT token
  static String getUserRoleFromToken () {
    try {
      String token = TMTLocalStorage.getString(GetXStorageConstants.jwtToken);
      if (token.isEmpty) {
        return "";
      } else {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(token);
        return decodedToken["role"];
      }
    } catch (error) {
      return "";
    }
  }

  /// retrieve seller storeId from JWT token
  static String getSellerStoreIdFromToken (String token) {
    try {
      if (token.isEmpty) {
        return "";
      } else {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(token);
        return decodedToken["sellerStoreId"].toString();
      }
    } catch (error) {
      return "";
    }
  }

  /// retrieve plan id from JWT token
  static int getPlanIdFromToken () {
    try {
      String token = TMTLocalStorage.getString(GetXStorageConstants.jwtToken);
      if (token.isEmpty) {
        return -1;
      } else {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(token);
        return decodedToken["planId"];
      }
    } catch (error) {
      return -1;
    }
  }

  /// retrieve is document verified status from JWT token
  static bool getIsDocumentVerifiedFromToken () {
    try {
      String token = TMTLocalStorage.getString(GetXStorageConstants.jwtToken);
      if (token.isEmpty) {
        return false;
      } else {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(token);
        var v = decodedToken["isDocumentVerified"];
        return v == 1;
      }
    } catch (error) {
      return false;
    }
  }

  /// retrieve is document verified status from JWT token
  static int getMaxProductLimitFromToken () {
    try {
      String token = TMTLocalStorage.getString(GetXStorageConstants.jwtToken);
      if (token.isEmpty) {
        return 5;
      } else {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(token);
        var v = decodedToken["productsAllowed"];
        return v;
      }
    } catch (error) {
      return 5;
    }
  }

  /// show dialog for disabled user status
  static void showUserDisabledDialog(BuildContext context) {
    showDialog(context: context, builder: (c){
      return Material(
        color: Colors.transparent,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TMTRoundedCornersContainer(
                padding: EdgeInsets.only(left: WidthDimension.w_20,
                    right: WidthDimension.w_20,
                    top: HeightDimension.h_20,
                    bottom: HeightDimension.h_20),
                bgColor: AppColor.neutral_100,
                borderRadius: BorderRadius.circular(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                          top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                      child: Text('ALERT', style: TMTFontStyles.textTeen(
                        fontSize: TMTFontSize.sp_16,
                        fontWeight: FontWeight.w700,
                        color: AppColor.neutral_800,), textAlign: TextAlign.center,),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                      child: Text('Your seller account has been disabled.',
                        style: TMTFontStyles.text(fontSize: TMTFontSize.sp_14,
                          fontWeight: FontWeight.w600,
                          color: AppColor.textColor,), textAlign: TextAlign.center,),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: EdgeInsets.only(
                            top: HeightDimension.h_5, bottom: HeightDimension.h_5),
                        child: TMTRoundedCornersContainer(
                          bgColor: AppColor.primary,
                          padding: EdgeInsets.only(top: HeightDimension.h_8, bottom: HeightDimension.h_8, left: WidthDimension.w_12, right: WidthDimension.w_12),
                          child: Text('Dismiss', style: TMTFontStyles.text(
                            fontSize: TMTFontSize.sp_13,
                            fontWeight: FontWeight.w700,
                            color: AppColor.neutral_100,),),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    });
  }

  /// check image max size
  static Future<bool> isFileBiggerThan1MB (XFile? pickedFile) async {
    var maxFileSizeInBytes = 2 * 1048576; // 2MB
    var imagePath = await pickedFile!.readAsBytes();

    var fileSize = imagePath.length; // Get the file size in bytes
    if (fileSize <= maxFileSizeInBytes) {
      return false;
    } else {
      return true;
    }
  }

  static createFirstPostLink(int id) async {
    final DynamicLinkParameters parameters = DynamicLinkParameters(
      uriPrefix: 'https://takemytack.page.link',
      link: Uri.parse('https://takemytack.page.link/id/$id'),
      androidParameters: AndroidParameters(
        packageName: 'uk.co.takemytack',
      ),

      // Other things to add as an example. We don't need it now
      iosParameters: IOSParameters(
        bundleId: 'com.example.ios',
        minimumVersion: '1.0.1',
        appStoreId: '123456789',
      ),
    );

    final long = parameters.link;
    final short = parameters.longDynamicLink;

    print(long);
    print(short);
  }
}
