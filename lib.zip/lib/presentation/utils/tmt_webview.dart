import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:take_my_tack/presentation/utils/custom_gif_loading.dart';
import 'package:take_my_tack/presentation/widgets/tmt_toast.dart';
import 'dart:async';
import 'package:webview_flutter/webview_flutter.dart';

class TMTWebView extends StatefulWidget {
  String url;
  TMTWebView({super.key, required this.url});

  @override
  State<StatefulWidget> createState() => _IntegrationScreenState();
}

class _IntegrationScreenState extends State<TMTWebView> {
  late WebViewController controller;

  @override
  void initState() {
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading bar.
          },
          onPageStarted: (String url) {
            const Loading().start(context);
          },
          onPageFinished: (String url) {
            Loading.stop();
          },
          onWebResourceError: (WebResourceError error) {
            print(error);
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => _canGoBack(context),
      child: Scaffold(
          body: Stack(
            children: [
              Positioned(
                top: 75.h,
                left: 0,
                right: 0,
                bottom: 0,
                child: WebViewWidget(controller: controller),
              ),
              Positioned(
                top: 45.h,
                left: 30,
                child: GestureDetector(
                  child: const Icon(
                    Icons.arrow_back_ios,
                    color: Colors.black,
                  ),
                  onTap: () {
                    Navigator.pop(context, "");
                  },
                ),
              )
            ],
          )),
    );
  }

  Future<bool> _canGoBack(BuildContext context) async {
    if (await controller.canGoBack()) {
      controller.goBack();
      return Future.value(false);
    } else {
      return Future.value(true);
    }
  }
}
