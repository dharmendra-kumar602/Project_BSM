import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';

class TMTMediaPicker {
  final ImagePicker _picker = ImagePicker();
  final BuildContext context;
  TMTMediaPicker(this.context);

  Future<XFile?> pickImageFromGallery({int? imageQuality}) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery, imageQuality: imageQuality);
      return pickedFile;
    } catch (e) {
      if (e is PlatformException && e.code == 'camera_access_denied') {
        final statuses = await [
          Permission.storage,
          Permission.photos,
        ].request();
        if ((statuses[Permission.photos]?.isGranted ?? false) && (statuses[Permission.storage]?.isGranted?? false)) {
          final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery, imageQuality: imageQuality);
          return pickedFile;
        } else {
          showPopupForLocation(context, message: "Permissions are required.", positiveText: "Okay", negativeText: "Dismiss", callBack: (e){});
          if (kDebugMode) {
            print("An error occurred: $e");
          }
        }
      } else {
        showPopupForLocation(context, message: "Permissions are required.", positiveText: "Okay", negativeText: "Dismiss", callBack: (e){});
      }
    }
    return null;
  }

  Future<XFile?> pickImageFromCamera({int? imageQuality}) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(source: ImageSource.camera, imageQuality: imageQuality);
      return pickedFile;
    } catch (e) {
      if (e is PlatformException && e.code == 'camera_access_denied') {
        final statuses = await [
          Permission.camera,
        ].request();
        if (statuses[Permission.camera]?.isGranted ?? false) {
          final XFile? pickedFile = await _picker.pickImage(source: ImageSource.camera, imageQuality: imageQuality);
          return pickedFile;
        } else {
          showPopupForLocation(context, message: "Permissions are required.", positiveText: "Okay", negativeText: "Dismiss", callBack: (e){});
          if (kDebugMode) {
            print("An error occurred: $e");
          }
        }
      } else {
        showPopupForLocation(context, message: "Permissions are required.", positiveText: "Okay", negativeText: "Dismiss", callBack: (e){});
      }
    }
    return null;
  }

  static void showPopupForLocation(
      BuildContext context,
      {String title = "Alert",
        required String message,
        required String positiveText,
        required String negativeText,
        required Function(bool isYes) callBack}) {
    showDialog(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext c) {
        return Center(
          child: Material(
            color: Colors.transparent,
            child: Container(
              width: 300,
              decoration: BoxDecoration(
                  color: AppColor.neutral_100,
                  borderRadius: BorderRadius.circular(14)
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  VerticalSpacing(HeightDimension.h_10),
                  Text(
                    title,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 22, color: AppColor.primary),
                  ),
                  VerticalSpacing(10),
                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Divider(color: AppColor.primary),
                  ),
                  VerticalSpacing(10),
                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Text(
                      textAlign: TextAlign.center,
                      message,
                      style: const TextStyle(fontSize: 18.0),
                    ),
                  ),
                  VerticalSpacing(10),
                  TextButton(
                    child: Text(positiveText, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColor.primary),),
                    onPressed: () async {
                      callBack.call(true);
                      Navigator.of(context).pop();
                    },
                  ),
                  VerticalSpacing(10)
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}