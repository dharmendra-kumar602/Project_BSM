import 'package:flutter/services.dart';

class DoubleTextInputFormatter extends TextInputFormatter {
  static const int maxLength = 8; // 2 characters before decimal + 1 decimal point + 2 characters after decimal

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final regex = RegExp(r'^\d{0,5}(\.\d{0,2})?$');
    if (regex.hasMatch(newValue.text) && newValue.text.length <= maxLength) {
      return newValue;
    } else {
      return oldValue;
    }
  }
}
