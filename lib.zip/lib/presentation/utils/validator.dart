import 'package:form_field_validator/form_field_validator.dart';

class Validator {
  static var usernameValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter username."),
  ]);

  static var emailValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter email."),
    EmailValidator(errorText: "Please enter valid email."),
    PatternValidator(r'[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,6}$', errorText: "Please enter valid email."),
    MaxLengthValidator(50, errorText: "Email should not be greater than 50 characters.")
  ]);

  static var passwordValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter password."),
    PatternValidator(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~])', errorText: "Password must be 6-20 characters long, and contain at least 1 uppercase, 1 lowercase, 1 number and 1 special character."),
  ]);

  static var loginPasswordValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter password."),
  ]);

  static FormFieldValidator<String> confirmPasswordValidator(String password, String newPassword) {
    return (value) {
      if (value?.isEmpty ?? false) {
        return 'Please enter your password confirmation';
      }
      if (value != password) {
        return 'Password do not match';
      }
      return null;
    };
  }

  static FormFieldValidator<String> validateCaptchaText(String captchaCode) {
    return (value) {
      if (value?.isEmpty ?? false) {
        return 'Please enter captcha';
      }
      if (value != captchaCode) {
        return 'Captcha does not match.';
      }
      return null;
    };
  }

  static var forgotPasswordEmailValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter email."),
    EmailValidator(errorText: "Please enter valid email."),
  ]);

  static var nameValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter name."),
  ]);

  static var firstNameValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter first name."),
  ]);

  static var sellerNameValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter Seller name."),
  ]);

  static var titleValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter title."),
  ]);

  static var descriptionValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter description."),
  ]);

  static var additionalDetails = MultiValidator([
    RequiredValidator(errorText: "Please enter details."),
    MaxLengthValidator(15, errorText: "Details should not be greater than 100 characters."),
  ]);

  static var lastNameValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter last name."),
  ]);

  static var mobileNumberValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter mobile number."),
    MinLengthValidator(7, errorText: "Contact number should be 7 minimum characters."),
    MaxLengthValidator(15, errorText: "Contact number should not be greater than 15 characters."),
  ]);

  static var contactNumberValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter contact number."),
    MinLengthValidator(7, errorText: "Contact number should be 7 minimum characters."),
    MaxLengthValidator(15, errorText: "Contact number should not be greater than 15 characters."),
  ]);

  static var cityValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter city."),
  ]);

  static var addressLineValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter address line."),
  ]);

  static var addressLine1Validate = MultiValidator([
    RequiredValidator(errorText: "Please enter address line 2."),
  ]);

  static var countyValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter county."),
  ]);

  static var postCodeValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter post code."),
  ]);

  static var countryValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter country."),
  ]);

  static var productNameValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter product name."),
    MaxLengthValidator(55, errorText: 'Name should not be more than 55 characters.'),
  ]);

  static var productDescriptionValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter product description."),
  ]);

  static var brandNameValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter brand name."),
  ]);

  static var streetValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter street / locality."),
  ]);

  static var priceValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter price."),
    MinDoubleValidator(0, errorText: 'Must be greater than 0.'),
    MaxDoubleValidator(1000, errorText: 'Must be less than 1000.'),
  ]);

  static var lengthValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter length."),
    MinDoubleValidator(0, errorText: 'Must be greater than 0.'),
    MaxDoubleValidator(150, errorText: 'Must be less than 150 cm.'),
  ]);

  static var widthValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter width."),
    MinDoubleValidator(0, errorText: 'Must be greater than 0.'),
    MaxDoubleValidator(150, errorText: 'Must be less than 150 cm.'),
  ]);

  static var heightValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter height."),
    MinDoubleValidator(0, errorText: 'Must be greater than 0.'),
    MaxDoubleValidator(150, errorText: 'Must be less than 150 cm.'),
  ]);

  static var weightValidate = MultiValidator([
    RequiredValidator(errorText: "Please enter weight."),
    MinDoubleValidator(0, errorText: 'Must be greater than 0 kg.'),
    MaxDoubleValidator(50, errorText: 'Must be less than 50 kg.'),
  ]);
}


class MinIntValidator extends TextFieldValidator {
  final int minValue;
  MinIntValidator(this.minValue, {String errorText = 'Value too low.'})
      : super(errorText);

  @override
  bool isValid(String? value) {
    try {
      final intValue = int.parse(value!);
      return intValue >= minValue;
    } catch (e) {
      return false;
    }
  }
}

class MaxIntValidator extends TextFieldValidator {
  final int maxValue;
  MaxIntValidator(this.maxValue, {String errorText = 'Value too high.'})
      : super(errorText);

  @override
  bool isValid(String? value) {
    try {
      final intValue = int.parse(value!);
      return intValue <= maxValue;
    } catch (e) {
      return false;
    }
  }
}

class MinDoubleValidator extends TextFieldValidator {
  final double minValue;
  MinDoubleValidator(this.minValue, {String errorText = 'Value too low.'})
      : super(errorText);

  @override
  bool isValid(String? value) {
    try {
      final intValue = double.parse(value!);
      return intValue >= minValue;
    } catch (e) {
      return false;
    }
  }
}

class MaxDoubleValidator extends TextFieldValidator {
  final double maxValue;
  MaxDoubleValidator(this.maxValue, {String errorText = 'Value too high.'})
      : super(errorText);

  @override
  bool isValid(String? value) {
    try {
      final intValue = double.parse(value!);
      return intValue <= maxValue;
    } catch (e) {
      return false;
    }
  }
}