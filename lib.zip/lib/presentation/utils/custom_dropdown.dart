import 'package:flutter/material.dart';
import 'package:take_my_tack/core/model/processing_time_model.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/widgets/tmt_dropdown/tmt_dropdown.dart';

class CustomDropdown {

  /// get custom dropdown widget
  static Widget getCustomDropdown (BuildContext context, String hint, List<String> values, FormFieldValidator validator, Function(String v) callback) {
    return DropdownButtonFormField2<String>(
      isExpanded: true,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      decoration: InputDecoration(
        errorMaxLines: 3,
        filled: true,
        fillColor : AppColor.neutral_100,
        focusColor : AppColor.neutral_100,
        hoverColor : AppColor.neutral_100,
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5,)
        ),
        disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
        errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
        focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
        contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 12),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
      ),
      hint: Text(
        hint,
        style: TMTFontStyles.text(fontSize: TMTFontSize.sp_12, color: AppColor.textColor),
      ),
      items: values
          .map((item) => DropdownMenuItem<String>(
        value: item,
        child: Text(
          item,
          style: const TextStyle(
            fontSize: 14,
          ),
        ),
      ))
          .toList(),
      validator: validator,
      onChanged: (value) {
        callback.call(value ?? "");
      },
      onSaved: (value) {

      },
      buttonStyleData: const ButtonStyleData(
        padding: EdgeInsets.only(right: 18),
      ),
      iconStyleData: const IconStyleData(
        icon: Icon(
          Icons.keyboard_arrow_down_outlined,
          color: AppColor.textColor,
        ),
        iconSize: 24,
      ),
      dropdownStyleData: DropdownStyleData(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
      menuItemStyleData: const MenuItemStyleData(
        padding: EdgeInsets.symmetric(horizontal: 16),
      ),
    );
  }

  /// get custom data type dropdown widget
  static Widget getCustomDataTypeDropdown (BuildContext context, String hint, List<ProcessingTimeModel> values, FormFieldValidator validator, Function(int v) callback) {
    return DropdownButtonFormField2<ProcessingTimeModel>(
      isExpanded: true,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      decoration: InputDecoration(
        filled: true,
        errorMaxLines: 3,
        fillColor : AppColor.neutral_100,
        focusColor : AppColor.neutral_100,
        hoverColor : AppColor.neutral_100,
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5,)
        ),
        disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
        errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
        focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
        contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 12),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: AppColor.textColor, width: 0.5)
        ),
      ),
      hint: Text(
        hint,
        style: TMTFontStyles.text(fontSize: TMTFontSize.sp_12, color: AppColor.textColor),
      ),
      items: values
          .map((item) => DropdownMenuItem<ProcessingTimeModel>(
        value: item,
        child: Text(
          item.name,
          style: const TextStyle(
            fontSize: 14,
          ),
        ),
      ))
          .toList(),
      validator: validator,
      onChanged: (value) {
        callback.call(value?.index ?? 0);
      },
      onSaved: (value) {

      },
      buttonStyleData: const ButtonStyleData(
        padding: EdgeInsets.only(right: 18),
      ),
      iconStyleData: const IconStyleData(
        icon: Icon(
          Icons.keyboard_arrow_down_outlined,
          color: AppColor.textColor,
        ),
        iconSize: 24,
      ),
      dropdownStyleData: DropdownStyleData(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
      menuItemStyleData: const MenuItemStyleData(
        padding: EdgeInsets.symmetric(horizontal: 16),
      ),
    );
  }
}