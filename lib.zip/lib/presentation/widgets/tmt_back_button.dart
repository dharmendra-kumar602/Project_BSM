import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class TMTBackButton extends StatelessWidget {

  final Widget child;
  final WillPopCallback? onWillPop;
  final String? route;
  String? arguments;

  TMTBackButton({super.key, required this.child, this.onWillPop, this.route, this.arguments});

  @override
  Widget build(BuildContext context) {
    /// callback for back button press
    return WillPopScope(onWillPop: onWillPop ?? () async {
      /// check if there's any route available to remove
      if (Navigator.canPop(context)) {
        return Future.value(true);
      } else {
        if (arguments != null) {
          /// if arguments aren't null then move to given route with arguments
          Get.offNamed(route!, arguments: arguments);
        } else {
          /// move to given route with out arguments
          Get.offNamed(route!);
        }
        /// return false, because we don't want to remove current route again.
        return Future.value(false);
      }
    }, child: child);
  }
}