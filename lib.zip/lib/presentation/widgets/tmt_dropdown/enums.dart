part of 'tmt_dropdown.dart';

enum DropdownDirection {
  textDirection,
  right,
  left,
}
