import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import '../pages/intro_pages/intro_controller.dart';

class TMTImagesIndicator extends StatelessWidget {
  const TMTImagesIndicator({Key? key, required this.images, required this.introPageController}) : super(key: key);
  final IntroPageController introPageController;
  final List<String> images;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: images.asMap().entries.map((entry) {
        return GestureDetector(
          onTap: () => introPageController.carouselController.animateToPage(entry.key),
          child: Container(
            width: 10.0,
            height: 10.0,
            margin: const EdgeInsets.only(right: 2, left: 2),
            decoration: BoxDecoration(
              border: Border.all(color: AppColor.primary, width: 0.5),
                borderRadius:  const BorderRadius.all(Radius.circular(TMTRadius.r_20)),
                color: introPageController.isCurrentIndex == entry.key
                    ? AppColor.primary
                    : AppColor.neutral_100),
          ),
        );
      }).toList(),
    );
  }
}