import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';

class CommonBottomNavigationBar extends StatelessWidget {

  final int currentSelectedItem;
  final ValueChanged<int>? onTap;

  const CommonBottomNavigationBar({Key? key, required this.currentSelectedItem, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      showSelectedLabels: true,
       showUnselectedLabels: true,
       type: BottomNavigationBarType.fixed,
       selectedLabelStyle: TMTFontStyles.text(
         fontSize: TMTFontSize.sp_9,
         color: AppColor.primaryBG,
         fontWeight: FontWeight.w400,
       ),
       unselectedLabelStyle: TMTFontStyles.text(
         fontSize: TMTFontSize.sp_9,
         color: AppColor.neutral_800,
         fontWeight: FontWeight.w400,
       ),
       selectedItemColor: AppColor.primaryBG,
       iconSize: 25,
       onTap: onTap,
       currentIndex: currentSelectedItem,
       items: [
         BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 0 ? TMTImages.icHomeEnabled : TMTImages.icHome, height: 25, width: 25,), label: "Home",),
         BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 1 ? TMTImages.icGroupEnabled : TMTImages.icGroup, height: 25, width: 25,), label: "Categories"),
         BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 2 ? TMTImages.icHeartEnabled : TMTImages.icHeart, height: 25, width: 25,), label: "Wishlist"),
         BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 3 ? TMTImages.icCartEnabled : TMTImages.icCart, height: 25, width: 25,), label: "Cart",),
         BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 4 ? TMTImages.icUserEnabled : TMTImages.icUser, height: 25, width: 25,), label: "Profile",),
       ],);
  }
}

class CommonSellerBottomNavigationBar extends StatelessWidget {

  final int currentSelectedItem;
  final ValueChanged<int>? onTap;

  const CommonSellerBottomNavigationBar({Key? key, required this.currentSelectedItem, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      showSelectedLabels: true,
      showUnselectedLabels: true,
      type: BottomNavigationBarType.fixed,
      selectedLabelStyle: TMTFontStyles.text(
        fontSize: TMTFontSize.sp_9,
        color: AppColor.primaryBG,
        fontWeight: FontWeight.w400,
      ),
      unselectedLabelStyle: TMTFontStyles.text(
        fontSize: TMTFontSize.sp_9,
        color: AppColor.neutral_800,
        fontWeight: FontWeight.w400,
      ),
      selectedItemColor: AppColor.primaryBG,
      iconSize: 25,
      onTap: onTap,
      currentIndex: currentSelectedItem,
      items: [
        BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 0 ? TMTImages.icHomeEnabled : TMTImages.icHome, height: 25, width: 25,), label: "Home",),
        BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 1 ? TMTImages.icOrdersEnabled : TMTImages.icOrders, height: 25, width: 25,), label: "Orders"),
        BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 2 ? TMTImages.icManageProductsEnabled : TMTImages.icManageProducts, height: 25, width: 25,), label: "Products"),
        BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 3 ? TMTImages.icSupportEnabled : TMTImages.icSupport, height: 25, width: 25,), label: "Support",),
        BottomNavigationBarItem(icon: Image.asset(currentSelectedItem == 4 ? TMTImages.icUserEnabled : TMTImages.icUser, height: 25, width: 25,), label: "Profile",),
      ],);
  }
}