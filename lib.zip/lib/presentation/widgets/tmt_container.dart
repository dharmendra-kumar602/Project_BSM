import 'package:flutter/material.dart';

class TMTContainer extends StatelessWidget {
  final BoxDecoration? decoration;
  final Widget? child;
  final double? height;
  final Color? color;
  final double? width;
  final EdgeInsets? margin;
  final Alignment? align;
  final EdgeInsetsGeometry? padding;

  const TMTContainer({
    Key? key,
    this.child,
    this.decoration,
    this.height,
    this.width,
    this.align,
    this.margin,
    this.padding,
    this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    /// return container widget
    return Container(
      width: width,
      height: height,
      color: color,
      decoration: decoration,
      margin: margin,
      padding: padding,
      child: child,
    );
  }
}
