import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_family.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class TMTTextButton extends StatelessWidget {
  const TMTTextButton(
      {this.onTap,
      required this.buttonTitle,
      this.isDisable = false,
      this.width,
      Key? key,
      this.color,
      this.height,
        this.padding,
        this.margin,
        this.border,
        this.borderRadius,
        this.materialColor,
        this.isForwardIcon,
      this.textStyle})
      : super(key: key);
  final Function()? onTap;
  final String buttonTitle;
  final bool isDisable;
  final Color? color;
  final double? width;
  final double? height;
  final TextStyle? textStyle;
  final Color? materialColor;
  final EdgeInsetsGeometry? padding;
  final BoxBorder? border;
  final BorderRadiusGeometry? borderRadius;
  final EdgeInsetsGeometry? margin;
  final bool? isForwardIcon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? const EdgeInsets.all(1),
      margin: margin ?? const EdgeInsets.all(1),
      width: width,
      decoration: BoxDecoration(
          color: isDisable ? AppColor.neutral_100 : color ?? AppColor.primaryBG,
          border: border ?? Border.all(color: isDisable ? AppColor.neutral_800 : AppColor.neutral_100, width: 0.8),
          borderRadius: borderRadius ?? BorderRadius.circular(
            TMTRadius.r_35,
          )),
      height: height ?? HeightDimension.h_50,
      child: TextButton(
        style: ButtonStyle(
            overlayColor: MaterialStateProperty.all(
                 materialColor)),
        onPressed: isDisable ? null : onTap,
        child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TMTTextWidget(
             title: buttonTitle,
             style: textStyle ?? TMTFontStyles.textTeen(color: isDisable ? AppColor.textColor : Colors.white, fontSize: TMTFontSize.sp_16, fontWeight: FontWeight.w600),),
                const HorizontalSpacing(5),
                Visibility(
                  visible: isForwardIcon ?? false,
                    child: Icon(Icons.arrow_forward, color: isDisable ? AppColor.neutral_500 : Colors.white, size: 25))
              ],
            )),
      ),
    );
  }
}