import 'dart:async';
import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class TMTToast {

  static Timer? _toastTimer;
  static OverlayEntry? _overlayEntry;

  /*
   Method use to show success toast.
   Parameter- BuildContext context,
      String message,{String? title}.
   Return -> No Return type.
  */
  static void showSuccessToast(BuildContext context,
      String message,{String? title}) {
    if (_toastTimer == null || !(_toastTimer?.isActive ?? false)) {
      _overlayEntry = _createOverlayEntry(context, message, true, title: title);
      Overlay.of(context).insert(_overlayEntry!);
      _toastTimer = Timer(const Duration(seconds: 2), () {
        if (_overlayEntry != null) {
          _overlayEntry?.remove();
        }
      });
    }
  }

  /*
   Method use to show error toast.
   Parameter- BuildContext context,
      String message,{String? title}.
   Return -> No Return type.
  */
  static void showErrorToast(BuildContext context,
      String message,{String? title}) {
    if (_toastTimer == null || !(_toastTimer?.isActive ?? false)) {
      _overlayEntry = _createOverlayEntry(context, message, false, title: title);
      Overlay.of(context).insert(_overlayEntry!);
      _toastTimer = Timer(const Duration(seconds: 2), () {
        if (_overlayEntry != null) {
          try {
            _overlayEntry?.remove();
          } catch (e) {

          }
        }
      });
    }
  }

  /*
   Method use to create overlay widget for toast.
   Parameter- BuildContext context, String title, String message, bool isSuccess.
   Return -> OverlayEntry.
  */
  static OverlayEntry _createOverlayEntry(BuildContext context, String message, bool isSuccess, {String? title}) {
    return OverlayEntry(
      builder: (c) => Positioned(
        bottom: HeightDimension.h_20,
        right: WidthDimension.w_25,
        left: WidthDimension.w_25,
        child: Material(
          elevation: 6.0,
          borderRadius: BorderRadius.circular(TMTRadius.r_10),
          child: isSuccess ? _successToast(message, title: title) : _errorToast(message, title: title),
        ),
      ),
    );
  }

  /*
   Method use to create success toast.
   Parameter- BuildContext context, String message, {String? title,}.
   Return -> Widget.
  */
  static Widget _successToast (String message, {String? title,}) {
    return TMTRoundedCornersContainer(
      borderColor: AppColor.greenToast,
      borderWidth: 0.1,
      height: HeightDimension.h_65,
      bgColor: AppColor.greenToast,
      borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_10),),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TMTRoundedCornersContainer(
            height: double.infinity,
            width: WidthDimension.w_18,
            bgColor: AppColor.green,
            borderRadius: const BorderRadius.only(topLeft: Radius.circular(TMTRadius.r_10), bottomLeft: Radius.circular(TMTRadius.r_10)),
          ),
          HorizontalSpacing(WidthDimension.w_15),
          SizedBox(
            height: HeightDimension.h_16,
            width: HeightDimension.h_16,
            child: Image.asset(TMTImages.icToastSuccess),
          ),
          HorizontalSpacing(WidthDimension.w_15),
          SizedBox(
            width: WidthDimension.w_200,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                VerticalSpacing(HeightDimension.h_5),
                TMTTextWidget(title: title ?? "Success", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_14,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ),),
                VerticalSpacing(HeightDimension.h_2),
                TMTTextWidget(title: message, style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_10,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w400,
                ), maxLines: 2,),
                VerticalSpacing(HeightDimension.h_5),
              ],
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: (){
             _overlayEntry?.remove();
            },
            child: SizedBox(
              height: HeightDimension.h_12,
              width: HeightDimension.h_12,
              child: Image.asset(TMTImages.icSuccessToastCancel),
            ),
          ),
          HorizontalSpacing(WidthDimension.w_15),
        ],
      ),
    );
  }

  /*
   Method use to create error toast.
   Parameter- BuildContext context, String message, {String? title,}.
   Return -> Widget.
  */
  static Widget _errorToast (String message, {String? title,}) {
    return TMTRoundedCornersContainer(
      borderColor: AppColor.primaryToast,
      borderWidth: 0.1,
      height: HeightDimension.h_65,
      bgColor: AppColor.primaryToast,
      borderRadius: const BorderRadius.all(Radius.circular(TMTRadius.r_10),),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TMTRoundedCornersContainer(
            height: double.infinity,
            width: WidthDimension.w_18,
            bgColor: AppColor.primaryBG,
            borderRadius: const BorderRadius.only(topLeft: Radius.circular(TMTRadius.r_10), bottomLeft: Radius.circular(TMTRadius.r_10)),
          ),
          HorizontalSpacing(WidthDimension.w_15),
          SizedBox(
            height: HeightDimension.h_16,
            width: HeightDimension.h_16,
            child: Image.asset(TMTImages.icToastError),
          ),
          HorizontalSpacing(WidthDimension.w_15),
          SizedBox(
            width: WidthDimension.w_200,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                VerticalSpacing(HeightDimension.h_5),
                TMTTextWidget(title: title ?? "Error", style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_14,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w500,
                ), maxLines: 1,),
                VerticalSpacing(HeightDimension.h_2),
                TMTTextWidget(title: message, style: TMTFontStyles.text(
                  fontSize: TMTFontSize.sp_10,
                  color: AppColor.neutral_800,
                  fontWeight: FontWeight.w400,
                ), maxLines: 2,),
                VerticalSpacing(HeightDimension.h_5),
              ],
            ), 
          ),
          const Spacer(),
          GestureDetector(
            onTap: (){
              try {
                _overlayEntry?.remove();
              } catch (e) {

              }
            },
            child: SizedBox(
              height: HeightDimension.h_12,
              width: HeightDimension.h_12,
              child: Image.asset(TMTImages.icErrorToastCancel),
            ),
          ),
          HorizontalSpacing(WidthDimension.w_15),
        ],
      ),
    );
  }
}