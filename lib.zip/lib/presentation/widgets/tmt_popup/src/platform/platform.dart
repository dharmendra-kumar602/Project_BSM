export 'dart:io' if (dart.library.html) 'web.dart';
