class Platform {
  static final bool isIOS = false;
}
