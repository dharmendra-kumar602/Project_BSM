import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/pages/intro_pages/intro_controller.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/utils/tmt_webview.dart';
import 'package:take_my_tack/presentation/widgets/tmt_container.dart';
import 'package:take_my_tack/presentation/widgets/tmt_spacing.dart';
import 'package:take_my_tack/presentation/widgets/tmt_text.dart';

class TMTCarouselTextSlider extends StatelessWidget {
  const TMTCarouselTextSlider({Key? key, required this.title, required this.description, required this.introPageController, required this.images}) : super(key: key);
  final IntroPageController introPageController;
  final List<String> title;
  final List<String> description;
  final List<String> images;

  @override
  Widget build(BuildContext context) {
    final List<Widget> imageSliders = [];
    for (int i=0; i < title.length; i++) {
      imageSliders.add(Container(
        margin: EdgeInsets.only(left: WidthDimension.w_15, right: WidthDimension.w_15),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TMTContainer(
                height: SizeConfig.safeBlockVertical * 34,
                  margin: EdgeInsets.only(top: HeightDimension.h_50, left: WidthDimension.w_50, right: WidthDimension.w_50),
                  width: double.infinity,
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(25), bottomRight: Radius.circular(25)),
                      image: DecorationImage(
                          fit: BoxFit.fill,
                          image: AssetImage(images[i]))
                  )),
              VerticalSpacing(HeightDimension.h_35),
              TMTTextWidget(title: title[i], textAlign: TextAlign.center, style: TMTFontStyles.textTeen(fontSize: TMTFontSize.sp_25, fontWeight: FontWeight.w700, color: AppColor.neutral_800), maxLines: 3),
              VerticalSpacing(HeightDimension.h_5),
              description[i].contains("www.tacktalk.co.uk") ?  RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  style: TMTFontStyles.text(fontSize: TMTFontSize.sp_15, fontWeight: FontWeight.w400, color: AppColor.neutral_800),
                  children: <TextSpan>[
                    const TextSpan(text: 'Chat with fellow horse lovers in the chat forum: ask questions, start topics and be part of the trending conversations. Visit '),
                    TextSpan(
                        text: 'www.tacktalk.co.uk',
                        style: TMTFontStyles.text(fontSize: TMTFontSize.sp_15, fontWeight: FontWeight.w400, color: AppColor.neutral_800, textDecoration: TextDecoration.underline),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () {
                            Navigator.push(context, MaterialPageRoute(builder: (c){
                              return TMTWebView(url: "http://tacktalk.co.uk/");
                            }));
                          }),
                    const TextSpan(text: ' for a site full of content, articles and our blogs!'),
                  ],
                ),
              ) : TMTTextWidget(title: description[i], textAlign: TextAlign.center, style: TMTFontStyles.text(fontSize: TMTFontSize.sp_15, fontWeight: FontWeight.w400, color: AppColor.neutral_800), maxLines: 10),
            ],
          ),
        ),
      ));
    }
    return CarouselSlider(
      items: imageSliders,
      carouselController: introPageController.carouselController,
      options: CarouselOptions(
          autoPlayAnimationDuration: const Duration(milliseconds: 1000),
          autoPlay: false,
          viewportFraction: 1.0,
          height: SizeConfig.safeBlockVertical * 71,
          enlargeCenterPage: false,
          onPageChanged: (index, reason) {
            introPageController.changeCurrentIndexValue(index);
          }),
    );
  }
}