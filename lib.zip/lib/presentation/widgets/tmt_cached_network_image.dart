import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/widgets/tmt_rounded_container.dart';

class TMTCachedImage {
  /*
   Method use get cached network image widget.
   Parameter- String imageUrl.
   Return -> Widget.
  */
  static Widget networkImage(String imageUrl, {BoxFit? fit}) {
    return CachedNetworkImage(
      imageUrl: imageUrl,
      fit: fit,
      progressIndicatorBuilder: (context, url, downloadProgress) => Center(
        child: SizedBox(
            height: HeightDimension.h_10,
            width: HeightDimension.h_10,
            child: CircularProgressIndicator(
              value: downloadProgress.progress,
              strokeWidth: 1,
            )),
      ),
      errorWidget: (context, url, error) => TMTRoundedCornersContainer(
        bgColor: AppColor.neutral_400,
        height: HeightDimension.h_10,
        width: HeightDimension.h_10,

      ),
    );
  }
}
