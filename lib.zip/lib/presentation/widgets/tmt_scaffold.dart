import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';

class TMTScaffold extends StatelessWidget {
  final Widget body;
  final Widget bottomNavigationBar;
  final Widget? floatingActionButton;
  final PreferredSizeWidget? appBar;
  final Color? backgroundColor;
  final bool isExtendBehindAppbar;
  final bool isResizeToAvoidBottomInset;

  const TMTScaffold(
      {Key? key,
      this.appBar,
      this.backgroundColor = AppColor.white,
      this.floatingActionButton,
      required this.body,
      this.isResizeToAvoidBottomInset = true,
      this.bottomNavigationBar = const SizedBox(),
        this.isExtendBehindAppbar = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    /// return scaffold widget
    return Scaffold(
      resizeToAvoidBottomInset: isResizeToAvoidBottomInset,
      extendBodyBehindAppBar: isExtendBehindAppbar,
      extendBody: true,
      floatingActionButton: floatingActionButton,
      appBar: appBar,
      backgroundColor: backgroundColor,
      body: body,
      bottomNavigationBar: bottomNavigationBar,
    );
  }
}