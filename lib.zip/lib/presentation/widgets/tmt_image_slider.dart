import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/pages/intro_pages/intro_controller.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/widgets/tmt_container.dart';

class CarouselImagesSlider extends StatelessWidget {
  const CarouselImagesSlider({Key? key, required this.images, required this.introPageController}) : super(key: key);
  final IntroPageController introPageController;
  final List<String> images;

  @override
  Widget build(BuildContext context) {
    final List<Widget> imageSliders = images.map((item) =>
        TMTContainer(
          margin: EdgeInsets.only(top: HeightDimension.h_80, left: WidthDimension.w_60, right: WidthDimension.w_60),
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(25), bottomRight: Radius.circular(25)),
            image: DecorationImage(
                fit: BoxFit.fill,
                image: AssetImage(item))
          ))).toList();
       return CarouselSlider(
       items: imageSliders,
       carouselController: introPageController.carouselController,
       options: CarouselOptions(
           autoPlayAnimationDuration: const Duration(milliseconds: 1000),
           height: MediaQuery.of(context).size.height/2.0,
           autoPlay: false,
           scrollPhysics: const NeverScrollableScrollPhysics(),
           enlargeCenterPage: false,
           viewportFraction: 1.0,
           onPageChanged: (index, reason) {
             introPageController.changeCurrentIndexValue(index);
           }),
     );
  }
}
