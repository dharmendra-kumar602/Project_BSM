import 'package:flutter/material.dart';

class TMTRoundedContainer extends StatelessWidget {

  final Widget? child;
  final double? height;
  final double? width;
  final EdgeInsets? margin;
  final Color? bgColor;
  final Alignment? align;
  final EdgeInsetsGeometry? padding;

  const TMTRoundedContainer({
    Key? key,
    this.child,
    this.height,
    this.width,
    this.align,
    this.bgColor,
    this.margin,
    this.padding,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: bgColor,
        border: Border.all(color: Colors.grey, width: 0.5)
      ),
      margin: margin,
      padding: padding,
      child: child,
    );
  }
}

class TMTRoundedCornersContainer extends StatelessWidget {

  final Widget? child;
  final double? height;
  final double? width;
  final EdgeInsets? margin;
  final Color? bgColor;
  final Color? borderColor;
  final Alignment? align;
  final EdgeInsetsGeometry? padding;
  final BorderRadius? borderRadius;
  final List<BoxShadow>? boxShadow;
  final double? borderWidth;

  const TMTRoundedCornersContainer({
    Key? key,
    this.child,
    this.height,
    this.width,
    this.align,
    this.bgColor,
    this.borderColor,
    this.margin,
    this.padding,
    this.borderRadius,
    this.boxShadow,
    this.borderWidth
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        boxShadow: boxShadow,
        color: bgColor,
          border: Border.all(
            width: borderWidth ?? 1.0,
            color: borderColor ?? Colors.transparent,
          ),
          borderRadius: borderRadius ?? const BorderRadius.all(Radius.circular(20))
      ),
      margin: margin,
      padding: padding,
      child: child,
    );
  }
}

class TMTCustomBorderContainer extends StatelessWidget {

  final Widget? child;
  final double? height;
  final double? width;
  final EdgeInsets? margin;
  final Color? bgColor;
  final Color? borderColor;
  final Alignment? align;
  final EdgeInsetsGeometry? padding;
  final BoxBorder? border;
  final BorderRadius? borderRadius;
  final List<BoxShadow>? boxShadow;

  const TMTCustomBorderContainer({
    Key? key,
    this.child,
    this.height,
    this.width,
    this.align,
    this.bgColor,
    this.borderColor,
    this.margin,
    this.padding,
    this.border,
    this.borderRadius,
    this.boxShadow
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
          boxShadow: boxShadow,
          color: bgColor,
          border: border,
          borderRadius: borderRadius
      ),
      margin: margin,
      padding: padding,
      child: child,
    );
  }
}
