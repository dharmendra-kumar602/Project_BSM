import 'package:flutter/material.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';

// Custom Button Widget for Report details, Forgot password(reset button)
class TMTTextWidget extends StatelessWidget {
  final String title;
  final TextStyle? style;
  final TextAlign textAlign;
  final int? maxLines;
  final TextDirection? textDirection;
  final Locale? locale;
  final bool? softWrap;
  final TextOverflow? overflow;
  final TextWidthBasis? textWidthBasis;
  final TextHeightBehavior? textHeightBehavior;

  const TMTTextWidget(
      {Key? key,
      required this.title,
      this.style,
      this.textAlign = TextAlign.start,
      this.maxLines = 3,
      this.locale,
      this.overflow,
      this.softWrap,
      this.textDirection,
      this.textHeightBehavior,
      this.textWidthBasis})
      : super(key: key);

  /*
  - Method use to build screen and its a screens life cycle method.
  - Parameter -> @BuildContext - Current widget context.
  - Return -> Return a widget.
  */
  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: style ?? TMTFontStyles.text(),
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow ?? TextOverflow.ellipsis,
      softWrap: softWrap,
    );
  }
}