import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:take_my_tack/presentation/resources/app_color.dart';
import 'package:take_my_tack/presentation/resources/images.dart';
import 'package:take_my_tack/presentation/widgets/tmt_cached_network_image.dart';

class TMTFullScreenImage extends StatelessWidget {
  final String tag;
  final String img;

  const TMTFullScreenImage({super.key, required this.tag, required this.img});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: (){
          Navigator.pop(context);
        },
        child: Center(
          child: DSCachedNetworkImage(
            url: img,
            fit: BoxFit.fitWidth,
          ),
        ),
      ),
    );
  }
}

class DSCachedNetworkImage extends StatelessWidget {
  const DSCachedNetworkImage({
    Key? key,
    required this.url,
    this.fit,
    this.height = 50,
    this.width = 50
  }) : super(key: key);

  final String url;
  final BoxFit? fit;
  final double? height;
  final double? width;

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: url,
      fit: fit,
      errorWidget: (context, text, a) => Image.asset(TMTImages.icToastError,fit: BoxFit.cover),
      progressIndicatorBuilder: (context, url, downloadProgress) =>
          Center(
            child: SizedBox(
                height: height,
                width: width,
                child: CircularProgressIndicator(color: AppColor.lightGrey,strokeWidth: 2,
                    value: downloadProgress.progress)),
          ),
    );
  }
}
