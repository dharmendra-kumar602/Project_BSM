import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:take_my_tack/presentation/resources/dimension.dart';
import 'package:take_my_tack/presentation/resources/font_size.dart';
import 'package:take_my_tack/presentation/resources/font_style.dart';
import 'package:take_my_tack/presentation/utils/custom_outline_input_border.dart';
import '../resources/app_color.dart';

class TMTTextField extends StatelessWidget {
  TMTTextField({
    this.hintText,
    this.validator,
    this.errorText,
    this.prefixIcon,
    this.suffixIcon,
    this.keyboardType,
    this.isSecure = false,
    this.isRequired = false,
    this.onChanged,
    this.enableInteractiveSelection = true,
    this.onTap,
    this.isReadOnly = false,
    this.inputFormatters,
    this.prefixText,
    this.enabled,
    this.textCapitalization = TextCapitalization.none,
    this.textInputAction = TextInputAction.next,
    this.onFieldSubmitted,
    this.focusNode,
    this.padding,
    this.maxLines = 1,
    this.maxLength,
    this.fillColor = AppColor.white,
    this.suffixIconConstraints,
    this.style,
    this.errorStyle,
    this.errorBorderColor,
    this.focusedErrorBorderColor,
    this.focusedBorderColor,
    this.enabledBorderColor,
    this.prefix,
    this.suffix,
    this.contentPadding = const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 8),
    this.floatingLabelBehavior,
    Key? key,
    required TextEditingController controller,
  })  : _emailTextEditingController = controller,
        super(key: key);
  final bool enableInteractiveSelection;
  final TextEditingController _emailTextEditingController;
  final String? hintText;
  final String? errorText;
  final String? Function(String?)? validator;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final bool isSecure;
  final bool isRequired;
  final TextInputType? keyboardType;
  final void Function(String)? onChanged;
  final void Function()? onTap;
  final bool isReadOnly;
  final String? prefixText;
  final bool? enabled;
  final List<TextInputFormatter>? inputFormatters;
  final FocusNode? focusNode;
  final int? maxLines;
  final int? maxLength;
  final Color? fillColor;
  final Color? focusedErrorBorderColor;
  final Color? focusedBorderColor;
  final Color? errorBorderColor;
  final Color? enabledBorderColor;
  final TextStyle? errorStyle;
  final Widget? prefix;
  final Widget? suffix;
  final EdgeInsetsGeometry? padding;
  final BoxConstraints? suffixIconConstraints;
  TextCapitalization textCapitalization;
  TextInputAction? textInputAction;
  void Function(String)? onFieldSubmitted;
  TextStyle? style;
  EdgeInsetsGeometry contentPadding;
  final FloatingLabelBehavior? floatingLabelBehavior;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ?? const EdgeInsets.all(5),
      child: TextFormField(
        autocorrect: false,
        enableSuggestions: false,
        obscuringCharacter:'*',
        style: style ?? TMTFontStyles.text(color: AppColor.neutral_800, fontSize: TMTFontSize.sp_13, fontWeight: FontWeight.w500),
        maxLines: maxLines,
        maxLength: maxLength,
        focusNode: focusNode,
        onFieldSubmitted: onFieldSubmitted,
        textInputAction: textInputAction,
        enabled: enabled,
        inputFormatters: inputFormatters,
        textCapitalization: textCapitalization,
        onChanged: onChanged,
        onTap: onTap,
        readOnly: isReadOnly,
        enableInteractiveSelection: enableInteractiveSelection,
        keyboardType: keyboardType,
        controller: _emailTextEditingController,
        cursorColor: AppColor.neutral_800,
        validator: validator,
        obscureText: isSecure,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        decoration: InputDecoration(
          focusedErrorBorder:  CustomOutlineInputBorder(
              borderSide: BorderSide(color: focusedErrorBorderColor ?? AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
          errorBorder:  CustomOutlineInputBorder(
              borderSide:  BorderSide(color: errorBorderColor ?? AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
          enabledBorder: CustomOutlineInputBorder(
              borderSide: BorderSide(color: enabledBorderColor ?? AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
          floatingLabelBehavior: floatingLabelBehavior ?? FloatingLabelBehavior.auto,
          focusedBorder: CustomOutlineInputBorder(
              borderSide: BorderSide(color: focusedBorderColor ?? AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
          prefixText: prefixText,
          contentPadding: contentPadding,
          border: CustomOutlineInputBorder(
              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
          ),
          suffixIcon: suffixIcon,
          prefixIcon: prefixIcon,
          prefix: prefix,
          suffix: suffix,
          errorText: errorText,
          errorStyle: errorStyle,
          hintText: hintText,
          errorMaxLines: 3,
          filled: true,
          fillColor: fillColor,
          labelText: hintText,
          labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
        ),
      ),
    );
  }
}

class TMTTextNoHintField extends StatelessWidget {
  TMTTextNoHintField({
    this.validator,
    this.errorText,
    this.prefixIcon,
    this.suffixIcon,
    this.keyboardType,
    this.isSecure = false,
    this.isRequired = false,
    this.onChanged,
    this.enableInteractiveSelection = true,
    this.onTap,
    this.isReadOnly = false,
    this.inputFormatters,
    this.prefixText,
    this.enabled,
    this.textCapitalization = TextCapitalization.none,
    this.textInputAction = TextInputAction.next,
    this.onFieldSubmitted,
    this.focusNode,
    this.padding,
    this.maxLines = 1,
    this.maxLength,
    this.fillColor = AppColor.white,
    this.suffixIconConstraints,
    this.style,
    this.errorStyle,
    this.errorBorderColor,
    this.focusedErrorBorderColor,
    this.focusedBorderColor,
    this.enabledBorderColor,
    this.prefix,
    this.suffix,
    this.contentPadding = const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 8),
    this.floatingLabelBehavior,
    Key? key,
    required TextEditingController controller,
  })  : _emailTextEditingController = controller,
        super(key: key);
  final bool enableInteractiveSelection;
  final TextEditingController _emailTextEditingController;
  final String? errorText;
  final String? Function(String?)? validator;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final bool isSecure;
  final bool isRequired;
  final TextInputType? keyboardType;
  final void Function(String)? onChanged;
  final void Function()? onTap;
  final bool isReadOnly;
  final String? prefixText;
  final bool? enabled;
  final List<TextInputFormatter>? inputFormatters;
  final FocusNode? focusNode;
  final int? maxLines;
  final int? maxLength;
  final Color? fillColor;
  final Color? focusedErrorBorderColor;
  final Color? focusedBorderColor;
  final Color? errorBorderColor;
  final Color? enabledBorderColor;
  final TextStyle? errorStyle;
  final Widget? prefix;
  final Widget? suffix;
  final EdgeInsetsGeometry? padding;
  final BoxConstraints? suffixIconConstraints;
  TextCapitalization textCapitalization;
  TextInputAction? textInputAction;
  void Function(String)? onFieldSubmitted;
  TextStyle? style;
  EdgeInsetsGeometry contentPadding;
  final FloatingLabelBehavior? floatingLabelBehavior;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      autocorrect: false,
      enableSuggestions: false,
      obscuringCharacter:'*',
      style: style ?? TMTFontStyles.text(color: AppColor.neutral_800, fontSize: TMTFontSize.sp_13, fontWeight: FontWeight.w500),
      maxLines: maxLines,
      maxLength: maxLength,
      focusNode: focusNode,
      onFieldSubmitted: onFieldSubmitted,
      textInputAction: textInputAction,
      enabled: enabled,
      inputFormatters: inputFormatters,
      textCapitalization: textCapitalization,
      onChanged: onChanged,
      onTap: onTap,
      readOnly: isReadOnly,
      enableInteractiveSelection: enableInteractiveSelection,
      keyboardType: keyboardType,
      controller: _emailTextEditingController,
      cursorColor: AppColor.neutral_800,
      validator: validator,
      obscureText: isSecure,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      decoration: InputDecoration(
          focusedErrorBorder:  CustomOutlineInputBorder(
              borderSide: const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
          errorBorder:  CustomOutlineInputBorder(
              borderSide:  const BorderSide(color: AppColor.primary, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
          enabledBorder: CustomOutlineInputBorder(
              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
          floatingLabelBehavior: FloatingLabelBehavior.auto,
          focusedBorder: CustomOutlineInputBorder(
              borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15)),
          contentPadding: const EdgeInsets.only(left: 18, right: 18, top: 10, bottom: 15),
          border: CustomOutlineInputBorder(
            borderSide: const BorderSide(color: AppColor.borderColor, width: 0.5), borderRadius: BorderRadius.circular(TMTRadius.r_15),
          ),
          errorMaxLines: 3,
          filled: false,
          hintText: "Use this space to add information about yourself, such as your favourite horse, your riding discipline, your favourite tack etc.",
          hintStyle: TMTFontStyles.text(color: AppColor.textColor.withOpacity(0.7), fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500),
          labelStyle: TMTFontStyles.text(color: AppColor.textColor, fontSize: TMTFontSize.sp_12, fontWeight: FontWeight.w500)
      ),
    );
  }
}